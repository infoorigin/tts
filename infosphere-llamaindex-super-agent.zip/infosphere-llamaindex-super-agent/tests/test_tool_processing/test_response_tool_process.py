import pytest
from pathlib import Path
from typing import Any, Dict, List
from app.meta_agent.agent import Agent, LoopData
from app.meta_agent.initialize import initialize_agent
from llama_index.core.llms import ChatMessage, MessageRole, TextBlock
import os

current_dir = os.path.dirname(os.path.abspath(__file__))
os.environ["SETTINGS_FILE_PATH"] = os.path.join(current_dir,"..\config\settings.json")

@pytest.mark.asyncio
async def test_tool_processing():

    # Agent Initialization
    config = initialize_agent()
    agent = Agent(config=config, number=0)
    assert agent is not None, "Failed to initialize Agent"


    # Setup Loop Data    
    loop_data = LoopData()
    agent.loop_data = loop_data

    
    # Defining Response of LLM    
    response = '{"thoughts": ["The user is asking for my name again, I should reiterate my name clearly.", "It\'s important to maintain a friendly tone while providing the information."], "headline": "Responding to name inquiry", "tool_name": "response", "tool_args": {"text": "**My name is Savant Meta Agent! 🤖** I\'m here to assist you with any questions or tasks you have. What would you like to know?"}}'

    
    # Response Tool Processing
    tool_response = await agent.process_tools(response)
    print(f'Tool Response: {tool_response}')


    # Response Tool Response Validation
    assert isinstance(tool_response, str)
    assert "My name is Savant Meta Agent" in tool_response