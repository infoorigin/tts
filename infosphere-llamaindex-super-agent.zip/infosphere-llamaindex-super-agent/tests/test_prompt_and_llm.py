import pytest
import json
from pathlib import Path
from typing import Any, Dict

from app.meta_agent.agent import Agent, LoopData, UserMessage
from app.meta_agent.initialize import initialize_agent
from llama_index.core.llms import ChatMessage  # ensure correct import
import os

# ensure config points to your test settings
os.environ["SETTINGS_FILE_PATH"] = str(Path(__file__).parent / "config" / "settings.json")

FINAL_PROMPT_DIR = Path(r"D:\\infosphere-llamaindex-super-agent\\final_prompt")

@pytest.mark.asyncio
async def test_prepare_prompt_and_call_llm():

    # ---- Deleting the prompt files ----
    if FINAL_PROMPT_DIR.exists():
        for file in FINAL_PROMPT_DIR.glob("*.txt"):
            try:
                file.unlink()  # deletes the file
                print(f"Deleted: {file}")
            except Exception as e:
                print(f"Failed to delete {file}: {e}")

    """
    End-to-end test:
    1. Initializes an Agent with a test configuration.
    2. Loads conversation history from a JSON file.
    3. Prepares a full LLM prompt.
    4. Sends it to the real LLM.
    5. Saves LLM response into a file.
    """

    # --- Setup ---
    config = initialize_agent()
    agent = Agent(config=config, number=0)
    assert agent is not None, "Failed to initialize Agent"

    loop_data = LoopData()
    agent.loop_data = loop_data

    # Load test conversation history
    history_path = Path("tests/test_history.json")
    assert history_path.exists(), f"History file not found at {history_path}"

    try:
        loop_data.history_output = json.loads(history_path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as e:
        pytest.fail(f"Failed to parse history JSON: {e}")

    # --- Inject messages into agent ---
    def push_message_to_agent(agent: Agent, message: Dict[str, Any]) -> None:
        ai_flag = bool(message.get("ai", False))
        content = message.get("content", "")

        if isinstance(content, dict) and not ai_flag and "user_message" in content:
            agent.hist_add_user_message(UserMessage(content["user_message"]))
        else:
            msg_text = json.dumps(content, ensure_ascii=False) if isinstance(content, dict) else content
            if ai_flag:
                agent.hist_add_ai_response(msg_text)
            else:
                agent.hist_add_user_message(UserMessage(msg_text))

    for msg in loop_data.history_output:
        push_message_to_agent(agent, msg)

    # --- Act 1: Prepare full prompt ---
    full_prompt = await agent.prepare_prompt(agent.loop_data)

    # Save prepared prompt to file for inspection
    prompt_file = Path("tests/prepare_prompt_result.txt")
    with prompt_file.open("w", encoding="utf-8") as f:
        for i, msg in enumerate(full_prompt, start=1):
            role = getattr(msg, "role", "unknown")
            content = getattr(msg, "content", "")
            f.write(f"{i}. ROLE={role} | CONTENT={content}\n\n")

    # --- Act 2: Call the real LLM with the prepared prompt ---
    chat_messages = [
        ChatMessage(role=m.role, content=m.content)
        for m in full_prompt
    ]

    response, reasoning = await agent.call_chat_model(messages=chat_messages)

    # --- Save LLM response ---
    response_file = Path("tests/llm_response_output.txt")
    response_file.write_text(response, encoding="utf-8")

    print("\n--- LLM Response saved to tests/llm_response_output.txt ---\n", response)

   