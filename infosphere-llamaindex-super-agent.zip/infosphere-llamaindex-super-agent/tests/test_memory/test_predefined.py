import os
import pytest
from app.meta_agent.agent import UserMessage

KNOWLEDGE_DIR = os.path.join(
    os.path.dirname(__file__),
    "..", "..", "knowledge", "custom", "facts"
)

# BYEROZIL_CONTENT = """
# Byerozil is an experimental nootropic compound developed in 2018 by Arcadia Biopharma.
# It is primarily studied for its potential to enhance short-term memory and improve focus in patients with mild cognitive decline.
# The drug works by modulating acetylcholine receptor activity in the prefrontal cortex.
# Recommended investigational dose: 25 mg once daily, taken in the morning.
# Exceeding 50 mg per day has been linked to increased heart rate, dizziness, and insomnia.
# Byerozil has not yet been approved by the FDA or EMA and is currently in Phase II clinical trials.
# Patients with a history of epilepsy are advised not to take Byerozil due to possible seizure risk.
# """

@pytest.mark.asyncio
async def test_predefined(agent_with_test_settings):
    """Ensure agent retrieves correct information from knowledge base."""

    # 1) Create the temporary Byerozil knowledge file
    # os.makedirs(KNOWLEDGE_DIR, exist_ok=True)
    # test_file_path = os.path.join(KNOWLEDGE_DIR, "byerozil.txt")
    # with open(test_file_path, "w", encoding="utf-8") as f:
    #     f.write(BYEROZIL_CONTENT)

    # try:
        # 2) Run the test with the knowledge present
    agent = agent_with_test_settings
    agent.hist_add_user_message(UserMessage(message="What do you know about elexo drug?"))
    response = await agent.run_message_workflow()

    # assert "arcadia biopharma" in response.lower()

    # finally:
    #     # 3) Cleanup: remove the test file
    #     if os.path.exists(test_file_path):
    #         os.remove(test_file_path)
