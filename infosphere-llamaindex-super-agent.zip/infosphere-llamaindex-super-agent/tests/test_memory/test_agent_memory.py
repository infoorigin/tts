import pytest
from app.meta_agent.agent import UserMessage


@pytest.mark.asyncio
async def test_research_analyst_knowledge_recall(agent_with_test_settings):
    """
    Ensure the Research Analyst agent retrieves relevant content from its
    embedded knowledge_base when prompted with a research-type question.
    """

    # Configure the agent fixture (profile already set via settings.json)
    agent = agent_with_test_settings

    # Send a query that should activate the research_analyst agent
    agent.hist_add_user_message(
        # UserMessage(message="Which territories or accounts show low engagement despite high call frequency?")
        UserMessage(message="can you share the analysis of performance on elexo drug?")
    )

    response = await agent.run_message_workflow()

    # Convert response to lowercase for easier assertions
    text = str(response).lower()

    # Assert that content from Analyst Knowledge Pack appears in response
    # (the pack includes keywords like 'elexo', 'crm systems', 'payer coverage')
    # assert "elexo" in text or "crm" in text or "payer" in text or "analyst agent" in text, \
    #     "Expected research_analyst knowledge not found in recall response."
