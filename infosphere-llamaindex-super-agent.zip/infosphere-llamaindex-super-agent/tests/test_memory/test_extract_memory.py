import pytest
from app.meta_agent.utils.memory import Memory
from app.meta_agent.executors.message_workflow_end._a_memorize_facts import MemorizeMemories

@pytest.mark.asyncio
async def test_memorize_creates_memories(agent_with_test_settings):
    """MemorizeMemories task extracts facts from a conversation and stores them in memory."""

    mem = await Memory.get(agent_with_test_settings)

    # Create the memorize executor with the agent
    memorizer = MemorizeMemories(agent=agent_with_test_settings)

    agent_with_test_settings.hist_add_message(False, "I love playing badminton every weekend.")
    agent_with_test_settings.hist_add_ai_response("That’s awesome! I’ll remember badminton is your weekend hobby.")

    task = await memorizer.execute()
    await task  

    # Fetch docs from mem
    all_docs = mem.get_all_docs()
    texts = [doc.text for doc in all_docs.values()]

    # Assert at least one memory was saved and contains expected facts
    assert any("badminton" in t for t in texts)
    assert any("weekend" in t for t in texts)
