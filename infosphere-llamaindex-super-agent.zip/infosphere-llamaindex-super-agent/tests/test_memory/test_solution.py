import os
import pytest
from app.meta_agent.agent import UserMessage


@pytest.mark.asyncio
async def test_predefined(agent_with_test_settings):
    """Ensure agent retrieves correct information from knowledge base."""


    # 2) Run the test with the knowledge present
    agent = agent_with_test_settings
    agent.hist_add_user_message(UserMessage(message="First purchase trigger is reported for account Yale New Haven at region north-east "))
    response = await agent.run_message_workflow()

    # assert "purchase" in response.lower()
