import pytest
import re
from app.meta_agent.agent import UserMessage

from app.meta_agent.utils.agent_activity_dispatcher import LogDispatcher
from app.meta_agent.utils.agent_activity_storage import LocalMemoryLogStorage
    # initialize LogDispatcher with local memory storage (good for notebooks)


@pytest.mark.asyncio
async def test_user_personalization_with_memory(agent_with_test_settings):
    """Agent learns user facts and uses them to personalize responses."""

    LogDispatcher.initialize(LocalMemoryLogStorage())
    print("LogDispatcher initialized with LocalMemoryLogStorage")

    agent = agent_with_test_settings

    agent.hist_add_user_message(UserMessage(message="First purchase trigger is reported for account Yale New Haven at region north-east "))
    await agent.run_message_workflow()

    agent.hist_add_user_message(UserMessage(message="An adverse event has been reported."))
    await agent.run_message_workflow()

    agent.hist_add_user_message(UserMessage(message="MUN Reported"))
    await agent.run_message_workflow()