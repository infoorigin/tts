import pytest
from app.meta_agent.utils.memory import Memory
from llama_index.core import Document

from app.meta_agent.utils.memory_consolidation import (create_memory_consolidator,ConsolidationAction)
DEFAULT_MEMORY_THRESHOLD = 0.7


@pytest.mark.asyncio
async def test_insert_and_get_document(agent_with_test_settings):
    consolidator = create_memory_consolidator(
                        agent_with_test_settings,
                        similarity_threshold=DEFAULT_MEMORY_THRESHOLD,  # More permissive for discovery
                        max_similar_memories=8,
                        max_llm_context_memories=4
                    )
    result_obj = await consolidator.process_new_memory(
                        new_memory="new consolidated memory",
                        area=Memory.Area.FACTS.value,
                        metadata={"area": Memory.Area.FACTS.value}
                    )
    assert result_obj is not None


@pytest.mark.asyncio
async def test_consolidation_update(agent_with_test_settings):
    """Update an existing fact when new information refines the same detail."""
    mem = await Memory.get(agent_with_test_settings)

    # pre-populating memory
    await mem.insert_text("Alice is a backend engineer working on X", {"area": Memory.Area.FACTS.value})

    consolidator = create_memory_consolidator(agent_with_test_settings)
    
    res = await consolidator.process_new_memory(
        new_memory="Alice got promoted to senior backend engineer",
        area=Memory.Area.FACTS.value,
        metadata={"area": Memory.Area.FACTS.value}
    )

    assert res["success"]

    all_docs = mem.get_all_docs()
    actions = [d.metadata.get("consolidation_action") for d in all_docs.values()]

    assert ConsolidationAction.UPDATE.value in actions


@pytest.mark.asyncio
async def test_consolidation_replace(agent_with_test_settings):
    """Replace an outdated fact when the new memory provides the same detail."""
    mem = await Memory.get(agent_with_test_settings)

    # pre-populating memory
    await mem.insert_text("Alice likes to play cricket", {"area": Memory.Area.FACTS.value})
    consolidator = create_memory_consolidator(agent_with_test_settings)
    
    res = await consolidator.process_new_memory(
        new_memory="Alice likes to play cricket",
        area=Memory.Area.FACTS.value,
        metadata={"area": Memory.Area.FACTS.value}
    )

    assert res["success"]

    all_docs = mem.get_all_docs()
    actions = [d.metadata.get("consolidation_action") for d in all_docs.values()]
    
    assert (
        ConsolidationAction.REPLACE.value in actions
        or "keep_separate_safety" in actions
    )


@pytest.mark.asyncio
async def test_consolidation_keep_seperate(agent_with_test_settings):
    """Keep a new fact separate when it describes a different aspect of Alice’s life."""
    mem = await Memory.get(agent_with_test_settings)

    # pre-populating memory
    await mem.insert_text("Alice likes to eat hot-pancakes everyday", {"area": Memory.Area.FACTS.value})
    consolidator = create_memory_consolidator(agent_with_test_settings)
    
    res = await consolidator.process_new_memory(
        new_memory="Alice likes to drink cold coffee on weekends",
        area=Memory.Area.FACTS.value,
        metadata={"area": Memory.Area.FACTS.value}
    )

    assert res["success"]

    all_docs = mem.get_all_docs()
    actions = [d.metadata.get("consolidation_action") for d in all_docs.values()]

    assert ConsolidationAction.KEEP_SEPARATE.value in actions


@pytest.mark.asyncio
async def test_consolidation_merge(agent_with_test_settings):
    """Merge duplicate or near-duplicate facts into a single consolidated memory."""
    mem = await Memory.get(agent_with_test_settings)

    # pre-populating memory
    await mem.insert_text("User name is Alice", {"area": Memory.Area.FACTS.value})
    await mem.insert_text("User mentioned her name is Alice", {"area": Memory.Area.FACTS.value})
    await mem.insert_text("User name is Alice", {"area": Memory.Area.FACTS.value})
    await mem.insert_text("User mentioned her name is Alice", {"area": Memory.Area.FACTS.value})
    await mem.insert_text("User name is Alice", {"area": Memory.Area.FACTS.value})
    await mem.insert_text("User mentioned her name is Alice", {"area": Memory.Area.FACTS.value})
    consolidator = create_memory_consolidator(agent_with_test_settings)
    
    res = await consolidator.process_new_memory(
        new_memory="User name is Alice",
        area=Memory.Area.FACTS.value,
        metadata={"area": Memory.Area.FACTS.value}
    )

    assert res["success"]

    all_docs = mem.get_all_docs()
    actions = [d.metadata.get("consolidation_action") for d in all_docs.values()]

    assert (
        ConsolidationAction.MERGE.value in actions
        or "keep_separate_safety" in actions
    )