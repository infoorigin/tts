
import pytest
from app.meta_agent.utils.memory import Memory
from llama_index.core import Document

@pytest.mark.asyncio
async def test_insert_and_get_document(agent_with_test_settings):
    """Insert a single document and fetch it back by ID."""
    mem = await Memory.get(agent_with_test_settings)

    doc_id = await mem.insert_text("hello world", {"area": "default"})
    assert isinstance(doc_id, str)

    docs = mem.get_by_ids([doc_id])
    assert len(docs) == 1
    assert docs[0].text == "hello world"
    assert docs[0].metadata["id"] == doc_id


@pytest.mark.asyncio
async def test_insert_multiple_documents(agent_with_test_settings):
    """Insert multiple documents and confirm retrieval."""
    mem = await Memory.get(agent_with_test_settings)

    docs = [Document(text="doc one"), Document(text="doc two")]
    ids = await mem.insert_documents(docs)

    assert len(ids) == 2
    retrieved = mem.get_by_ids(ids)
    assert {d.text for d in retrieved} == {"doc one", "doc two"}


@pytest.mark.asyncio
async def test_delete_document_by_id(agent_with_test_settings):
    """Insert and then delete a document by ID."""
    mem = await Memory.get(agent_with_test_settings)

    doc_id = await mem.insert_text("to be deleted", {})
    docs = mem.get_by_ids([doc_id])
    assert docs  # confirm exists

    removed = await mem.delete_documents_by_ids([doc_id])
    assert len(removed) == 1
    assert not mem.get_by_ids([doc_id])  # should be gone


@pytest.mark.asyncio
async def test_search_similarity(agent_with_test_settings):
    """Insert docs and search with semantic similarity."""
    mem = await Memory.get(agent_with_test_settings)

    await mem.insert_text("python2 programming language", {"area": "default"})
    await mem.insert_text("java2 programming language", {"area": "default"})

    results = await mem.search_similarity_threshold(
        query="python",
        limit=2,
        threshold=0.0,
    )
    assert len(results) > 0
    assert any("python" in doc.text for doc in results)


@pytest.mark.asyncio
async def test_reload_memory(agent_with_test_settings):
    """Ensure persistence works after reload."""
    mem1 = await Memory.get(agent_with_test_settings)
    doc_id = await mem1.insert_text("persist test", {})

    mem2 = await Memory.reload(agent_with_test_settings)
    docs = mem2.get_by_ids([doc_id])
    assert len(docs) == 1
    assert docs[0].text == "persist test"
