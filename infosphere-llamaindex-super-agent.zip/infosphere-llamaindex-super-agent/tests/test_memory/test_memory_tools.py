import pytest
from app.meta_agent.utils.memory import Memory
from app.meta_agent.tools.memory_save import MemorySave
from app.meta_agent.tools.memory_load import MemoryLoad
from app.meta_agent.tools.memory_delete import MemoryDelete
from app.meta_agent.tools.memory_forget import MemoryForget
from app.meta_agent.agent import LoopData


@pytest.mark.asyncio
async def test_memory_save_inserts_fact(agent_with_test_settings):
    """MemorySave tool stores a new fact in memory and returns a confirmation message."""
    mem = await Memory.get(agent_with_test_settings)

    tool = MemorySave(
        agent=agent_with_test_settings,
        name="save_memory",
        method="execute",
        args=[],
        message="Save fact",
        loop_data=LoopData(),
    )

    res = await tool.execute(text="User’s favorite color is blue", area=Memory.Area.FACTS.value)

    all_docs = mem.get_all_docs()
    texts = [doc.text for doc in all_docs.values()]
    assert any("favorite color is blue" in t for t in texts)
    assert "saved" in res.message.lower()


@pytest.mark.asyncio
async def test_memory_load_finds_fact(agent_with_test_settings):
    """MemoryLoad tool retrieves relevant facts matching a query."""
    mem = await Memory.get(agent_with_test_settings)
    await mem.insert_text("User lives in Paris", {"area": Memory.Area.FACTS.value})

    tool = MemoryLoad(
        agent=agent_with_test_settings,
        name="load_memory",
        method="execute",
        args=[],
        message="Load fact",
        loop_data=LoopData(),
    )

    res = await tool.execute(query="Where does the user live?", threshold=0.5)

    assert "Paris" in res.message


@pytest.mark.asyncio
async def test_memory_delete_removes_fact_by_id(agent_with_test_settings):
    """MemoryDelete tool deletes facts by their document IDs."""
    mem = await Memory.get(agent_with_test_settings)
    doc_id = await mem.insert_text("User owns a Tesla", {"area": Memory.Area.FACTS.value})

    tool = MemoryDelete(
        agent=agent_with_test_settings,
        name="delete_memory",
        method="execute",
        args=[],
        message="Delete fact",
        loop_data=LoopData(),
    )

    res = await tool.execute(ids=doc_id)

    all_docs = mem.get_all_docs()
    assert all("Tesla" not in d.text for d in all_docs.values())
    assert "deleted" in res.message.lower()
