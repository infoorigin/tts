import pytest
import re
from app.meta_agent.agent import UserMessage


@pytest.mark.asyncio
async def test_user_personalization_with_memory(agent_with_test_settings):
    """Agent learns user facts and uses them to personalize responses."""

    agent = agent_with_test_settings

    # 1) First query: no personalization yet
    agent.hist_add_user_message(UserMessage(message="Tell me about myself"))
    response1 = await agent.run_message_workflow()

    assert re.search(
        r"(no.*information|don.?t.*know|have.*no.*info|couldn.?t.*find.*information)",
        response1.lower(),
    )

    # 2) Default behavior: agent gives Python code example
    agent.hist_add_user_message(UserMessage(message="Give me a short code example to reverse a list."))
    response2 = await agent.run_message_workflow()
    resp2_low = response2.lower()

    assert "python" in resp2_low
    assert (
        "python" in resp2_low
        or "print(" in resp2_low
        or re.search(r"\bdef\s+\w+\(", resp2_low)
    )

    # 3) Provide user facts with Java preference
    agent.hist_add_user_message(
        UserMessage(
            message=(
                "User name is John Doe. He is a software engineer. "
                "His expertise is in Java and prefers code examples in Java."
            )
        )
    )
    response3 = await agent.run_message_workflow()
    assert "saved" in response3.lower()

    # 4) Ask again: agent should recall stored facts
    agent.hist_add_user_message(UserMessage(message="Tell me about myself"))
    response4 = await agent.run_message_workflow()
    resp4_low = response4.lower()

    assert "john doe" in resp4_low
    assert "java" in resp4_low

    # 5) Ask again for code example: should now be Java
    agent.hist_add_user_message(UserMessage(message="Give me a short code example to reverse a list."))
    response5 = await agent.run_message_workflow()
    resp5_low = response5.lower()

    assert (
        "java" in resp5_low
        or "system.out.println" in resp5_low
    )
