import pytest
import json
import os
from pathlib import Path
from typing import Any, Dict, List

from app.meta_agent.agent import Agent, LoopData, UserMessage
from app.meta_agent.initialize import initialize_agent

from app.meta_agent.utils.agent_activity_dispatcher import LogDispatcher
from app.meta_agent.utils.agent_activity_storage import LocalMemoryLogStorage
 
"""Agent learns user facts and uses them to personalize responses."""
# initialize LogDispatcher with local memory storage
LogDispatcher.initialize(LocalMemoryLogStorage())
print("LogDispatcher initialized with LocalMemoryLogStorage")

# Configure environment for test
current_dir = os.path.dirname(os.path.abspath(__file__))
os.environ["SETTINGS_FILE_PATH"] = os.path.join(current_dir, "config", "settings.json")


FINAL_PROMPT_DIR = Path(r"D:\\infosphere-llamaindex-super-agent\\final_prompt")


@pytest.mark.asyncio
async def test_task_executor():

    # ---- Deleting the prompt files ----
    if FINAL_PROMPT_DIR.exists():
        for file in FINAL_PROMPT_DIR.glob("*.txt"):
            try:
                file.unlink()  # deletes the file
                print(f"Deleted: {file}")
            except Exception as e:
                print(f"Failed to delete {file}: {e}")

    # ---- Setup Phase ----
    config = initialize_agent()
    assert config is not None, "Agent configuration failed to initialize"

    agent = Agent(config=config, number=0)
    assert isinstance(agent, Agent), "Agent object was not properly created"

    loop_data = LoopData()
    agent.loop_data = loop_data
    assert agent.loop_data is loop_data, "LoopData was not properly attached to the Agent"

    # ---- Execution Phase ----
    # user_message = UserMessage("A shopkeeper has two types of rice: one costing ₹50 per kg and the other ₹70 per kg. In what ratio should he mix them so that the mixture costs ₹60 per kg?")
    user_message = UserMessage("First purchase trigger is reported for account Yale New Haven.")
    agent.hist_add_user_message(user_message)

    result = await agent.run_message_workflow()

    # ---- Verification Phase ----
    assert result is not None, "message_workflow returned None — expected a result"

    # Optional: Validate that result contains math operation
    # result_str = str(result)
    # assert "6000" in result_str, "Expected result '6000' not found in result"
    # assert "1:1" in result_str, "Expected result '1:1' not found in result"