import asyncio
from fastmcp import Client
import pytest

@pytest.mark.asyncio
async def test_list_tools():
    async with Client("http://localhost:8000/mcp") as client:
        tools = await client.list_tools()
        for tool in tools:
            print(f"{tool.name}: {tool.description}")

