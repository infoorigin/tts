import pytest
import asyncio
from app.meta_agent.initialize import initialize_agent
from app.meta_agent.utils.history import History
from app.meta_agent.utils import settings
from app.meta_agent.agent import Agent, UserMessage
import json
from pathlib import Path
import os

# ---------------------------
# Setup data directory
# ---------------------------
current_dir = os.path.dirname(os.path.abspath(__file__))

# Build absolute path to the folder
DATA_DIR = os.path.join(current_dir, "history_test_data")

DATA_DIR: Path = Path(DATA_DIR)

# ---------------------------
# Utility functions
# ---------------------------
def load_json(filename):
    file_path = DATA_DIR / filename
    if file_path.exists():
        with open(file_path, "r", encoding="utf-8") as f:
            return json.load(f)
    return []

def add_conversation_to_history(history:History, conversation_pairs):
    for pair in conversation_pairs:
        if "Human" in pair:
            history.add_message(ai=False, content=pair["Human"]["user_message"])
        if "AI" in pair:
            history.add_message(ai=True, content=pair["AI"])
        if "user_intervention" in pair:
            history.add_message(ai=False, content=pair["user_intervention"])

# ---------------------------
# Test
# ---------------------------
@pytest.mark.asyncio
async def test_history_compression_full_cycle():
    os.environ["SETTINGS_FILE_PATH"] = os.path.join(DATA_DIR,"settings.json") 
    
    set = settings.get_settings()
    config = initialize_agent()
    agent = Agent(config=config, number=0)
    history = History(agent)

    # STEP 0: Load existing current topic messages from JSON
    conversation_pairs = load_json("current_topic.json")
    add_conversation_to_history(history, conversation_pairs)

    ctx_len = set["chat_model_ctx_length"]
    ctx_hist_ratio = set["chat_model_ctx_history"]
    total_threshold = int(ctx_len * ctx_hist_ratio)

    # ---------------------------
    # Helper to print token states
    # ---------------------------
    def print_token_state(stage):
        curr = history.current.get_tokens()
        hist = sum(t.get_tokens() for t in history.topics)
        bulk = sum(b.get_tokens() for b in history.bulks)
        total_tokens = history.get_tokens()
        print(f"\n=== {stage.upper()} ===")
        print(f"Total Tokens: {total_tokens} / {total_threshold}")
        print(f"  Current Topic Tokens: {curr}")
        print(f"  Topics Tokens:       {hist}")
        print(f"  Bulk Tokens:         {bulk}")
        print(f"  #Topics: {len(history.topics)}, #Bulks: {len(history.bulks)}")

    # ---------------------------
    # STEP 1: Compress current topic if needed
    # ---------------------------
    await history.compress()
    print_token_state("after current compression")
    assert len(history.current.messages) > 0, "Current topic should still have messages"
    assert len(history.topics) == 0, "Topics should still be empty after compression only"

    # ---------------------------
    # STEP 2: Simulate new user message → triggers new topic
    # ---------------------------
    new_msg = UserMessage(message="This is a new user message after compression")
    # Instead of hist_add_user_message, call new_topic directly
    history.new_topic()
    # Add the new message to current topic
    history.add_message(ai=False, content=new_msg.message)
    print_token_state("after new_topic call with new message")

    # Verify old compressed topic moved to topics
    assert len(history.topics) > 0, "Old compressed topic should have moved to topics"
    # Verify current topic only has the new message
    assert history.current.messages[-1].content == new_msg.message, "Current topic should contain only the new message"

    # ---------------------------
    # STEP 3: Trigger topic compression → may move to bulks if threshold hit
    # ---------------------------
    await history.compress()
    print_token_state("after topic compression")

    # ---------------------------
    # STEP 4: Trigger bulk compression/merge/delete
    # ---------------------------
    await history.compress()
    print_token_state("after bulk compression/merge/delete")

    # ---------------------------
    # STEP 5: Save current_topic.json
    # ---------------------------
    with open(DATA_DIR / "current_topic.json", "w", encoding="utf-8") as f:
        json.dump([m.to_dict() for m in history.current.messages], f, indent=4)

    # ---------------------------
    # STEP 6: Save topic.json (append to existing topics)
    # ---------------------------
    existing_topics = load_json("topic.json")
    # Append newly compressed topic(s) if any
    for t in history.topics:
        existing_topics.append(t.to_dict())
    with open(DATA_DIR / "topic.json", "w", encoding="utf-8") as f:
        json.dump(existing_topics, f, indent=4)

    # ---------------------------
    # STEP 7: Save bulk.json
    # ---------------------------
    with open(DATA_DIR / "bulk.json", "w", encoding="utf-8") as f:
        json.dump([b.to_dict() for b in history.bulks], f, indent=4)

    # ---------------------------
    # STEP 8: Final sanity check
    # ---------------------------
    assert history.get_tokens() <= total_threshold, "Final token count should be under ctx threshold"
 