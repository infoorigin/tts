import os
import json
import uuid
from pathlib import Path
import pytest
from app.meta_agent.agent import Agent, UserMessage, LoopData
from app.meta_agent.initialize import initialize_agent
from app.meta_agent.utils import files
from app.meta_agent.utils.chat_manager import _get_chat_file_path, _deserialize_context, save_tmp_chat

CONTEXT_ID = "95Rip8Md"
USER_MESSAGE = "perform deep research on data science"

current_dir = os.path.dirname(os.path.abspath(__file__))
os.environ["SETTINGS_FILE_PATH"] = os.path.join(current_dir, "history_test_data", "settings.json")


def mirror_user_message_to_agents(agents, user_message: str, id_prefix: str = ""):
    
    for a in agents:
        if not a:
            continue
        try:
            aa = a.context.agent_activity
            item_id = str(uuid.uuid4())
            item = {
                "no": len(getattr(aa, "agent_activities", [])) + 1,
                "id": item_id,
                "type": "user",
                "heading": "User message",
                "content": user_message,
                "temp": False,
                "kvps": {"attachments": []},
            }

            if hasattr(aa, "add_agent_activity"):
                try:
                    aa.add_agent_activity(
                        type=item["type"],
                        heading=item["heading"],
                        content=item["content"],
                        kvps=item["kvps"],
                        id=item["id"],
                        temp=item["temp"],
                    )
                except Exception:
                    # fallback to raw append
                    try:
                        aa.agent_activities.append(item)
                    except Exception:
                        pass
            else:
                try:
                    aa.agent_activities.append(item)
                except Exception:
                    pass
        except Exception:
            pass


@pytest.mark.asyncio
async def test_history_flow_minimal():
    # init config/context
    cfg = initialize_agent()

    path = _get_chat_file_path(CONTEXT_ID)
    assert Path(path).exists(), f"seeded chat.json not found at {path}"
    data = json.loads(files.read_file(path))

    # ensure keys needed by _deserialize_context exist
    data.setdefault(
        "agent_activity",
        {
            "guid": "",
            "agent_number": 0,
            "stages": [],
            "updates": [],
            "agent_activities": [],
        },
    )
    data.setdefault("agent_meta", {})
    data.setdefault("history", {})

    context = _deserialize_context(data)

    # resolve agents
    main_agent = context.agent_meta
    streaming_agent = context.streaming_agent or main_agent

    main_agent.hist_add_user_message(UserMessage(USER_MESSAGE))

    agents_to_log = [main_agent]
    if streaming_agent and streaming_agent is not main_agent:
        agents_to_log.append(streaming_agent)

    mirror_user_message_to_agents(agents_to_log, USER_MESSAGE, id_prefix="test-user")

    # if streaming agent is different, also add same user message into its history
    if streaming_agent and streaming_agent is not main_agent:
        streaming_agent.hist_add_user_message(UserMessage(USER_MESSAGE))
        s_loop = LoopData(user_message=streaming_agent.last_user_message)
        s_loop.last_response = USER_MESSAGE
        s_loop.history_output = streaming_agent.history.output()
        streaming_agent.loop_data = s_loop

    # seed loop_data for main agent (always)
    main_agent.loop_data = LoopData(
        user_message=main_agent.last_user_message,
        last_response=USER_MESSAGE,
        history_output=main_agent.history.output(),
    )

    # persist context and compress histories
    save_tmp_chat(context)
    await main_agent.history.compress()
    if streaming_agent and streaming_agent is not main_agent:
        await streaming_agent.history.compress()

    # run workflow (don't fail test if workflow raises)
    try:
        await main_agent.run_message_workflow()
    except Exception:
        pass

    # final save/compress and reload
    await main_agent.history.compress()
    if streaming_agent and streaming_agent is not main_agent:
        await streaming_agent.history.compress()

    save_tmp_chat(context)

    reloaded_js = files.read_file(path)
    reloaded_data = json.loads(reloaded_js)
    reloaded_context = _deserialize_context(reloaded_data)

    reloaded_main = reloaded_context.agent_meta
    reloaded_streaming = reloaded_context.streaming_agent

    # gather user messages from main history
    user_msgs = [m["content"] for m in reloaded_main.history.output() if not m["ai"]]

    assert any(
        (isinstance(m, str) and USER_MESSAGE in m) or
        (isinstance(m, dict) and (m.get("user_message") == USER_MESSAGE or USER_MESSAGE in json.dumps(m)))
        for m in user_msgs
    ), "User message missing in main agent history"

    assert reloaded_streaming is not None, "Streaming agent missing after reload"

    # If streaming agent is separate, ensure it has AI content
    if reloaded_streaming is not reloaded_main:
        stream_ai_msgs = [m["content"] for m in reloaded_streaming.history.output() if m["ai"]]
        assert len(stream_ai_msgs) > 0, "Streaming agent has no AI response stored"
