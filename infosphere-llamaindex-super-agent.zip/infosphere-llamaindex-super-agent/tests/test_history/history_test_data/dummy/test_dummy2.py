import os
import json
from pathlib import Path
import pytest

os.environ["SETTINGS_FILE_PATH"] = str(
    Path(__file__).parent / "history_test_data" / "settings.json"
)

from app.meta_agent.agent import Agent, UserMessage, LoopData
from app.meta_agent.utils import chat_manager, files
from app.meta_agent.initialize import initialize_agent
from llama_index.core.llms import ChatMessage


FORCE_CONTEXT_ID = "sCuOXT8r"
USER_MESSAGE = "What do you think about IT sector?"


@pytest.mark.asyncio
async def test_full_internal_append_and_compress():
    """
    Full internal workflow:
    Existing chat → append user message → save → check tokens → compress → generate LLM → append → compress → final save.
    """

    # --- Step 1: Initialize Agent config ---
    cfg = initialize_agent()

    # --- Step 2: Load existing context from chat.json ---
    path = chat_manager._get_chat_file_path(FORCE_CONTEXT_ID)
    assert Path(path).exists(), f"chat.json for context {FORCE_CONTEXT_ID} not found"

    js = files.read_file(path)
    data = json.loads(js)
    context = chat_manager._deserialize_context(data)

    # --- Step 3: Create Agent instance internally ---
    agent = Agent.__new__(Agent)
    agent.config = cfg
    agent.number = 0
    agent.context = context
    agent.history = context.agent_meta.history
    agent.loop_data = LoopData(user_message=USER_MESSAGE)
    agent.last_user_message = USER_MESSAGE

    # Streaming agent preserves original Q&A
    streaming_agent = context.streaming_agent
    if streaming_agent:
        streaming_agent.loop_data = LoopData(user_message=USER_MESSAGE)

    # --- Step 4: Append user message internally ---
    user_msg_obj = UserMessage(message=USER_MESSAGE)
    agent.hist_add_user_message(user_msg_obj)

    # --- Step 5: Save immediately ---
    chat_manager.save_tmp_chat(context)

    # --- Step 6: Compress after user message if token limit exceeded ---
    await agent.history.compress()
    if streaming_agent and streaming_agent != agent:
        await streaming_agent.history.compress()
   
    # --- Step 7: Generate LLM response internally ---
    agent.loop_data = LoopData(user_message=USER_MESSAGE)

    # System prompt
    messages = [ChatMessage(role="system", content="You are a helpful assistant.")]

    # Include previous history
    for m in agent.history.current.messages:
        content = m.content
        if isinstance(content, dict):
            content = content.get("user_message")
        role = "assistant" if m.ai else "user"
        messages.append(ChatMessage(role=role, content=content))

    # Add the new user message
    messages.append(ChatMessage(role="user", content=USER_MESSAGE))

    # Call LLM
    ai_response, _ = await agent.call_chat_model(messages=messages)


    # Append response to agent and streaming_agent histories
    agent.hist_add_ai_response(ai_response)
    if streaming_agent and streaming_agent != agent:
        streaming_agent.hist_add_ai_response(ai_response)

    # --- Step 8: Compress after AI response if needed ---
    await agent.history.compress()
    if streaming_agent and streaming_agent != agent:
        await streaming_agent.history.compress()

    # --- Step 9: Final save ---
    chat_manager.save_tmp_chat(context)

    # --- Step 10: Reload and verify ---
    reloaded_data = json.loads(files.read_file(path))
    reloaded_context = chat_manager._deserialize_context(reloaded_data)

    reloaded_agent = reloaded_context.agent_meta
    reloaded_streaming = reloaded_context.streaming_agent

    # Collect user and AI messages
    user_msgs, ai_msgs = [], []
    for m in reloaded_agent.history.current.messages:
        if m.ai:
            ai_msgs.append(m.content)
        else:
            if isinstance(m.content, dict):
                user_msgs.append(m.content.get("user_message"))
            else:
                user_msgs.append(m.content)

    # --- Assertions ---
    assert USER_MESSAGE in user_msgs, "User message missing in agent history"
    assert ai_response in ai_msgs, "AI response missing in agent history"

    if reloaded_streaming and reloaded_streaming != reloaded_agent:
        stream_ai_msgs = [
            m.content for m in reloaded_streaming.history.current.messages if m.ai
        ]
        assert ai_response in stream_ai_msgs, "AI response missing in streaming agent history"

    print("[INFO] Test passed: Full internal append, compress, LLM response, and save workflow verified")
