import os
import json
from pathlib import Path
import pytest

os.environ["SETTINGS_FILE_PATH"] = str(
    Path(__file__).parent / "history_test_data" / "settings.json"
)

from app.meta_agent.agent import Agent, UserMessage, LoopData
from app.meta_agent.utils import chat_manager, files
from app.meta_agent.initialize import initialize_agent

FORCE_CONTEXT_ID = "T8TazCmf"
USER_MESSAGE = "What do you think about street dogs?"

@pytest.mark.asyncio
async def test_append_user_message_to_existing_context_real_llm():
    """Full workflow with real LLM and streaming agent preservation."""

    # --- Step 1: Load context ---
    cfg = initialize_agent()

    path = chat_manager._get_chat_file_path(FORCE_CONTEXT_ID)
    assert Path(path).exists(), f"chat.json for context {FORCE_CONTEXT_ID} not found"
    js = files.read_file(path)
    data = json.loads(js)
    context = chat_manager._deserialize_context(data)

    # --- Step 2: Create Agent instance manually ---
    agent = Agent.__new__(Agent)
    agent.config = cfg
    agent.number = 0
    agent.context = context
    agent.history = context.agent_meta.history
    agent.loop_data = LoopData(user_message=USER_MESSAGE)
    agent.last_user_message = USER_MESSAGE

    streaming_agent = context.streaming_agent
    if streaming_agent:
        streaming_agent.loop_data = LoopData(user_message=USER_MESSAGE)

    print(f"[INFO] Loaded context {context.id}")

    # --- Step 3: Append user message (PASS OBJECT) ---
    user_msg_obj = UserMessage(message=USER_MESSAGE)
    msg_obj = agent.hist_add_user_message(message=user_msg_obj)
    assert msg_obj is not None
    print(f"[INFO] User message appended: {user_msg_obj.message}")

    # --- Step 4: Call real LLM ---
    ai_response = await agent.generate_llm_response()
    print(f"[INFO] Real AI response received: {ai_response}")

    # --- Step 5: Update streaming agent ---
    if streaming_agent and streaming_agent != agent:
        streaming_agent.hist_add_ai_response(ai_response)

    # --- Step 6: Save updated context ---
    chat_manager.save_tmp_chat(context)
    print("[INFO] chat.json updated and saved")

    # --- Step 7: Reload and verify ---
    reloaded_data = json.loads(files.read_file(path))
    reloaded_context = chat_manager._deserialize_context(reloaded_data)

    reloaded_agent = reloaded_context.agent_meta
    reloaded_streaming = reloaded_context.streaming_agent

    all_msgs = reloaded_agent.history.current.messages

    user_msgs = []
    ai_msgs = []

    for m in all_msgs:
        if m.ai:
            ai_msgs.append(m.content)
        else:
            # ✅ Handle dict or string for user messages
            if isinstance(m.content, dict):
                user_msgs.append(m.content.get("user_message"))
            else:
                user_msgs.append(m.content)

    # ✅ Assertions
    assert USER_MESSAGE in user_msgs, f"User message missing in agent history: {user_msgs}"
    assert ai_response in ai_msgs, "AI response missing in agent history"

    if reloaded_streaming and reloaded_streaming != reloaded_agent:
        stream_ai_msgs = []
        for m in reloaded_streaming.history.current.messages:
            if m.ai:
                stream_ai_msgs.append(m.content)
        assert ai_response in stream_ai_msgs, "AI response missing in streaming agent history"