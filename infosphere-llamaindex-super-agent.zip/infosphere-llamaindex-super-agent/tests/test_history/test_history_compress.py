import pytest
from app.meta_agent.agent import Agent
from app.meta_agent.initialize import initialize_agent
from app.meta_agent.utils.history import History
from app.meta_agent.utils import settings
import json
import os
from pathlib import Path



current_dir = os.path.dirname(os.path.abspath(__file__))

# Build absolute path to the folder
DATA_DIR = os.path.join(current_dir, "history_test_data")
DATA_DIR = Path(DATA_DIR)  # make it a Path object

def load_json(filename):
    file_path = DATA_DIR / filename  # ✅ no join(), much cleaner
    with open(file_path, "r", encoding="utf-8") as f:
        return json.load(f)

def add_conversation_to_history(history, conversation_pairs):
    for pair in conversation_pairs:
        if "Human" in pair:
            history.add_message(ai=False, content=pair["Human"]["user_message"])
        if "AI" in pair:
            history.add_message(ai=True, content=pair["AI"])
        if "user_intervention" in pair:
            history.add_message(ai=False, content=pair["user_intervention"])


@pytest.mark.asyncio
async def test_history_compression_current_topic_only():
    os.environ["SETTINGS_FILE_PATH"] = os.path.join(DATA_DIR,"settings.json") 
    set = settings.get_settings()
    config = initialize_agent()
    agent = Agent(config=config, number=0)
    history = History(agent)

    # Load current topic messages from JSON
    conversation_pairs = load_json("current_topic.json")
    add_conversation_to_history(history, conversation_pairs)

    # --- Calculate token threshold ---
    ctx_len = set["chat_model_ctx_length"]
    ctx_hist_ratio = set["chat_model_ctx_history"]
    total_threshold = int(ctx_len * ctx_hist_ratio)

    curr = history.current.get_tokens()
    total_tokens_before = history.get_tokens()

    print(f"\n=== TOKEN DEBUG ===")
    print(f"CTX : {ctx_len}")
    print(f"CTX ratio : {ctx_hist_ratio}")
    print(f"CTX Threshold: {total_threshold}")
    print(f"Total Tokens (Before): {total_tokens_before}")
    print(f"Current Topic Tokens: {curr}")
    
    print("\n--- BEFORE COMPRESSION ---")
    for i, msg in enumerate(history.current.messages, start=1):
        print(f"{i}. AI={msg.ai}, tokens={msg.tokens}, summary={msg.summary}")
        print("CONTENT:")
        print(msg.content)
        print("-" * 80)

    before_count = len(history.current.messages)

    # --- Compress current topic only ---
    print("\n>>> Calling history.compress()")
    compressed = await history.compress()  # will only affect current topic

    after_count = len(history.current.messages)
    total_tokens_after = history.get_tokens()

    print("\n--- AFTER COMPRESSION ---")
    for i, msg in enumerate(history.current.messages, start=1):
        print(f"{i}. AI={msg.ai}, tokens={msg.tokens}, content={msg.content}, summary={msg.summary}")

    print(f"\nTokens Before: {total_tokens_before}")
    print(f"Tokens After:  {total_tokens_after}")
    print(f"Messages Before: {before_count}")
    print(f"Messages After:  {after_count}")

    # --- Assertions ---
    assert compressed is True, (
        f"Expected compression to be triggered but it wasn't. "
        f"Tokens: {total_tokens_before}, Threshold: {total_threshold}"
    )
    
    assert after_count <= before_count, (
        f"Compression was triggered but message count did not reduce "
        f"(Before: {before_count}, After: {after_count})"
    )

    assert total_tokens_after <= total_tokens_before, (
        f"Compression was triggered but token count did not reduce "
        f"(Before: {total_tokens_before}, After: {total_tokens_after})"
    )
