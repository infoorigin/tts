import pytest
import json
from pathlib import Path
from typing import Any, Dict, List

from app.meta_agent.agent import Agent, LoopData, UserMessage
from app.meta_agent.initialize import initialize_agent
import os

current_dir = os.path.dirname(os.path.abspath(__file__))
os.environ["SETTINGS_FILE_PATH"] = os.path.join(current_dir,"settings.json")

FINAL_PROMPT_DIR = Path(r"D:\\infosphere-llamaindex-super-agent\\final_prompt")

@pytest.mark.asyncio
async def test_prepare_prompt():

    # ---- Deleting the prompt files ----
    if FINAL_PROMPT_DIR.exists():
        for file in FINAL_PROMPT_DIR.glob("*.txt"):
            try:
                file.unlink()  # deletes the file
                print(f"Deleted: {file}")
            except Exception as e:
                print(f"Failed to delete {file}: {e}")
    
    # Agent Initialization    
    config = initialize_agent()
    agent = Agent(config=config, number=0)
    assert agent is not None, "Failed to initialize Agent"

    
    # Setup Loop Data and History
    loop_data = LoopData()
    agent.loop_data = loop_data


    # Injecting History from JSON     
    history_path = Path(__file__).parent / "test_history.json"
    assert history_path.exists(), f"History file not found at {history_path}"
    
    try:
        loop_data.history_output = json.loads(history_path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as e:
        pytest.fail(f"Failed to parse history JSON: {e}")


    # Helper: inject messages
    def push_message_to_agent(agent: Agent, message: Dict[str, Any]) -> None:
        ai_flag = bool(message.get("ai", False))
        content = message.get("content", "")

        if isinstance(content, dict) and not ai_flag and "user_message" in content:
            agent.hist_add_user_message(UserMessage(content["user_message"]))
        else:
            msg_text = json.dumps(content, ensure_ascii=False) if isinstance(content, dict) else content
            if ai_flag:
                agent.hist_add_ai_response(msg_text)
            else:
                agent.hist_add_user_message(UserMessage(msg_text))

    for msg in loop_data.history_output:
        push_message_to_agent(agent, msg)

    
    # Call Prepare Prompt    
    full_prompt = await agent.prepare_prompt(agent.loop_data)


    # Prompt Validations
    assert isinstance(full_prompt, list), "Full prompt should be a list"
    assert len(full_prompt) > 0, "Full prompt should contain at least one message"

    
    # System Response Validation    
    system_first_msg = full_prompt[0]
    assert system_first_msg.role.value == "system"


    # History Validation    
    historic_message = " ".join([str(getattr(m, "content", m)) for m in full_prompt])
    assert "who are you?" in historic_message, "Historical user message missing from prompt"
    
    
    # Current User Message Validation
    current_user_message = full_prompt[-1]
    assert current_user_message.role.value == "user" and current_user_message.blocks[0].text.split("[EXTRAS]")[0].strip() == '{"user_message": "can you tell me what is your name?"}', \
    "Last user message should be 'can you tell me what is your name?'"