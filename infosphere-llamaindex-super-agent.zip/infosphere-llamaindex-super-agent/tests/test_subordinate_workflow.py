import pytest
import json
import os
from pathlib import Path
from typing import Any, Dict, List
from app.meta_agent.agent import Agent, LoopData, UserMessage
from app.meta_agent.initialize import initialize_agent


# Configure environment for test
current_dir = os.path.dirname(os.path.abspath(__file__))
os.environ["SETTINGS_FILE_PATH"] = os.path.join(current_dir, "config", "settings.json")

FINAL_PROMPT_DIR = Path(r"D:\\infosphere-llamaindex-super-agent\\final_prompt")

@pytest.mark.asyncio
async def test_task_executor():

    # ---- Deleting the prompt files ----
    if FINAL_PROMPT_DIR.exists():
        for file in FINAL_PROMPT_DIR.glob("*.txt"):
            try:
                file.unlink()  # deletes the file
                print(f"Deleted: {file}")
            except Exception as e:
                print(f"Failed to delete {file}: {e}")

    # ---- Setup Phase ----
    config = initialize_agent()
    assert config is not None, "Agent configuration failed to initialize"

    agent = Agent(config=config, number=0)
    assert isinstance(agent, Agent), "Agent object was not properly created"

    loop_data = LoopData()
    agent.loop_data = loop_data
    assert agent.loop_data is loop_data, "LoopData was not properly attached to the Agent"

    # ---- Execution Phase ----
    user_message = UserMessage("conduct a deep research on mobile devices and IOT technology and its applications via a subordinate agent")
    # user_message = UserMessage("what is the capital of India")
    agent.hist_add_user_message(message=user_message)

    result = await agent.run_message_workflow()
    assert result is not None

    # ---- Save Result Phase ----
    result_file = Path(current_dir) / "result.txt"
    with open(result_file, "w", encoding="utf-8") as f:
        # make it JSON-safe if result is dict, else just dump string
        if isinstance(result, (dict, list)):
            f.write(json.dumps(result, indent=4, ensure_ascii=False))
        else:
            f.write(str(result))
