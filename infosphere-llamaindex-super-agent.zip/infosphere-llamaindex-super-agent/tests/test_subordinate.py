import pytest
from pathlib import Path
import os
from app.meta_agent.agent import Agent
from app.meta_agent.initialize import initialize_agent
from app.meta_agent.tools.call_sub_agent import Delegation  # adjust if path differs
from app.meta_agent.utils.agent_activity_dispatcher import LogDispatcher
from app.meta_agent.utils.agent_activity_storage import LocalMemoryLogStorage
 
    # initialize LogDispatcher with local memory storage (good for notebooks)
LogDispatcher.initialize(LocalMemoryLogStorage())
print("LogDispatcher initialized with LocalMemoryLogStorage")

from app.meta_agent.utils.agent_activity_dispatcher import LogDispatcher
from app.meta_agent.utils.agent_activity_storage import LocalMemoryLogStorage
 
"""Agent learns user facts and uses them to personalize responses."""
# initialize LogDispatcher with local memory storage
LogDispatcher.initialize(LocalMemoryLogStorage())
print("LogDispatcher initialized with LocalMemoryLogStorage")

# Configure environment for test
current_dir = os.path.dirname(os.path.abspath(__file__))
os.environ["SETTINGS_FILE_PATH"] = os.path.join(current_dir, "config", "settings.json")

FINAL_PROMPT_DIR = Path(r"D:\\infosphere-llamaindex-super-agent\\final_prompt")

@pytest.mark.asyncio
async def test_end_to_end_call_subordinate():

    # ---- Deleting the prompt files ----
    if FINAL_PROMPT_DIR.exists():
        for file in FINAL_PROMPT_DIR.glob("*.txt"):
            try:
                file.unlink()  # deletes the file
                print(f"Deleted: {file}")
            except Exception as e:
                print(f"Failed to delete {file}: {e}")

    # ---- Setup ----
    config = initialize_agent()
    agent = Agent(0, config)
    
    # create Delegation tool (call_subordinate)
    tool = Delegation(
        agent=agent,
        name="call_sub_agent",
        method=None,
        args={},
        message="",
        loop_data=None,
    )

    # ---- Execution ----
    user_msg = "Conduct a deep research on mobile devices and IoT technology, focusing on their applications, current trends, and future prospects. Provide a comprehensive report."
    response = await tool.execute(message=user_msg)
    
    # ---- Assertions ----
    assert response is not None, "Delegation tool did not return a response"
    assert response.message is not None, "Response has no message"
    assert isinstance(response.message, str), "Response message should be string"
    assert response.sub_agent=="AM1"
    assert response.default_agent=="AM0"
    # ---- Save to file ----
    result_file = Path("result.txt")
    result_file.write_text(response.message, encoding="utf-8")

    # ensure file was created and is not empty
    assert result_file.exists()
    assert result_file.read_text(encoding="utf-8").strip() != ""

    print("Result written to:", result_file.resolve())

