# conftest.py
import os
import pytest
from app.meta_agent.agent import Agent,LoopData
from app.meta_agent.initialize import initialize_agent
from app.meta_agent.utils import settings
from app.meta_agent.utils.memory import Memory
import uuid,shutil


current_dir = os.path.dirname(os.path.abspath(__file__))

# Build absolute path to the folder
TEST_CONFIG_DIR = os.path.join(current_dir, "config")

@pytest.fixture
def agent_with_test_settings():
    os.environ["SETTINGS_FILE_PATH"] = os.path.join(TEST_CONFIG_DIR,"settings.json") 
    set = settings.get_settings()
    config = initialize_agent()
    # assign unique subdir for this test
    # unique_subdir = f"{config.memory_subdir}_{uuid.uuid4().hex[:8]}"
    # config.memory_subdir = unique_subdir

    agent = Agent(config=config, number=0)
  
    agent.loop_data = LoopData()

    # cleanup before test
    subdir = config.memory_subdir  
    db_dir = Memory._abs_db_dir(subdir)

    if os.path.exists(db_dir):
        shutil.rmtree(db_dir)
    
    yield agent

    # cleanup after test
    # if os.path.exists(db_dir):
    #     shutil.rmtree(db_dir)
    # Memory.index.pop(unique_subdir, None)

    # db_dir = Memory._abs_db_dir(unique_subdir)
    # if os.path.exists(db_dir):
    #     shutil.rmtree(db_dir)
    # Memory.index.pop(unique_subdir, None)