import pytest
import json
from pathlib import Path
from typing import Any, Dict, List
from app.meta_agent.agent import Agent, LoopData
from app.meta_agent.initialize import initialize_agent
from llama_index.core.llms import ChatMessage, MessageRole, TextBlock
import os

current_dir = os.path.dirname(os.path.abspath(__file__))
os.environ["SETTINGS_FILE_PATH"] = os.path.join(current_dir,"..\config\settings.json")

def load_prompt_from_json(path: Path | str) -> List[ChatMessage]:
    
    #  Convert Raw JSON to List[ChatMessage]
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"Prompt JSON not found: {p.resolve()}")

    raw = json.loads(p.read_text(encoding="utf-8"))
    role_map = {"system": MessageRole.SYSTEM, "assistant": MessageRole.ASSISTANT}

    return [
        ChatMessage(
            role=role_map.get(item.get("role", "user").strip().lower(), MessageRole.USER),
            blocks=[TextBlock(text=item.get("text", ""))]
        )
        for item in raw
    ]

def load_file(filename: str):
    
    #  Get JSON File Path
    prompt_path = Path(__file__).parent / filename
    return load_prompt_from_json(prompt_path)


@pytest.mark.asyncio
async def test_llm_math_tool():

    #  Load Full Prompt
    full_prompt_llamaindex = load_file('math_tool_full_prompt.json')

    
    #  Agent Initialization
    config = initialize_agent()
    agent = Agent(config=config, number=0)
    assert agent is not None, "Failed to initialize Agent"

    
    #  Call LLM for math tool
    response, reasoning = await agent.call_chat_model(full_prompt_llamaindex)

    
    #  Basic Response Validation
    assert isinstance(response, str) and response.strip() != ""
    assert isinstance(reasoning, str)

    
    #  JSON Structure Validation
    try:
        response_json: Dict[str, Any] = json.loads(response)
    except json.JSONDecodeError as e:
        pytest.fail(f"LLM response is not valid JSON: {e}")

    
    #  Load Full Prompt With LLM Response With Math Tool
    required_keys = ["thoughts", "headline", "tool_name", "tool_args"]
    for key in required_keys:
        assert key in response_json, f"Key '{key}' not found in LLM response JSON"

    
    #  Tool Arguments Validation    
    assert isinstance(response_json.get("tool_args"), dict), "tool_args must be a dict"
    assert "text" in response_json["tool_args"], "Key 'text' missing inside tool_args"
    assert response_json["tool_args"]["text"].strip(), "tool_args.text should not be empty"


    #  Math Tool Name Validation
    expected_tool_name = "math_tool"
    assert response_json["tool_name"] == expected_tool_name, (
        f"Expected tool_name to be '{expected_tool_name}', got '{response_json['tool_name']}'"
    )



@pytest.mark.asyncio
async def test_math_tool_to_response_tool():

    
    #  Load Full Prompt With LLM Response With Math Tool
    full_prompt_llamaindex = load_file('math_to_response_tool_prompt.json')


    
    #  Agent Initialization   
    config = initialize_agent()
    agent = Agent(config=config, number=0)
    assert agent is not None, "Failed to initialize Agent"


    
    #  Call LLM
    response, reasoning = await agent.call_chat_model(full_prompt_llamaindex)


    
    #  Basic Validation   
    assert isinstance(response, str) and response.strip() != ""
    assert isinstance(reasoning, str)


    
    #  JSON Structure Validation    
    try:
        response_json: Dict[str, Any] = json.loads(response)
    except json.JSONDecodeError as e:
        pytest.fail(f"LLM response is not valid JSON: {e}")

    
    #  LLM Response Keys Validation   
    required_keys = ["thoughts", "headline", "tool_name", "tool_args"]
    for key in required_keys:
        assert key in response_json, f"Key '{key}' not found in LLM response JSON"

    
    #  Response Tool Name Validation   
    expected_tool_name = "response"
    assert response_json["tool_name"] == expected_tool_name, (
        f"Expected tool_name to be '{expected_tool_name}', got '{response_json['tool_name']}'"
    )