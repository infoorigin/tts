import os
from app.meta_agent.initialize import initialize_agent

current_dir = os.path.dirname(os.path.abspath(__file__))
os.environ["SETTINGS_FILE_PATH"] = os.path.join(current_dir,"config\settings.json")

def test_agent_init():
    config = initialize_agent()
    profile = config.profile
    print(f"Agent profile {profile}")

