# Savant Meta Agent Workflow Setup and Execution Guide

## 1. Create a Virtual Environment
Create a new Python virtual environment:
```bash
python -m venv .venv
```

## 2. Activate the Virtual Environment
Activate your virtual environment:
```bash
.venv\Scripts\activate
```

## 3. Install Dependencies
Install all required Python packages:
```bash
pip install -r requirements.txt
```

## 4. Set Up Environment Variables
In the project’s root directory, create a `.env` file and add the following environment variables:
```
OPENAI_API_KEY=<your_openai_api_key>
HISTORY_TEST_DATA=tests/test_history/history_test_data
SETTINGS_FILE_PATH = tests/config
```

## 5. start the MCP server

Navigate to the `mcp_serve` directory and run:
```bash
python server.py
  ```

## 6: Start the Uvicorn Debug Server
  Once the MCP server is running, start the Uvicorn debug server.
  ```bash
  uvicorn app.main:app --reload --host $HOST --port $PORT 
  ``` 
  After **“Application startup complete”**, the API will be ready.

  ### Send a `POST` request to:
  ```
  http://127.0.0.1:8000/api/v1/meta_agent/chat
  ```

## 7. Developer Note (Memory Management in Jupyter Notebook)
In the Jupyter Notebook, under the **Memory Deletion** section:
- Set `reset_memory = True` to clear/delete all saved memory.
- Set `reset_memory = False` to keep the existing memory.
