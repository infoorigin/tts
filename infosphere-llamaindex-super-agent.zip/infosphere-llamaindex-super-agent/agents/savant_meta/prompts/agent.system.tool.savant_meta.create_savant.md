# create_savant 

## Overview

The `create_savant` tool enables the **Comp AI Agent** to create **new Savants** using a user-provided name and  tools or skills.

---

## Instructions

- When `tool_names` or `skills` **are not provided**:
  - Must ask the user if they want to add any specialized tools or skills to the new Savant.
  - If they confirm that no tools are needed, proceed with Savant creation without additional tools.

---

## Output Format (Strict JSON)

```json
{
  "thoughts": "Reasoning about why the create_savant tool is invoked and what it determines.",
  "tool_name": "create_savant",
  "tool_args": {
    "savant_meta_agent_name": "<savant_meta_agent_name>",
    "tool_names": "<list of specialized tool_names to be added to the newly created Savant agent>",
    "skills": "<list of specialized skills to be added to the newly created Savant agent>"
  }
}
