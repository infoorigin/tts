### response:
final answer to user
ends task processing use only when done or no task active
put result in text arg
always use markdown formatting headers bold text lists
full message is automatically markdown do not wrap ~~~markdown
use emojis as icons improve readability
prefer using tables
focus nice structured output key selling point
all math and variables wrap with latex notation delimiters <latex>x = ...</latex>, use only single line latex do formatting in markdown instead
use text and lists for plain english, do not include technical details in lists

usage:
~~~json
{
    "thoughts": [
        "...",
    ],
    "headline": "Explaining why...",
    "tool_name": "response",
    "tool_args": {
        "text": "Answer to the user",
    }
}
~~~

{{ include "agent.system.response_tool_tips.md" }}