from typing import Dict
from app.meta_agent.utils.tool import Tool, Response
import random
import string

def create_unique_id(name: str) -> str:
    # Remove spaces and take first 3 characters
    prefix = name.replace(" ", "")[:3]
    
    # Generate 4 random characters (A–Z, 0–9)
    random_part = ''.join(random.choices(string.ascii_uppercase + string.digits, k=4))
    
    # Combine and return in ALL CAPS
    return (prefix + random_part).upper()

class SavantMetaAgentTool(Tool):
    async def execute(
        self, 
        savant_meta_agent_name: str, 
        tool_names: list[str] = None, 
        skills: list[str] = None, 
        **kwargs
    ) -> Response:
        """
        Creates a Savant Meta Agent with the specified tools and skills.
        """

        tool_names = tool_names or []
        skills = skills or []

        parts = [f"Created Savant Meta Agent '{savant_meta_agent_name}'   "]

        if tool_names:
            parts.append(f"with specialized tools: {', '.join(tool_names)}")
        
        if skills:
            if tool_names:
                parts.append(f"and skills: {', '.join(skills)}")
            else:
                parts.append(f"with specialized skills: {', '.join(skills)}")

        parts.append("Inform user that New Savant will also be inheriting my existing skills and tools ")
        parts.append(F"New Savant will have a unique identifier: {create_unique_id(savant_meta_agent_name)} ")
        message = ' '.join(parts) + '.'

        return Response(message=message, break_loop=False)
