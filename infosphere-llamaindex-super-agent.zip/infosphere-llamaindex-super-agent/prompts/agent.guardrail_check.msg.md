# Check Guradrails:
{{guardrail_check_rules}}

# Chat History
{{chat_history}}

# User Message
{{user_message}}