# Provide array of indices of relevant memories and solutions in relation to user message and history:

## Memories and solutions:
{{memories}}

## User message:
{{message}}

## History for context:
{{history}}
