import json
from typing import Any
from app.meta_agent.utils.files import VariablesPlugin
from app.meta_agent.utils import files
from app.meta_agent.utils.print_style import PrintStyle

class CallSubordinate(VariablesPlugin):
    def get_variables(self, file: str, backup_dirs: list[str] | None = None) -> dict[str, Any]:

        # collect all prompt profiles from subdirectories (_context.md file)
        profiles = []
        agent_subdirs = files.get_subdirectories("agents", exclude=["_example"])
        for agent_subdir in agent_subdirs:
            try:
                dir_path = files.get_abs_path("agents", agent_subdir) 
                context = files.read_prompt_file(
                    "_context.md",
                    [files.get_abs_path("agents", agent_subdir)]
                )
                profiles.append({"name": agent_subdir, "context": context})
            except Exception as e:
                PrintStyle().error(f"Error loading agent profile '{agent_subdir}': {e}")

        # in case of no profiles
        if not profiles:
            profiles = [
                {"name": "default", "context": "Default Savant Meta Agent AI Assistant"}
            ]

        return {"agent_profiles": profiles}
