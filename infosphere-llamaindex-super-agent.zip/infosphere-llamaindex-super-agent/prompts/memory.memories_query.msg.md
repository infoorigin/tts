# Provide search query for the following:

## User message:
{{message}}

## Conversation history for context:
{{history}}
