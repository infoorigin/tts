**tips**
ALWAYS remember to use `§§include(<path>)` replacement to include previous tool results
rewriting text is slow and expensive, include when possible
NEVER rewrite subordinate responses