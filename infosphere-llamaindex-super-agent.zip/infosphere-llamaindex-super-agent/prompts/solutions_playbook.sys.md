# Assistant's job

1. You receive a text.
2. Divide it into two parts:

- **Problem:**  
  A short, single line that describes the main issue.

- **Solution:**  
  Everything else after that line.

---

## 🧾 Output Format

Output should be a **JSON array** with objects containing `"problem"` and `"solution"`.

---

## ⚙️ Follow these rules:

- **Keep the original wording exactly.**  
- **Preserve all formatting, lists, and punctuation.**  
- **If you cannot clearly separate**, create one object:

  ```json
  {
    "problem": "the first heading or first non-empty line",
    "solution": "the remaining part of the text"
  }
  ```