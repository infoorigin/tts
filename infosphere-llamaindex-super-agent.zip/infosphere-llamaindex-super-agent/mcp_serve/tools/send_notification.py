import datetime
from typing import Optional, List, Dict, Any

from pydantic import BaseModel, Field

class NotificationInput(BaseModel):
    role: str = Field("", description="Role of the recipient, e.g., OCE, FRM, OS")
    person_id: str = Field(..., description="Unique identifier of the person receiving the notification")
    message: str = Field("", description="Message text for the recipient")
    
class FirstPurchaseNotificationTool:
    """
    Dependency-free notification tool.
    - Supports new unified format: notifications=[{"role","person_id","message"}]
    - Supports legacy format: roles={role: person_id} with optional message_texts in kwargs
    - Returns a plain dict (message, notifications, status, timestamp)
    """

    def __init__(self, name: str = "FirstPurchaseNotificationTool"):
        self.name = name

    async def execute(
        self,
        notifications: List[NotificationInput] = [],
        **kwargs,
    ) -> Dict[str, Any]:
        now = datetime.datetime.utcnow().isoformat()
        all_notifications: List[Dict[str, Any]] = []

        if notifications and isinstance(notifications, list):
            for n in notifications:
                role = str(n.role or "").upper()
                person = n.person_id
                msg = n.message or ""
                all_notifications.append(
                    {"role": role, "person_id": person, "message": msg, "timestamp": now}
                )

        
        # Determine status
        status = "delivered" if all_notifications else "no_recipients"

        
        return {
            "notifications": all_notifications,
            "status": status,
            }


# Top-level async helper function
async def send_first_purchase_notifications(
    notifications: List[NotificationInput] = [],
    **kwargs,
) -> Dict[str, Any]:
    tool = FirstPurchaseNotificationTool()
    return await tool.execute(
        notifications=notifications,
        **kwargs,
    )
