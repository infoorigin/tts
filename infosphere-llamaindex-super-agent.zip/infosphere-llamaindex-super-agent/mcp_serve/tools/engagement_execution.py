import uuid
import datetime
from typing import Callable, Dict, Any, List, Optional, Set,Tuple

from pydantic import BaseModel, Field

class PlannedTask(BaseModel):
    role: str = Field(..., description="Role responsible for the task, e.g., OCE, FRM, MANAGER.")
    task_name: Optional[str] = Field(None, description="Short name or identifier of the task.")
    due_date: Optional[str] = Field(None, description="ISO-8601 date for when the task is due.")

class EngagementInput(BaseModel):
    territory: str = Field(..., description="Territory identifier for which the plan is validated.", example="US_WEST")
    assignments: Optional[Dict[str, str]] = Field(
        None, description="Optional mapping of roles to assigned user IDs.", example={"OCE": "123", "FRM": "456"}
    )
    planned_tasks: List[PlannedTask] = Field(..., description="List of planned engagement tasks.")


class EngagementPlanValidationTool:
    """
    Generic engagement plan validator (no external base classes).
    - execute(...) -> returns plain dict (no Response class required).
    - By default requires roles OCE and FRM to have at least one planned task.
    - You can provide a `validation_fn(plan_summary) -> (validated: bool, issues: List[str])`
      to plug in custom or more complex rules.
    """

    def __init__(self, name: str = "EngagementPlanValidationTool"):
        self.name = name

    async def execute(
        self,
        territory: str = "default",
        planned_tasks: Optional[List[Dict[str, Any]]] = [],
        **kwargs,
    ) -> Dict[str, Any]:
        """
        Validate planned tasks and return a plan id and summary.

        :param territory: territory identifier
        :param planned_tasks: list of task dicts, each ideally containing a "role" key
        :param validation_fn: optional function(plan_summary) -> (validated: bool, issues: List[str])
        :param kwargs: extra args (ignored by default)
        :return: plain dict with message, status, plan_summary, issues
        """
        now_iso = datetime.datetime.utcnow().isoformat()
        plan_id = str(uuid.uuid4())
        tasks = planned_tasks or []

        # roles extracted safely
        roles_with_tasks: Set[str] = {str(t.get("role")).upper() for t in tasks if t.get("role")}
        required_roles: Set[str] = {"OCE", "FRM"}

        # default validation logic
        issues: List[str] = []
        validated = True

        if not required_roles.issubset(roles_with_tasks):
            validated = False
            missing = required_roles - roles_with_tasks
            issues.append(f"Missing required tasks for role(s): {', '.join(sorted(missing))}")

        # Allow custom validation function to augment/override
    
        plan_summary = {
            "plan_id": plan_id,
            "territory": territory,
            "tasks_count": len(tasks),
            "roles_with_tasks": sorted(list(roles_with_tasks)),
            "issues": issues.copy(),
            "created_at": now_iso,
        }

        # set status
        if not tasks:
            status = "no_tasks"
        elif validated and not issues:
            status = "validated"
        elif issues:
            status = "issues"
        else:
            status = "validated" if validated else "issues"

        # create message
        if status == "validated":
            message = (
                f"Engagement plan for territory '{territory}' validated successfully — "
                f"status: {status}. Plan ID: {plan_id}. "
                f"Roles covered: {', '.join(plan_summary['roles_with_tasks']) or 'none'}. "
                f"Total tasks: {plan_summary['tasks_count']}."
            )
        elif status == "issues":
            message = (
                f"Engagement plan validation for territory '{territory}' completed — "
                f"status: {status}. Issues found: {', '.join(issues)}. "
                f"Plan ID: {plan_id}."
            )
        else:  # no_tasks
            message = (
                f"Engagement plan validation for territory '{territory}' completed — "
                f"status: {status}. No tasks provided. Plan ID: {plan_id}."
            )

        return {
            "message": message,
            "status": status,
            "plan_summary": plan_summary,
            "issues": issues,
            }


# Top-level async helper function (returns dict)
async def engagement_check(territory: str = "default_territory", 
                           planned_tasks: List[PlannedTask]=[]) -> Dict[str, Any]:
    tool = EngagementPlanValidationTool()
    tasks_as_dictionaries = [task.model_dump() for task in planned_tasks]
    return await tool.execute(territory=territory, planned_tasks=tasks_as_dictionaries)

