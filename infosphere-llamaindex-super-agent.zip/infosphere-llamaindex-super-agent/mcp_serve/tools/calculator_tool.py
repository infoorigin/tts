# calculator_tool.py
import ast
from typing import Union

class _SafeEval(ast.NodeVisitor):
    """
    Evaluate arithmetic expressions safely by walking the AST and allowing only
    arithmetic operations and numeric constants.
    """

    ALLOWED_BINOPS = {
        ast.Add: lambda a, b: a + b,
        ast.Sub: lambda a, b: a - b,
        ast.Mult: lambda a, b: a * b,
        ast.Div: lambda a, b: a / b,
        ast.Mod: lambda a, b: a % b,
        ast.FloorDiv: lambda a, b: a // b,
        ast.Pow: lambda a, b: a ** b,
    }

    ALLOWED_UNARYOPS = {
        ast.UAdd: lambda a: +a,
        ast.USub: lambda a: -a,
    }


def _normalize(expr: str) -> str:
    """
    Minimal safe normalizations:
      - replace unicode multiplication '×' with '*'
      - treat '^' as power operator and convert to '**'
    We intentionally do not perform any heavy parsing/word-to-operator conversions.
    """
    return expr.replace("×", "*").replace("^", "**")


def safe_eval_expression(expression: str) -> str:
    """
    Safely evaluate a basic arithmetic expression and return an int or float.
    Raises ValueError on invalid/unsafe input.
    """
    if not isinstance(expression, str) or not expression.strip():
        raise ValueError("Empty or non-string expression")

    expr = _normalize(expression.strip())

    # parse to AST in 'eval' mode
    try:
        parsed = ast.parse(expr, mode="eval")
    except SyntaxError as se:
        raise ValueError(f"Syntax error in expression: {se}")

    evaluator = _SafeEval()
    result = evaluator.visit(parsed)

    # return int when value is integer-like
    if isinstance(result, float) and result.is_integer():
        return int(result)
    print("Result from mcp calculator tool:", result)
    return result
