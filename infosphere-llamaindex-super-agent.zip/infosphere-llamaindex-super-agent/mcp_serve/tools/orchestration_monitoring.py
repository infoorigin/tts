import datetime
from typing import Dict, Any, Optional


class OrchestrationMonitoringClosureTool:
    """
    Generic, dependency-free version of OrchestrationMonitoringClosureTool.
    Monitors SLA adherence and task completion, determines closure status,
    and returns a uniform dict output suitable for orchestration systems.
    """

    def __init__(self, name: str = "OrchestrationMonitoringClosureTool"):
        self.name = name

    async def execute(
        self,
        territory: str = "default",
        plan_id: Optional[str] = None,
        metrics: Optional[Dict[str, Any]] = None,
        **kwargs,
    ) -> Dict[str, Any]:
        """
        Evaluate orchestration closure readiness.

        :param territory: str — the operational territory.
        :param plan_id: str — the engagement or orchestration plan ID.
        :param metrics: dict — optional metrics such as SLA % and task counts.
        :return: dict containing message, status, metrics, and timestamp.
        """

        # Default metrics if none provided
        metrics = metrics or {"sla_met_pct": 100, "completed": 3, "pending": 0}

        # Determine status
        if metrics["pending"] == 0 and metrics["sla_met_pct"] == 100:
            status = "closed"
        elif metrics["pending"] > 0 and metrics["sla_met_pct"] >= 80:
            status = "partial"
        else:
            status = "open"
            
        # Construct message
        message = (
            f"Orchestration monitoring for territory '{territory}' completed — status: {status}. "
            f"Plan ID: {plan_id or 'N/A'}. "
            f"SLA met: {metrics.get('sla_met_pct', 'N/A')}%. "
            f"Tasks completed: {metrics.get('completed', 'N/A')}, "
            f"pending: {metrics.get('pending', 'N/A')}."
        )

        # Return a unified result structure
        return {
            "message": message,
            "status": status,
            "metrics": metrics,
            "timestamp": datetime.datetime.utcnow().isoformat(),
        }


# ✅ Top-level async helper for MCP or orchestration engine
async def monitor_closure(
    territory: str = "default",
    plan_id: Optional[str] = None,
    metrics: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    tool = OrchestrationMonitoringClosureTool()
    return await tool.execute(territory=territory, plan_id=plan_id, metrics=metrics)


