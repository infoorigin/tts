from typing import Dict, Any, Optional


class FieldPersonAssignmentTool:
    """
    Generic version of FieldPersonAssignmentTool — no external dependencies.
    Simulates assigning primary persons for each field role in a territory.
    Returns a plain dict instead of a Response object.
    """

    def __init__(self, name: str = "FieldPersonAssignmentTool"):
        self.name = name

    async def execute(
        self,
        territory: str = "default",
        **kwargs,
    ) -> Dict[str, Any]:
        """
        Select primary person for each role.
        Accepts an optional members_list dict keyed by role with candidate entries.
        Returns assigned person info, rationale, and status summary.
        """

        # Mock assignments (can be replaced with real logic)
        assignments = {
            "OS": {"person_id": "os_Robert_Taylor", "rationale": "account owner; nearby"},
            "OCE": {"person_id": "oce_Emily_Davis", "rationale": "closest by proximity; recent engagement"},
            "FRM": {"person_id": "frm_Michael_Lee", "rationale": "assigned payer lead"},
            "MSL": {"person_id": "msl_Sarah_Johnson", "rationale": "standby for MUN"},
        }

        # Determine status
        if not assignments:
            status = "no_assignments"
        elif len(assignments) < 4:
            status = "partial"
        else:
            status = "validated"

        # Build summary message
        assigned_summary = ", ".join(
            f"{role}: {info['person_id']}" for role, info in assignments.items()
        ) or "No assignments available"

        message = (
            f"Field force assignment for territory '{territory}' completed — "
            f"status: {status}. Assignments: {assigned_summary}."
        )

        # Return generic result
        return {
            "status": status,
            "assignments": assignments,
            }


async def assign_field_force(
    territory: str = "default"
) -> Dict[str, Any]:
    tool = FieldPersonAssignmentTool()
    return await tool.execute(territory=territory)

