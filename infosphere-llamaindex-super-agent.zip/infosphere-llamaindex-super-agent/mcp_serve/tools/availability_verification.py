import os
from typing import Callable, Dict, Any, Tuple, Optional

current_dir = os.path.dirname(os.path.abspath(__file__))
print(f"Current directory: {current_dir}")


class AssignedPersonAvailabilityTool:
    """
    Generic availability tool (no external base classes).
    - execute(...) -> returns plain dict (no Response class required).
    - accepts assignments in either format:
        {"OS": {"person_id": "abc"}}  or  {"OS": "abc"}
    - optional availability_check callback can be provided:
        availability_check(role: str, person_id: str, territory: str, **kwargs)
            -> (available: bool, notes: str)
    """

    def __init__(self, name: str = "AssignedPersonAvailabilityTool"):
        self.name = name

    async def execute(
        self,
        assignments: Optional[Dict[str, Any]] = None,
        territory: str = "default",
        **kwargs,
    ) -> Dict[str, Any]:
        """
        Check availability for each assigned role/person.

        :param assignments: dict of role -> person or dict. Example:
            {"OS": {"person_id": "abc"}, "OCE": "xyz"}
        :param territory: territory identifier (used for message/logging)
        :param availability_check: optional callback(role, person_id, territory) -> (available, notes)
        :param kwargs: extra args, ignored by default (keeps function generic)
        :return: dict with keys: message, status, availability
        """
        availability: Dict[str, Dict[str, Any]] = {}

        # default availability logic if none provided
        def _default_check(role: str, person_id: str, terr: str) -> Tuple[bool, str]:
            # simple mock: OS has travel note, others available
            if role.upper() == "OS":
                return True, "On planned travel (expected back in 3 days)"
            return True, "Available"

        checker =  _default_check

        for role, info in (assignments or {}).items():
            # handle both nested and flat formats
            if isinstance(info, dict):
                pid = info.get("person_id") or info.get("id") or f"{role}_unknown"
            else:
                pid = str(info)

            try:
                available, notes = checker(role, pid, territory)
            except Exception as e:
                # If provided checker fails, mark as unavailable and include error note
                available = False
                notes = f"availability_check error: {e!s}"

            availability[role] = {"person_id": pid, "available": bool(available), "notes": str(notes)}

        # derive overall status
        if not availability:
            status = "no_assignments"
        elif all(v["available"] for v in availability.values()):
            status = "all_available"
        elif any(v["available"] for v in availability.values()):
            status = "partial_unavailable"
        else:
            status = "all_unavailable"

        return {
            "status": status,
            "availability": availability,
            }


# Top-level async helper function (returns dict)
async def check_availability(assignments: Optional[Dict[str, Any]] = None, territory: str = "default") -> Dict[str, Any]:
    tool = AssignedPersonAvailabilityTool()
    return await tool.execute(assignments=assignments, territory=territory)


