# client_test.py
import asyncio
from fastmcp.client import Client

async def main():
    async with Client("http://127.0.0.1:3000/mcp") as client:
        print("\n--- Test external API ---")
        api_result = await client.call_tool("get_external_data", {"query": "test"})
        print(api_result)

        print("\n--- Test CLI command ---")
        cmd_result = await client.call_tool("run_external_command", {"command": "echo Hello MCP"})
        print(cmd_result)

asyncio.run(main()) 
