# server.py
import asyncio
from typing import  List
from fastmcp import FastMCP
from pydantic import Field

from tools.availability_verification import check_availability
from tools.engagement_execution import PlannedTask, engagement_check
from tools.field_force_assignment_tool import assign_field_force
from tools.orchestration_monitoring import monitor_closure
from tools.send_notification import NotificationInput, send_first_purchase_notifications
from tools.territory_alignment_tool import check_territory_alignment 
from tools.calculator_tool import safe_eval_expression  
 
mcp = FastMCP(
    name="Meta MCP Server",
    instructions="MCP server that calls external APIs and tools",
)

@mcp.tool(name="territory_alignment_tool",
          description="Verifies the territory alignment  for a given account.",
          output_schema={
            "type": "object",
            "properties": {
                "territory": {"type": "string", "description": "Territory assigned to the account"}
                    }
            }
)
async def territory_alignment_tool(
    account: str = Field(
        default="default_account",
        description="Account identifier to check territory alignment for."
    )
):
    return await check_territory_alignment(account=account)


@mcp.tool(name="field_force_assignment",
          description="Assigns primary persons for each field role in a territory. Returns assigned person info, rationale, and status summary.",
          output_schema={
            "type": "object",
            "properties": {
                "status": {"type": "string", "description": "Status of the assignments"},
                "assignments": {
                    "type": "object",
                    "description": "Assigned persons for each role with rationale",
                    "additionalProperties": {
                        "type": "object",
                        "properties": {
                            "person_id": {"type": "string", "description": "Identifier of the assigned person"},
                            "rationale": {"type": "string", "description": "Rationale for the assignment"}
                        }
                    }
                },
                    }
            }
)
async def assign_field_persons(territory: str = Field(
        default="default_territory",
        description="Account Territory  for which to assign field force persons."
    )):
    return await assign_field_force(territory=territory)


@mcp.tool(name="availability_verification",
          description="Verifies the availability of assigned persons for each role in a territory.",
          output_schema={
            "type": "object",
            "properties": {
                "status": {"type": "string", "description": "Overall availability status"},
                "availability": {
                    "type": "object",
                    "description": "Availability details for each role",
                    "additionalProperties": {
                        "type": "object",
                        "properties": {
                            "person_id": {"type": "string", "description": "Identifier of the person"},
                            "available": {"type": "boolean", "description": "Availability status"},
                            "notes": {"type": "string", "description": "Additional notes on availability"}
                        }
                    }
                },
                    }
            }
)
async def assigned_person_availability(
    assignments: dict = Field(
        default={},
        description="Assigned persons for each role to verify availability for.",
        examples=[{"OS": {"person_id": "abc"}, "OCE": "xyz"}]
    ),
    territory: str = Field(
        default="default_territory",
        description="Account Territory to verify availability for."
)):
    return await check_availability(assignments, territory)

@mcp.tool(name="send_notification",
          description="Sends notifications to specified roles.  Returns status and details of the notification process.", 
          output_schema={
            "type": "object",
            "properties": {
                "status": {"type": "string", "description": "Status of the notification sending process"},
                "details": {"type": "string", "description": "Additional details about the notification process"}
                    }
            }
)
async def first_purchase_notify_tool(notifications: List[NotificationInput] = Field(
        default_factory=list,
        description=(
            "List of notification objects, each containing role, person_id, and message. "
            "Supports unified format: [{'role': 'OS', 'person_id': 'abc', 'message': '...'}]"
        ))
    ):
    return await send_first_purchase_notifications(notifications=notifications)




@mcp.tool(name="engagement_execution",
          description="Validates and executes engagement plans based on assignments and territory.",
          output_schema={
        "type": "object",
        "properties": {
            "message": {"type": "string"},
            "status": {"type": "string"},
            "plan_summary": {"type": "object"},
            "issues": {"type": "array", "items": {"type": "string"}},
            }
    }  
          )
async def validate_engagement(territory: str = "default_territory",
                              planned_tasks: List[PlannedTask] = Field([], description="List of planned engagement tasks.")):
    return await engagement_check(territory=territory, planned_tasks=planned_tasks)


@mcp.tool(name="orchestration_monitoring",
          description="Monitors the closure of orchestration plans and provides metrics.")
async def monitor_closure_tool(territory: str = "default_territory", plan_id: str = "", metrics: dict = {}):
    return await monitor_closure(territory=territory, plan_id=plan_id, metrics=metrics)





if __name__ == "__main__":
    asyncio.run(mcp.run_http_async(transport="http", host="127.0.0.1", port=3000, path="/mcp"))
