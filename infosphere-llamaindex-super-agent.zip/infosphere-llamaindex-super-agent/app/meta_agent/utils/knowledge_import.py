import glob
import os
import hashlib
import asyncio
from typing import Any, Dict, Literal, TypedDict
from llama_index.core import Document
from app.meta_agent.utils.file_document_reader import FileDocumentReader
from app.meta_agent.utils.agent_activity import AgentActivityItem
from app.meta_agent.utils.print_style import PrintStyle
from app.meta_agent.utils.dirty_json import DirtyJson
from app.meta_agent.agent import AgentContext


class KnowledgeImport(TypedDict):
    file: str
    checksum: str
    ids: list[str]
    state: Literal["changed", "original", "removed"]
    documents: list[Any]


def calculate_checksum(file_path: str) -> str:
    """Generate MD5 checksum of a file."""
    hasher = hashlib.md5()
    with open(file_path, "rb") as f:
        # Safer: read in chunks to avoid memory blowup on very large files
        for chunk in iter(lambda: f.read(8192), b""):
            hasher.update(chunk)
    return hasher.hexdigest()


def load_knowledge(
    log_item: AgentActivityItem | None,
    knowledge_dir: str,
    index: Dict[str, KnowledgeImport],
    metadata: dict[str, Any] = {},
    filename_pattern: str = "**/*",
) -> Dict[str, KnowledgeImport]:
    """
    Load knowledge files from a directory with change detection and metadata enhancement.
    """

    cnt_files = 0
    cnt_docs = 0
    reader = FileDocumentReader()

    # Validate knowledge directory
    if not knowledge_dir:
        if log_item:
            log_item.stream(progress="\nNo knowledge directory specified")
        PrintStyle(font_color="yellow").print("No knowledge directory specified")
        return index

    if not os.path.exists(knowledge_dir):
        try:
            os.makedirs(knowledge_dir, exist_ok=True)
            if not os.path.exists(knowledge_dir) or not os.access(knowledge_dir, os.R_OK):
                error_msg = f"Knowledge directory {knowledge_dir} was created but is not accessible"
                if log_item:
                    log_item.stream(progress=f"\n{error_msg}")
                PrintStyle(font_color="red").print(error_msg)
                return index

            if log_item:
                log_item.stream(progress=f"\nCreated knowledge directory: {knowledge_dir}")
            PrintStyle(font_color="green").print(f"Created knowledge directory: {knowledge_dir}")
        except (OSError, PermissionError) as e:
            error_msg = f"Failed to create knowledge directory {knowledge_dir}: {e}"
            if log_item:
                log_item.stream(progress=f"\n{error_msg}")
            PrintStyle(font_color="red").print(error_msg)
            return index

    if not os.access(knowledge_dir, os.R_OK):
        error_msg = f"Knowledge directory {knowledge_dir} exists but is not readable"
        if log_item:
            log_item.stream(progress=f"\n{error_msg}")
        PrintStyle(font_color="red").print(error_msg)
        return index

    # Discover files
    try:
        kn_files = glob.glob(os.path.join(knowledge_dir, filename_pattern), recursive=True)
        kn_files = [f for f in kn_files if os.path.isfile(f) and not os.path.basename(f).startswith(".")]
    except Exception as e:
        PrintStyle(font_color="red").print(f"Error scanning knowledge directory {knowledge_dir}: {e}")
        if log_item:
            log_item.stream(progress=f"\nError scanning directory: {e}")
        return index

    if kn_files:
        PrintStyle.standard(f"Found {len(kn_files)} knowledge files in {knowledge_dir}, processing...")
        if log_item:
            log_item.stream(progress=f"\nFound {len(kn_files)} knowledge files in {knowledge_dir}, processing...")

    # Process each file
    for file_path in kn_files:
        try:
            # Skip unsupported extensions explicitly (prevents accidental binary ingestion)
            if not reader.is_supported(file_path):
                continue

            checksum = calculate_checksum(file_path)
            if not checksum:
                continue

            file_key = file_path
            file_data: KnowledgeImport = index.get(
                file_key,
                {
                    "file": file_key,
                    "checksum": "",
                    "ids": [],
                    "state": "changed",
                    "documents": [],
                },
            )

            # Change detection
            if file_data.get("checksum") == checksum:
                file_data["state"] = "original"
            else:
                file_data["state"] = "changed"

            # Load changed files
            if file_data["state"] == "changed":
                file_data["checksum"] = checksum

                try:
                    raw_docs = reader.load_data(file_path)

                    enhanced_metadata = {
                        **metadata,
                        "source_file": os.path.basename(file_path),
                        "source_path": file_path,
                        "file_type": os.path.splitext(file_path)[-1].lstrip(".").lower(),
                        "knowledge_source": True,
                        "import_timestamp": None,
                        "agent_role": metadata.get("agent_role", "meta"),
                    }

                    # PLAYBOOK branch — only run if area == "playbook"
                    if enhanced_metadata.get("area") == "playbook":
                        # build combined text
                        combined_text = ""
                        for d in raw_docs:
                            if isinstance(d, str):
                                combined_text += d + "\n\n"
                            elif hasattr(d, "get_content"):
                                try:
                                    combined_text += d.get_content() + "\n\n"
                                except Exception:
                                    combined_text += str(d) + "\n\n"
                            else:
                                combined_text += str(d) + "\n\n"

                        provided_pb_id = metadata.get("playbook_id")
                        stable_id = (
                            str(provided_pb_id)
                            if provided_pb_id
                            else hashlib.sha1((file_path + checksum).encode("utf-8")).hexdigest()[:16]
                        )
                        enhanced_metadata["playbook_id"] = stable_id
                        enhanced_metadata["area"] = "playbook"

                        docs_to_insert: list[Document] = []

                        try:
                            # Try to locate AgentContext and an agent instance
                            try:
                                ctx = AgentContext.first()
                                agent_for_util = ctx.get_agent() if ctx else None
                            except Exception as e:
                                agent_for_util = None
                                PrintStyle(font_color="yellow").print(f"AgentContext lookup failed: {e}")

                            util_response = None
                            parsed = None

                            if agent_for_util:
                                # attempt to read system prompt
                                try:
                                    system_prompt = agent_for_util.read_prompt("solutions_playbook.sys.md")

                                except Exception as e:
                                    system_prompt = None
                                    PrintStyle(font_color="yellow").print(f"Playbook: read_prompt failed: {e}")

                                # call utility model synchronously (safe fallback for running loops)
                                try:
                                    try:
                                        util_response = asyncio.run(
                                            agent_for_util.call_utility_model(
                                                system=system_prompt, message=combined_text, callback=None, background=False
                                            )
                                        )
                                    except RuntimeError:
                                        loop = asyncio.get_event_loop()
                                        util_response = loop.run_until_complete(
                                            agent_for_util.call_utility_model(
                                                system=system_prompt, message=combined_text, callback=None, background=False
                                            )
                                        )
                                except Exception as e:
                                    util_response = None
                                    PrintStyle(font_color="yellow").print(f"Playbook: utility LLM call failed: {e}")

                                # parse LLM output
                                # print(util_response)
                                if isinstance(util_response, str) and util_response.strip():
                                    try:
                                        parsed = DirtyJson.parse_string(util_response.strip())
                                    except Exception as e:
                                        parsed = None
                                        PrintStyle(font_color="yellow").print(f"Playbook: DirtyJson parse failed: {e}")

                            else:
                                PrintStyle.standard("Playbook: no agent_for_util available — will use fallback if needed.")

                            # Build entries from parsed or fallback
                            if isinstance(parsed, list):
                                entries = parsed
                            elif isinstance(parsed, dict):
                                entries = [parsed]
                            else:
                                entries = [{"problem": os.path.basename(file_path), "solution": combined_text}]


                            # Create Documents from entries (preserve text)
                            for entry in entries:
                                try:
                                    prob = entry.get("problem", "") if isinstance(entry, dict) else ""
                                    sol = entry.get("solution", "") if isinstance(entry, dict) else ""
                                    txt = f"# Problem\n{prob}\n\n# Solution\n{sol}"
                                    md = {**enhanced_metadata, "playbook_id": stable_id, "area": "playbook"}
                                    docs_to_insert.append(Document(text=txt, metadata=md))
                                except Exception as e:
                                    PrintStyle(font_color="yellow").print(f"Playbook: failed to build document from entry: {e}")

                            # final safety: ensure at least one doc exists
                            if not docs_to_insert:
                                PrintStyle(font_color="yellow").print(
                                    f"No documents produced for playbook {file_path} — inserting raw fallback."
                                )
                                txt = f"# Problem\n{os.path.basename(file_path)}\n\n# Solution\n{combined_text}"
                                md = {**enhanced_metadata, "playbook_id": stable_id, "area": "playbook"}
                                docs_to_insert = [Document(text=txt, metadata=md)]

                        except Exception as e:
                            PrintStyle(font_color="red").print(f"Unexpected error in playbook processor for {file_path}: {e}")
                            # fallback single raw doc on hard failure
                            txt = f"# Problem\n{os.path.basename(file_path)}\n\n# Solution\n{combined_text}"
                            md = {**enhanced_metadata, "playbook_id": stable_id, "area": "playbook"}
                            docs_to_insert = [Document(text=txt, metadata=md)]

                        # attach and count for playbook
                        file_data["documents"] = docs_to_insert
                        cnt_files += 1
                        cnt_docs += len(docs_to_insert)


                    else:
                        # NON-PLAYBOOK: original behavior
                        documents: list[Document] = []
                        for doc in raw_docs:
                            if isinstance(doc, Document):
                                doc.metadata = {**getattr(doc, "metadata", {}), **enhanced_metadata}
                                documents.append(doc)
                            else:
                                documents.append(Document(text=str(doc), metadata=enhanced_metadata))

                        file_data["documents"] = documents
                        cnt_files += 1
                        cnt_docs += len(documents)

                except Exception as e:
                    PrintStyle(font_color="red").print(f"Error loading {file_path}: {e}")
                    if log_item:
                        log_item.stream(progress=f"\nError loading {os.path.basename(file_path)}: {e}")
                    continue

            index[file_key] = file_data

        except Exception as e:
            PrintStyle(font_color="red").print(f"Error processing {file_path}: {e}")
            continue

    # Mark removed files
    current_files = set(kn_files)
    for file_key, file_data in list(index.items()):
        if file_key not in current_files and not file_data.get("state"):
            index[file_key]["state"] = "removed"

    # Final logging
    if cnt_files > 0 or cnt_docs > 0:
        PrintStyle.standard(f"Processed {cnt_docs} documents from {cnt_files} files.")
        if log_item:
            log_item.stream(progress=f"\nProcessed {cnt_docs} documents from {cnt_files} files.")

    return index
