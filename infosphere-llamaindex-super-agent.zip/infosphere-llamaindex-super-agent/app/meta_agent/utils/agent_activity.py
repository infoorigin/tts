from dataclasses import dataclass, field
import json
from typing import  Literal, Optional, TypeVar, Callable
import asyncio

from app.meta_agent.utils.agent_activity_dispatcher import LogDispatcher

T = TypeVar("T")
import uuid
from collections import OrderedDict  # Import OrderedDict
from app.meta_agent.utils.strings import truncate_text_by_ratio
import copy
from typing import TypeVar

T = TypeVar("T")

Type = Literal[
    "agent",
    "browser",
    "code_exe",
    "error",
    "hint",
    "info",
    "progress",
    "response",
    "tool",
    "input",
    "user",
    "util",
    "warning",
]

ProgressUpdate = Literal["persistent", "temporary", "none"]


HEADING_MAX_LEN: int = 120
CONTENT_MAX_LEN: int = 10000
KEY_MAX_LEN: int = 60
VALUE_MAX_LEN: int = 3000
PROGRESS_MAX_LEN: int = 120


def _truncate_heading(text: str | None) -> str:
    if text is None:
        return ""
    return truncate_text_by_ratio(str(text), HEADING_MAX_LEN, "...", ratio=1.0)


def _truncate_progress(text: str | None) -> str:
    if text is None:
        return ""
    return truncate_text_by_ratio(str(text), PROGRESS_MAX_LEN, "...", ratio=1.0)


def _truncate_key(text: str) -> str:
    return truncate_text_by_ratio(str(text), KEY_MAX_LEN, "...", ratio=1.0)


def _truncate_value(val: T) -> T:
    # If dict, recursively truncate each value
    if isinstance(val, dict):
        for k in list(val.keys()):
            v = val[k]
            del val[k]
            val[_truncate_key(k)] = _truncate_value(v)
        return val
    # If list or tuple, recursively truncate each item
    if isinstance(val, list):
        for i in range(len(val)):
            val[i] = _truncate_value(val[i])
        return val
    if isinstance(val, tuple):
        return tuple(_truncate_value(x) for x in val) # type: ignore

    # Convert non-str values to json for consistent length measurement
    if isinstance(val, str):
        raw = val
    else:
        try:
            raw = json.dumps(val, ensure_ascii=False)
        except Exception:
            raw = str(val)

    if len(raw) <= VALUE_MAX_LEN:
        return val  # No truncation needed, preserve original type

    # Do a single truncation calculation
    removed = len(raw) - VALUE_MAX_LEN
    replacement = f"\n\n<< {removed} Characters hidden >>\n\n"
    truncated = truncate_text_by_ratio(raw, VALUE_MAX_LEN, replacement, ratio=0.3)
    return truncated


def _truncate_content(text: str | None) -> str:
    if text is None:
        return ""
    raw = str(text)
    if len(raw) <= CONTENT_MAX_LEN:
        return raw

    # Same dynamic replacement logic as value truncation
    removed = len(raw) - CONTENT_MAX_LEN
    while True:
        replacement = f"\n\n<< {removed} Characters hidden >>\n\n"
        truncated = truncate_text_by_ratio(raw, CONTENT_MAX_LEN, replacement, ratio=0.3)
        new_removed = len(raw) - (len(truncated) - len(replacement))
        if new_removed == removed:
            break
        removed = new_removed
    return truncated


def _mask_recursive(obj: T) -> T:
    """Recursively mask secrets in nested objects."""
    try:
        from app.meta_agent.utils.secrets import SecretsManager

        secrets_mgr = SecretsManager.get_instance()

        if isinstance(obj, str):
            return secrets_mgr.mask_values(obj)
        elif isinstance(obj, dict):
            return {k: _mask_recursive(v) for k, v in obj.items()}  # type: ignore
        elif isinstance(obj, list):
            return [_mask_recursive(item) for item in obj]  # type: ignore
        else:
            return obj
    except Exception as _e:
        # If masking fails, return original object
        return obj


@dataclass
class AgentActivityItem:
    agent_activity: "AgentActivity"
    no: int
    type: str
    heading: str = ""
    content: str = ""
    temp: bool = False
    update_progress: Optional[ProgressUpdate] = "persistent"
    kvps: Optional[OrderedDict] = None  # Use OrderedDict for kvps
    id: Optional[str] = None  # Add id field
    guid: str = ""

    def __post_init__(self):
        self.guid = self.agent_activity.guid

    def update(
        self,
        type: Type | None = None,
        heading: str | None = None,
        content: str | None = None,
        kvps: dict | None = None,
        temp: bool | None = None,
        update_progress: ProgressUpdate | None = None,
        **kwargs,
    ):
        """Update this item and notify observers."""
        if self.guid == self.agent_activity.guid:
            self.agent_activity._update_item(
                self.no,
                type=type,
                heading=heading,
                content=content,
                kvps=kvps,
                temp=temp,
                update_progress=update_progress,
                **kwargs,
            )
            # Note: _update_item calls _notify_observers automatically

    def stream(
        self,
        heading: str | None = None,
        content: str | None = None,
        **kwargs,
    ):
        """Stream content updates and notify observers."""
        if heading is not None:
            self.update(heading=self.heading + heading)
        if content is not None:
            self.update(content=self.content + content)

        for k, v in kwargs.items():
            prev = self.kvps.get(k, "") if self.kvps else ""
            self.update(**{k: prev + v})

    def output(self):
        return {
            "no": self.no,
            "id": self.id,  # Include id in output
            "type": self.type,
            "heading": self.heading,
            "content": self.content,
            "temp": self.temp,
            "kvps": self.kvps,
        }


class AgentActivity:
    """
    AgentActivity with optional observer pattern for publishing.
    
    All methods are synchronous - publishing is handled via observers.
    This keeps the class simple and avoids async complexity.
    """

    def __init__(self, context_id:str):
        self.context_id = context_id
        self.guid: str = str(uuid.uuid4())
        self.updates: list[int] = []
        self.agent_activities: list[AgentActivityItem] = []
        self._observers: list[Callable[[int], None]] = []  # Callbacks for updates
        self._auto_publish_enabled: bool = False  # ✅ DUPLICATE PREVENTION FLAG
        self.set_initial_progress()

    def latest_item_no(self) -> int:
        """Get the latest item number."""
        return len(self.agent_activities) - 1
    # =========================================================================
    # OBSERVER PATTERN (Optional - for auto-publishing)
    # =========================================================================

    def add_observer(self, callback: Callable[[int], None]):
        """
        Add an observer that gets called when items are updated.
        
        The callback receives the item number that was updated.
        
        Usage:
            def on_update(item_no: int):
                asyncio.create_task(publish_item(activity, item_no))
            
            activity.add_observer(on_update)
        """
        self._observers.append(callback)
    
    def remove_observer(self, callback: Callable[[int], None]):
        """Remove an observer callback."""
        if callback in self._observers:
            self._observers.remove(callback)
    
    def _notify_observers(self, item_no: int):
        """Notify all observers that an item was updated."""
        for observer in self._observers:
            try:
                observer(item_no)
            except Exception as e:
                print(f"[AgentActivity] Observer error: {e}")

    def get_agent_activity_items(self, start_post: int | None = None, end_post: int | None = None):
        """
        Return a slice of agent_activities in their current state.

        Args:
            start_post: starting index (inclusive)
            end_post: ending index (exclusive)

        Returns:
            List[dict] with each item's output().

        Notes:
            - Unlike `output()`, this does NOT deduplicate based on update order.
            - Items are returned in creation order.
        """
        # Default slice semantics
        if start_post is None:
            start_post = 0
        if end_post is None:
            end_post = len(self.agent_activities)

        # Handle empty or reversed ranges safely
        if start_post < 0:
            start_post = 0
        if end_post < start_post:
            return []

        result = []
        for item in self.agent_activities:
            if start_post <= item.no <= end_post:   # inclusive of start_post and end_post
                result.append(item.output())

        return result
    
    # =========================================================================
    # ORIGINAL METHODS (Unchanged logic)
    # =========================================================================

    def add_agent_activity(
        self,
        type: Type,
        heading: str | None = None,
        content: str | None = None,
        kvps: dict | None = None,
        temp: bool | None = None,
        update_progress: ProgressUpdate | None = None,
        id: Optional[str] = None,  # Add id parameter
        **kwargs,
    ) -> AgentActivityItem:

        # add a minimal item to the log
        item = AgentActivityItem(
            agent_activity=self,
            no=len(self.agent_activities),
            type=type,
        )
        self.agent_activities.append(item)

        # and update it (to have just one implementation)
        self._update_item(
            no=item.no,
            type=type,
            heading=heading,
            content=content,
            kvps=kvps,
            temp=temp,
            update_progress=update_progress,
            id=id,
            **kwargs,
        )
        return item

    def _update_item(
        self,
        no: int,
        type: str | None = None,
        heading: str | None = None,
        content: str | None = None,
        kvps: dict | None = None,
        temp: bool | None = None,
        update_progress: ProgressUpdate | None = None,
        id: Optional[str] = None,  # Add id parameter
        **kwargs,
    ):
        item = self.agent_activities[no]

        # adjust all content before processing
        if heading is not None:
            heading = _mask_recursive(heading)
            heading = _truncate_heading(heading)
            item.heading = heading
        if content is not None:
            content = _mask_recursive(content)
            content = _truncate_content(content)
            item.content = content
        if kvps is not None:
            kvps = OrderedDict(copy.deepcopy(kvps))
            kvps = _mask_recursive(kvps)
            kvps = _truncate_value(kvps)
            item.kvps = kvps
        elif item.kvps is None:
            item.kvps = OrderedDict()
        if kwargs:
            kwargs = copy.deepcopy(kwargs)
            kwargs = _mask_recursive(kwargs)
            item.kvps.update(kwargs)

        if type is not None:
            item.type = type

        if update_progress is not None:
            item.update_progress = update_progress

        if temp is not None:
            item.temp = temp

        if id is not None:
            item.id = id

        self.updates += [item.no]
        self._update_progress_from_item(item)
        
        # Notify observers (if any)
        self._notify_observers(item.no)

    def set_progress(self, progress: str, no: int = 0, active: bool = True):
        progress = _mask_recursive(progress)
        progress = _truncate_progress(progress)
        self.progress = progress
        if not no:
            no = len(self.agent_activities)
        self.progress_no = no
        self.progress_active = active

    def set_initial_progress(self):
        self.set_progress("Waiting for input", 0, False)

    def output(self, start=None, end=None):
        if start is None:
            start = 0
        if end is None:
            end = len(self.updates)

        out = []
        seen = set()
        for update in self.updates[start:end]:
            if update not in seen:
                out.append(self.agent_activities[update].output())
                seen.add(update)

        return out

    def reset(self):
        self.guid = str(uuid.uuid4())
        self.updates = []
        self.agent_activities = []
        self.set_initial_progress()

    def _update_progress_from_item(self, item: AgentActivityItem):
        if item.heading and item.update_progress != "none":
            if item.no >= self.progress_no:
                self.set_progress(
                    item.heading,
                    (item.no if item.update_progress == "persistent" else -1),
                )


# =============================================================================
# HELPER: Setup Auto-Publishing (Optional)
# =============================================================================

def setup_auto_publish(activity: AgentActivity, dispatcher=None):
    """
    Setup automatic publishing for an AgentActivity.
    
    IDEMPOTENT: Safe to call multiple times - only sets up once.
    
    Call this after creating or deserializing an activity to enable
    real-time publishing to clients.
    
    Usage:
        # Option 1: After creating new activity
        activity = AgentActivity()
        setup_auto_publish(activity)
        
        # Option 2: After deserializing
        activity = _deserialize_activity(json_data)
        setup_auto_publish(activity)  # Now publishes new updates
        
        # Option 3: With specific dispatcher
        setup_auto_publish(activity, my_dispatcher)
    
    Args:
        activity: AgentActivity instance
        dispatcher: Optional dispatcher. If None, uses singleton.
    """
    # ✅ DUPLICATE PREVENTION: Check if already setup
    if hasattr(activity, '_auto_publish_enabled') and activity._auto_publish_enabled:
        print(f"[setup_auto_publish] Already enabled for {activity.guid}")
        return  # Already setup, do nothing
    
    if dispatcher is None:
        try:
            dispatcher = LogDispatcher.get_instance()
        except Exception as e:
            print(f"[setup_auto_publish] Dispatcher not available: {e}")
            return
    
    def observer(item_no: int):
        """Observer callback that publishes updates"""
        asyncio.create_task(dispatcher.publish(activity, item_no))
    
    activity.add_observer(observer)
    
    # ✅ SET FLAG: Mark as enabled to prevent duplicate setup
    activity._auto_publish_enabled = True
    print(f"[setup_auto_publish] Enabled for {activity.guid}")