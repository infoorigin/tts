from abc import ABC, abstractmethod
from typing import Optional, List, Dict, Any, AsyncIterator
from dataclasses import dataclass
from datetime import datetime
import asyncio
import json


@dataclass
class LogChangeEvent:
    """Represents a change to a log item."""
    event_id: str
    context_id: str
    item_no: int
    item_data: Dict[str, Any]
    timestamp: float


class ILogStorage(ABC):
    """Storage abstraction for distributed log management."""

    @abstractmethod
    async def save_log_item(self, context_id: str, item_no: int, item_data: dict) -> None:
        pass

    @abstractmethod
    async def get_log_items(self, context_id: str) -> List[dict]:
        pass

    @abstractmethod
    async def publish_change(self, context_id: str, item_no: int, item_data: dict) -> str:
        pass

    @abstractmethod
    async def subscribe_changes(
        self, 
        context_id: str,
        after_event_id: str = "0",
        block_ms: Optional[int] = None
    ) -> AsyncIterator[LogChangeEvent]:
        pass


class LocalMemoryLogStorage(ILogStorage):
    """In-memory storage for development/testing."""

    def __init__(self):
        self.logs: Dict[str, List[dict]] = {}
        self.changes: Dict[str, List[LogChangeEvent]] = {}
        self._event_counter = 0

    async def save_log_item(self, context_id: str, item_no: int, item_data: dict) -> None:
        items = self.logs.setdefault(context_id, [])
        while len(items) <= item_no:
            items.append(None)
        items[item_no] = item_data

    async def get_log_items(self, context_id: str) -> List[dict]:
        items = self.logs.get(context_id, [])
        return [item for item in items if item is not None]

    async def publish_change(self, context_id: str, item_no: int, item_data: dict) -> str:
        changes = self.changes.setdefault(context_id, [])
        self._event_counter += 1
        
        event = LogChangeEvent(
            event_id=str(self._event_counter),
            context_id=context_id,
            item_no=item_no,
            item_data=item_data,
            timestamp=datetime.now().timestamp()
        )
        
        changes.append(event)
        return event.event_id

    async def subscribe_changes(
        self, 
        context_id: str,
        after_event_id: str = "0",
        block_ms: Optional[int] = None
    ) -> AsyncIterator[LogChangeEvent]:
        """
        Returns events AFTER the given event_id (exclusive).
        
        Example:
            after_event_id="5" -> returns events 6, 7, 8, ... (not 5)
        """
        changes = self.changes.get(context_id, [])
        
        # Find the starting index
        start_idx = 0
        if after_event_id != "0":
            # Find the index AFTER the event with this ID
            for i, event in enumerate(changes):
                if event.event_id == after_event_id:
                    start_idx = i + 1  # Start AFTER this event
                    break
        
        # Yield existing events after start_idx
        for event in changes[start_idx:]:
            yield event
        
        # If blocking requested, poll for new events
        if block_ms is not None:
            timeout = block_ms / 1000.0
            elapsed = 0
            poll_interval = 0.1
            last_checked_len = len(changes)
            
            while elapsed < timeout:
                await asyncio.sleep(poll_interval)
                elapsed += poll_interval
                
                changes = self.changes.get(context_id, [])
                if len(changes) > last_checked_len:
                    # Yield only NEW events
                    for event in changes[last_checked_len:]:
                        yield event
                    return  # Exit after yielding new events
        
        return


class RedisLogStorage(ILogStorage):
    """Redis-backed storage for production."""

    def __init__(self, redis_url: str):
        from redis import asyncio as aioredis
        self.redis = aioredis.from_url(redis_url)
        self.stream_maxlen = 10_000

    def _key_items(self, context_id: str) -> str:
        return f"log:{context_id}:items"
    
    def _key_changes(self, context_id: str) -> str:
        return f"log:{context_id}:changes"

    async def save_log_item(self, context_id: str, item_no: int, item_data: dict) -> None:
        key = self._key_items(context_id)
        await self.redis.hset(
            key,
            str(item_no),
            json.dumps(item_data, ensure_ascii=False)
        )

    async def get_log_items(self, context_id: str) -> List[dict]:
        key = self._key_items(context_id)
        data = await self.redis.hgetall(key)
        
        if not data:
            return []
        
        items_dict = {}
        for k, v in data.items():
            item_no = int(k.decode() if isinstance(k, bytes) else k)
            item_json = v.decode() if isinstance(v, bytes) else v
            items_dict[item_no] = json.loads(item_json)
        
        max_no = max(items_dict.keys()) if items_dict else -1
        result = []
        for i in range(max_no + 1):
            if i in items_dict:
                result.append(items_dict[i])
        
        return result

    async def publish_change(self, context_id: str, item_no: int, item_data: dict) -> str:
        key = self._key_changes(context_id)
        event_id = await self.redis.xadd(
            key,
            {
                "item_no": str(item_no),
                "data": json.dumps(item_data, ensure_ascii=False),
                "timestamp": str(datetime.now().timestamp())
            },
            maxlen=self.stream_maxlen,
            approximate=True
        )
        return event_id

    async def subscribe_changes(
        self, 
        context_id: str,
        after_event_id: str = "0",
        block_ms: Optional[int] = None
    ) -> AsyncIterator[LogChangeEvent]:
        key = self._key_changes(context_id)
        last_id = after_event_id if after_event_id != "0" else "0-0"

        try:
            results = await self.redis.xread(
                {key: last_id},
                block=block_ms
            )
            
            if not results:
                return

            for stream_key, messages in results:
                for event_id, fields in messages:
                    decoded = {
                        (k.decode() if isinstance(k, bytes) else k):
                        (v.decode() if isinstance(v, bytes) else v)
                        for k, v in fields.items()
                    }
                    
                    event = LogChangeEvent(
                        event_id=event_id,
                        context_id=context_id,
                        item_no=int(decoded["item_no"]),
                        item_data=json.loads(decoded["data"]),
                        timestamp=float(decoded["timestamp"])
                    )
                    
                    yield event

        except asyncio.CancelledError:
            raise
        except Exception as e:
            print(f"[RedisStorage] Subscribe error: {e}")
            return