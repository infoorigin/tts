import asyncio
from queue import Queue, Empty
from threading import Lock
from typing import Dict, List, Any, Optional, TYPE_CHECKING

from app.meta_agent.utils.agent_activity_storage import ILogStorage

if TYPE_CHECKING:
    from app.meta_agent.utils.agent_activity import AgentActivity


class LogDispatcher:
    """
    Singleton dispatcher for distributing log updates across pods and clients.
    
    Usage:
        # Initialize once (typically in FastAPI startup)
        LogDispatcher.initialize(storage)
        
        # Get instance anywhere
        dispatcher = LogDispatcher.get_instance()
        await dispatcher.publish(activity, item_no)
        
        # Shutdown (typically in FastAPI shutdown)
        await LogDispatcher.get_instance().shutdown()
    """
    
    _instance: Optional["LogDispatcher"] = None
    _class_lock = Lock()

    def __init__(self, storage:ILogStorage):
        """Private constructor. Use initialize() or get_instance() instead."""
        self.storage = storage
        self.subscribers: Dict[str, List[Queue]] = {}
        self.lock = Lock()
        self.listeners: Dict[str, asyncio.Task] = {}
        self.shutdown_event = asyncio.Event()
    
    @classmethod
    def initialize(cls, storage) -> "LogDispatcher":
        """
        Initialize the singleton instance.
        Call this once during application startup.
        
        Args:
            storage: ILogStorage implementation
            
        Returns:
            The singleton instance
        """
        with cls._class_lock:
            if cls._instance is None:
                cls._instance = cls(storage)
            else:
                cls._instance.storage = storage
            return cls._instance
    
    @classmethod
    def get_instance(cls) -> "LogDispatcher":
        """
        Get the singleton instance.
        Raises RuntimeError if not initialized.
        
        Returns:
            The singleton instance
        """
        if cls._instance is None:
            raise RuntimeError(
                "LogDispatcher not initialized. "
                "Call LogDispatcher.initialize(storage) first."
            )
        return cls._instance
    
    @classmethod
    def is_initialized(cls) -> bool:
        """Check if the singleton has been initialized."""
        return cls._instance is not None
    
    @classmethod
    def reset(cls):
        """Reset the singleton (useful for testing)."""
        with cls._class_lock:
            cls._instance = None

    async def publish(self, agent_activity: "AgentActivity", item_no: int=None):
        """
        Publish an agent activity item update.
        
        Note: Does NOT call _fanout_local() directly to avoid duplicates.
        The background listener will pick up the event from storage and fanout.
        """
        if item_no is None:
            item_no = agent_activity.latest_item_no()
        item = agent_activity.agent_activities[item_no]
        item_data = item.output()
        context_id = agent_activity.context_id
        
        try:
            await self.storage.save_log_item(context_id, item_no, item_data)
            await self.storage.publish_change(context_id, item_no, item_data)
            # ❌ DO NOT call _fanout_local here - listener will handle it
        except Exception as e:
            print(f"[Dispatcher] Failed to publish item {item_no}: {e}")

    async def publish_all(self, agent_activity: "AgentActivity", from_index: int = 0):
        """Publish multiple updates from an AgentActivity."""
        for i in range(from_index, len(agent_activity.updates)):
            item_no = agent_activity.updates[i]
            await self.publish(agent_activity, item_no)

    def subscribe(self, context_id: str) -> Queue:
        """Subscribe to updates for a context."""
        q = Queue(maxsize=1000)
        
        with self.lock:
            self.subscribers.setdefault(context_id, []).append(q)
            
            # Start listener only if not already running
            if context_id not in self.listeners:
                print(f"[Dispatcher] Creating NEW listener for {context_id}")
                self.listeners[context_id] = asyncio.create_task(
                    self._listen_for_changes(context_id)
                )
            else:
                print(f"[Dispatcher] Reusing EXISTING listener for {context_id}")
        
        return q

    def unsubscribe(self, context_id: str, q: Queue):
        """Unsubscribe a client queue."""
        with self.lock:
            subs = self.subscribers.get(context_id, [])
            if q in subs:
                subs.remove(q)
            
            if not subs:
                self.subscribers.pop(context_id, None)
                task = self.listeners.pop(context_id, None)
                if task:
                    task.cancel()

    def _fanout_local(self, context_id: str, item_data: dict):
        """Send update to all local subscriber queues."""
        with self.lock:
            subs = self.subscribers.get(context_id, [])
            for q in subs:
                try:
                    q.put_nowait(item_data)
                except:
                    pass

    async def _listen_for_changes(self, context_id: str):
        """
        Background task: listen for changes from storage and fan out.
        
        Prevents duplicates by:
        1. Tracking last_event_id across loop iterations
        2. Only one listener per context per pod (enforced by subscribe())
        3. Storage returns events AFTER last_event_id (exclusive)
        """
        last_event_id = "0"
        backoff = 1
        
        
        try:
            while not self.shutdown_event.is_set():
                try:
                    event_count = 0
                    
                    # Get events after last_event_id (storage handles exclusion)
                    async for event in self.storage.subscribe_changes(
                        context_id,
                        after_event_id=last_event_id,
                        block_ms=5000
                    ):
                         
                        # Update BEFORE fanout to prevent reprocessing on error
                        last_event_id = event.event_id
                        
                        self._fanout_local(context_id, event.item_data)
                        event_count += 1
                        backoff = 1
                    
                    if event_count == 0:
                        await asyncio.sleep(0.1)
                    
                except asyncio.CancelledError:
                    raise
                except Exception as e:
                    print(f"[Dispatcher] Listener error for {context_id}: {e}")
                    # Keep last_event_id on error - don't reprocess events
                    await asyncio.sleep(backoff)
                    backoff = min(backoff * 2, 10)
        
        finally:
            print(f"[Dispatcher] Stopped listening: {context_id}")

    async def stream_events(self, context_id: str):
        """Generator for Server-Sent Events (SSE) streaming."""
        q = None
        try:
            items = await self.storage.get_log_items(context_id)
            for item_data in items:
                yield {"type": "history", "data": item_data}
        except Exception as e:
            print(f"[Dispatcher] Failed to load history: {e}")
        
        q = self.subscribe(context_id)
        try:
            yield {"type": "connected", "data": {"context_id": context_id}}
            
            while not self.shutdown_event.is_set():
                try:
                    item_data = await asyncio.get_event_loop().run_in_executor(
                        None, q.get, True, 1.0  # ← Reduced timeout from 10s to 1s
                    )
                    yield {"type": "update", "data": item_data}
                    
                except Empty:
                    # Check shutdown more frequently
                    if self.shutdown_event.is_set():
                        break
                    yield {"type": "keepalive", "data": {}}
        
        except asyncio.CancelledError:
            # Server shutting down or client disconnected
            print(f"[Dispatcher] Stream cancelled for {context_id}")
            raise
        finally:
            if q is not None:
                self.unsubscribe(context_id, q)

    async def shutdown(self):
        """Stop all background listeners."""
        self.shutdown_event.set()
        
        for task in list(self.listeners.values()):
            task.cancel()
        
        await asyncio.gather(*self.listeners.values(), return_exceptions=True)
        print("[Dispatcher] Shutdown complete")