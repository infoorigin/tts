from abc import abstractmethod
from typing import Any
from app.meta_agent.utils import extract_tools, files 
from typing import TYPE_CHECKING
if TYPE_CHECKING:
    from app.meta_agent.agent import Agent

class TaskExecutor:

    def __init__(self, agent: "Agent|None", **kwargs):
        self.agent: "Agent" = agent # type: ignore < here we ignore the type check as there are currently no extensions without an agent
        self.kwargs = kwargs

    @abstractmethod
    async def execute(self, **kwargs) -> Any:
        pass


async def call_executors(extension_point: str, agent: "Agent|None" = None, **kwargs) -> Any:

    # get default executors
    defaults = await _get_executors("app/meta_agent/executors/" + extension_point)
    classes = defaults

    # get agent executors
    if agent and agent.config.profile:
        agentics = await _get_executors("agents/" + agent.config.profile + "/executors/" + extension_point)
        if agentics:
            # merge them, agentics overwrite defaults
            unique = {}
            for cls in defaults + agentics:
                unique[_get_file_from_module(cls.__module__)] = cls

            # sort by name
            classes = sorted(unique.values(), key=lambda cls: _get_file_from_module(cls.__module__))

    # call executors
    for cls in classes:
        await cls(agent=agent).execute(**kwargs)


def _get_file_from_module(module_name: str) -> str:
    return module_name.split(".")[-1]

_cache: dict[str, list[type[TaskExecutor]]] = {}
async def _get_executors(folder:str):
    global _cache
    folder = files.get_abs_path(folder)
    if folder in _cache:
        classes = _cache[folder]
    else:
        if not files.exists(folder):
            return []
        classes = extract_tools.load_classes_from_folder(
            folder, "*", TaskExecutor
        )
        _cache[folder] = classes

    return classes

