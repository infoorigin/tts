import os
from typing import Any, List, Dict

from llama_index.core import SimpleDirectoryReader
from llama_index.core.readers.json import JSONReader
from llama_index.readers.file import CSVReader, PDFReader, MarkdownReader, HTMLTagReader, DocxReader

class FileDocumentReader:
    """
    Unified file reader for multiple formats.
    Automatically chooses the right LlamaIndex reader based on file extension.
    """

    def __init__(self):
        # Map extensions (lowercase, with leading dot) to reader classes/instances
        self.reader_map: Dict[str, Any] = {
            ".json": JSONReader(),
            ".csv": CSVReader(),
            ".pdf": PDFReader(),
            ".md": MarkdownReader(),
            ".markdown": MarkdownReader(),
            ".html": HTMLTagReader(),
            ".htm": HTMLTagReader(),
            ".docx": DocxReader(),
            ".txt": SimpleDirectoryReader,   # class (special handling)
            ".text": SimpleDirectoryReader,  # class (special handling)
        }

    def get_supported_extensions(self) -> List[str]:
        return sorted(self.reader_map.keys())

    def is_supported(self, file_path: str) -> bool:
        ext = os.path.splitext(file_path)[1].lower()
        return ext in self.reader_map

    def load_data(self, file_path: str):
        """
        Load a single file into Documents.
        Uses robust param dispatch to handle reader signature differences across LlamaIndex versions.
        """
        ext = os.path.splitext(file_path)[1].lower()

        if not self.is_supported(file_path):
            raise ValueError(f"Unsupported file extension: {ext}")

        reader = self.reader_map[ext]

        # SimpleDirectoryReader is provided as a class so we can pass input_files=[...]
        if isinstance(reader, type) and issubclass(reader, SimpleDirectoryReader):
            return reader(input_files=[file_path]).load_data()

        # For other readers, try common signatures in order
        try:
            return reader.load_data(input_file=file_path)
        except TypeError:
            pass
        try:
            return reader.load_data(file=file_path)
        except TypeError:
            pass
        return reader.load_data(file_path)