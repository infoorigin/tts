import os
import json
import faiss
import logging
import psycopg2
import numpy as np
from datetime import datetime
from typing import Any, Dict, List, Sequence, Optional
from enum import Enum
from simpleeval import simple_eval
from llama_index.core import (
    Document,
    VectorStoreIndex,
    StorageContext,
    load_index_from_storage,
)
from llama_index.core.schema import MetadataMode
from llama_index.core.storage.docstore import SimpleDocumentStore
from llama_index.vector_stores.faiss import FaissVectorStore

from app.meta_agent.utils import guids, files, knowledge_import
from app.meta_agent.utils.print_style import PrintStyle
from app.meta_agent.utils.agent_activity import AgentActivityItem
from app.meta_agent.agent import Agent
from app.meta_agent.llm import models

logging.getLogger("llama_index").setLevel(logging.ERROR)


class Memory:
    """Local FAISS + docstore persistence with LlamaIndex."""

    class Area(Enum):
        DEFAULT = "default"
        FACTS = "facts"
        SOLUTIONS = "solutions"
        INSTRUMENTS = "instruments"
        PLAYBOOK = "playbook"

    # cache of Memory objects per subdir
    index: Dict[str, "Memory"] = {}

    # ------------------------------
    # Lifecycle
    # ------------------------------
    @staticmethod
    async def get(agent: Agent, *, use_index: bool = True) -> "Memory":
        memory_subdir = agent.config.memory_subdir or "default"
        if Memory.index.get(memory_subdir) is None:
            log_item = agent.context.agent_activity.add_agent_activity(
                type="util", heading=f"Initializing VectorDB in '/{memory_subdir}'"
            )
            mem = Memory._initialize_wrapper(
                log_item=log_item,
                model_config=agent.config.embeddings_model,
                memory_subdir=memory_subdir,
                use_index=use_index,
            )
            Memory.index[memory_subdir] = mem
            if agent.config.knowledge_subdirs:
                await mem.preload_knowledge(
                    log_item, agent.config.knowledge_subdirs, memory_subdir
                )
            return mem
        return Memory.index[memory_subdir]

    @staticmethod
    async def reload(agent: Agent, *, use_index: bool = True) -> "Memory":
        memory_subdir = agent.config.memory_subdir or "default"
        if Memory.index.get(memory_subdir):
            del Memory.index[memory_subdir]
        return await Memory.get(agent, use_index=use_index)

    @staticmethod
    def _initialize_wrapper(
        log_item: Optional[AgentActivityItem],
        model_config: models.ModelConfig,
        memory_subdir: str,
        use_index: bool = True,
    ) -> "Memory":
        PrintStyle.standard("Initializing VectorDB...")
        if log_item:
            log_item.stream(progress="\nInitializing VectorDB")

        persist_dir = Memory._abs_db_dir(memory_subdir)
        os.makedirs(persist_dir, exist_ok=True)

        vector_store_path = os.path.join(persist_dir, "default__vector_store.json")
        index_store_path = os.path.join(persist_dir, "index_store.json")

        embedder = models.get_embedding_model(
            model_config.provider, model_config.name, **model_config.build_kwargs()
        )

        if os.path.exists(vector_store_path) and os.path.exists(index_store_path):
            vector_store = FaissVectorStore.from_persist_dir(persist_dir)
            storage_context = StorageContext.from_defaults(
                vector_store=vector_store,
                persist_dir=persist_dir,
            )
            index = load_index_from_storage(storage_context)
        else:
            # First run, nothing persisted yet → bootstrap
            dim = len(embedder.get_text_embedding("dimension_probe"))
            faiss_index = faiss.IndexFlatIP(dim)
            vector_store = FaissVectorStore(faiss_index=faiss_index)
            storage_context = StorageContext.from_defaults(
                vector_store=vector_store,
                docstore=SimpleDocumentStore()
            )
            index = VectorStoreIndex([], storage_context=storage_context, embed_model=embedder)
            storage_context.persist(persist_dir=persist_dir)

        # Write embedding metadata
        meta_file_path = files.get_abs_path(persist_dir, "embedding.json")
        files.write_file(
            meta_file_path,
            json.dumps(
                {"model_provider": model_config.provider, "model_name": model_config.name}
            ),
        )

        return Memory(
            storage_context=storage_context,
            vector_store=vector_store,
            index=index,
            embedder=embedder,
            memory_subdir=memory_subdir,
            use_index=use_index,
        )

    def __init__(
        self,
        storage_context: StorageContext,
        vector_store: FaissVectorStore,
        index: Optional[VectorStoreIndex],
        embedder: Any,
        memory_subdir: str,
        use_index: bool = True,
    ):
        self.storage_context = storage_context
        self.db = vector_store
        self.index = index
        self.embedder = embedder
        self.memory_subdir = memory_subdir
        self.use_index = use_index

    # ------------------------------
    # Knowledge preload
    # ------------------------------
    async def preload_knowledge(
        self,
        log_item: Optional[AgentActivityItem],
        kn_dirs: List[str],
        memory_subdir: str
    ):
        """Preload all domain and agent-specific knowledge into memory."""
        if log_item:
            log_item.update(heading="Preloading knowledge...")

        db_dir = Memory._abs_db_dir(memory_subdir)
        os.makedirs(db_dir, exist_ok=True)

        index_path = files.get_abs_path(db_dir, "knowledge_import.json")
        index: Dict[str, knowledge_import.KnowledgeImport] = {}
        if os.path.exists(index_path):
            with open(index_path, "r", encoding="utf-8") as f:
                index = json.load(f)

        # ---- Load knowledge from standard and agent-specific folders ----
        index = self._preload_knowledge_folders(log_item, kn_dirs, index)

        # ---- Insert / delete changed documents ----
        for file in index:
            if index[file]["state"] in ["changed", "removed"] and index[file].get("ids", []):
                await self.delete_documents_by_ids(index[file]["ids"])
            if index[file]["state"] == "changed":
                index[file]["ids"] = await self.insert_documents(index[file]["documents"])

        # ---- Clean up index file ----
        index = {k: v for k, v in index.items() if v["state"] != "removed"}
        for file in index:
            index[file].pop("documents", None)
            index[file].pop("state", None)

        with open(index_path, "w", encoding="utf-8") as f:
            json.dump(index, f)

    def _preload_playbooks_from_db(
    self,
    log_item,
    index: Dict[str, "knowledge_import.KnowledgeImport"],
    ):
        """
        Load active playbooks from the Postgres pb_store table.
        Each row's `id` becomes playbook_id, and `pb_file_path` is ingested.
        """

        # Read creds from env with sensible defaults (yours)
        host = os.getenv("PB_DB_HOST")
        port = os.getenv("PB_DB_PORT")
        db   = os.getenv("PB_DB_NAME")
        user = os.getenv("PB_DB_USER")
        pwd  = os.getenv("PB_DB_PASSWORD")

        conn = None
        try:
            conn = psycopg2.connect(host=host, port=port, dbname=db, user=user, password=pwd)
            cur = conn.cursor()
            cur.execute("""
                SELECT pb_id, pb_content_source, pb_content
                FROM pb_store
            """)
            rows = cur.fetchall()
            if rows and log_item:
                log_item.stream(progress=f"\nFound {len(rows)} DB playbooks. Importing...")

            for row in rows:
                pb_id, source, content = row
                pb_id = str(pb_id).strip() if pb_id is not None else ""
                source = (source or "").strip().lower()

                if not pb_id:
                    continue

                if source == "default":
                    # 1. Write DB content to a lightweight temp file
                    tmp_root = os.path.join(os.getcwd(), "tmp_playbooks")
                    os.makedirs(tmp_root, exist_ok=True)
                    tmp_file = os.path.join(tmp_root, f"{pb_id}.txt")

                    with open(tmp_file, "w", encoding="utf-8") as f:
                        f.write(str(content or ""))

                    # 2. Load it using the SAME loader
                    index = knowledge_import.load_knowledge(
                        log_item=log_item,
                        knowledge_dir=tmp_root,
                        index=index,
                        metadata={"area": Memory.Area.PLAYBOOK.value, "playbook_id": pb_id},
                        filename_pattern=f"{pb_id}.txt",
                    )

                elif source == "local":
                    # 3. Existing behavior for file paths
                    file_path = os.path.normpath(str(content))
                    dir_path, fname = os.path.split(file_path)

                    if os.path.exists(file_path):
                        index = knowledge_import.load_knowledge(
                            log_item=log_item,
                            knowledge_dir=dir_path,
                            index=index,
                            metadata={"area": Memory.Area.PLAYBOOK.value, "playbook_id": pb_id},
                            filename_pattern=fname,
                        )
                    else:
                        PrintStyle(font_color="yellow").print(f"DB playbook file not found: {file_path}")

            cur.close()
        except Exception as e:
            PrintStyle(font_color="yellow").print(f"DB playbook preload failed: {e}")
        finally:
            if conn:
                conn.close()

        return index

    def _preload_knowledge_folders(
        self,
        log_item: Optional[AgentActivityItem],
        kn_dirs: List[str],
        index: Dict[str, knowledge_import.KnowledgeImport],
    ):
        """Load all standard, custom, and embedded agent knowledge folders."""

        # ---- Load standard domain areas (facts, solutions, instruments, etc.) ----
        for kn_dir in kn_dirs:
            for area in Memory.Area:
                index = knowledge_import.load_knowledge(
                    log_item,
                    files.get_abs_path("knowledge", kn_dir, area.value),
                    index,
                    {"area": area.value},
                )

            # ---- Load general instruments (markdown files) ----
            index = knowledge_import.load_knowledge(
                log_item,
                files.get_abs_path("instruments"),
                index,
                {"area": Memory.Area.INSTRUMENTS.value},
                filename_pattern="**/*.md",
            )


        # ---- Load knowledge directly from each agent’s internal folder ----
        agent_root = os.path.abspath(os.path.join(os.getcwd(), "agents"))
        if os.path.exists(agent_root):
            for agent_name in os.listdir(agent_root):
                agent_dir = os.path.join(agent_root, agent_name)
                kb_dir = os.path.join(agent_dir, "knowledge_base")

                if not os.path.isdir(kb_dir):
                    continue

                index = knowledge_import.load_knowledge(
                    log_item,
                    kb_dir,
                    index,
                    {
                        "area": Memory.Area.DEFAULT.value,
                        "agent_role": agent_name.lower(),
                    },
                    filename_pattern="**/*.*",
                )
        # index = self._preload_playbooks_from_db(log_item, index)
        return index

    # ------------------------------
    # Search
    # ------------------------------
    async def search_similarity_threshold(
        self, query: str, limit: int, threshold: float, filter: str = ""
    ):
        if not self.index:
            raise RuntimeError("VectorStoreIndex is required for search.")

        retriever = self.index.as_retriever(similarity_top_k=limit)
        nodes = await retriever.aretrieve(query)

        if filter:
            comp = Memory._get_comparator(filter)
            nodes = [n for n in nodes if comp(n.node.metadata)]

        nodes = [n for n in nodes if (n.score or 0.0) >= threshold]
        return nodes

    # ------------------------------
    # Delete
    # ------------------------------
    async def delete_documents_by_query(
        self, query: str, threshold: float, filter: str = ""
    ):
        k = 100
        tot = 0
        removed = []

        while True:
            # Perform similarity search with score
            docs = await self.search_similarity_threshold(
                query, limit=k, threshold=threshold, filter=filter
            )
            removed += docs

            # Extract document IDs and filter based on score
            # document_ids = [result[0].metadata["id"] for result in docs if result[1] < score_limit]
            document_ids = [result.metadata["id"] for result in docs]

            # Delete documents with IDs over the threshold score
            if document_ids:
                # fnd = self.db.get(where={"id": {"$in": document_ids}})
                # if fnd["ids"]: self.db.delete(ids=fnd["ids"])
                # tot += len(fnd["ids"])
                # map metadata ids -> docstore node ids first
                node_ids = self._meta_ids_to_node_ids(document_ids)
                if node_ids:
                    try:
                        # ask vectorstore to delete by node ids (the IDs vectorstore expects)
                        await self.db.adelete(ids=node_ids, ref_doc_id=None)
                    except Exception as e:
                        # fallback: remove from docstore and rebuild (robust fallback)
                        PrintStyle().warning(f"Vectorstore delete failed, falling back: {e}")
                        for nid in node_ids:
                            self.storage_context.docstore.delete_document(nid)
                        self._rebuild_faiss()

                tot += len(document_ids)

            # If fewer than K document IDs, break the loop
            if len(document_ids) < k:
                break

        if tot:
            self._save_db()  # persist
        return removed
    
    async def delete_documents_by_ids(self, ids: List[str]):
        removed_docs: List[Document] = []
        ds = self.storage_context.docstore
        for node_id, node in list(ds.docs.items()):
            doc_id = node.metadata.get("id")
            if doc_id and doc_id in ids:
                removed_docs.append(
                    Document(
                        text=node.get_content(metadata_mode=MetadataMode.NONE),
                        metadata=node.metadata,
                    )
                )
                ds.delete_document(node_id)

        self._rebuild_faiss()
        return removed_docs

    def _rebuild_faiss(self):
        dim = len(self.embedder.get_text_embedding("dimension_probe"))
        new_faiss = faiss.IndexFlatIP(dim)
        self.db = FaissVectorStore(faiss_index=new_faiss)

        self.storage_context = StorageContext.from_defaults(
            vector_store=self.db,
            docstore=self.storage_context.docstore,
        )

        self.index = VectorStoreIndex(
            [], storage_context=self.storage_context, embed_model=self.embedder
        )

        # reinject docs
        docs = list(self.get_all_docs().values())
        for d in docs:
            self.index.insert(d)

        self._save_db()


    # ------------------------------
    # Insert
    # ------------------------------
    async def insert_text(self, text: str, metadata: Dict[str, Any] = None):
        metadata = dict(metadata or {})
        doc_id = self._generate_doc_id()
        metadata.setdefault("id", doc_id)
        metadata.setdefault("timestamp", self.get_timestamp())
        metadata.setdefault("area", Memory.Area.DEFAULT.value)
        agent_role = getattr(self.agent.config, "profile", "") if hasattr(self, "agent") else ""
        metadata.setdefault("agent_role", agent_role.lower())

        doc = Document(text=text, metadata=metadata)
        await self.insert_documents([doc])
        return doc_id

    async def insert_documents(self, docs: List[Document]):
        if not self.index:
            self.index = VectorStoreIndex(
                [], storage_context=self.storage_context, embed_model=self.embedder
            )

        for doc in docs:
            doc.metadata.setdefault("id", self._generate_doc_id())
            doc.metadata.setdefault("timestamp", self.get_timestamp())
            doc.metadata.setdefault("area", Memory.Area.DEFAULT.value)
            self.index.insert(doc)

        self._save_db()
        return [doc.metadata["id"] for doc in docs]

    # ------------------------------
    # Helpers
    # ------------------------------
    def get_by_ids(self, ids: Sequence[str]) -> List[Document]:
        ids = list(ids) if isinstance(ids, (list, tuple, set)) else [ids]
        ds = self.storage_context.docstore
        results = []
        for node in ds.docs.values():
            doc_id = node.metadata.get("id")
            if doc_id in ids:
                results.append(
                    Document(
                        text=node.get_content(metadata_mode=MetadataMode.NONE),
                        metadata=node.metadata,
                    )
                )
        return results

    async def aget_by_ids(self, ids: Sequence[str], /) -> List[Document]:
        return self.get_by_ids(ids)
    
    def get_all_docs(self) -> Dict[str, Document]:
        ds = self.storage_context.docstore
        out: Dict[str, Document] = {}
        for node in ds.docs.values():
            doc_id = node.metadata.get("id")
            if not doc_id:
                continue
            out[doc_id] = Document(
                text=node.get_content(metadata_mode=MetadataMode.NONE),
                metadata=node.metadata,
            )
        return out
    
    def _meta_ids_to_node_ids(self, meta_ids: List[str]) -> List[str]:
        ds = self.storage_context.docstore
        node_ids = []
        for node_id, node in ds.docs.items():
            doc_id = node.metadata.get("id")
            if doc_id and doc_id in meta_ids:
                node_ids.append(node_id)
        return node_ids


    def _save_db(self):
        persist_dir = Memory._abs_db_dir(self.memory_subdir)
        os.makedirs(persist_dir, exist_ok=True)
        self.storage_context.persist(persist_dir=persist_dir)

    def _generate_doc_id(self) -> str:
        used = {
            n.metadata.get("id") for n in self.storage_context.docstore.docs.values()
        }
        while True:
            doc_id = guids.generate_id(10)
            if doc_id not in used:
                return doc_id

    # ------------------------------
    # Utils
    # ------------------------------
    @staticmethod
    def _get_comparator(condition: str):
        def comparator(data: Dict[str, Any]):
            try:
                return simple_eval(condition, names=data)
            except Exception as e:
                PrintStyle.error(f"Error evaluating condition: {e}")
                return False
        return comparator

    @staticmethod
    def _abs_db_dir(memory_subdir: str) -> str:
        return files.get_abs_path("memory", memory_subdir)

    @staticmethod
    def get_timestamp():
        return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    @staticmethod
    def format_docs_plain(docs: List[Document]) -> List[str]:
        result = []
        for doc in docs:
            text = ""
            for k, v in doc.metadata.items():
                text += f"{k}: {v}\n"
            text += f"Content: {doc.text}"
            result.append(text)
        return result


# ------------------------------
# Free helpers
# ------------------------------
def get_memory_subdir_abs(agent: Agent) -> str:
    return files.get_abs_path("memory", agent.config.memory_subdir or "default")


def get_custom_knowledge_subdir_abs(agent: Agent) -> str:
    for dir in agent.config.knowledge_subdirs:
        if dir != "default":
            return files.get_abs_path("knowledge", dir)
    raise Exception("No custom knowledge subdir set")


def reload():
    Memory.index = {}
