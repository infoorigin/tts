from app.meta_agent.utils.executors import TaskExecutor
from app.meta_agent.agent import LoopData
from app.meta_agent.utils import memory


class MemoryInit(TaskExecutor):

    async def execute(self, loop_data: LoopData = LoopData(), **kwargs):
        db = await memory.Memory.get(self.agent)
        

   