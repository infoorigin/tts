from app.meta_agent.utils.agent_activity_dispatcher import LogDispatcher
from app.meta_agent.utils.executors import TaskExecutor
from app.meta_agent.agent import LoopData


class LiveResponse(TaskExecutor):

    async def execute(
        self,
        loop_data: LoopData = LoopData(),
        text: str = "",
        parsed: dict = {},
        **kwargs,
    ):
        try:
            if (
                not "tool_name" in parsed
                or parsed["tool_name"] != "response"
                or "tool_args" not in parsed
                or "text" not in parsed["tool_args"]
                or not parsed["tool_args"]["text"]
            ):
                return  # not a response

            # create log message and store it in loop data temporary params
            if "log_item_response" not in loop_data.params_temporary:
                loop_data.params_temporary["log_item_response"] = (
                    self.agent.context.agent_activity.add_agent_activity(
                        type="response",
                        heading=f"icon://chat {self.agent.agent_name}: Responding",
                    )
                )

            # update log message
            thoughts=parsed["thoughts"] or []
            log_item = loop_data.params_temporary["log_item_response"]
            log_item.update(thoughts=thoughts, content=parsed["tool_args"]["text"], event_type="response", headline="Agent Responding")
            # await LogDispatcher.get_instance().publish(self.agent.context.agent_activity, log_item.no)
        except Exception as e:
            pass
