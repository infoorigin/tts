from app.meta_agent.utils.agent_activity_dispatcher import LogDispatcher
from app.meta_agent.utils.executors import TaskExecutor
from app.meta_agent.agent import LoopData
import math
from app.meta_agent.executors.before_main_llm_call._10_log_for_stream import build_heading, build_default_heading


class LogFromStream(TaskExecutor):

    async def execute(
        self,
        loop_data: LoopData = LoopData(),
        text: str = "",
        parsed: dict = {},
        **kwargs,
    ):

        heading = build_default_heading(self.agent)
        if "headline" in parsed:
            heading = build_heading(self.agent, parsed['headline'])
        elif "tool_name" in parsed:
            heading = build_heading(self.agent, f"Using tool {parsed['tool_name']}") # if the llm skipped headline
        elif "thoughts" in parsed:
            # thought length indicator
            thoughts = "\n".join(parsed["thoughts"])
            pipes = "|" * math.ceil(math.sqrt(len(thoughts)))
            heading = build_heading(self.agent, f"Thinking... {pipes}")
        
        # create log message and store it in loop data temporary params
        if "log_item_generating" not in loop_data.params_temporary:
            loop_data.params_temporary["log_item_generating"] = (
                self.agent.context.agent_activity.add_agent_activity(
                    type="agent",
                    heading=heading,
                )
            )

        # update log message
        activity_item = loop_data.params_temporary["log_item_generating"]

        # keep reasoning from previous logs in kvps
        kvps = {}
        if activity_item.kvps is not None and "reasoning" in activity_item.kvps:
            kvps["reasoning"] = activity_item.kvps["reasoning"]
        kvps.update(parsed)

        # update the log item
        if (
                not "tool_name" in parsed
                or parsed["tool_name"] != "response"
                or "tool_args" not in parsed
                or "text" not in parsed["tool_args"]
                or not parsed["tool_args"]["text"]
            ):
                activity_item.update(heading=heading, content=text, kvps=kvps, event_type="reasoning", headline=kvps.get("headline", heading))
                # await LogDispatcher.get_instance().publish(self.agent.context.agent_activity, activity_item.no)