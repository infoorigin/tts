from app.meta_agent.utils.executors import TaskExecutor
from app.meta_agent.agent import LoopData, AgentContextType
from app.meta_agent.utils import chat_manager


class SaveChat(TaskExecutor):
    async def execute(self, loop_data: LoopData = LoopData(), **kwargs):
        # Skip saving BACKGROUND contexts as they should be ephemeral
        if self.agent.context.type == AgentContextType.BACKGROUND:
            return

        chat_manager.save_tmp_chat(self.agent.context)
