from app.meta_agent.utils.executors import TaskExecutor
from app.meta_agent.agent import LoopData



class LogForStream(TaskExecutor):

    async def execute(self, loop_data: LoopData = LoopData(), text: str = "", **kwargs):
        # create log message and store it in loop data temporary params
        if "log_item_generating" not in loop_data.params_temporary:
            loop_data.params_temporary["log_item_generating"] = (
                self.agent.context.agent_activity.add_agent_activity(
                    type="agent",
                    heading=build_default_heading(self.agent),
                )
            )

def build_heading(agent, text: str):
    return f"icon://network_intelligence {agent.agent_name}: {text}"

def build_default_heading(agent):
    return build_heading(agent, "Generating...") 