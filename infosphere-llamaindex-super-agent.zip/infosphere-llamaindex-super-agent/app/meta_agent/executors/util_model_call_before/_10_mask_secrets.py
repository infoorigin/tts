from app.meta_agent.utils.executors import TaskExecutor
from app.meta_agent.utils.secrets import SecretsManager


class MaskToolSecrets(TaskExecutor):

    async def execute(self, **kwargs):
        # model call data
        call_data:dict = kwargs.get("call_data", {})
            
        secrets_mgr = SecretsManager.get_instance()
        
        # mask system and user message
        if system:=call_data.get("system"):
            call_data["system"] = secrets_mgr.mask_values(system)
        if message:=call_data.get("message"):
            call_data["message"] = secrets_mgr.mask_values(message)