from typing import Any
from app.meta_agent.utils.executors import TaskExecutor
from app.meta_agent.agent import LoopData

class GuardrailCheck(TaskExecutor):

    async def execute(self, guardrail_prompt: list[str] = [], loop_data: LoopData = LoopData(), output_check: bool = False):
        if self.agent.agent_name == 'AM0':
            # Select proper markdown rule set
            guardrail_file =  "agent.guardrail_check.sys.md"

            guardrail_check_rules = self.agent.read_prompt(guardrail_file)
            chat_history = loop_data.history_output
            user_message = loop_data.user_message.content

            response = self.agent.read_prompt(
                "agent.guardrail_check.msg.md",
                guardrail_check_rules=guardrail_check_rules,
                chat_history=chat_history,
                user_message=user_message
            )
            guardrail_prompt.append(response)
        else:
            return None