import asyncio
from dataclasses import  dataclass, field
from pydantic import Field as pd_Field 
from enum import Enum
import logging
import os
from typing import (
    Any,
    Awaitable,
    Callable,
    Dict,
    List,
    Optional,
    Iterator,
    AsyncIterator,
    Tuple,
    TypedDict,
)

from litellm import aembedding, completion, acompletion, embedding
import litellm

from app.meta_agent.utils import dotenv
from app.meta_agent.utils import settings
from app.meta_agent.utils.dotenv import load_dotenv
from app.meta_agent.utils.providers import get_provider_config
from app.meta_agent.utils.rate_limiter import RateLimiter
from app.meta_agent.utils.tokens import approximate_tokens

from llama_index.core.llms import (
    ChatMessage,
    ChatResponse,
    LLMMetadata,
)
from llama_index.core.embeddings import BaseEmbedding


# disable extra logging, must be done repeatedly, otherwise browser-use will turn it back on for some reason
def turn_off_logging():
    os.environ["LITELLM_LOG"] = "ERROR"  # only errors
    litellm.suppress_debug_info = True
    # Silence **all** LiteLLM sub-loggers (utils, cost_calculator…)
    for name in logging.Logger.manager.loggerDict:
        if name.lower().startswith("litellm"):
            logging.getLogger(name).setLevel(logging.ERROR)


# init
load_dotenv()
turn_off_logging()
litellm.modify_params = True  # helps fix anthropic tool calls by browser-use


class ModelType(Enum):
    CHAT = "Chat"
    EMBEDDING = "Embedding"


@dataclass
class ModelConfig:
    type: ModelType
    provider: str
    name: str
    api_base: str = ""
    ctx_length: int = 0
    limit_requests: int = 0
    limit_input: int = 0
    limit_output: int = 0
    vision: bool = False
    kwargs: dict = field(default_factory=dict)

    def build_kwargs(self):
        kwargs = self.kwargs.copy() or {}
        if self.api_base and "api_base" not in kwargs:
            kwargs["api_base"] = self.api_base
        return kwargs


class ChatChunk(TypedDict):
    """Simplified response chunk for chat models."""
    response_delta: str
    reasoning_delta: str


class ChatGenerationResult:
    """Accumulates streamed chat chunks and separates 'reasoning' from 'response'."""
    def __init__(self, chunk: ChatChunk | None = None):
        self.reasoning = ""
        self.response = ""
        self.thinking = False
        self.thinking_tag = ""
        self.unprocessed = ""
        self.native_reasoning = False
        self.thinking_pairs = [("<think>", "</think>"), ("<reasoning>", "</reasoning>")]
        if chunk:
            self.add_chunk(chunk)

    def add_chunk(self, chunk: ChatChunk) -> ChatChunk:
        if chunk["reasoning_delta"]:
            self.native_reasoning = True

        # Native reasoning present => take as-is; otherwise parse <think> tags if any
        if self.native_reasoning:
            processed_chunk = ChatChunk(
                response_delta=chunk["response_delta"],
                reasoning_delta=chunk["reasoning_delta"],
            )
        else:
            processed_chunk = self._process_thinking_chunk(chunk)

        self.reasoning += processed_chunk["reasoning_delta"]
        self.response += processed_chunk["response_delta"]
        return processed_chunk

    def _process_thinking_chunk(self, chunk: ChatChunk) -> ChatChunk:
        response_delta = self.unprocessed + chunk["response_delta"]
        self.unprocessed = ""
        return self._process_thinking_tags(response_delta, chunk["reasoning_delta"])

    def _process_thinking_tags(self, response: str, reasoning: str) -> ChatChunk:
        if self.thinking:
            close_pos = response.find(self.thinking_tag)
            if close_pos != -1:
                reasoning += response[:close_pos]
                response = response[close_pos + len(self.thinking_tag):]
                self.thinking = False
                self.thinking_tag = ""
            else:
                if self._is_partial_closing_tag(response):
                    self.unprocessed = response
                    response = ""
                else:
                    reasoning += response
                    response = ""
        else:
            for opening_tag, closing_tag in self.thinking_pairs:
                if response.startswith(opening_tag):
                    response = response[len(opening_tag):]
                    self.thinking = True
                    self.thinking_tag = closing_tag

                    close_pos = response.find(closing_tag)
                    if close_pos != -1:
                        reasoning += response[:close_pos]
                        response = response[close_pos + len(closing_tag):]
                        self.thinking = False
                        self.thinking_tag = ""
                    else:
                        if self._is_partial_closing_tag(response):
                            self.unprocessed = response
                            response = ""
                        else:
                            reasoning += response
                            response = ""
                    break
                elif len(response) < len(opening_tag) and self._is_partial_opening_tag(response, opening_tag):
                    self.unprocessed = response
                    response = ""
                    break

        return ChatChunk(response_delta=response, reasoning_delta=reasoning)

    def _is_partial_opening_tag(self, text: str, opening_tag: str) -> bool:
        for i in range(1, len(opening_tag)):
            if text == opening_tag[:i]:
                return True
        return False

    def _is_partial_closing_tag(self, text: str) -> bool:
        if not self.thinking_tag or not text:
            return False
        max_check = min(len(text), len(self.thinking_tag) - 1)
        for i in range(1, max_check + 1):
            if text.endswith(self.thinking_tag[:i]):
                return True
        return False

    def output(self) -> ChatChunk:
        response = self.response
        reasoning = self.reasoning
        if self.unprocessed:
            if reasoning and not response:
                reasoning += self.unprocessed
            else:
                response += self.unprocessed
        return ChatChunk(response_delta=response, reasoning_delta=reasoning)


rate_limiters: dict[str, RateLimiter] = {}
api_keys_round_robin: dict[str, int] = {}


def get_api_key(service: str) -> str:
    # get api key for the service
    key = (
        dotenv.get_dotenv_value(f"API_KEY_{service.upper()}")
        or dotenv.get_dotenv_value(f"{service.upper()}_API_KEY")
        or dotenv.get_dotenv_value(f"{service.upper()}_API_TOKEN")
        or "None"
    )
    # if the key contains a comma, use round-robin
    if "," in key:
        api_keys = [k.strip() for k in key.split(",") if k.strip()]
        api_keys_round_robin[service] = api_keys_round_robin.get(service, -1) + 1
        key = api_keys[api_keys_round_robin[service] % len(api_keys)]
    return key


def get_rate_limiter(
    provider: str, name: str, requests: int, input: int, output: int
) -> RateLimiter:
    key = f"{provider}\\{name}"
    rate_limiters[key] = limiter = rate_limiters.get(key, RateLimiter(seconds=60))
    limiter.limits["requests"] = requests or 0
    limiter.limits["input"] = input or 0
    limiter.limits["output"] = output or 0
    return limiter


async def apply_rate_limiter(
    model_config: ModelConfig | None,
    input_text: str,
    rate_limiter_callback: (
        Callable[[str, str, int, int], Awaitable[bool]] | None
    ) = None,
):
    if not model_config:
        return
    limiter = get_rate_limiter(
        model_config.provider,
        model_config.name,
        model_config.limit_requests,
        model_config.limit_input,
        model_config.limit_output,
    )
    limiter.add(input=approximate_tokens(input_text))
    limiter.add(requests=1)
    await limiter.wait(rate_limiter_callback)
    return limiter


def apply_rate_limiter_sync(
    model_config: ModelConfig | None,
    input_text: str,
    rate_limiter_callback: (
        Callable[[str, str, int, int], Awaitable[bool]] | None
    ) = None,
):
    if not model_config:
        return
    import asyncio, nest_asyncio

    nest_asyncio.apply()
    return asyncio.run(
        apply_rate_limiter(model_config, input_text, rate_limiter_callback)
    )


class LiteLLMChatWrapper():
    """
    LlamaIndex-compatible LLM wrapper around LiteLLM completion/astream APIs.
    Streams by yielding ChatResponse(delta=...).
    """
    model_name: str
    provider: str
    kwargs: dict
    a0_model_conf: Optional[ModelConfig]

    class Config:
        arbitrary_types_allowed = True
        extra = "allow"
        validate_assignment = False

    def __init__(
        self,
        model: str,
        provider: str,
        model_config: Optional[ModelConfig] = None,
        **kwargs: Any,
    ):
        super().__init__()
        self.model_name = f"{provider}/{model}"
        self.provider = provider
        self.kwargs = kwargs
        self.a0_model_conf = model_config

    @property
    def metadata(self):
        return LLMMetadata(
            model_name=self.model_name,
            context_window=self.a0_model_conf.ctx_length if self.a0_model_conf else None,
        )

    def _convert_messages(self, messages: List[ChatMessage]) -> List[dict]:
        """
        Convert LlamaIndex ChatMessage -> LiteLLM message dicts.
        ChatMessage: role in {"user","assistant","system","tool"}, content: str
        """
        return [{"role": m.role.value, "content": m.content} for m in messages]

    def chat(self, messages: List[ChatMessage], **kwargs: Any) -> ChatResponse:
        msgs = self._convert_messages(messages)
        apply_rate_limiter_sync(self.a0_model_conf, str(msgs))
        resp = completion(
            model=self.model_name,
            messages=msgs,
            **{**self.kwargs, **kwargs},
        )
        parsed = _parse_chunk(resp)
        output = ChatGenerationResult(parsed).output()
        return ChatResponse(
            message=ChatMessage(role="assistant", content=output["response_delta"]),
            raw=resp,
        )

    def stream_chat(self, messages: List[ChatMessage], **kwargs: Any) -> Iterator[ChatResponse]:
        msgs = self._convert_messages(messages)
        apply_rate_limiter_sync(self.a0_model_conf, str(msgs))

        result = ChatGenerationResult()
        for chunk in completion(
            model=self.model_name,
            messages=msgs,
            stream=True,
            **{**self.kwargs, **kwargs},
        ):
            parsed = _parse_chunk(chunk)
            output = result.add_chunk(parsed)
            if output["response_delta"]:
                # Yield incremental deltas using ChatResponse(delta=...)
                yield ChatResponse(
                    message=ChatMessage(role="assistant", content=result.response),
                    delta=output["response_delta"],
                    raw=chunk,
                )

    async def achat(self, messages: List[ChatMessage], **kwargs: Any) -> ChatResponse:
        msgs = self._convert_messages(messages)
        await apply_rate_limiter(self.a0_model_conf, str(msgs))

        result = ChatGenerationResult()
        response = await acompletion(
            model=self.model_name,
            messages=msgs,
            stream=True,
            **{**self.kwargs, **kwargs}
        )
        async for chunk in response:  # type: ignore
            parsed = _parse_chunk(chunk)
            result.add_chunk(parsed)

        final = result.output()
        return ChatResponse(
            message=ChatMessage(role="assistant", content=final["response_delta"]),
            raw=None,
        )

    async def astream_chat(self, messages: List[ChatMessage], **kwargs: Any) -> AsyncIterator[ChatResponse]:
        msgs = self._convert_messages(messages)
        await apply_rate_limiter(self.a0_model_conf, str(msgs))

        result = ChatGenerationResult()
        response = await acompletion(
            model=self.model_name,
            messages=msgs,
            stream=True,
            **{**self.kwargs, **kwargs}
        )
        async for chunk in response:  # type: ignore
            parsed = _parse_chunk(chunk)
            output = result.add_chunk(parsed)
            if output["response_delta"]:
                yield ChatResponse(
                    message=ChatMessage(role="assistant", content=result.response),
                    delta=output["response_delta"],
                    raw=chunk,
                )

    # ---- Convenience unified call with callbacks (kept API from your original) ----
    async def unified_call(
        self,
        system_message: str = "",
        user_message: str = "",
        messages: List[ChatMessage] | None = None,
        response_callback: Callable[[str, str], Awaitable[None]] | None = None,
        reasoning_callback: Callable[[str, str], Awaitable[None]] | None = None,
        tokens_callback: Callable[[str, int], Awaitable[None]] | None = None,
        rate_limiter_callback: (
            Callable[[str, str, int, int], Awaitable[bool]] | None
        ) = None,
        **kwargs: Any,
    ) -> Tuple[str, str]:
        """
        Streams using LiteLLM acompletion and returns (response_text, reasoning_text).
        """
        turn_off_logging()

        if not messages:
            messages = []
        if system_message:
            messages.insert(0, ChatMessage(role="system", content=system_message))
        if user_message:
            messages.append(ChatMessage(role="user", content=user_message))

        msgs_conv = self._convert_messages(messages)

        # Apply rate limiting if configured
        limiter = await apply_rate_limiter(
            self.a0_model_conf, str(msgs_conv), rate_limiter_callback
        )

        # call model (stream)
        _completion = await acompletion(
            model=self.model_name,
            messages=msgs_conv,
            stream=True,
            **{**self.kwargs, **kwargs},
        )

        # results
        result = ChatGenerationResult()

        # iterate over chunks
        async for chunk in _completion:  # type: ignore
            parsed = _parse_chunk(chunk)
            output = result.add_chunk(parsed)

            # collect reasoning delta and call callbacks
            if output["reasoning_delta"]:
                if reasoning_callback:
                    await reasoning_callback(output["reasoning_delta"], result.reasoning)
                if tokens_callback:
                    await tokens_callback(
                        output["reasoning_delta"],
                        approximate_tokens(output["reasoning_delta"]),
                    )
                if limiter:
                    limiter.add(output=approximate_tokens(output["reasoning_delta"]))

            # collect response delta and call callbacks
            if output["response_delta"]:
                if response_callback:
                    await response_callback(output["response_delta"], result.response)
                if tokens_callback:
                    await tokens_callback(
                        output["response_delta"],
                        approximate_tokens(output["response_delta"]),
                    )
                if limiter:
                    limiter.add(output=approximate_tokens(output["response_delta"]))

        # return complete results
        return result.response, result.reasoning


class BrowserCompatibleChatWrapper(LiteLLMChatWrapper):
    """
    A wrapper for browser agents that may expect a .model attribute.
    """
    def __init__(self, *args, **kwargs):
        turn_off_logging()
        super().__init__(*args, **kwargs)
        # Browser-use may expect a 'model' attribute
        self.model = self.model_name


# =============================
# Embedding (LlamaIndex) Wrappers
# =============================

class LiteLLMEmbeddingWrapper(BaseEmbedding):
    """Wrapper for LiteLLM embeddings to fit LlamaIndex BaseEmbedding interface."""

    kwargs: Dict[str, Any] = pd_Field(default_factory=dict)
    model_conf: Optional[Any] = None

    def __init__(
        self,
        model: str,
        provider: str,
        model_config: Optional[ModelConfig] = None,
        **kwargs: Any,
    ):
        super().__init__()
        # For LiteLLM: OpenAI models just use the raw name,
        # Other providers expect provider/model format
        self.model_name = f"{provider}/{model}" if provider != "openai" else model
        self.kwargs = kwargs
        self.model_conf = model_config

    # --- required BaseEmbedding abstract methods ---

    def _get_text_embedding(self, text: str) -> List[float]:
        """Embed a single text string."""
        apply_rate_limiter_sync(self.model_conf, text)
        resp = embedding(model=self.model_name, input=[text], **self.kwargs)
        item = resp.data[0]  
        return item.get("embedding") if isinstance(item, dict) else item.embedding 

    def _get_query_embedding(self, query: str) -> List[float]:
        """Embed a query string (same as text for LiteLLM models)."""
        return self._get_text_embedding(query)

    async def _aget_text_embedding(self, text: str) -> List[float]:
        """Embed a single text string."""
        apply_rate_limiter_sync(self.model_conf, text)
        resp = await aembedding(model=self.model_name, input=[text], **self.kwargs)
        item = resp.data[0]  
        return item.get("embedding") if isinstance(item, dict) else item.embedding 
    
    async def _aget_query_embedding(self, query: str) -> List[float]:
        """Async version of query embedding."""
        resp = await aembedding(model=self.model_name, input=[query], **self.kwargs)
        item = resp.data[0]
        return item.get("embedding") if isinstance(item, dict) else item.embedding

    def _get_text_embeddings(self, texts: List[str]) -> List[List[float]]:
        """Embed a batch of texts."""
        apply_rate_limiter_sync(self.model_conf, " ".join(texts))
        resp = embedding(model=self.model_name, input=texts, **self.kwargs)
        return [
            item.get("embedding") if isinstance(item, dict) else item.embedding  # type: ignore
            for item in resp.data  # type: ignore
        ]


# ======================
# Factory / Helper funcs
# ======================

def _get_litellm_chat(
    cls: type = LiteLLMChatWrapper,
    model_name: str = "",
    provider_name: str = "",
    model_config: Optional[ModelConfig] = None,
    **kwargs: Any,
):
    # use api key from kwargs or env
    api_key = kwargs.pop("api_key", None) or get_api_key(provider_name)

    # Only pass API key if key is not a placeholder
    if api_key and api_key not in ("None", "NA"):
        kwargs["api_key"] = api_key

    provider_name, model_name, kwargs = _adjust_call_args(
        provider_name, model_name, kwargs
    )
    return cls(
        provider=provider_name, model=model_name, model_config=model_config, **kwargs
    )


def _get_litellm_embedding(
    model_name: str,
    provider_name: str,
    model_config: Optional[ModelConfig] = None,
    **kwargs: Any,
):
    # Check if this is a local sentence-transformers model
    if provider_name == "huggingface" :
       raise NotImplementedError("Use LocalSentenceTransformerWrapper for local sentence-transformers models.")
    
    # use api key from kwargs or env
    api_key = kwargs.pop("api_key", None) or get_api_key(provider_name)

    # Only pass API key if key is not a placeholder
    if api_key and api_key not in ("None", "NA"):
        kwargs["api_key"] = api_key

    provider_name, model_name, kwargs = _adjust_call_args(
        provider_name, model_name, kwargs
    )
    return LiteLLMEmbeddingWrapper(
        model=model_name, provider=provider_name, model_config=model_config, **kwargs
    )


def _parse_chunk(chunk: Any) -> ChatChunk:
    """
    Parse LiteLLM (sync or stream) chunk to extract content + reasoning.
    Supports providers that put text either in choices[].delta or choices[].message,
    and reasoning in "reasoning_content".
    """
    delta = chunk["choices"][0].get("delta", {})
    message = chunk["choices"][0].get("message", {}) or chunk["choices"][0].get(
        "model_extra", {}
    ).get("message", {})
    response_delta = (
        delta.get("content", "")
        if isinstance(delta, dict)
        else getattr(delta, "content", "")
    ) or (
        message.get("content", "")
        if isinstance(message, dict)
        else getattr(message, "content", "")
    )
    reasoning_delta = (
        delta.get("reasoning_content", "")
        if isinstance(delta, dict)
        else getattr(delta, "reasoning_content", "")
    )

    return ChatChunk(reasoning_delta=reasoning_delta, response_delta=response_delta)


def _adjust_call_args(provider_name: str, model_name: str, kwargs: dict):
    # remap other to openai for litellm
    if provider_name == "other":
        provider_name = "openai"

    return provider_name, model_name, kwargs


def _merge_provider_defaults(
    provider_type: str, original_provider: str, kwargs: dict
) -> tuple[str, dict]:
    # Normalize .env-style numeric strings (e.g., "timeout=30") into ints/floats for LiteLLM
    def _normalize_values(values: dict) -> dict:
        result: dict[str, Any] = {}
        for k, v in values.items():
            if isinstance(v, str):
                try:
                    result[k] = int(v)
                except ValueError:
                    try:
                        result[k] = float(v)
                    except ValueError:
                        result[k] = v
            else:
                result[k] = v
        return result

    provider_name = original_provider  # default: unchanged
    cfg = get_provider_config(provider_type, original_provider)
    if cfg:
        provider_name = cfg.get("litellm_provider", original_provider).lower()

        # Extra arguments nested under `kwargs` for readability
        extra_kwargs = cfg.get("kwargs") if isinstance(cfg, dict) else None  # type: ignore[arg-type]
        if isinstance(extra_kwargs, dict):
            for k, v in extra_kwargs.items():
                kwargs.setdefault(k, v)

    # Inject API key based on the *original* provider id if still missing
    if "api_key" not in kwargs:
        key = get_api_key(original_provider)
        if key and key not in ("None", "NA"):
            kwargs["api_key"] = key

    # Merge LiteLLM global kwargs (timeouts, stream_timeout, etc.)
    try:
        global_kwargs = settings.get_settings().get("litellm_global_kwargs", {})  # type: ignore[union-attr]
    except Exception:
        global_kwargs = {}
    if isinstance(global_kwargs, dict):
        for k, v in _normalize_values(global_kwargs).items():
            kwargs.setdefault(k, v)

    return provider_name, kwargs


# =========
# Factories
# =========

def get_chat_model(
    provider: str, name: str, model_config: Optional[ModelConfig] = None, **kwargs: Any
) -> LiteLLMChatWrapper:
    orig = provider.lower()
    provider_name, kwargs = _merge_provider_defaults("chat", orig, kwargs)
    return _get_litellm_chat(
        LiteLLMChatWrapper, name, provider_name, model_config, **kwargs
    )


def get_browser_model(
    provider: str, name: str, model_config: Optional[ModelConfig] = None, **kwargs: Any
) -> BrowserCompatibleChatWrapper:
    orig = provider.lower()
    provider_name, kwargs = _merge_provider_defaults("chat", orig, kwargs)
    return _get_litellm_chat(
        BrowserCompatibleChatWrapper, name, provider_name, model_config, **kwargs
    )


def get_embedding_model(
    provider: str, name: str, model_config: Optional[ModelConfig] = None, **kwargs: Any
) -> LiteLLMEmbeddingWrapper :
    orig = provider.lower()
    provider_name, kwargs = _merge_provider_defaults("embedding", orig, kwargs)
    return _get_litellm_embedding(name, provider_name, model_config, **kwargs)
