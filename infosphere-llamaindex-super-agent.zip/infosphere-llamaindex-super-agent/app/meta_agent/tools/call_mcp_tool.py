# call_mcp_tool.py
from typing import Any, Dict, List, Optional
from app.meta_agent.utils.tool import Tool, Response
from app.meta_agent.utils.print_style import PrintStyle
from fastmcp.client import Client

# Default MCP server
MCP_URL_DEFAULT = "http://127.0.0.1:3000/mcp"

# Cache discovered tools per mcp_url
_DISCOVERED_TOOLS_CACHE: Dict[str, List[str]] = {}


class MCPTool(Tool):
    """
    Minimal MCPTool:
      - primary selector: mcp_tool_name (alias: tool, tool_name)
      - server: mcp_url (alias: agent_url). Defaults to MCP_URL_DEFAULT.
      - discovery: client.list_tools / client.get_tools / client.call_tool("list_tools", {})
      - fallback: explicit `fallback_tools` kwarg (List[str]) used & cached when network discovery fails
      - supports `run_all_tools` (bool) and optional `tool_order` (List[str]) to enforce order
      - accepts nested `tool_args` dict for payload
    """

    async def execute(self, **kwargs) -> Response:
        """
        Backwards-friendly execute:
          - aliases: agent_url -> mcp_url, tool_name -> mcp_tool_name
          - nested tool_args becomes the payload for the called tool
          - supports run_all_tools (bool) and optional tool_order (List[str])
        """
        print(f"Inside mcp tool")
        # Normalize common aliases (backwards compatibility)
        if "agent_url" in kwargs and "mcp_url" not in kwargs:
            kwargs["mcp_url"] = kwargs.pop("agent_url")
        if "tool_name" in kwargs and "mcp_tool_name" not in kwargs and "tool" not in kwargs:
            kwargs["mcp_tool_name"] = kwargs.pop("tool_name")

        PrintStyle.info(f"MCPTool.execute called with kwargs: {list(kwargs.keys())}")

        requested_tool: Optional[str] = kwargs.get("mcp_tool_name") or kwargs.get("tool")
        tool_placeholder: Optional[str] = kwargs.get("tool_placeholder")

        mcp_url: str = kwargs.get("mcp_url", MCP_URL_DEFAULT)
        fallback_tools: Optional[List[str]] = kwargs.get("fallback_tools")

        # unwrap nested tool_args
        nested_tool_args = kwargs.get("tool_args") if isinstance(kwargs.get("tool_args"), dict) else {}
        # base payload: include top-level keys except internal ones
        base_payload: Dict[str, Any] = {
            k: v for k, v in kwargs.items()
            if k not in {
                "mcp_tool_description","mcp_url", "agent_url", "tool", "tool_name", "mcp_tool_name", "tool_placeholder",
                "fallback_tools", "tool_args", "run_all_tools", "run_all", "tool_order"
            }
        }
        payload_for_call = {**base_payload, **nested_tool_args}

        # run_all flag and tool_order (optional)
        run_all = kwargs.get("run_all_tools") or kwargs.get("run_all") or False
        tool_order: Optional[List[str]] = kwargs.get("tool_order") if isinstance(kwargs.get("tool_order"), list) else None

        # If no concrete tool requested and not running all, return discovered list (break_loop=True)
        if not requested_tool and not run_all:
            try:
                tools = await self.discover_tools(mcp_url, fallback_tools=fallback_tools)
            except Exception as e:
                PrintStyle.error(f"Tool discovery failed at {mcp_url}: {e}")
                return Response(message=f"Tool discovery failed: {e}", break_loop=False)

            # placeholder auto-select
            if tool_placeholder and isinstance(tool_placeholder, str):
                tool_placeholder = tool_placeholder.strip()
                if tool_placeholder in tools:
                    requested_tool = tool_placeholder
                    PrintStyle.debug(f"Placeholder '{tool_placeholder}' matched discovered tool; proceeding.")
                else:
                    message = {
                        "discovered_tools": tools,
                        "placeholder": tool_placeholder,
                        "note": f"Placeholder '{tool_placeholder}' did not match any discovered tool on {mcp_url}."
                    }
                    return Response(message=str(message), break_loop=True)

            return Response(message=str({"discovered_tools": tools, "mcp_url": mcp_url}), break_loop=True)

        # If run_all requested: discover and call each tool (respect tool_order if provided)
        if run_all and not requested_tool:
            try:
                tools = await self.discover_tools(mcp_url, fallback_tools=fallback_tools)
            except Exception as e:
                PrintStyle.error(f"Tool discovery failed at {mcp_url}: {e}")
                return Response(message=f"Tool discovery failed: {e}", break_loop=False)

            # apply optional ordering: first the tools in tool_order (if present and in discovered), then remaining discovered tools
            ordered_tools: List[str] = []
            if tool_order:
                for t in tool_order:
                    if t in tools and t not in ordered_tools:
                        ordered_tools.append(t)
                for t in tools:
                    if t not in ordered_tools:
                        ordered_tools.append(t)
            else:
                ordered_tools = tools

            aggregated: Dict[str, Any] = {}
            try:
                async with Client(mcp_url) as client:
                    for t in ordered_tools:
                        try:
                            PrintStyle.debug(f"Calling tool '{t}' as part of run_all with payload: {payload_for_call}")
                            res = await client.call_tool(t, payload_for_call)
                            aggregated[t] = {"status": "ok", "result": res}
                        except Exception as te:
                            PrintStyle.error(f"Tool '{t}' failed: {te}")
                            aggregated[t] = {"status": "error", "error": str(te)}
                return Response(message=str(aggregated), break_loop=False)
            except Exception as e:
                PrintStyle.error(f"Failed to open client for run_all at {mcp_url}: {e}")
                # if fallback_tools present, ensure they are cached for UI
                if mcp_url not in _DISCOVERED_TOOLS_CACHE and fallback_tools:
                    try:
                        await self._cache_fallback_tools(mcp_url, fallback_tools)
                    except Exception:
                        pass
                return Response(message=f"run_all_tools failed: {e}", break_loop=False)

        # If a specific tool requested: call it
        if requested_tool:
            requested_tool = requested_tool.strip()
            try:
                async with Client(mcp_url) as client:
                    PrintStyle.debug(f"Calling remote tool '{requested_tool}' at {mcp_url} with payload: {payload_for_call}")
                    remote_result: Any = await client.call_tool(requested_tool, payload_for_call)

                # Normalize remote result
                if isinstance(remote_result, dict):
                    for key in ("result", "output", "message", "data"):
                        if key in remote_result:
                            result_text = remote_result[key]
                            break
                    else:
                        result_text = remote_result
                else:
                    result_text = remote_result

                return Response(message=str(result_text), break_loop=False)

            except Exception as e:
                PrintStyle.error(f"MCPTool error calling '{requested_tool}' at {mcp_url}: {e}")
                # ensure cache exists for UI if fallback_tools provided
                if mcp_url not in _DISCOVERED_TOOLS_CACHE and fallback_tools:
                    try:
                        await self._cache_fallback_tools(mcp_url, fallback_tools)
                    except Exception:
                        pass
                return Response(message=f"MCPTool error calling '{requested_tool}': {e}", break_loop=False)

        # unreachable guard
        return Response(message="No operation performed (insufficient inputs).", break_loop=False)

    async def _cache_fallback_tools(self, mcp_url: str, fallback_tools: List[str]) -> List[str]:
        names = [t for t in fallback_tools if isinstance(t, str)]
        _DISCOVERED_TOOLS_CACHE[mcp_url] = names
        PrintStyle.debug(f"Cached {len(names)} fallback tools for {mcp_url}")
        return names

    async def discover_tools(self, mcp_url: str, fallback_tools: Optional[List[str]] = None) -> List[str]:
        """
        Discover tools from the MCP server or use fallback_tools if provided and discovery fails.
        Returns list of tool names (and caches them).
        """
        # Return cache if available
        if mcp_url in _DISCOVERED_TOOLS_CACHE:
            PrintStyle.debug(f"Using cached tools for {mcp_url}")
            return _DISCOVERED_TOOLS_CACHE[mcp_url]

        PrintStyle.debug(f"Discovering tools from MCP at {mcp_url}...")
        try:
            async with Client(mcp_url) as client:
                # Preferred API: list_tools()
                if hasattr(client, "list_tools"):
                    try:
                        tools = await client.list_tools()
                        if isinstance(tools, list):
                            tool_names = [
                                t if isinstance(t, str) else (t.get("name") if isinstance(t, dict) else str(t))
                                for t in tools
                            ]
                            _DISCOVERED_TOOLS_CACHE[mcp_url] = tool_names
                            PrintStyle.info(f"Discovered {len(tool_names)} tools via list_tools() at {mcp_url}")
                            return tool_names
                    except Exception as e:
                        PrintStyle.debug(f"client.list_tools() failed: {e}")

                # Alternate API: get_tools()
                if hasattr(client, "get_tools"):
                    try:
                        tools = await client.get_tools()
                        if isinstance(tools, list):
                            tool_names = [
                                t if isinstance(t, str) else (t.get("name") if isinstance(t, dict) else str(t))
                                for t in tools
                            ]
                            _DISCOVERED_TOOLS_CACHE[mcp_url] = tool_names
                            PrintStyle.info(f"Discovered {len(tool_names)} tools via get_tools() at {mcp_url}")
                            return tool_names
                    except Exception as e:
                        PrintStyle.debug(f"client.get_tools() failed: {e}")

                # Fallback helper call: call_tool('list_tools', {})
                try:
                    remote = await client.call_tool("list_tools", {})
                    if isinstance(remote, list):
                        tool_names = [
                            t if isinstance(t, str) else (t.get("name") if isinstance(t, dict) else str(t))
                            for t in remote
                        ]
                        _DISCOVERED_TOOLS_CACHE[mcp_url] = tool_names
                        PrintStyle.info(f"Discovered {len(tool_names)} tools via call_tool('list_tools') at {mcp_url}")
                        return tool_names
                    if isinstance(remote, dict) and "tools" in remote:
                        tools = remote["tools"]
                        tool_names = [
                            t if isinstance(t, str) else (t.get("name") if isinstance(t, dict) else str(t))
                            for t in tools
                        ]
                        _DISCOVERED_TOOLS_CACHE[mcp_url] = tool_names
                        PrintStyle.info(f"Discovered {len(tool_names)} tools via call_tool('list_tools') at {mcp_url}")
                        return tool_names
                except Exception as e:
                    PrintStyle.debug(f"client.call_tool('list_tools') failed: {e}")

        except Exception as client_exc:
            PrintStyle.debug(f"Client discovery raised exception: {client_exc}")

        # Network discovery failed -> use explicit fallback_tools if provided
        if fallback_tools:
            PrintStyle.info(f"Using explicit fallback_tools for {mcp_url}")
            return await self._cache_fallback_tools(mcp_url, fallback_tools)

        # Nothing to return
        PrintStyle.error(f"Tool discovery failed for {mcp_url} and no fallback_tools provided.")
        raise RuntimeError("Could not discover tools from MCP server (no supported discovery API succeeded).")
