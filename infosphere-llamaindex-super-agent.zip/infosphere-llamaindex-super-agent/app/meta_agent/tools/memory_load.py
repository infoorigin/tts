from app.meta_agent.utils.memory import Memory
from app.meta_agent.utils.tool import Tool, Response

DEFAULT_THRESHOLD = 0.7
DEFAULT_LIMIT = 10


class MemoryLoad(Tool):

    async def execute(self, query="", threshold=DEFAULT_THRESHOLD, limit=DEFAULT_LIMIT, filter="", **kwargs):
        db = await Memory.get(self.agent)

        # --- Build safe role filter ---
        agent_role = getattr(self.agent.config, "profile", "").lower()
        if agent_role and agent_role != "none":
            # Restrict to the agent’s own role or shared docs
            role_filter = f"agent_role == '{agent_role}' or agent_role == 'none'"
        else:
            # Default (e.g., for savant_meta or global agents)
            role_filter = "agent_role == 'none'"

        # --- Combine with any incoming filter (like area filters) ---
        if filter:
            final_filter = f"({filter}) and ({role_filter})"
        else:
            final_filter = role_filter

        # --- Query memory database ---
        docs = await db.search_similarity_threshold(
            query=query,
            limit=limit,
            threshold=threshold,
            filter=final_filter,
        )

        if len(docs) == 0:
            result = self.agent.read_prompt("fw.memories_not_found.md", query=query)
        else:
            text = "\n\n".join(Memory.format_docs_plain(docs))
            result = str(text)

        return Response(message=result, break_loop=False)
