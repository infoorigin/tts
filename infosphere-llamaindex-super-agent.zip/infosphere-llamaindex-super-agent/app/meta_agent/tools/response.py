from app.meta_agent.utils.agent_activity_dispatcher import LogDispatcher
from app.meta_agent.utils.tool import Tool, Response


class ResponseTool(Tool):

    async def execute(self, **kwargs):
        return Response(message=self.args["text"] if "text" in self.args else self.args["message"], break_loop=True)

    async def before_execution(self, **kwargs):
        pass

    async def after_execution(self, response, **kwargs):
        # do not add anything to the history or output

        if self.loop_data and "log_item_response" in self.loop_data.params_temporary:
            activity_item = self.loop_data.params_temporary["log_item_response"]
            activity_item.update(finished=True) # mark the message as finished
            # await LogDispatcher.get_instance().publish(self.agent.context.agent_activity, activity_item.no)
