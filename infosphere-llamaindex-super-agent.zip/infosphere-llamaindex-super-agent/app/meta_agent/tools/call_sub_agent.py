from app.meta_agent.utils.tool import Tool, Response
from app.meta_agent.initialize import initialize_agent
import app.meta_agent.agent as agent_mod
from app.meta_agent.agent import Agent, UserMessage, HandledException


class Delegation(Tool):

    async def execute(self, message: str = "", reset: str = "", **kwargs):
        """
        Delegate message handling to a subordinate agent.
        Contributes to the global iteration guard and aborts when the cap is exceeded.
        """

        # Count this tool call toward the global ceiling
        agent_mod.GLOBAL_ITERATION_COUNT += 1
        if agent_mod.GLOBAL_ITERATION_COUNT > agent_mod.MAX_ITERATION:
            warning_msg = (
                f"Sub-agent delegation stopped — reached global iteration limit ({agent_mod.MAX_ITERATION})."
            )
            print(warning_msg)
            # Hard abort so recursion unwinds fast and consistently
            raise HandledException(warning_msg)

        # (Re)create subordinate if missing or reset requested
        if (
            self.agent.get_data(Agent.DATA_NAME_SUBORDINATE) is None
            or str(reset).lower().strip() == "true"
        ):
            # initialize default config
            config = initialize_agent()

            # set subordinate prompt profile if provided, if not, keep original
            agent_profile = kwargs.get("profile")
            if agent_profile:
                config.profile = agent_profile
            #Below line Added for testing purpose
            # default_agent = self.agent.agent_name
            # crate agent
            sub = Agent(self.agent.number + 1, config, self.agent.context)
            # register superior/subordinate
            sub.set_data(Agent.DATA_NAME_SUPERIOR, self.agent)
            self.agent.set_data(Agent.DATA_NAME_SUBORDINATE, sub)
            
        # add user message to subordinate agent
        subordinate: Agent = self.agent.get_data(Agent.DATA_NAME_SUBORDINATE)  # type: ignore
        subordinate.hist_add_user_message(UserMessage(message=message, attachments=[]))
        #Below line Added for testing purpose
        # run subordinate monologue
        result = await subordinate.run_message_workflow()

        # hint to use includes for long responses
        additional = None

        # result
        return Response(message=result, break_loop=False, additional=additional)

    def get_log_object(self):
        return self.agent.context.log.log(
            type="tool",
            heading=f"icon://communication {self.agent.agent_name}: Calling Subordinate Agent",
            content="",
            kvps=self.args,
        )