# # from app.meta_agent.utils.tool import Tool, Response

# # class MathTool(Tool):
# #     """Tool to perform addition and solve expressions."""

# #     async def execute(self, text: str = "", **kwargs):
# #         result = kwargs.get("solution", "")
# #         return Response(message=result, break_loop=False)









import sympy as sp
import re
from sympy.parsing.sympy_parser import parse_expr
from app.meta_agent.utils.tool import Tool, Response
from llama_index.core.llms import ChatMessage
import json
from app.meta_agent.utils.extract_tools import json_parse_dirty

class MathTool(Tool):
    """Tool to perform mathematical calculations"""

    async def execute(self, text: str = "", **kwargs):
        """
        Executes math problems.
        """
        try:
            # Clean and parse input as sympy expression
            cleaned = text.lower().replace("^", "**")
            cleaned = re.sub(r'[^0-9a-z+\-*/().= ]', '', cleaned)

            # Try direct expression evaluation
            expr = parse_expr(cleaned, evaluate=True)
            result = sp.simplify(expr)
            solution = f"The result for '{text}' is {result}."
            return Response(message=solution, break_loop=False)

        except Exception:
            # Try equation solving if '=' present
            if "=" in text:
                try:
                    lhs, rhs = cleaned.split("=")
                    eq = sp.Eq(parse_expr(lhs), parse_expr(rhs))
                    solutions = sp.solve(eq)
                    solution = f"The solution for '{text}' is {solutions}."
                    return Response(message=solution, break_loop=False)
                except Exception:
                    pass

            # Fallback: basic word problem solver
            numbers = [float(n) for n in re.findall(r'\d+(?:\.\d+)?', cleaned)]
            solution = "Unable to solve this word problem automatically."
            if numbers:
                if "sum" in cleaned or "total" in cleaned:
                    solution = f"The total of {numbers} is {sum(numbers)}."
                elif "difference" in cleaned or "less" in cleaned:
                    solution = f"The difference between {numbers[0]} and {numbers[1]} is {numbers[0] - numbers[1]}."
                elif "product" in cleaned or "times" in cleaned:
                    solution = f"The product of {numbers[0]} and {numbers[1]} is {numbers[0] * numbers[1]}."
                elif "divide" in cleaned or "per" in cleaned:
                    solution = f"{numbers[0]} divided by {numbers[1]} is {numbers[0] / numbers[1]}."
                else:
                    prompt = self.agent.read_prompt("fw.math_calculation.md")
                    user_message = text
                    llama_index_prompt = [
                        {"role": "system", "content": prompt},
                        {"role": "user", "content":user_message}
                    ]
                    chat_messages = [ChatMessage(role=m["role"], content=m["content"]) for m in llama_index_prompt]
                    # lite_llm_messages = self._convert_messages(chat_messages)
                    solution, reasoning = await self.agent.call_chat_model(messages=chat_messages)
                    parsed_json = json_parse_dirty(solution)
                    cleaned_result = parsed_json['solution']
            return Response(message=cleaned_result, break_loop=False)




# import re
# import sympy as sp
# from sympy.parsing.sympy_parser import parse_expr
# from app.meta_agent.utils.tool import Tool, Response

# class MathTool(Tool):
#     """Tool to perform mathematical reasoning and equation solving."""

#     async def execute(self, text: str = "", **kwargs):
#         cleaned = self._clean_input(text)

#         # Try expression evaluation first
#         result = self._try_expression(cleaned)
#         if result is not None:
#             return Response(message=f"The result for '{text}' is {result}.", break_loop=False)

#         # Try equation solving if '=' present
#         result = self._try_equation(cleaned)
#         if result is not None:
#             return Response(message=f"The solution for '{text}' is {result}.", break_loop=False)

#         # Fallback for simple word problems
#         result = self._try_word_problem(cleaned)
#         return Response(message=result, break_loop=False)

#     def _clean_input(self, text: str) -> str:
#         text = text.lower().replace("^", "**")
#         return re.sub(r'[^0-9a-z+\-*/().= ]', '', text)

#     def _try_expression(self, cleaned: str):
#         try:
#             expr = parse_expr(cleaned, evaluate=True)
#             return sp.simplify(expr)
#         except Exception:
#             return None

#     def _try_equation(self, cleaned: str):
#         if "=" not in cleaned:
#             return None
#         try:
#             lhs, rhs = cleaned.split("=")
#             eq = sp.Eq(parse_expr(lhs), parse_expr(rhs))
#             return sp.solve(eq)
#         except Exception:
#             return None

#     def _try_word_problem(self, cleaned: str):
#         numbers = [float(n) for n in re.findall(r'\d+(?:\.\d+)?', cleaned)]
#         if not numbers:
#             return "Unable to solve this problem automatically."
#         if "sum" in cleaned or "total" in cleaned:
#             return f"The total of {numbers} is {sum(numbers)}."
#         if "difference" in cleaned or "less" in cleaned and len(numbers) >= 2:
#             return f"The difference between {numbers[0]} and {numbers[1]} is {numbers[0] - numbers[1]}."
#         if "product" in cleaned or "times" in cleaned and len(numbers) >= 2:
#             return f"The product of {numbers[0]} and {numbers[1]} is {numbers[0] * numbers[1]}."
#         if "divide" in cleaned or "per" in cleaned and len(numbers) >= 2:
#             return f"{numbers[0]} divided by {numbers[1]} is {numbers[0] / numbers[1]}."
#         return "Unable to interpret this word problem."





# import re
# from app.meta_agent.utils.tool import Tool, Response

# class MathTool(Tool):
#     """Simple Math Tool with direct arithmetic and LLM fallback for word problems."""

#     async def execute(self, text: str = "", **kwargs):
#         # Clean input
#         cleaned = text.lower()

#         # Try simple arithmetic
#         simple_result = self._try_simple_arithmetic(cleaned)
#         if simple_result is not None:
#             return Response(message=f"The result for '{text}' is {simple_result}.", break_loop=False)

#         # Fallback: Word problem → call LLM with prompt
#         llm_prompt = self.agent.read_prompt("fw.math_calculation.md").format(problem=text)
#         return Response(message={
#                 "problem": text,
#                 "solution": ""
#             }, break_loop=True)  # break_loop=True to trigger LLM

#     def _try_simple_arithmetic(self, text: str):
#         # Match simple expressions like "5 + 3" or "12 * 4"
#         match = re.match(r'^\s*(\d+)\s*([+\-*/])\s*(\d+)\s*$', text)
#         if match:
#             a, op, b = match.groups()
#             a, b = float(a), float(b)
#             if op == '+':
#                 return a + b
#             elif op == '-':
#                 return a - b
#             elif op == '*':
#                 return a * b
#             elif op == '/':
#                 return a / b if b != 0 else "Division by zero error"
#         return None



# import re
# import json
# from app.meta_agent.utils.tool import Tool, Response

# class MathTool(Tool):
#     """Simple Math Tool with direct arithmetic and LLM fallback for word problems."""

#     async def execute(self, text: str = "", **kwargs):
#         cleaned = text.lower()

#         # 1. Try simple arithmetic first
#         simple_result = self._try_simple_arithmetic(cleaned)
#         if simple_result is not None:
#             return Response(
#                 message={"problem": text, "solution": f"The result is {simple_result}."},
#                 break_loop=False,
#             )

#         # 2. Fallback: Solve word problem using LLM
#         llm_result = await self._solve_word_problem(text)
#         return Response(message=llm_result, break_loop=False)

#     def _try_simple_arithmetic(self, text: str):
#         """Detects and computes simple arithmetic expressions like 5+3, 10/2, etc."""
#         match = re.match(r'^\s*(\d+)\s*([+\-*/])\s*(\d+)\s*$', text)
#         if match:
#             a, op, b = match.groups()
#             a, b = float(a), float(b)
#             if op == '+':
#                 return a + b
#             elif op == '-':
#                 return a - b
#             elif op == '*':
#                 return a * b
#             elif op == '/':
#                 return a / b if b != 0 else "Division by zero error"
#         return None

#     async def _solve_word_problem(self, problem_text: str):
#         """
#         Calls LLM with a structured prompt and parses its JSON output.
#         Returns a dict with 'problem' and 'solution'.
#         """
#         # Read prompt template from Markdown file
#         llm_prompt = self.agent.read_prompt("fw.math_calculation.md").format(problem=problem_text)

#         # Call your agent's LLM interface
#         llm_response = await self.agent.call_chat_model(llm_prompt)

#         try:
#             result_json = json.loads(llm_response)
#             return result_json  # Should be {"problem": "...", "solution": "..."}
#         except json.JSONDecodeError:
#             # Fallback in case LLM didn't return valid JSON
#             return {"problem": problem_text, "solution": llm_response}


