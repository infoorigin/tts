import asyncio, random, string
import nest_asyncio

from app.meta_agent.utils.agent_activity_dispatcher import LogDispatcher
nest_asyncio.apply()

from collections import OrderedDict
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
import random,string
from typing import Any, Awaitable, Callable, Coroutine, Dict
from app.meta_agent.llm import models
from app.meta_agent.utils import files, history, dirty_json, tokens, extract_tools, errors
from app.meta_agent.utils.errors import RepairableException
from app.meta_agent.utils.dirty_json import DirtyJson
from app.meta_agent.utils.defer import DeferredTask
from app.meta_agent.utils.executors import call_executors
from llama_index.core.llms import ChatMessage
from llama_index.core.prompts import ChatPromptTemplate
from app.meta_agent.utils.localization import Localization
import app.meta_agent.utils.agent_activity as AgentActivity
from app.meta_agent.utils.print_style import PrintStyle
import json 
import os

# ---------- GLOBAL LOOP GUARD (module-wide, shared across all agents/tools) ----------
MAX_ITERATION = 15
GLOBAL_ITERATION_COUNT = 0
GLOBAL_CALL_DEPTH = 0  # tracks nested run_message_workflow depth; reset only when root exits
# ------------------------------------------------------------------------------------

class AgentContextType(Enum):
    USER = "user"
    TASK = "task"
    BACKGROUND = "background"

class HandledException(Exception):
    pass

class AgentContext:

    _contexts: dict[str, "AgentContext"] = {}
    _counter: int = 0
    _notification_manager = None

    def __init__(
        self,
        config: "AgentConfig",
        id: str | None = None,
        name: str | None = None,
        agent_meta: "Agent|None" = None,
        agent_activity: AgentActivity.AgentActivity | None = None,
        paused: bool = False,
        streaming_agent: "Agent|None" = None,
        created_at: datetime | None = None,
        type: AgentContextType = AgentContextType.USER,
        last_message: datetime | None = None,
    ):
        # build context
        self.id = id or AgentContext.generate_id()
        self.name = name
        self.config = config
        self.agent_activity = agent_activity or AgentActivity.AgentActivity(context_id=self.id)
        #Auto publish setup for listener
        #AgentActivity.setup_auto_publish(self.agent_activity)
        self.agent_meta = agent_meta or Agent(0,self.config, self)
        self.paused = paused
        self.streaming_agent = streaming_agent
        self.task: DeferredTask | None = None
        self.created_at = created_at or datetime.now(timezone.utc)
        self.type = type
        AgentContext._counter += 1
        self.no = AgentContext._counter
        # set to start of unix epoch
        self.last_message = last_message or datetime.now(timezone.utc)

        existing = self._contexts.get(self.id, None)
        if existing:
            AgentContext.remove(self.id)
        self._contexts[self.id] = self

    @staticmethod
    def get(id: str):
        return AgentContext._contexts.get(id, None)

    @staticmethod
    def first():
        if not AgentContext._contexts:
            return None
        return list(AgentContext._contexts.values())[0]

    @staticmethod
    def all():
        return list(AgentContext._contexts.values())

    @staticmethod
    def generate_id():
        def generate_short_id():
            return ''.join(random.choices(string.ascii_letters + string.digits, k=8))
        while True:
            short_id = generate_short_id()
            if short_id not in AgentContext._contexts:
                return short_id

    @classmethod
    def get_notification_manager(cls):
        if cls._notification_manager is None:
            from app.meta_agent.utils.notification import NotificationManager  # type: ignore
            cls._notification_manager = NotificationManager()
        return cls._notification_manager

    @staticmethod
    def remove(id: str):
        context = AgentContext._contexts.pop(id, None)
        if context and context.task:
            context.task.kill()
        return context

    def serialize(self):
        return {
            "id": self.id,
            "name": self.name,
            "created_at": (
                Localization.get().serialize_datetime(self.created_at)
                if self.created_at
                else Localization.get().serialize_datetime(datetime.fromtimestamp(0))
            ),
            "no": self.no,
            "log_guid": self.agent_activity.guid,
            "log_version": len(self.agent_activity.updates),
            "log_length": len(self.agent_activity.agent_activities),
            "paused": self.paused,
            "last_message": (
                Localization.get().serialize_datetime(self.last_message)
                if self.last_message
                else Localization.get().serialize_datetime(datetime.fromtimestamp(0))
            ),
            "type": self.type.value,
        }

    @staticmethod
    def log_to_all(
        type: AgentActivity.Type,
        heading: str | None = None,
        content: str | None = None,
        kvps: dict | None = None,
        temp: bool | None = None,
        update_progress: AgentActivity.ProgressUpdate | None = None,
        id: str | None = None,  # Add id parameter
        **kwargs,
    ) -> list[AgentActivity.AgentActivityItem]:
        items: list[AgentActivity.AgentActivityItem] = []
        for context in AgentContext.all():
            items.append(
                context.agent_activity.add_agent_activity(
                    type, heading, content, kvps, temp, update_progress, id, **kwargs
                )
            )
        return items

    def kill_process(self):
        if self.task:
            self.task.kill()

    def reset(self):
        self.kill_process()
        self.agent_activity.reset()
        self.agent_meta = Agent(0, self.config, self)
        self.streaming_agent = None
        self.paused = False

    def nudge(self):
        self.kill_process()
        self.paused = False
        self.task = self.run_task(self.get_agent().run_message_workflow)
        return self.task

    def get_agent(self):
        return self.streaming_agent or self.agent_meta

    def communicate(self, msg: "UserMessage", broadcast_level: int = 1):
        self.paused = False  # unpause if paused

        current_agent = self.get_agent()

        if self.task and self.task.is_alive():
            # set intervention messages to agent(s):
            intervention_agent = current_agent
            while intervention_agent and broadcast_level != 0:
                intervention_agent.intervention = msg
                broadcast_level -= 1
                intervention_agent = intervention_agent.data.get(
                    Agent.DATA_NAME_SUPERIOR, None
                )
        else:
            self.task = self.run_task(self._process_chain, current_agent, msg)

        return self.task

    def run_task(
        self, func: Callable[..., Coroutine[Any, Any, Any]], *args: Any, **kwargs: Any
    ):
        if not self.task:
            self.task = DeferredTask(
                thread_name=self.__class__.__name__,
            )
        self.task.start_task(func, *args, **kwargs)
        return self.task

    # this wrapper ensures that superior agents are called back if the chat was loaded from file and original callstack is gone
    async def _process_chain(self, agent: "Agent", msg: "UserMessage|str", user=True):
        try:
            msg_template = (
                agent.hist_add_user_message(msg)  # type: ignore
                if user
                else agent.hist_add_tool_result(
                    tool_name="call_sub_agent", tool_result=msg  # type: ignore
                )
            )
            response = await agent.run_message_workflow()  # type: ignore
            superior = agent.data.get(Agent.DATA_NAME_SUPERIOR, None)
            if superior:
                response = await self._process_chain(superior, response, False)  # type: ignore
            return response
        except Exception as e:
            agent.handle_critical_exception(e)



@dataclass
class AgentConfig:
    chat_model: models.ModelConfig
    utility_model: models.ModelConfig
    embeddings_model: models.ModelConfig
    browser_model: models.ModelConfig
    mcp_servers: str
    profile: str = ""
    memory_subdir: str = ""
    knowledge_subdirs: list[str] = field(default_factory=lambda: ["default", "custom"])
    browser_http_headers: dict[str, str] = field(default_factory=dict)  # Custom HTTP headers for browser requests
    code_exec_ssh_enabled: bool = True
    code_exec_ssh_addr: str = "localhost"
    code_exec_ssh_port: int = 55022
    code_exec_ssh_user: str = "root"
    code_exec_ssh_pass: str = ""
    additional: Dict[str, Any] = field(default_factory=dict)


@dataclass
class UserMessage:
    message: str
    attachments: list[str] = field(default_factory=list[str])
    system_message: list[str] = field(default_factory=list[str])


class LoopData:
    def __init__(self, **kwargs):
        self.iteration = -1
        self.system = []
        self.user_message: history.Message | None = None
        self.history_output: list[history.OutputMessage] = []
        self.extras_temporary: OrderedDict[str, history.MessageContent] = OrderedDict()
        self.extras_persistent: OrderedDict[str, history.MessageContent] = OrderedDict()
        self.last_response = ""
        self.params_temporary: dict = {}
        self.params_persistent: dict = {}

        # override values with kwargs
        for key, value in kwargs.items():
            setattr(self, key, value)

class Agent:

    DATA_NAME_SUPERIOR = "_superior"
    DATA_NAME_SUBORDINATE = "_subordinate"
    DATA_NAME_CTX_WINDOW = "ctx_window"

    def __init__(
        self, number: int, config: AgentConfig, context: AgentContext | None = None
    ):

        # agent config
        self.config = config

        # agent context
        self.context = context or AgentContext(config=config, agent_meta=self)

        # non-config vars
        self.number = number
        self.agent_name = f"AM{self.number}"

        self.history = history.History(self)  # type: ignore[abstract]
        self.last_user_message: history.Message | None = None
        self.intervention: UserMessage | None = None
        self.data: dict[str, Any] = {}  # free data object all the tools can use

    async def rejected_reasoning_callback(self, chunk: str, full: str):
        printer = PrintStyle(italic=True, font_color="#b3ffd9", padding=False)
        # Stream data handling
        stream_data = {"chunk": chunk, "full": full}
        if stream_data.get("chunk"):
            printer.stream(stream_data["chunk"])
        # Use the full stream for downstream processing
        await self.handle_reasoning_stream(stream_data["full"])

    async def rejected_stream_callback(self, chunk: str, full: str):
        printer = PrintStyle(italic=True, font_color="#b3ffd9", padding=False)
        # Stream the chunk after extensions processed it
        stream_data = {"chunk": chunk, "full": full}
        if stream_data.get("chunk"):
            printer.stream(stream_data["chunk"])

        try:
            if hasattr(self, "loop_data") and self.loop_data is not None:
                self.loop_data.last_response = stream_data["full"]
        except Exception:
            pass

        await self.handle_response_stream(stream_data["full"])

    async def guardrail_check(self, output_check: bool = False): 
        try:                
            guardrail_prompt: list[str] = []
            await self.call_executors("guardrail_check", guardrail_prompt=guardrail_prompt, loop_data=self.loop_data, output_check=output_check)
            if guardrail_prompt:
                full_prompt: list[ChatMessage] = [ChatMessage(
                    role="system",
                    content=guardrail_prompt[0] if isinstance(guardrail_prompt, list) else guardrail_prompt
                )]
                
                guardrail_response, reasoning = await self.call_chat_model(messages=full_prompt)

                data = json.loads(guardrail_response)

                guardrail_value = data.get("guardrail")
                text_value = data["tool_args"]["text"]
                if ((guardrail_value == True) or (guardrail_value == "True")):
                    return full_prompt, text_value
                else:
                    return None, None                  
            else:
                return None, None

        except Exception as e:
            self.handle_critical_exception(e)

    async def run_message_workflow(self):
        global MAX_ITERATION, GLOBAL_ITERATION_COUNT, GLOBAL_CALL_DEPTH

        # ---- track depth so we reset only when outermost workflow exits ----
        was_root = (GLOBAL_CALL_DEPTH == 0)
        GLOBAL_CALL_DEPTH += 1
        while True:
            try:
                # ✅ fast-fail if already beyond limit
                if GLOBAL_ITERATION_COUNT == MAX_ITERATION:
                    message = (
                        f"Agent workflow stopped — maximum iteration limit ({MAX_ITERATION}) reached. "
                        f"Possible recursive loop detected."
                    )
                    print(message)
                    self.context.agent_activity.add_agent_activity(
                        type="error",
                        content=f"[{self.agent_name}] {message}"
                    )
                    # Hard abort so recursion stop immediately
                    raise HandledException(message)

                self.loop_data = LoopData(user_message=self.last_user_message)
                await self.call_executors("message_workflow_start", loop_data=self.loop_data)

                printer = PrintStyle(italic=True, font_color="#b3ffd9", padding=False)

                # -------------------- GUARDRAIL CHECK --------------------
                #todo get intent for the guardrail check
                guardrail_validation_prompt, guardrail_text =  None, "" # await self.guardrail_check() 
                # guardrail_validation_prompt=None
                if guardrail_validation_prompt is not None:
                    # polite_reason = "This query is restricted as per policy."
                    guardrail_response, reasoning = await self.call_chat_model(messages=guardrail_validation_prompt, 
                    response_callback=self.rejected_stream_callback,
                    reasoning_callback=self.rejected_reasoning_callback)
                    self.hist_add_ai_response(guardrail_response)
                    return {"type":"text", "value":guardrail_text}
                
                else:
                    while True:
                        # ---- bump global counter once per inner iteration ----
                        GLOBAL_ITERATION_COUNT += 1
                        if GLOBAL_ITERATION_COUNT > MAX_ITERATION:
                            msg = (
                                f"Agent workflow stopped — maximum iteration limit ({MAX_ITERATION}) reached. "
                                f"Possible recursive loop detected."
                            )
                            print(msg)
                            self.context.agent_activity.add_agent_activity(
                                type="error",
                                content=f"[{self.agent_name}] {msg}"
                            )
                            raise HandledException(msg)

                        self.context.streaming_agent = self  # mark self as current streamer
                        self.loop_data.iteration += 1
                        self.loop_data.params_temporary = {}  # clear temporary params

                        # call message_loop_start extensions
                        await self.call_executors(
                            "message_loop_start", loop_data=self.loop_data
                        )

                        try:
                            # prepare LLM chain (model, system, history)
                            prompt = await self.prepare_prompt(loop_data=self.loop_data)
                            # call before_main_llm_call extensions
                            await self.call_executors("before_main_llm_call", loop_data=self.loop_data)

                            async def reasoning_callback(chunk: str, full: str):
                                
                                stream_data = {"chunk": chunk, "full": full}
                                # Stream masked chunk after extensions processed it
                                if stream_data.get("chunk"):
                                    printer.stream(stream_data["chunk"])
                                # Use the potentially modified full text for downstream processing
                                await self.handle_reasoning_stream(stream_data["full"])


                            async def stream_callback(chunk: str, full: str):
                                # existing behaviour ...
                                stream_data = {"chunk": chunk, "full": full}

                                # stream masked chunk after extensions processed it
                                if stream_data.get("chunk"):
                                    printer.stream(stream_data["chunk"])

                                # store the last_response progressively and finally
                                try:
                                    # keep a running last_response so extensions can inspect mid-stream if needed
                                    if hasattr(self, "loop_data") and self.loop_data is not None:
                                        self.loop_data.last_response = stream_data["full"]
                                except Exception:
                                    pass

                                # Use the potentially modified full text for downstream processing
                                await self.handle_response_stream(stream_data["full"])

                            # --- NEW CODE: capture previous assistant text before calling LLM ---
                            def _stringify_content_for_compare(content):
                                try:
                                    if isinstance(content, str):
                                        return content.strip()
                                    if isinstance(content, dict):
                                        if "tool_args" in content and isinstance(content["tool_args"], dict):
                                            txt = content["tool_args"].get("text")
                                            if isinstance(txt, str):
                                                return txt.strip()
                                        return json.dumps(content, ensure_ascii=False).strip()
                                except Exception:
                                    pass
                                return ""

                            prev_assistant_text = ""
                            try:
                                for out in reversed(self.loop_data.history_output):
                                    if out.get("ai"):
                                        prev_assistant_text = _stringify_content_for_compare(out.get("content", ""))
                                        break
                            except Exception:
                                prev_assistant_text = ""
                            # --- END NEW CODE ---
                        
                            # call main LLM
                            agent_response, _reasoning = await self.call_chat_model(
                                messages=prompt, # type: ignore
                                response_callback=stream_callback,
                                reasoning_callback=reasoning_callback,
                            )
                            #Pubish 
                            await LogDispatcher.get_instance().publish(self.context.agent_activity)

                            # try:
                            #     if self.context and getattr(self.context, "agent_activity", None):
                            #         self.context.agent_activity.add_agent_activity(
                            #             type="response",
                            #             heading=f"icon://network_intelligence {self.agent_name}: Responded",
                            #             content=agent_response or "",
                            #             kvps={"finished": True},
                            #         )
                            # except Exception:
                            #     pass

                            # compare current final response to the previous persisted assistant message
                            agent_resp_text = (agent_response or "").strip()
                            is_duplicate = bool(prev_assistant_text and prev_assistant_text == agent_resp_text)

                            if is_duplicate:
                                dup_cnt = self.loop_data.params_temporary.get("duplicate_count", 0) + 1
                                self.loop_data.params_temporary["duplicate_count"] = dup_cnt

                                # persist the repeated assistant response once
                                self.hist_add_ai_response(agent_response)

                                warning_msg = self.read_prompt("fw.msg_repeat.md")
                                self.hist_add_warning(message=warning_msg)
                                PrintStyle(font_color="orange", padding=True).print(warning_msg)
                                try:
                                    self.context.agent_activity.add_agent_activity(type="warning", content=warning_msg)
                                except Exception:
                                    pass

                                DUPLICATE_THRESHOLD = 1
                                if dup_cnt >= DUPLICATE_THRESHOLD:
                                    self.loop_data.params_temporary.pop("duplicate_count", None)
                                    return agent_response
                                else:
                                    continue
                            else:
                                self.loop_data.params_temporary.pop("duplicate_count", None)
                                self.hist_add_ai_response(agent_response)
                                tools_result = await self.process_tools(agent_response)
                                if tools_result:
                                    return tools_result
                            
                            
                        except RepairableException as e:
                            # Forward repairable errors to the LLM, maybe it can fix them
                            msg = {"message": errors.format_error(e)}
                            await self.call_executors("error_format", msg=msg)
                            self.hist_add_warning(msg["message"])
                            PrintStyle(font_color="red", padding=True).print(msg["message"])
                            self.context.agent_activity.add_agent_activity(type="error", content=msg["message"])
                        except Exception as e:
                            # Other exception kill the loop
                            self.handle_critical_exception(e)

                        finally:
                            # call message_loop_end extensions
                            await self.call_executors(
                                "message_loop_end", loop_data=self.loop_data
                            )

            # exceptions outside message loop:
            except Exception as e:
                self.handle_critical_exception(e)
            finally:
                self.context.streaming_agent = None  # unset current streamer
                # call message_workflow_end extensions
                await self.call_executors("message_workflow_end", loop_data=self.loop_data)  # type: ignor
                # reset global counter only when the outermost finishes ----
                GLOBAL_CALL_DEPTH = max(0, GLOBAL_CALL_DEPTH - 1)
                if was_root and GLOBAL_CALL_DEPTH == 0:
                    GLOBAL_ITERATION_COUNT = 0

    async def prepare_prompt(self, loop_data: LoopData) -> list[ChatMessage]:
        self.context.agent_activity.set_progress("Building prompt")
        # call executor before setting prompts
        await self.call_executors("message_loop_prompts_before", loop_data=loop_data)

        # set system prompt and message history
        loop_data.system = await self.get_system_prompt(self.loop_data)
        loop_data.history_output = self.history.output()

        # and allow extensions to edit them
        await self.call_executors("message_loop_prompts_after", loop_data=loop_data)

        # concatenate system prompt
        system_text = "\n\n".join(loop_data.system)

        # join extras
        extras = history.Message(  # type: ignore[abstract]
            False,
            content=self.read_prompt(
                "agent.context.extras.md",
                extras=dirty_json.stringify(
                    {**loop_data.extras_persistent, **loop_data.extras_temporary}
                ),
            ),
        ).output()
        loop_data.extras_temporary.clear()

        # convert history + extras to LLM format
        history_llamaindex: list[ChatMessage] = history.output_llamaindex(
            loop_data.history_output + extras
        )

        # build full prompt from system prompt, message history and extras
        full_prompt: list[ChatMessage] = [
            ChatMessage(role="system" ,content=system_text),
            *history_llamaindex,
        ]
        full_text = ChatPromptTemplate.from_messages(full_prompt).format()
       
        base_dir = os.path.join(os.getcwd(), "final_prompt")
        os.makedirs(base_dir, exist_ok=True)
 
        # Filename with timestamp
        timestamp = datetime.now().strftime("%Y-%m_%H-%M-%S")
        filename = f"prompt_{timestamp}.txt"
 
        file_path = os.path.join(base_dir, filename)
 
        with open(file_path, "w", encoding="utf-8") as f:
            f.write(full_text)

        # store as last context window content
        self.set_data(
            Agent.DATA_NAME_CTX_WINDOW,
            {
                "text": full_text,
                "tokens": tokens.approximate_tokens(full_text),
            },
        )
        return full_prompt
 
    async def get_system_prompt(self, loop_data: LoopData) -> list[str]:
        system_prompt: list[str] = []
        await self.call_executors(
            "system_prompt", system_prompt=system_prompt, loop_data=loop_data
        )
        return system_prompt

    def parse_prompt(self, _prompt_file: str, **kwargs):
        dirs = [files.get_abs_path("prompts")]
        if (
            self.config.profile
        ):  # if agent has custom folder, use it and use default as backup
            prompt_dir = files.get_abs_path("agents", self.config.profile, "prompts")
            dirs.insert(0, prompt_dir)
        prompt = files.parse_file(
            _prompt_file, _directories=dirs, **kwargs
        )
        return prompt

    def read_prompt(self, file: str, **kwargs) -> str:
        dirs = [files.get_abs_path("prompts")]
        if (
            self.config.profile
        ):  # if agent has custom folder, use it and use default as backup
            prompt_dir = files.get_abs_path("agents", self.config.profile, "prompts")
            dirs.insert(0, prompt_dir)
        prompt = files.read_prompt_file(
            file, _directories=dirs, **kwargs
        )
        prompt = files.remove_code_fences(prompt)
        return prompt
    
    async def process_tools(self, msg: str):
        # search for tool usage requests in agent message
        tool_request = extract_tools.json_parse_dirty(msg)

        if tool_request is not None:
            raw_tool_name = tool_request.get("tool_name", "")  # Get the raw tool name
            tool_args = tool_request.get("tool_args", {})

            tool_name = raw_tool_name  # Initialize tool_name with raw_tool_name
            tool_method = None  # Initialize tool_method

            # Split raw_tool_name into tool_name and tool_method if applicable
            if ":" in raw_tool_name:
                tool_name, tool_method = raw_tool_name.split(":", 1)

            tool = None  # Initialize tool to None

            # Try getting tool from MCP first
            try:
                import app.meta_agent.utils.mcp_handler as mcp_helper

                mcp_tool_candidate = mcp_helper.MCPConfig.get_instance().get_tool(
                    self, tool_name
                )
                if mcp_tool_candidate:
                    tool = mcp_tool_candidate
            except ImportError:
                PrintStyle(
                    background_color="black", font_color="yellow", padding=True
                ).print("MCP helper module not found. Skipping MCP tool lookup.")
            except Exception as e:
                PrintStyle(
                    background_color="black", font_color="red", padding=True
                ).print(f"Failed to get MCP tool '{tool_name}': {e}")

            # get required tool response
            if not tool:
                tool = self.get_tool(
                    name=tool_name, method=tool_method, args=tool_args, message=msg, loop_data=self.loop_data
                )

            if tool:

                # Call tool hooks for compatibility
                await tool.before_execution(**tool_args)
                
                # Allow extensions to preprocess tool arguments
                await self.call_executors("tool_execute_before", tool_args=tool_args or {}, tool_name=tool_name)

                response = await tool.execute(**tool_args)
                               
                await tool.after_execution(response)

                if response.break_loop:
                    return response.message
            else:
                error_detail = (
                    f"Tool '{raw_tool_name}' not found or could not be initialized."
                )
                self.hist_add_warning(error_detail)
                PrintStyle(font_color="red", padding=True).print(error_detail)
                self.context.agent_activity.add_agent_activity(
                    type="error", content=f"{self.agent_name}: {error_detail}"
                )
        else:
            warning_msg_misformat = self.read_prompt("fw.msg_misformat.md")
            self.hist_add_warning(warning_msg_misformat)
            PrintStyle(font_color="red", padding=True).print(warning_msg_misformat)
            self.context.agent_activity.add_agent_activity(
                type="error",
                content=f"{self.agent_name}: Message misformat, no valid tool request found.",
            )

    def get_tool(
        self, name: str, method: str | None, args: dict, message: str, loop_data: LoopData | None, **kwargs
    ):
        from app.meta_agent.tools.unknown import Unknown
        from app.meta_agent.utils.tool import Tool

        classes = []

        # try agent tools first
        if self.config.profile:
            try:
                classes = extract_tools.load_classes_from_file(
                    "agents/" + self.config.profile + "/tools/" + name + ".py", Tool  # type: ignore[arg-type]
                )
            except Exception:
                pass

        # try default tools
        if not classes:
            try:
                classes = extract_tools.load_classes_from_file(
                    "app/meta_agent/tools/" + name + ".py", Tool  # type: ignore[arg-type]
                )
            except Exception as e:
                pass
        tool_class = classes[0] if classes else Unknown
        return tool_class(
            agent=self, name=name, method=method, args=args, message=message, loop_data=loop_data, **kwargs
        )

    def get_data(self, field: str):
        return self.data.get(field, None)

    def set_data(self, field: str, value):
        self.data[field] = value

    async def call_utility_model(
        self,
        system: str,
        message: str,
        callback: Callable[[str], Awaitable[None]] | None = None,
        background: bool = False,
    ):
        model = self.get_utility_model()

        # call executors
        call_data = {
            "model": model,
            "system": system,
            "message": message,
            "callback": callback,
            "background": background,
        }
        await self.call_executors("util_model_call_before", call_data=call_data)

        # propagate stream to callback if set
        async def stream_callback(chunk: str, total: str):
            if call_data["callback"]:
                await call_data["callback"](chunk)

        response, _reasoning = await call_data["model"].unified_call(
            system_message=call_data["system"],
            user_message=call_data["message"],
            response_callback=stream_callback,
            rate_limiter_callback=self.rate_limiter_callback if not call_data["background"] else None,
        )

        return response
    
    async def call_chat_model(
        self,
        messages: list[ChatMessage],
        response_callback: Callable[[str, str], Awaitable[None]] | None = None,
        reasoning_callback: Callable[[str, str], Awaitable[None]] | None = None,
        background: bool = False,
    ):
        response = ""

        # model class
        model = self.get_chat_model()

        # call model
        response, reasoning = await model.unified_call(
            messages=messages,
            reasoning_callback=reasoning_callback,
            response_callback=response_callback,
            rate_limiter_callback=self.rate_limiter_callback if not background else None,
        )

        return response, reasoning

    async def rate_limiter_callback(
        self, message: str, key: str, total: int, limit: int
    ):
        # show the rate limit waiting in a progress bar, no need to spam the chat history
        self.context.agent_activity.set_progress(message, True)
        return False

    def get_chat_model(self):
        return models.get_chat_model(
            self.config.chat_model.provider,
            self.config.chat_model.name,
            model_config=self.config.chat_model,
            **self.config.chat_model.build_kwargs(),
        )

    def get_utility_model(self):
        return models.get_chat_model(
            self.config.utility_model.provider,
            self.config.utility_model.name,
            model_config=self.config.utility_model,
            **self.config.utility_model.build_kwargs(),
        )

    def get_browser_model(self):
        return models.get_browser_model(
            self.config.browser_model.provider,
            self.config.browser_model.name,
            model_config=self.config.browser_model,
            **self.config.browser_model.build_kwargs(),
        )

    def get_embedding_model(self):
        return models.get_embedding_model(
            self.config.embeddings_model.provider,
            self.config.embeddings_model.name,
            model_config=self.config.embeddings_model,
            **self.config.embeddings_model.build_kwargs(),
        )     
    
    async def call_executors(self, extension_point: str, **kwargs) -> Any:
        return await call_executors(extension_point=extension_point, agent=self, **kwargs)
    
    def concat_messages(
        self, messages
    ):  # TODO add param for message range, topic, history
        return self.history.output_text(human_label="user", ai_label="assistant")
    
    def hist_add_message(
    self, ai: bool, content: history.MessageContent, tokens: int = 0
    ):
        self.last_message = datetime.now(timezone.utc)
        # Allow executors to process content before adding to history
        content_data = {"content": content}
        #asyncio.run(self.call_executors("hist_add_before", content_data=content_data, ai=ai))
        return self.history.add_message(ai=ai, content=content_data["content"], tokens=tokens)
    
    def hist_add_ai_response(self, message: str):
        if hasattr(self, "loop_data") and self.loop_data is not None:
            try:
                self.loop_data.last_response = message
            except Exception:
                pass
        content = self.parse_prompt("fw.ai_response.md", message=message)
        return self.hist_add_message(True, content=content)
    
    def hist_add_warning(self, message: history.MessageContent):
        content = self.parse_prompt("fw.warning.md", message=message)
        return self.hist_add_message(False, content=content)
    
    def hist_add_tool_result(self, tool_name: str, tool_result: str, **kwargs):
        data = {
            "tool_name": tool_name,
            "tool_result": tool_result,
            **kwargs,
        }
        asyncio.run(self.call_executors("hist_add_tool_result", data=data))
        return self.hist_add_message(False, content=data)

    def handle_critical_exception(self, exception: Exception):
        if isinstance(exception, HandledException):
            raise exception  # Re-raise the exception to kill the loop
        elif isinstance(exception, asyncio.CancelledError):
            # Handling for asyncio.CancelledError
            PrintStyle(font_color="white", background_color="red", padding=True).print(
                f"Context {self.context.id} terminated during message loop"
            )
            raise HandledException(
                exception
            )  # Re-raise the exception to cancel the loop
        else:
            # Handling for general exceptions
            error_text = errors.error_text(exception)
            error_message = errors.format_error(exception)

            # Mask secrets in error messages
            PrintStyle(font_color="red", padding=True).print(error_message)
            self.context.agent_activity.add_agent_activity(
                type="error",
                heading="Error",
                content=error_message,
                kvps={"text": error_text},
            )
            PrintStyle(font_color="red", padding=True).print(
                f"{self.agent_name}: {error_text}"
            )

            raise HandledException(exception)  # Re-raise the exception to kill the loop
        
    def hist_add_user_message(self, message: UserMessage, intervention: bool = False):
        self.history.new_topic()  # user message starts a new topic in history
        
        content = self.parse_prompt(
            "fw.user_message.md",
            message=message.message,
            attachments=message.attachments,
            system_message=message.system_message,
        )

        # remove empty parts from template
        if isinstance(content, dict):
            content = {k: v for k, v in content.items() if v}

        # add to history
        msg = self.hist_add_message(False, content=content)  # type: ignore
        self.last_user_message = msg
        return msg

    async def handle_response_stream(self, stream: str):
        try:
            if not stream or len(stream) < 25:
                return  # nothing useful to parse
            # attempt to parse DirtyJson; if not parsed => ignore
            response = DirtyJson.parse_string(stream)
            if isinstance(response, dict):
                # call executors (correct extension invocation)
                await self.call_executors(
                    "response_stream",
                    loop_data=self.loop_data,
                    text=stream,
                    parsed=response,
                )
        except Exception:
            # swallow, we don't want streaming hooks to kill the agent
            return


    async def handle_reasoning_stream(self, stream: str):
        await self.handle_intervention()
        await self.call_executors(
            "reasoning_stream",
            loop_data=self.loop_data,
            text=stream,
        )