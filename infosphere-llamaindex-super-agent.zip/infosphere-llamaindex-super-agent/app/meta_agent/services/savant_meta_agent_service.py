# app/meta_agent/services/savant_meta_agent_service.py

import os
import json
import uuid
import random
import string
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional, List, Dict, Any, ClassVar
from pydantic import BaseModel
from app.meta_agent.agent import Agent, AgentContext, UserMessage
from app.meta_agent.utils.chat_manager import _get_chat_file_path, _deserialize_context
from app.meta_agent.utils.memory import Memory
from app.meta_agent.initialize import initialize_agent, initialize_mcp_async
import shutil
from app.meta_agent.utils import settings
from app.meta_agent.utils.agent_activity_dispatcher import LogDispatcher
from app.meta_agent.utils.agent_activity_storage import LocalMemoryLogStorage
        


class SavantMetaAgentRequest(BaseModel):
    context_id: Optional[str] = None
    user_message: str


class SavantMetaAgentService:
    _instance: ClassVar[Optional["SavantMetaAgentService"]] = None
    _initialized: ClassVar[bool] = False

    # ---------------- Memory initialization ----------------
    def __init__(self, settings_path: Optional[Path] = None):
        """Private constructor - use get_instance() instead"""
        if SavantMetaAgentService._instance is not None:
            raise RuntimeError("Use SavantMetaAgentService.get_instance() instead of calling the constructor directly.")

        p = Path(settings_path or os.getenv("SETTINGS_FILE_PATH", ""))
        s = p / "settings.json" if p.is_dir() else p
        if not s.exists():
            raise FileNotFoundError("settings.json not found. Pass settings_path or set SETTINGS_FILE_PATH.")
        os.environ["SETTINGS_FILE_PATH"] = str(s)
        self.config = None
        self.agent: Optional[Agent] = None
        self._memory = None

    # ---------------- Singleton Accessor ----------------
    @classmethod
    async def get_instance(
        cls,
        *,
        settings_path: Optional[Path] = None,
        reset_memory: bool = False,
        agent_number: int = 0
    ) -> "SavantMetaAgentService":
        """
        Returns the singleton instance of SavantMetaAgentService.
        If not initialized, runs async get_instance() once.
        """
        if cls._instance is None:
            cls._instance = cls(settings_path=settings_path)
            await cls._instance._async_initialize(reset_memory=reset_memory, agent_number=agent_number)
            cls._initialized = True
        return cls._instance

    async def _async_initialize(self, *, reset_memory=False, agent_number=0):
        """Performs async initialization"""
        self.config = initialize_agent()
        await initialize_mcp_async()
        # ensure LogDispatcher is initialized for notebook/script runs
        try:
            LogDispatcher.get_instance()
        except RuntimeError:
            # fallback to local memory storage if not initialized yet
            LogDispatcher.initialize(LocalMemoryLogStorage())
        self.agent = Agent(config=self.config, number=agent_number)
        self._memory = await Memory.reload(self.agent)

    @staticmethod
    def __clear_memory(*, path: str = "memory/pytest_memory", reset_memory: bool = False):
        p = Path(path)
        if not reset_memory:
            result = {"status": "skipped","message": "Skipping memory deletion (reset_memory=False).","path": str(p)}
        elif p.exists():
            try:
                shutil.rmtree(p)
                result = {"status": "success","message": f"Memory cleared successfully","path": str(p)}
            except Exception as e:
                result = {"status": "error","message": f"Failed to clear memory: {str(e)}","path": str(p)}
        else:
            result = {"status": "not found","message": "No saved memory data found — nothing to delete.","path": str(p)}

        # Simplified print logic
        if "ipykernel" in sys.modules:
            print(json.dumps(result, indent=2, ensure_ascii=False))
            return None
        return result


    # ---------------- Public Memory Reset ----------------
    @classmethod
    async def reset_service(cls, reset_memory: bool ) -> dict:
        """Delete memory if requested and reinitialize service twice to ensure clean state."""
        results = []

        # Run twice to flush residual caches and reload clean
        for i in range(3):
            cls._SavantMetaAgentService__clear_memory(reset_memory=reset_memory)
            cls._instance = None
            cls._initialized = False
            await cls.get_instance(reset_memory=False)
            results.append(f"Run {i+1} completed")

        msg = "Memory cleared and service fully reinitialized (double run)" if reset_memory else "Skipped memory deletion; reinitialized service"
        return {
            "status": "success",
            "message": msg,
            "reset_memory": reset_memory,
            "runs": results
        }

    
    async def get_context(self,  context_id: Optional[str] = None) :
        context_id = (context_id or "").strip() or self._new_context_id()
        chat_path = Path(_get_chat_file_path(context_id))

        # Ensure chat exists
        if not chat_path.exists():
            self._seed_chat_file(context_id, chat_path)

        data = json.loads(chat_path.read_text(encoding="utf-8"))
        context = _deserialize_context(data)
        return context

    # ---------------- Messaging API ----------------
    async def send_message(self, *, user_message: str, context_id: Optional[str] = None, context: AgentContext = None) :
        req = SavantMetaAgentRequest(context_id=context_id, user_message=user_message)
        return await self.handle(req, context=context)

    async def handle(self, req: SavantMetaAgentRequest, context: AgentContext = None) -> Dict[str, Any]:
        if not context:
            context = self.get_context(context_id=req.context_id)
        
        main_agent: Agent = context.agent_meta
        streaming_agent: Agent = getattr(context, "streaming_agent", None) or main_agent

        # Append user message
        msg = UserMessage(req.user_message)
        main_agent.hist_add_user_message(msg)
        if streaming_agent is not main_agent:
            streaming_agent.hist_add_user_message(msg)

        # Mirror into activity logs
        agents_to_log: List[Agent] = [main_agent]
        if streaming_agent is not main_agent:
            agents_to_log.append(streaming_agent)
        self._mirror_user_message_to_agents(agents_to_log, req.user_message)

        activity_item = context.agent_activity.add_agent_activity(
                    event_type="workflow",
                    type="workflow",
                    heading={},
                    kvps={"workflow_status": "started"},
                )
        await LogDispatcher.get_instance().publish(context.agent_activity, activity_item.no)
        # Run workflow
        try:
            raw_result = await main_agent.run_message_workflow()
        except Exception as e:
            print(f"[SavantMetaAgentService] run_message_workflow error: {e}")
            raw_result = ""
        finally:
            activity_item = context.agent_activity.add_agent_activity(
                    event_type="workflow",
                    type="workflow",
                    heading={},
                    kvps={"workflow_status": "completed"}
                )
            await LogDispatcher.get_instance().publish(context.agent_activity,  activity_item.no)
        # Normalize to JSON result (preserve type/value shape)
        if isinstance(raw_result, dict):
            result_obj = raw_result
        else:
            try:
                result_obj = json.loads(raw_result)
            except Exception:
                result_obj = {"type": "text", "value": (raw_result or "").strip()}

        result_value = result_obj.get("value") if isinstance(result_obj, dict) else str(result_obj)

        return {
            "result_content": {
                "context_id": context.id,
                "result": result_value,
            }
        }

    # ---------------- Helpers ----------------
    def _new_context_id(self, length: int = 8) -> str:
        alphabet = string.ascii_letters + string.digits
        return "".join(random.choice(alphabet) for _ in range(length))

    def _seed_chat_file(self, context_id: str, chat_path: Path) -> None:
        chat_path.parent.mkdir(parents=True, exist_ok=True)
        try:
            from app.meta_agent.utils.chat_manager import save_tmp_chat
            save_tmp_chat(context_id=context_id)
            if chat_path.exists():
                return
        except Exception:
            pass

        now = datetime.now(timezone.utc).isoformat()
        seed = {
            "id": context_id,
            "name": "New Conversation",
            "created_at": now,
            "type": "user",
            "last_message": now,
            "agents": [{"number": 0, "data": {}}],
            "streaming_agent": 0,
            "agent_activity": {
                "guid": "",
                "agent_number": 0,
                "stages": [],
                "updates": [],
                "agent_activities": [],
            },
            "agent_meta": {},
            "history": {},
        }
        chat_path.write_text(json.dumps(seed, ensure_ascii=False, indent=2), encoding="utf-8")

    def _mirror_user_message_to_agents(self, agents: List[Agent], user_message: str) -> None:
        for agent in agents:
            ctx = getattr(agent, "context", None)
            if not ctx:
                continue
            aa = getattr(ctx, "agent_activity", None) or getattr(ctx, "streaming_activity", None)
            if not aa:
                continue
            try:
                aa.add_agent_activity(
                    type="user",
                    heading="User message",
                    content=user_message,
                    kvps={"attachments": []},
                    id=str(uuid.uuid4()),
                    temp=False,
                )
            except Exception:
                try:
                    activities = getattr(aa, "agent_activities", None) or []
                    activities.append({
                        "no": len(activities) + 1,
                        "id": str(uuid.uuid4()),
                        "type": "user",
                        "heading": "User message",
                        "content": user_message,
                        "temp": False,
                        "kvps": {"attachments": []},
                    })
                    setattr(aa, "agent_activities", activities)
                except Exception:
                    continue
 
    # def clear_memory(path="memory/pytest_memory"):
    #     memory_dir = Path(path)
    #     if memory_dir.exists():
    #         shutil.rmtree(memory_dir)
    #         print(f"✅ Memory cleared successfully!")
    #     else:
    #         print(f"ℹ️ No memory found — nothing to delete.")
