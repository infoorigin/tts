from fastapi import APIRouter
from pydantic import BaseModel, Field, field_validator
from typing import List, Literal, Optional 

from app.meta_agent.services.savant_meta_agent_service import SavantMetaAgentService

ALLOWED_EMBED = {"agent_activities"}


class ChatRequest(BaseModel):
    message: str
    context_id: Optional[str] = None
    embed: Optional[List[str]] = None

    @field_validator("embed")
    @classmethod
    def check_embed_values(cls, v: Optional[List[str]]) -> Optional[List[str]]:
        if v is None:
            return v
        for item in v:
            if item not in ALLOWED_EMBED:
                raise ValueError(f"Invalid embed value: {item}. Allowed: {ALLOWED_EMBED}")
        return v

router = APIRouter()

@router.post("/chat")
async def get_user(request: ChatRequest):
    service = await SavantMetaAgentService.get_instance(reset_memory=True)
    context = await service.get_context(request.context_id)
    current_agent_activity_pos = context.agent_activity.latest_item_no()
    result = await service.send_message(user_message=request.message, context=context)
    response = result.get("result_content", {})
    
    # Embed activities if requested
    if request.embed and "agent_activities" in request.embed:
        activities = context.agent_activity.get_agent_activity_items(
            start_post=current_agent_activity_pos + 1
        )
        response["_embedded"] = {
            "agent_activities": activities
        }

    return response

