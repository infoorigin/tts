from fastapi import APIRouter
from pydantic import BaseModel
from app.meta_agent.services.savant_meta_agent_service import SavantMetaAgentService

router = APIRouter()

class MemoryFlag(BaseModel):
    reset_memory: bool 

@router.delete("/")
async def delete_memory(request: MemoryFlag):
    """Deletes memory if reset_memory=True, then reinitializes clean service."""
    result = await SavantMetaAgentService.reset_service(reset_memory=request.reset_memory)
    return result