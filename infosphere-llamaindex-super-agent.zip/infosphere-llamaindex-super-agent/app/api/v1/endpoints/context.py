import asyncio
import json
import time
from fastapi import APIRouter
from fastapi.responses import StreamingResponse

from app.meta_agent.utils.agent_activity_dispatcher import LogDispatcher
from app.meta_agent.utils.agent_activity_storage import LocalMemoryLogStorage, RedisLogStorage
from app.meta_agent.utils.agent_activity import AgentActivity

router = APIRouter()

@router.get("/{context_id}")
def get_user(context_id: str):
    return {"context_id": context_id}


def format_sse(event_type: str, data: dict) -> str:
    """
    Format as SSE (for browser EventSource compatibility).
    Use format_ndjson() for ChatGPT/Claude-style streaming.
    """
    return f"event: {event_type}\ndata: {json.dumps(data, ensure_ascii=False)}\n\n"


def format_ndjson(event_type: str,data: dict) -> str:
    """
    Format as NDJSON (Newline Delimited JSON) like ChatGPT/Claude.
    Each JSON object on its own line.
    """
    return json.dumps({"event":event_type, "data":data}, ensure_ascii=False) + "\n"

USE_REDIS = False  # Set based on your app configuration
# ---------------------------------------------------------------------
# --- Streaming Endpoint ----------------------------------------------
# ---------------------------------------------------------------------

@router.get("/{context_id}/log/stream")
async def stream_log(context_id: str):
    """Stream log updates via SSE."""
    dispatcher = LogDispatcher.get_instance()
    
    async def event_stream():
        try:
            async for event in dispatcher.stream_events(context_id):
                yield format_ndjson(event["type"], event["data"])
        except asyncio.CancelledError:
            print(f"[API] Client disconnected from {context_id}")
            raise
        except Exception as e:
            print(f"[API] Stream error for {context_id}: {e}")
            yield format_sse("error", {"message": str(e), "context_id": context_id})
    
    return StreamingResponse(
        event_stream(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        },
    )


@router.get("/{context_id}/log")
async def get_log(context_id: str):
    """Get complete log state (non-streaming)."""
    dispatcher = LogDispatcher.get_instance()
    
    try:
        items = await dispatcher.storage.get_log_items(context_id)
        return {"context_id": context_id, "items": items, "count": len(items)}
    except Exception as e:
        return {"context_id": context_id, "error": str(e), "items": []}


# ---------------------------------------------------------------------
# --- Development/Testing Endpoints -----------------------------------
# ---------------------------------------------------------------------

if not USE_REDIS:
    @router.post("/{context_id}/test/add")
    async def test_add_item(context_id: str):
        """Test: Add a dummy log item."""
        dispatcher = LogDispatcher.get_instance()
        
        item_data = {
            "no": 0,
            "id": None,
            "type": "info",
            "heading": f"Test item at {time.time()}",
            "content": "This is a test",
            "temp": False,
            "kvps": {"timestamp": time.time()}
        }
        
        # Only save and publish - let the listener handle fanout
        await dispatcher.storage.save_log_item(context_id, 0, item_data)
        await dispatcher.storage.publish_change(context_id, 0, item_data)
        
        return {"context_id": context_id, "message": "Test item added"}
    
    @router.post("/{context_id}/test/stream")
    async def test_stream_content(context_id: str):
        """Test: Simulate streaming content."""
        dispatcher = LogDispatcher.get_instance()
        chunks = ["Hello", " world", "!", " Test", " complete", "."]
        
        for i, chunk in enumerate(chunks):
            item_data = {
                "no": 0,
                "id": None,
                "type": "response",
                "heading": "Streaming test",
                "content": "".join(chunks[:i+1]),
                "temp": False,
                "kvps": {"finished": i == len(chunks) - 1}
            }
            
            # Only save and publish - let the listener handle fanout
            await dispatcher.storage.save_log_item(context_id, 0, item_data)
            await dispatcher.storage.publish_change(context_id, 0, item_data)
            await asyncio.sleep(0.2)
        
        return {"context_id": context_id, "message": "Streaming completed"}
