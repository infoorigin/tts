import asyncio
from fastapi import FastAPI
from contextlib import asynccontextmanager
import logging
from app.meta_agent.services.savant_meta_agent_service import SavantMetaAgentService
from app.meta_agent.utils.agent_activity_dispatcher import LogDispatcher
from app.meta_agent.utils.agent_activity_storage import LocalMemoryLogStorage, RedisLogStorage

# Configure logging
logging.basicConfig(
    level=logging.INFO
)
logger = logging.getLogger(__name__)

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup logic
    logger.info("Starting up FastAPI application...")
    service = await SavantMetaAgentService.get_instance(reset_memory=True)

    # Configuration TODO: Move to config file/env vars
    REDIS_URL = "redis://localhost:6379/0"
    USE_REDIS = False

    if USE_REDIS:
        storage = RedisLogStorage(REDIS_URL)
        print("[App] Using Redis storage")
    else:
        storage = LocalMemoryLogStorage()
        print("[App] Using in-memory storage")
    
    # Initialize singleton dispatcher
    LogDispatcher.initialize(storage)
    print("[App] Dispatcher initialized")
    
    try:
        yield
    finally:
        # Shutdown logic
        logger.info("Shutting down Agent Activity Dispatcher")
        if LogDispatcher.is_initialized():
            await LogDispatcher.get_instance().shutdown()
            # Give streams a moment to cleanup
            await asyncio.sleep(0.5)
        logger.info("Shutting down FastAPI application...")
        
         