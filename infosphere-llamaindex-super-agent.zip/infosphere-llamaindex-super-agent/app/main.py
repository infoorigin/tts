from fastapi import FastAPI
from app.api.lifespan import lifespan
from app.api.middleware.cors import add_cors_middleware
from app.api.v1.endpoints import clear_memory, context, meta_agent

app = FastAPI(
    title="Savant Meta Agents API",
    version="1.0.0",
    lifespan=lifespan
)

# Add middleware
add_cors_middleware(app)

app.include_router(context.router, prefix="/api/v1/contexts", tags=["contexts"])
app.include_router(meta_agent.router, prefix="/api/v1/meta_agent", tags=["meta_agent"])
app.include_router(clear_memory.router,prefix="/api/v1/memory",tags=["memory deletion"])

@app.get("/")
def read_root():
    return {"Savant Meta Agents"}

