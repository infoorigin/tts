### search_engine:
provide query arg get search results
returns list urls titles descriptions
**Example usage**:
~~~json
{
    "thoughts": [
        "...",
    ],
    "headline": "Searching web for video content",
    "tool_name": "search_engine",
    "tool_args": {
        "query": "Video of...",
    }
}
~~~
