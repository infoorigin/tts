```json
{
  "system_message": {{system_message}},
  "user_intervention": {{message}},
  "attachments": {{attachments}}
}
```
