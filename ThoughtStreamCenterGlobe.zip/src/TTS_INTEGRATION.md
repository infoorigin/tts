# Streaming TTS Integration

## Overview

The Savant Control Center now includes streaming text-to-speech (TTS) integration that provides audio playback for agent thoughts and responses. The system uses a streaming audio API to convert text to speech and plays the audio before displaying the typewriter effect.

## Features

### 1. **Selective TTS Application**
- **Thought Events**: TTS enabled ✓
- **Response Events**: TTS enabled ✓
- **Tool Events**: TTS disabled ✗ (tool execution events are visual-only)

### 2. **Event Flow with TTS**

For thought and response events:
1. Event received from stream
2. **Audio starts streaming** from TTS API
3. Audio indicator shows "Streaming audio..." with animated bars
4. Audio plays to completion
5. **Typewriter effect starts** (waits for audio to finish)
6. Text displays character by character
7. Event completes and next event begins

For tool events:
1. Event received from stream
2. **Typewriter effect starts immediately** (no TTS)
3. Text displays character by character
4. Event completes and next event begins

### 3. **Visual Feedback**

When audio is streaming:
- Header shows "Audio streaming" indicator
- Three animated bars pulse in the content area
- "Streaming audio..." message displays
- Typing cursor does not appear until audio completes

When typing (after audio):
- Animated dot indicator in header
- Typing cursor at end of text
- Character-by-character animation

## Configuration

### TTS API Settings

Access TTS settings via the "TTS Settings" button in testing mode:

1. Click **TTS Settings** button
2. Enter your TTS API endpoint URL
3. Click **Save Settings**

**Default URL**: `http://127.0.0.1:8000/api/v1/tts/stream`

### API Requirements

Your TTS API endpoint must:

1. Accept a `text` query parameter with URL-encoded text
2. Stream audio in a browser-compatible format (MP3, WAV, OGG, etc.)
3. Be accessible from the browser (CORS configured if needed)

**Example Request**:
```
http://127.0.0.1:8000/api/v1/tts/stream?text=Hello%20world%2C%20this%20is%20a%20test
```

**Expected Response**:
- Content-Type: `audio/mpeg` (or other audio format)
- Streaming audio data

## Technical Implementation

### Architecture

```
ContentDisplay.tsx
├── Detects event type (thought, tool, or response)
├── For thought/response:
│   ├── Calls streamingTTS.speak(fullText)
│   ├── Shows audio indicator
│   ├── Waits for audio completion
│   └── Starts typewriter
└── For tool:
    └── Starts typewriter immediately
```

### Service: `streamingTTS.ts`

The `StreamingTTS` service manages audio playback:

```typescript
// Start TTS (returns promise that resolves when done)
await streamingTTS.speak(text);

// Stop current playback
streamingTTS.stop();

// Configure API URL
streamingTTS.setApiUrl("http://your-api-url");

// Check if playing
const playing = streamingTTS.isPlaying();
```

### Error Handling

The system is designed to be resilient:

- **Network errors**: Audio fails gracefully, typewriter proceeds
- **API errors**: Logged to console, typewriter proceeds
- **Unsupported formats**: Falls back to typewriter-only mode
- **Component unmount**: Audio stops cleanly

All errors are logged but don't block the user experience.

## Testing

### With Local TTS Server

1. Start your TTS server at `http://127.0.0.1:8000`
2. Ensure the `/api/v1/tts/stream` endpoint is available
3. Click "Activate Agent" to trigger the workflow
4. Observe audio playback for thought/response events

### Without TTS Server

The system works perfectly fine without a TTS server:

- Audio requests will fail gracefully
- Typewriter effects will still display normally
- Events will process sequentially as expected
- Error messages logged to console (but app continues)

### Manual Testing

```javascript
// Test TTS directly in browser console
import { streamingTTS } from './services/streamingTTS';

// Test with custom URL
streamingTTS.setApiUrl('http://localhost:8000/api/v1/tts/stream');

// Test playback
await streamingTTS.speak('Hello, this is a test');
```

## Event Processing Flow

### Sequence Diagram

```
User Action
    ↓
Event Stream → Orchestrator → Event Queue
    ↓
ContentDisplay receives event
    ↓
Is event type "thought" or "response"?
    ↓ YES                           ↓ NO
Start TTS audio                Start typewriter immediately
    ↓
Wait for audio to finish
    ↓
Start typewriter
    ↓
Wait for typing to finish
    ↓
Signal event complete
    ↓
Next event begins
```

### Timing Guarantees

- **Sequential Processing**: Only one event processes at a time
- **Audio First**: TTS completes before typing begins (thought/response only)
- **Clean Transitions**: Each event fully completes before next starts
- **No Overlap**: Bubbles, audio, and typing are synchronized

## Customization

### Change TTS Provider

Update the API URL in settings to point to any compatible TTS service:

- **OpenAI TTS**: Configure endpoint wrapper
- **Google Cloud TTS**: Use streaming endpoint
- **Azure TTS**: Use streaming API
- **Custom TTS**: Any service that streams audio

### Modify Event Selection

Edit `/components/ContentDisplay.tsx` to change which events use TTS:

```typescript
// Current logic
const shouldUseTTS = event.type === "thought" || event.type === "response";

// Example: Enable for all events
const shouldUseTTS = true;

// Example: Only responses
const shouldUseTTS = event.type === "response";

// Example: None (disable TTS)
const shouldUseTTS = false;
```

### Adjust Visual Indicators

Modify the audio streaming UI in `ContentDisplay.tsx`:

- Change animation bars (currently 3 bars)
- Modify pulse timing
- Customize text messages
- Add/remove status indicators

## Browser Compatibility

The TTS integration uses HTML5 Audio API, supported by:

- ✓ Chrome/Edge (Chromium)
- ✓ Firefox
- ✓ Safari
- ✓ Opera
- ✓ Mobile browsers (iOS Safari, Chrome Mobile)

## Performance

### Audio Streaming Benefits

- **Low Latency**: Audio starts playing immediately as stream begins
- **Memory Efficient**: No need to download entire file first
- **Responsive**: User sees feedback instantly
- **Bandwidth Friendly**: Streaming reduces initial load

### Optimization Tips

1. **Server-side**: Use efficient audio codecs (MP3, Opus)
2. **Client-side**: Audio stops immediately on reset/unmount
3. **Network**: Consider caching for repeated phrases
4. **Format**: Use compressed formats to reduce bandwidth

## Troubleshooting

### Audio Not Playing

**Check**:
1. TTS API URL is correct in settings
2. API server is running and accessible
3. CORS headers are configured (if API is on different domain)
4. Browser console for error messages
5. Audio format is supported by browser

**Solution**:
- Test API endpoint directly in browser
- Check network tab for failed requests
- Verify API returns valid audio stream

### Audio Delays/Stuttering

**Causes**:
- Slow TTS API response
- Network latency
- Large text chunks

**Solutions**:
- Optimize TTS service response time
- Use faster audio codec
- Consider client-side caching
- Split very long texts

### Events Processing Too Fast/Slow

**Adjust timing** in `ContentDisplay.tsx`:

```typescript
// Current: 8ms per character
const timeout = setTimeout(() => {
  // ...
}, 8);

// Faster typing
const timeout = setTimeout(() => {
  // ...
}, 4);

// Slower typing
const timeout = setTimeout(() => {
  // ...
}, 15);
```

## Future Enhancements

Potential improvements:

1. **Voice Selection**: Allow user to choose TTS voice
2. **Speed Control**: Adjust audio playback speed
3. **Volume Control**: Master volume slider
4. **Pause/Resume**: Pause audio mid-stream
5. **Offline Mode**: Cache audio for offline playback
6. **Text Highlighting**: Sync highlighting with audio
7. **Subtitles**: Optional text display during audio
8. **Multiple Languages**: Support for i18n TTS

## API Example Implementation

### Python FastAPI Example

```python
from fastapi import FastAPI
from fastapi.responses import StreamingResponse
import edge_tts
import asyncio

app = FastAPI()

@app.get("/api/v1/tts/stream")
async def stream_tts(text: str):
    async def generate():
        communicate = edge_tts.Communicate(text, "en-US-GuyNeural")
        async for chunk in communicate.stream():
            if chunk["type"] == "audio":
                yield chunk["data"]
    
    return StreamingResponse(
        generate(),
        media_type="audio/mpeg",
        headers={
            "Access-Control-Allow-Origin": "*",
            "Cache-Control": "no-cache"
        }
    )
```

### Node.js Express Example

```javascript
const express = require('express');
const googleTTS = require('google-tts-api');
const axios = require('axios');

const app = express();

app.get('/api/v1/tts/stream', async (req, res) => {
  const text = req.query.text;
  
  try {
    const url = googleTTS.getAudioUrl(text, {
      lang: 'en',
      slow: false,
      host: 'https://translate.google.com',
    });
    
    const response = await axios({
      method: 'get',
      url: url,
      responseType: 'stream'
    });
    
    res.set({
      'Content-Type': 'audio/mpeg',
      'Access-Control-Allow-Origin': '*',
      'Cache-Control': 'no-cache'
    });
    
    response.data.pipe(res);
  } catch (error) {
    res.status(500).send('TTS error');
  }
});

app.listen(8000);
```

## Conclusion

The streaming TTS integration adds an immersive audio dimension to the Savant Control Center while maintaining the visual elegance and timing precision of the typewriter effects. The system is designed to be robust, configurable, and gracefully degradable when audio is unavailable.
