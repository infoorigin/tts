# TTS Test Server Examples

Quick examples to help you test the TTS integration with a local server.

## Option 1: Python with Edge-TTS (Recommended)

Edge-TTS is free and doesn't require API keys.

### Install Dependencies

```bash
pip install fastapi uvicorn edge-tts
```

### Server Code (`tts_server.py`)

```python
from fastapi import FastAPI
from fastapi.responses import StreamingResponse
from fastapi.middleware.cors import CORSMiddleware
import edge_tts
import asyncio

app = FastAPI()

# Enable CORS for browser access
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/api/v1/tts/stream")
async def stream_tts(text: str):
    """Stream TTS audio for the given text."""
    
    async def generate_audio():
        # Use Edge TTS with a natural-sounding voice
        communicate = edge_tts.Communicate(
            text, 
            voice="en-US-GuyNeural",  # Male voice
            # voice="en-US-JennyNeural",  # Female voice (alternative)
            rate="+10%",  # Slightly faster
            volume="+0%"
        )
        
        async for chunk in communicate.stream():
            if chunk["type"] == "audio":
                yield chunk["data"]
    
    return StreamingResponse(
        generate_audio(),
        media_type="audio/mpeg",
        headers={
            "Cache-Control": "no-cache",
            "Transfer-Encoding": "chunked"
        }
    )

@app.get("/")
async def root():
    return {
        "service": "Savant TTS Streaming Server",
        "status": "running",
        "endpoint": "/api/v1/tts/stream?text=YOUR_TEXT"
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8000)
```

### Run the Server

```bash
python tts_server.py
```

### Test It

```bash
# Open in browser or use curl
curl "http://127.0.0.1:8000/api/v1/tts/stream?text=Hello%20world" --output test.mp3
```

---

## Option 2: Node.js with Google TTS

Uses Google's unofficial TTS API (free, no key needed).

### Install Dependencies

```bash
npm install express google-tts-api axios cors
```

### Server Code (`server.js`)

```javascript
const express = require('express');
const googleTTS = require('google-tts-api');
const axios = require('axios');
const cors = require('cors');

const app = express();

// Enable CORS
app.use(cors());

app.get('/api/v1/tts/stream', async (req, res) => {
  const text = req.query.text;
  
  if (!text) {
    return res.status(400).send('Missing text parameter');
  }
  
  try {
    // Get audio URL from Google TTS
    const url = googleTTS.getAudioUrl(text, {
      lang: 'en',
      slow: false,
      host: 'https://translate.google.com',
    });
    
    // Stream the audio
    const response = await axios({
      method: 'get',
      url: url,
      responseType: 'stream'
    });
    
    res.set({
      'Content-Type': 'audio/mpeg',
      'Cache-Control': 'no-cache',
      'Transfer-Encoding': 'chunked'
    });
    
    response.data.pipe(res);
    
  } catch (error) {
    console.error('TTS Error:', error);
    res.status(500).send('TTS generation failed');
  }
});

app.get('/', (req, res) => {
  res.json({
    service: 'Savant TTS Streaming Server',
    status: 'running',
    endpoint: '/api/v1/tts/stream?text=YOUR_TEXT'
  });
});

const PORT = 8000;
app.listen(PORT, () => {
  console.log(`TTS Server running on http://127.0.0.1:${PORT}`);
  console.log(`Test: http://127.0.0.1:${PORT}/api/v1/tts/stream?text=Hello`);
});
```

### Run the Server

```bash
node server.js
```

---

## Option 3: Python with gTTS (Simplest)

Google Text-to-Speech library (simplest option).

### Install Dependencies

```bash
pip install fastapi uvicorn gtts
```

### Server Code (`gtts_server.py`)

```python
from fastapi import FastAPI
from fastapi.responses import StreamingResponse
from fastapi.middleware.cors import CORSMiddleware
from gtts import gTTS
import io

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/api/v1/tts/stream")
async def stream_tts(text: str):
    """Generate TTS audio for the given text."""
    
    # Generate TTS
    tts = gTTS(text=text, lang='en', slow=False)
    
    # Save to bytes buffer
    fp = io.BytesIO()
    tts.write_to_fp(fp)
    fp.seek(0)
    
    return StreamingResponse(
        iter([fp.read()]),
        media_type="audio/mpeg",
        headers={"Cache-Control": "no-cache"}
    )

@app.get("/")
async def root():
    return {
        "service": "Savant TTS Streaming Server (gTTS)",
        "status": "running"
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8000)
```

### Run the Server

```bash
python gtts_server.py
```

---

## Option 4: OpenAI TTS (Premium Quality)

Requires OpenAI API key but provides best quality.

### Install Dependencies

```bash
pip install fastapi uvicorn openai python-dotenv
```

### Environment Setup (`.env`)

```
OPENAI_API_KEY=your_api_key_here
```

### Server Code (`openai_tts_server.py`)

```python
from fastapi import FastAPI
from fastapi.responses import StreamingResponse
from fastapi.middleware.cors import CORSMiddleware
from openai import OpenAI
import os
from dotenv import load_dotenv

load_dotenv()

app = FastAPI()
client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/api/v1/tts/stream")
async def stream_tts(text: str):
    """Stream TTS audio using OpenAI."""
    
    response = client.audio.speech.create(
        model="tts-1",
        voice="alloy",  # Options: alloy, echo, fable, onyx, nova, shimmer
        input=text,
        speed=1.1  # Slightly faster for agent feel
    )
    
    return StreamingResponse(
        iter([response.content]),
        media_type="audio/mpeg",
        headers={"Cache-Control": "no-cache"}
    )

@app.get("/")
async def root():
    return {
        "service": "Savant TTS Streaming Server (OpenAI)",
        "status": "running"
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8000)
```

### Run the Server

```bash
python openai_tts_server.py
```

---

## Testing Your Server

### 1. Test in Browser

Open: `http://127.0.0.1:8000/api/v1/tts/stream?text=Hello%20world`

Should download/play an audio file.

### 2. Test with cURL

```bash
# Download audio file
curl "http://127.0.0.1:8000/api/v1/tts/stream?text=Testing%20the%20TTS%20server" --output test.mp3

# Play it (macOS)
afplay test.mp3

# Play it (Linux)
mpg123 test.mp3
```

### 3. Test in Savant Control Center

1. Start your TTS server
2. Open Savant Control Center
3. Click "TTS Settings" button
4. Verify URL is `http://127.0.0.1:8000/api/v1/tts/stream`
5. Click "Save Settings"
6. Click "Activate Agent"
7. Listen for audio on thought/response events!

---

## Voice Options

### Edge-TTS Voices (Option 1)

```python
# English voices
"en-US-GuyNeural"        # Male, conversational
"en-US-JennyNeural"      # Female, friendly
"en-US-AriaNeural"       # Female, cheerful
"en-GB-RyanNeural"       # Male, British
"en-AU-WilliamNeural"    # Male, Australian
```

### OpenAI Voices (Option 4)

```python
"alloy"   # Neutral, versatile
"echo"    # Male, clear
"fable"   # British accent
"onyx"    # Deep male voice
"nova"    # Energetic female
"shimmer" # Warm female
```

---

## Troubleshooting

### CORS Errors

Make sure your server has CORS enabled:
```python
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Allow all origins
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
```

### Port Already in Use

Change the port:
```python
uvicorn.run(app, host="127.0.0.1", port=8001)  # Use 8001 instead
```

Then update the URL in Savant TTS Settings to `http://127.0.0.1:8001/api/v1/tts/stream`

### Audio Not Playing

1. Check browser console for errors
2. Verify server is running (`http://127.0.0.1:8000` should show status)
3. Test endpoint directly in browser
4. Check audio format is supported (MP3 works everywhere)

### Slow Response

- Edge-TTS: Fast, free, good quality ✓ Recommended
- gTTS: Medium speed, free
- OpenAI: Fast but requires API key and costs money

---

## Production Deployment

For production use, consider:

1. **Authentication**: Add API key validation
2. **Rate Limiting**: Prevent abuse
3. **Caching**: Cache common phrases
4. **Load Balancing**: Handle multiple requests
5. **HTTPS**: Secure connections
6. **CDN**: Distribute audio globally

Example with caching:

```python
from functools import lru_cache
import hashlib

@lru_cache(maxsize=100)
def get_cached_audio(text_hash: str):
    # Cache audio based on text hash
    pass
```

---

## Conclusion

Start with **Option 1 (Edge-TTS)** for best balance of quality, speed, and ease of use. It's free, fast, and sounds great!

Once your server is running, the Savant Control Center will automatically stream audio for all thought and response events, creating an immersive AI agent experience.
