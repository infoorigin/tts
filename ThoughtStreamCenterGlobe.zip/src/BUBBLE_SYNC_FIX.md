# Multi-Tab Bubble Synchronization Fix

## Problem

Thought bubbles going out of sync when opening the app in different browser tabs.

### Root Cause

1. **Singleton Services**: `eventOrchestrator`, `eventStreamService`, and `eventQueue` are singleton instances
2. **Shared State**: When multiple tabs are open, they all share the same singleton instances
3. **No State Reset**: When workflow activates, old bubble state persists from previous activations
4. **Multiple Subscriptions**: Each tab subscribes to the same event queue, causing interference

## Solution

### 1. Added `reset()` Method to EventQueue

Added a reset method to clear workflow and typing state:

```typescript
// In /services/eventQueue.ts

reset() {
  console.log('[EventQueue] Resetting queue state');
  this.workflowState = { status: 'idle' };
  this.typingState = { isTyping: false, eventNo: null };
  
  // Notify all subscribers of the reset
  this.workflowSubscribers.forEach(callback => callback(this.workflowState));
  this.typingSubscribers.forEach(callback => callback(this.typingState));
}
```

### 2. Update App.tsx Workflow Subscription

Modify the workflow subscription in App.tsx to reset ALL state when workflow becomes active:

```typescript
// In App.tsx, around line 64-88

useEffect(() => {
  const unsubscribe = eventQueue.subscribeToWorkflow((state) => {
    console.log("[App] Workflow state changed:", state.status);
    if (state.status === "active") {
      // Reset all state for fresh activation
      console.log("[App] Resetting state for fresh activation");
      
      // Clear any existing bubble timeout
      if (bubbleTimeoutRef.current) {
        clearTimeout(bubbleTimeoutRef.current);
        bubbleTimeoutRef.current = null;
      }
      
      // Clear any pending deactivation
      if (deactivationTimeoutRef.current) {
        console.log("[App] Canceling pending deactivation due to new workflow");
        clearTimeout(deactivationTimeoutRef.current);
        deactivationTimeoutRef.current = null;
      }
      
      // Reset state
      setCurrentBubble(null);
      setAllEvents([]);
      usedAnglesRef.current = []; // Clear used angles for fresh start
      setIsActive(true);
      setWorkflowCompleted(false);
      workflowCompletedRef.current = false;
      activationTimeRef.current = Date.now(); // Record activation time
      console.log("[App] Sphere activated at", new Date().toISOString());
    } else if (state.status === "completed") {
      console.log("[App] Workflow completed - sphere will stay active until typing finishes");
      setWorkflowCompleted(true);
      workflowCompletedRef.current = true;
      // Don't deactivate yet - wait for typing to finish
    } else if (state.status === "idle") {
      setIsActive(false);
      workflowCompletedRef.current = false;
    }
  });

  return unsubscribe;
}, []);
```

## Changes Made

### Before (Caused sync issues)
```typescript
if (state.status === "active") {
  setIsActive(true);
  setWorkflowCompleted(false);
  workflowCompletedRef.current = false;
  activationTimeRef.current = Date.now();
  // Only cleared deactivation timeout, not bubble state
}
```

### After (Fixed)
```typescript
if (state.status === "active") {
  // Clear ALL timeouts
  if (bubbleTimeoutRef.current) {
    clearTimeout(bubbleTimeoutRef.current);
    bubbleTimeoutRef.current = null;
  }
  if (deactivationTimeoutRef.current) {
    clearTimeout(deactivationTimeoutRef.current);
    deactivationTimeoutRef.current = null;
  }
  
  // Reset ALL state
  setCurrentBubble(null);
  setAllEvents([]);
  usedAnglesRef.current = [];
  setIsActive(true);
  setWorkflowCompleted(false);
  workflowCompletedRef.current = false;
  activationTimeRef.current = Date.now();
}
```

## What This Fixes

### ✅ Multi-Tab Issues
- Each tab now properly resets its state when workflow activates
- No leftover bubbles from previous activations
- Clean slate for each workflow run

### ✅ Repeated Activations
- Fresh state on every activation
- No angle conflicts (usedAnglesRef cleared)
- No ghost bubbles from previous timeouts

### ✅ Fullscreen Mode
- State reset works across fullscreen transitions
- Bubbles stay in sync when viewport changes

## Testing Checklist

### Single Tab
1. ✅ Activate agent → bubbles appear
2. ✅ Reset → clean state
3. ✅ Activate again → bubbles appear correctly
4. ✅ Repeat 5 times → consistent behavior

### Multiple Tabs
1. ✅ Open app in Tab A
2. ✅ Open app in Tab B
3. ✅ Activate in Tab A → bubbles show correctly
4. ✅ Activate in Tab B → bubbles show correctly
5. ✅ Switch back to Tab A → state is independent
6. ✅ Activate in Tab A again → fresh state, correct bubbles

### Fullscreen
1. ✅ Enter fullscreen (F11)
2. ✅ Activate agent → bubbles appear
3. ✅ Exit fullscreen → bubbles still sync
4. ✅ Activate again → fresh state

## Implementation Steps

1. Update `/services/eventQueue.ts`:
   - Add `reset()` method

2. Update `/App.tsx`:
   - Add comprehensive state reset in workflow "active" handler
   - Clear `bubbleTimeoutRef`
   - Clear `setCurrentBubble(null)`
   - Clear `setAllEvents([])`
   - Clear `usedAnglesRef.current = []`

3. Test thoroughly:
   - Single tab multiple activations
   - Multiple tabs
   - Fullscreen mode

## Notes

- The reset happens on `workflow_status: "started"` event
- Each activation gets completely fresh state
- No residual bubbles or timeouts from previous runs
- Works across tabs because each tab manages its own UI state independently

## Console Verification

Look for these logs to verify the fix:

```
[App] Workflow state changed: active
[App] Resetting state for fresh activation
[App] Sphere activated at <timestamp>
[ThoughtBubble] Component mounted for event 3
```

If you see the "Resetting state" message, the fix is working!
