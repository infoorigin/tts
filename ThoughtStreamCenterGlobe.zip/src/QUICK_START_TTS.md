# Quick Start: TTS Integration

## 🚀 Get Audio Working in 5 Minutes

### Step 1: Install Python TTS Server

```bash
pip install fastapi uvicorn edge-tts
```

### Step 2: Create Server File

Save this as `tts_server.py`:

```python
from fastapi import FastAPI
from fastapi.responses import StreamingResponse
from fastapi.middleware.cors import CORSMiddleware
import edge_tts

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/api/v1/tts/stream")
async def stream_tts(text: str):
    async def generate_audio():
        communicate = edge_tts.Communicate(text, "en-US-GuyNeural")
        async for chunk in communicate.stream():
            if chunk["type"] == "audio":
                yield chunk["data"]
    
    return StreamingResponse(
        generate_audio(),
        media_type="audio/mpeg",
        headers={"Cache-Control": "no-cache"}
    )

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8000)
```

### Step 3: Start Server

```bash
python tts_server.py
```

You should see:
```
INFO:     Uvicorn running on http://127.0.0.1:8000
```

### Step 4: Test Server (Optional)

```bash
curl "http://127.0.0.1:8000/api/v1/tts/stream?text=Hello" -o test.mp3
```

### Step 5: Configure Savant

1. Open Savant Control Center
2. Click **"TTS Settings"** button
3. Verify URL: `http://127.0.0.1:8000/api/v1/tts/stream`
4. Click **"Save Settings"**

### Step 6: Activate and Listen! 🎧

1. Click **"Activate Agent"**
2. Listen for audio on thought and response events
3. Watch the typewriter wait for audio completion

---

## ✅ That's It!

You now have:
- ✅ Audio streaming for thought events
- ✅ Audio streaming for response events  
- ✅ Visual indicators during playback
- ✅ Synchronized typewriter effects

---

## 🎯 What Happens Now

### Thought Events
```
1. Event arrives
2. 🔊 Audio streams: "Analyzing information..."
3. [Audio plays for ~3 seconds]
4. ⌨️  Typewriter starts
5. Text appears character-by-character
```

### Response Events
```
1. Event arrives
2. 🔊 Audio streams: "Based on the analysis..."
3. [Audio plays for ~5 seconds]
4. ⌨️  Typewriter starts
5. Text appears character-by-character
```

### Tool Events
```
1. Event arrives
2. ⌨️  Typewriter starts immediately (no audio)
3. Text appears character-by-character
```

---

## 🔧 Troubleshooting

### "Connection Refused" Error

**Problem**: TTS server not running

**Solution**:
```bash
# Make sure server is running
python tts_server.py
```

### No Audio, No Errors

**Problem**: Wrong URL in settings

**Solution**:
1. Click "TTS Settings"
2. Check URL is exactly: `http://127.0.0.1:8000/api/v1/tts/stream`
3. Click "Save Settings"

### CORS Error

**Problem**: CORS not enabled on server

**Solution**: The code above already includes CORS - restart server

---

## 🎨 Customization

### Change Voice

Edit `tts_server.py`:

```python
# Current (Male)
communicate = edge_tts.Communicate(text, "en-US-GuyNeural")

# Female
communicate = edge_tts.Communicate(text, "en-US-JennyNeural")

# British Male
communicate = edge_tts.Communicate(text, "en-GB-RyanNeural")
```

### Change Speed

```python
communicate = edge_tts.Communicate(
    text, 
    "en-US-GuyNeural",
    rate="+20%"  # 20% faster
)
```

---

## 📚 More Information

- **Full Documentation**: See `TTS_INTEGRATION.md`
- **More Server Options**: See `TTS_TEST_SERVER.md`
- **Architecture Details**: See `ARCHITECTURE.md`
- **Complete Summary**: See `STREAMING_TTS_SUMMARY.md`

---

## 🎬 Enjoy Your Cinematic AI Agent!

Your Savant Control Center now speaks with a voice, creating an immersive experience like JARVIS from Iron Man or other movie AI assistants.

**Audio only plays for thoughts and responses** - tool events remain silent and visual-only for a balanced, professional feel.
