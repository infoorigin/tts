# Savant Agentic Platform - Simplified Architecture

## Overview

The application has been redesigned with a **centralized event queue** to eliminate complex state management issues. Both the bubble visualization and Intelligence Stream subscribe to the same event source, ensuring synchronization without manual state coordination.

## Architecture Diagram

```
┌─────────────────┐
│  Event Stream   │ (Mock or Real API)
│  Service        │
└────────┬────────┘
         │ emits AgentEvent
         ▼
┌─────────────────┐
│  Event          │
│  Orchestrator   │ ◄─── start/stop/reset
└────────┬────────┘
         │ transforms & queues
         │ publishes QueuedEvent
         ▼
┌─────────────────┐
│  Event Queue    │ (Pub/Sub)
│  (Singleton)    │
└────┬────────┬───┘
     │        │
     │        └──────────────┐
     ▼                       ▼
┌─────────────┐      ┌──────────────┐
│   Bubble    │      │   Content    │
│ Visualization│      │   Display    │
└─────────────┘      └──────────────┘
```

## Key Components

### 1. Event Stream Service (`/services/eventStream.ts`)
- **Responsibility**: Connects to API or provides mock data
- **Output**: Emits `AgentEvent` objects
- **State**: Manages connection state only

### 2. Event Orchestrator (`/services/eventOrchestrator.ts`)
- **Responsibility**: Transforms events and manages sequential processing
- **Input**: `AgentEvent` from stream
- **Output**: `QueuedEvent` published to queue
- **Logic**:
  - Handles workflow events (started/completed)
  - Splits response events into thinking + response
  - Sequences events with appropriate timing
  - No UI state management

### 3. Event Queue (`/services/eventQueue.ts`)
- **Responsibility**: Pub/Sub event distribution
- **Pattern**: Singleton with subscriber pattern
- **Subscribers**:
  - Workflow state (sphere activation)
  - Individual events (bubbles + content)
  - Queue empty (completion handling)
- **No state management** - just message passing

### 4. App Component (`/App.tsx`)
- **Responsibility**: UI coordination
- **State**: Minimal UI state only
  - `isActive` (sphere state)
  - `currentBubble` (active bubble)
  - `allEvents` (event list for content display)
- **Subscriptions**: Listens to event queue
- **No business logic** - just UI updates

### 5. Content Display (`/components/ContentDisplay.tsx`)
- **Responsibility**: Render events with typewriter effect and TTS
- **Input**: Array of `QueuedEvent` objects
- **State**: Local typewriter state per item + audio playback state
- **TTS Integration**: 
  - Thought & Response events: Play audio first, then typewriter
  - Tool events: Typewriter only (no audio)
- **Simple**: Each `ContentItem` manages its own typing independently

### 6. Streaming TTS Service (`/services/streamingTTS.ts`)
- **Responsibility**: Handle streaming text-to-speech playback
- **API Integration**: Connects to external TTS streaming endpoint
- **Pattern**: Singleton service with async/await promises
- **Features**:
  - Configurable API endpoint URL
  - Promise-based playback (resolves when audio completes)
  - Graceful error handling (continues on failure)
  - Automatic cleanup on stop/unmount

## Event Flow

### 1. Initialization
```typescript
// TESTING_MODE = true
User clicks "Activate Agent" 
  → eventOrchestrator.start()
  → eventStreamService.startStream()

// TESTING_MODE = false (production)
Component mounts
  → eventOrchestrator.start()
  → Waits for workflow_status: "started" event
```

### 2. Event Processing
```typescript
Stream emits AgentEvent
  → Orchestrator receives event
  → If workflow event: publish workflow state
  → If regular event: transform to QueuedEvent
  → Add to internal queue
  → Process sequentially with timing
  → Publish to EventQueue
  → Subscribers receive event
    ├─ App updates currentBubble
    └─ App adds to allEvents
  → ContentDisplay renders new item
  → If thought/response: 
    ├─ TTS audio streams and plays
    └─ Wait for audio completion
  → Item starts typewriter effect
  → Typing completes
  → Next event begins
```

### 3. Completion
```typescript
Stream completes
  → Orchestrator processes remaining queue
  → Last event finishes
  → EventQueue.publishQueueEmpty()
  → Workflow status "completed" published
  → Sphere deactivates after delay
```

## Benefits of New Architecture

### ✅ Eliminated Issues
1. **No state synchronization bugs** - single source of truth
2. **No refs tracking processing state** - queue handles it
3. **No complex useEffect dependencies** - simple subscriptions
4. **No runCounter hacks** - events have natural unique IDs
5. **No manual completion tracking** - orchestrator handles timing

### ✅ Simplified Components
1. **App.tsx**: 180 lines → ~150 lines (cleaner logic)
2. **ContentDisplay.tsx**: 326 lines → ~220 lines (no completion callbacks)
3. **New services**: Clear separation of concerns

### ✅ Maintainability
1. **Single event flow** - easy to trace
2. **Clear responsibilities** - each file has one job
3. **Easy debugging** - console logs show event flow
4. **Testable** - services are decoupled

## How to Extend

### Add a new subscriber
```typescript
useEffect(() => {
  const unsubscribe = eventQueue.subscribeToEvents((event) => {
    // Do something with event
  });
  return unsubscribe;
}, []);
```

### Modify event timing
Edit `eventOrchestrator.ts`:
```typescript
const processingTime = calculateYourCustomTiming(nextEvent);
```

### Add custom event types
1. Add type to `QueuedEvent` in `eventQueue.ts`
2. Handle in orchestrator transform
3. Handle in UI components

## Testing

### Manual Testing
```typescript
// In App.tsx
const TESTING_MODE = true; // Shows manual controls
```

### Production Mode
```typescript
const TESTING_MODE = false; // Auto-activates on workflow start
```

### With Real API
```typescript
// In App.tsx - uncomment URL parsing
const contextId = getContextIdFromURL();

// In eventStream.ts - uncomment real API code
// Uses http://localhost:8000/api/v1/contexts/{contextId}/log/stream
```

## Troubleshooting

### Events not appearing?
- Check console for "[EventQueue] Publishing event"
- Check console for "[App] Event received"
- Verify orchestrator is started

### Typewriter stuck?
- Each ContentItem is independent
- Check browser console for errors
- Events should complete automatically

### Sphere not activating?
- Check for "workflow_status: started" event
- In TESTING_MODE, click "Activate Agent"
- Check isActive state in React DevTools

## File Structure
```
/services
  ├── eventStream.ts       # API/Mock data source
  ├── eventOrchestrator.ts # Event transformation & sequencing
  ├── eventQueue.ts        # Pub/Sub event distribution
  └── streamingTTS.ts      # Streaming text-to-speech service

/components
  ├── ContentDisplay.tsx   # Intelligence Stream with typewriter + TTS
  ├── MindSphere.tsx       # Sphere visualization
  ├── ThoughtBubble.tsx    # Bubble animation
  └── PlaybookMemory.tsx   # Left panel

/App.tsx                   # Main coordinator + TTS settings

Documentation:
  ├── ARCHITECTURE.md      # System architecture overview
  ├── TTS_INTEGRATION.md   # TTS implementation guide
  └── API_SETUP.md         # API setup instructions
```
