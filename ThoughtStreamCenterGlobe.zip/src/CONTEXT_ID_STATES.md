# Context ID Visual States

## Overview
The context ID input now supports three clean states:
1. **Disconnected** - Ready to connect
2. **Input Active** - User entering context ID
3. **Connected** - Shows current context with option to disconnect

---

## Visual States

### State 1: Disconnected (Default)
```
╔════════════════════════════════════════╗
║ Intelligence Stream            🔊 ⚪   ║
╠════════════════════════════════════════╣
║                                        ║
║  🔗 Connect to Context                 ║  ← Click to expand
║                                        ║
╚════════════════════════════════════════╝
```

**Behavior:**
- Shows link icon + "Connect to Context"
- Hover: Icon turns red
- Click: Expands to input state

---

### State 2: Input Active (Expanded)
```
╔════════════════════════════════════════╗
║ Intelligence Stream            🔊 ⚪   ║
╠════════════════════════════════════════╣
║                                        ║
║  [abc123xyz_____] [Connect]            ║  ← Type & submit
║                                        ║
╚════════════════════════════════════════╝
```

**Behavior:**
- Input field auto-focused
- "Connect" button enabled when text entered
- Press Enter or click Connect to submit
- Click away (blur) with empty input → collapses

---

### State 3: Connected (Listening)
```
╔════════════════════════════════════════╗
║ Intelligence Stream            🔊 ⚪   ║
╠════════════════════════════════════════╣
║                                        ║
║  📻 Connected to abc123xyz          ⓧ  ║  ← Clear status
║                                        ║
╚════════════════════════════════════════╝
```

**Behavior:**
- Radio icon (pulsing, indicates active broadcast)
- "Connected to" label (clear context)
- Context ID displayed in bold (truncated if long)
- Small X button on hover (disconnect)
- Click X → disconnects and resets

---

## Interaction Flow

### Connecting to Context

```
┌─────────────────────┐
│  Disconnected       │
│  🔗 Connect to...   │
└──────┬──────────────┘
       │ User Clicks
       ▼
┌─────────────────────┐
│  Input Active       │
│  [____] [Connect]   │
└──────┬──────────────┘
       │ User Submits
       ▼
┌─────────────────────┐
│  Connected          │
│  ● abc123xyz     ⓧ  │
└─────────────────────┘
```

### Changing Context

```
┌──────────────────────────────┐
│  Connected                   │
│  📻 Connected to abc123xyz ⓧ │
└──────┬───────────────────────┘
       │ User Clicks X
       ▼
┌──────────────────────────────┐
│  Disconnected                │
│  🔗 Connect to Context       │
└──────┬───────────────────────┘
       │ User Connects Again
       ▼
┌──────────────────────────────┐
│  Connected                   │
│  📻 Connected to newcontext ⓧ│
└──────────────────────────────┘
```

---

## Design Details

### Connected State Components

**1. Radio Icon (Active Broadcast)**
```tsx
<Radio className="w-3.5 h-3.5 text-[#CC0000] animate-pulse" />
```
- Radio tower icon (broadcasting)
- Red color (#CC0000)
- Subtle pulse animation
- Clear "active connection" metaphor

**2. Descriptive Label**
```tsx
<span className="text-xs text-gray-500">
  Connected to
</span>
```
- Clear context about what the ID represents
- Small gray text (unobtrusive)
- Makes purpose immediately obvious

**3. Context ID Display**
```tsx
<span className="text-xs text-gray-700 font-medium truncate">
  {currentContextId}
</span>
```
- Small bold text (emphasis)
- Darker gray (important info)
- Truncates if too long
- Respects container width

**4. Disconnect Button**
```tsx
<button 
  className="w-5 h-5 rounded-full hover:bg-gray-100"
  title="Disconnect and change context"
>
  <X className="w-3 h-3 text-gray-400 group-hover:text-[#CC0000]" />
</button>
```
- 5px × 5px circular button
- Gray X icon (3px)
- Turns red on hover
- Clear tooltip on hover
- Smooth transition

---

## Responsive Behavior

### Long Context IDs
```
📻 Connected to abc123xyz456def789...     ⓧ
   ↑           ↑                     ↑    ↑
 Icon       Label                Truncate Button
```

**Implementation:**
- `truncate` class handles overflow
- Button stays visible (flex-shrink-0)
- Dot always shows (flex-shrink-0)

### Mobile Layout
```
┌────────────────────────────┐
│ Intelligence Stream        │
├────────────────────────────┤
│ 📻 Connected to abc123  ⓧ  │
└────────────────────────────┘
```

**Clear even on mobile - no confusion!**

---

## State Transitions

### Animation: Disconnect → Connect
```css
/* Exit: Connected state fades out + moves up */
opacity: 1 → 0
y: 0 → -10px
duration: 200ms

/* Enter: Connect button fades in */
opacity: 0 → 1
duration: 200ms
```

### Animation: Connect → Input
```css
/* Exit: Button fades out */
opacity: 1 → 0
duration: 200ms

/* Enter: Input fades in + moves down */
opacity: 0 → 1
y: -10px → 0
duration: 200ms
```

### Animation: Input → Connected
```css
/* Exit: Input fades out + moves up */
opacity: 1 → 0
y: 0 → -10px
duration: 200ms

/* Enter: Connected state fades in + moves down */
opacity: 0 → 1
y: -10px → 0
duration: 200ms
```

**All transitions use `mode="wait"`** = smooth, no overlap

---

## User Scenarios

### Scenario 1: First Time User
1. Opens app
2. Sees "Connect to Context"
3. Clicks to expand
4. Types context ID
5. Presses Enter
6. ✅ Connected! Shows pulsing dot + ID

### Scenario 2: Changing Context
1. Currently connected to "abc123"
2. Hovers over X button
3. Clicks X
4. Connection stopped
5. Back to "Connect to Context"
6. Enters new context ID
7. ✅ Connected to new context!

### Scenario 3: Accidental Click
1. Clicks "Connect to Context"
2. Input appears
3. Clicks away without typing
4. Input auto-collapses ✓
5. Back to "Connect to Context"

---

## Code Integration

### App.tsx State
```typescript
const [currentContextId, setCurrentContextId] = useState<string>("");
const [isListening, setIsListening] = useState(false);
const [contextInputExpanded, setContextInputExpanded] = useState(false);
```

### Connect Handler
```typescript
const handleStartListening = async (contextId: string) => {
  await streamingTTS.initializeAudio();
  setCurrentContextId(contextId);
  setIsListening(true);
  setContextInputExpanded(false);
  eventOrchestrator.start(contextId, false);
};
```

### Disconnect Handler
```typescript
const handleDisconnect = () => {
  console.log("Disconnecting from:", currentContextId);
  handleReset(); // Stops orchestrator, clears state
};
```

### Props to ContentDisplay
```typescript
<ContentDisplay 
  onStartListening={handleStartListening}
  onDisconnect={handleDisconnect}
  isListening={isListening}
  currentContextId={currentContextId}
  contextInputExpanded={contextInputExpanded}
  onToggleContextInput={() => setContextInputExpanded(!contextInputExpanded)}
/>
```

---

## Benefits

### ✅ Visual Clarity
- Always know connection status at a glance
- Radio icon = active broadcast/connection
- "Connected to" label = clear purpose
- Context ID visible = transparency
- No confusion about what you're looking at

### ✅ Easy Context Switching
- One click to disconnect
- No need to refresh page
- Smooth transitions

### ✅ Minimalist Design
- Takes minimal space (single line)
- No clutter
- Professional appearance

### ✅ User Control
- Users can see what they're connected to
- Easy to disconnect when done
- No confusion about state

---

## Testing Checklist

- [ ] Connect to context shows pulsing dot
- [ ] Context ID displays correctly
- [ ] Long IDs truncate properly
- [ ] X button shows on hover
- [ ] Click X disconnects properly
- [ ] Can reconnect after disconnect
- [ ] Transitions are smooth
- [ ] Blur closes empty input
- [ ] Enter key submits
- [ ] Works in testing mode
- [ ] Works in production mode

---

## Accessibility

### ✅ Keyboard Navigation
- Tab to focus X button
- Enter/Space to activate
- Focus visible on buttons

### ✅ Screen Readers
- "Disconnect" title on X button
- Context ID announced
- Button states clear

### ✅ Visual Feedback
- Hover states on all buttons
- Color changes (gray → red)
- Pulsing indicator for status

---

## Future Enhancements

### Copy Context ID
```
● abc123xyz  📋  ⓧ
             ↑
          Copy button
```

### Context History
```
Recent Contexts:
• abc123xyz (current)
• def456ghi
• xyz789jkl
```

### Connection Quality
```
● abc123xyz  ━━━━  ⓧ
             ↑
        Signal bars
```

---

## Summary

**3 Clean States:**
1. 🔗 **Disconnected** - "Connect to Context"
2. ⌨️ **Input** - Type & submit
3. ● **Connected** - Show ID + disconnect option

**User Flow:**
- Click → Type → Connect → See Status → Disconnect → Repeat

**Design Principles:**
- Minimalist (single line)
- Clear (always know status)
- Controllable (easy to change)
- Professional (J&J branding)

---

**Perfect balance of information and simplicity!** ✨
