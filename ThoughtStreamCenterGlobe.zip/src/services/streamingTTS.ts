import { TTS_API, MOCK_AUDIO, AUDIO_TIMING } from "../config/environment";

/**
 * Streaming Text-to-Speech Service
 * Handles streaming audio from TTS API and playback
 * 
 * Configuration is managed in /config/environment.ts
 * See that file for setup instructions
 */

export class StreamingTTS {
  private audio: HTMLAudioElement | null = null;
  private currentAbortController: AbortController | null = null;
  private userInteracted = false; // Track if user has interacted with the page
  private audioContext: AudioContext | null = null; // For checking autoplay policy
  
  // Configuration loaded from environment config
  private apiBaseUrl = TTS_API.url;
  private useMockAudio = true; // Set via setMockMode()
  private mockAudioFile = MOCK_AUDIO.filePath;
  private mockAudioVolume = MOCK_AUDIO.volume;
  
  /**
   * Initialize audio context and mark user interaction
   * Call this when user enables audio or interacts with the page
   * Returns true if successful, false if blocked by browser autoplay policy
   */
  async initializeAudio(): Promise<boolean> {
    if (this.userInteracted) {
      console.log('[StreamingTTS] Audio already initialized');
      return true; // Already initialized
    }
    
    try {
      // Try to create and resume AudioContext
      // This checks if the browser allows audio playback
      if (!this.audioContext) {
        this.audioContext = new AudioContext();
      }
      
      if (this.audioContext.state === 'suspended') {
        console.log('[StreamingTTS] Attempting to resume AudioContext...');
        await this.audioContext.resume();
      }
      
      this.userInteracted = true;
      console.log('[StreamingTTS] ✅ Audio initialized successfully - user interaction detected');
      return true;
    } catch (error) {
      console.warn('[StreamingTTS] ⚠️ Audio initialization blocked by browser autoplay policy');
      console.warn('[StreamingTTS] Audio will be initialized on first user interaction');
      // Don't log full error - it's expected in auto-start scenarios
      return false;
    }
  }
  
  /**
   * Check if audio can play (user has interacted)
   */
  canPlayAudio(): boolean {
    return this.userInteracted;
  }
  
  /**
   * Configure the TTS API endpoint
   */
  setApiUrl(url: string) {
    this.apiBaseUrl = url;
  }
  
  /**
   * Enable/disable mock audio mode
   */
  setMockMode(enabled: boolean) {
    this.useMockAudio = enabled;
    console.log(`[StreamingTTS] Mock mode ${enabled ? 'ENABLED' : 'DISABLED'}`);
  }
  
  /**
   * Set custom mock audio file path
   */
  setMockAudioFile(filePath: string) {
    this.mockAudioFile = filePath;
    console.log(`[StreamingTTS] Mock audio file set to: ${filePath}`);
  }
  
  /**
   * Play text using streaming TTS
   * Returns a promise that resolves when audio finishes playing
   */
  async speak(text: string): Promise<void> {
    console.log("[StreamingTTS] Starting TTS for text:", text.substring(0, 50) + "...");
    
    // Check if user has interacted with the page
    if (!this.canPlayAudio()) {
      console.warn("[StreamingTTS] Cannot play audio - no user interaction detected. Skipping audio playback.");
      // Resolve immediately without playing audio
      return Promise.resolve();
    }
    
    // Cancel any ongoing playback
    this.stop();
    
    // Use mock audio in testing mode
    if (this.useMockAudio) {
      return this.playMockAudio(text);
    }
    
    return new Promise((resolve, reject) => {
      try {
        // Create abort controller for this request
        this.currentAbortController = new AbortController();
        
        // Build full URL with all configured parameters
        const streamUrl = TTS_API.getFullUrl(text);
        
        console.log("[StreamingTTS] Fetching audio stream from:", streamUrl);
        
        // Create audio element
        this.audio = new Audio(streamUrl);
        
        // Handle successful playback completion
        this.audio.addEventListener("ended", () => {
          console.log("[StreamingTTS] Audio playback completed");
          this.cleanup();
          resolve();
        });
        
        // Handle errors
        this.audio.addEventListener("error", (e) => {
          console.error("[StreamingTTS] Audio error:", e);
          this.cleanup();
          // Don't reject - just resolve to allow the app to continue
          // This way if TTS fails, the typewriter will still proceed
          resolve();
        });
        
        // Handle abort
        this.currentAbortController.signal.addEventListener("abort", () => {
          console.log("[StreamingTTS] Playback aborted");
          this.cleanup();
          resolve();
        });
        
        // Start playing
        this.audio.play().catch((error) => {
          console.error("[StreamingTTS] Playback failed:", error);
          this.cleanup();
          // Don't reject - just resolve to allow the app to continue
          resolve();
        });
        
        console.log("[StreamingTTS] Audio playback started");
      } catch (error) {
        console.error("[StreamingTTS] Error setting up audio:", error);
        this.cleanup();
        // Don't reject - just resolve to allow the app to continue
        resolve();
      }
    });
  }
  
  /**
   * Stop current playback
   */
  stop() {
    if (this.audio) {
      console.log("[StreamingTTS] Stopping current playback");
      this.audio.pause();
      this.audio.currentTime = 0;
    }
    
    if (this.currentAbortController) {
      this.currentAbortController.abort();
    }
    
    this.cleanup();
  }
  
  /**
   * Check if currently playing
   */
  isPlaying(): boolean {
    return this.audio !== null && !this.audio.paused;
  }
  
  /**
   * Play mock audio for testing (simulates streaming)
   * Calculates realistic duration based on text length
   */
  private async playMockAudio(text: string): Promise<void> {
    console.log("[StreamingTTS] Using MOCK audio mode for testing");
    
    return new Promise((resolve) => {
      try {
        // Create abort controller for this request
        this.currentAbortController = new AbortController();
        
        // Calculate realistic duration based on text length
        // Uses configuration from AUDIO_TIMING
        const wordCount = text.split(/\s+/).length;
        const wordsPerSecond = AUDIO_TIMING.wordsPerMinute / 60;
        const estimatedDuration = (wordCount / wordsPerSecond) * 1000; // Convert to milliseconds
        const duration = Math.min(
          Math.max(estimatedDuration, AUDIO_TIMING.minDuration),
          AUDIO_TIMING.maxDuration
        );
        
        console.log(`[StreamingTTS] Mock audio: ${wordCount} words, duration: ${duration}ms`);
        
        let isCompleted = false;
        let timeoutId: number | null = null;
        
        // Function to complete the mock playback
        const completeMock = () => {
          if (isCompleted) return;
          isCompleted = true;
          
          if (timeoutId !== null) {
            clearTimeout(timeoutId);
            timeoutId = null;
          }
          
          this.cleanup();
          console.log("[StreamingTTS] Mock audio completed");
          resolve();
        };
        
        // Handle abort signal
        this.currentAbortController.signal.addEventListener("abort", () => {
          console.log("[StreamingTTS] Mock playback aborted");
          completeMock();
        });
        
        // Create audio element with mock file
        this.audio = new Audio(this.mockAudioFile);
        this.audio.volume = this.mockAudioVolume;
        
        // Try to play the audio, but don't block on errors
        const playPromise = this.audio.play();
        
        if (playPromise !== undefined) {
          playPromise
            .then(() => {
              console.log("[StreamingTTS] Mock audio started playing");
            })
            .catch((error) => {
              // Audio play failed (common in browsers with autoplay restrictions)
              // Just log it and continue with timeout-based simulation
              console.log("[StreamingTTS] Mock audio autoplay blocked (expected), using silent simulation");
            });
        }
        
        // Set timeout for the calculated duration
        // This is the primary mechanism - audio is just optional background
        timeoutId = window.setTimeout(() => {
          completeMock();
        }, duration);
        
      } catch (error) {
        console.error("[StreamingTTS] Error setting up mock audio:", error);
        this.cleanup();
        resolve();
      }
    });
  }
  
  /**
   * Cleanup resources
   */
  private cleanup() {
    if (this.audio) {
      try {
        // Safely stop audio without triggering errors
        this.audio.pause();
        this.audio.currentTime = 0;
        this.audio.src = "";
        this.audio.load(); // Reset the audio element
      } catch (e) {
        // Ignore cleanup errors
      }
      this.audio = null;
    }
    this.currentAbortController = null;
  }
}

// Singleton instance
export const streamingTTS = new StreamingTTS();
