import { getEventStreamUrl, EVENT_STREAM_API, USE_MOCK_EVENTS } from "../config/environment";

// Internal event format used throughout the application
export interface AgentEvent {
  no: number;
  id: string | null;
  profile?: string;
  type: "reasoning" | "tool" | "response" | "workflow";
  content: string[] | string;
  heading: string;
  temp?: boolean;
  kvps?: {
    workflow_status?: "started" | "completed";
    [key: string]: any;
  };
}

// New NDJSON HTTP Stream API format
export interface NDJSONStreamEvent {
  event: string;
  data: {
    no: number;
    id: string | null;
    type?: string;
    heading?: string;
    content?: string;
    temp?: boolean;
    kvps?: {
      event_type?: "workflow" | "reasoning" | "tool" | "response";
      workflow_status?: "started" | "completed";
      headline?: string;
      thoughts?: string[];
      tool_name?: string;
      tool_args?: any;
      tool_type?: string;
      [key: string]: any;
    };
  };
}

/**
 * Transform NDJSON stream event to internal AgentEvent format
 * Only processes events where event === "update"
 * Uses kvps.event_type as the actual event type
 * Uses kvps.headline as the heading
 * For reasoning events, uses kvps.thoughts as content
 */
export function transformNDJSONEvent(ndjsonEvent: NDJSONStreamEvent): AgentEvent | null {
  // Only process "update" events
  if (ndjsonEvent.event !== "update") {
    return null;
  }

  const { data } = ndjsonEvent;
  const eventType = data.kvps?.event_type;

  // Must have an event_type in kvps
  if (!eventType) {
    return null;
  }

  // Determine heading: use kvps.headline, or fallback to data.heading
  const heading = data.kvps?.headline || data.heading || "";

  // Determine content based on event type
  let content: string[] | string = "";
  
  if (eventType === "reasoning") {
    // For reasoning events, use kvps.thoughts array
    content = data.kvps?.thoughts || [];
  } else {
    // For other events, use data.content
    content = data.content || "";
  }

  return {
    no: data.no,
    id: data.id,
    type: eventType,
    heading,
    content,
    temp: data.temp,
    kvps: data.kvps,
  };
}

// Simulated NDJSON events that will be streamed (matching new API format)
const NDJSON_EVENTS: NDJSONStreamEvent[] = [
  {
    event: "update",
    data: {
      no: 1,
      id: null,
      type: "workflow",
      heading: "{}",
      content: "",
      temp: false,
      kvps: {
        workflow_status: "started",
        event_type: "workflow"
      }
    }
  },
  {
    event: "update",
    data: {
      no: 3,
      id: null,
      kvps: {
        thoughts: [
          "Received first purchase trigger for account Yale New Haven.",
          "According to the playbook, the first step is to confirm territory alignment for OS, OCE, FRM, and MSL roles.",
          "I will use the fpomcp.territory_alignment_tool to validate role assignments for this account."
        ],
        headline: "Starting First Purchase Trigger Process: Confirming Territory Alignment for Yale New Haven",
        tool_name: "fpomcp.territory_alignment_tool",
        tool_args: { account: "Yale New Haven" },
        event_type: "reasoning"
      }
    }
  },
  {
    event: "update",
    data: {
      no: 4,
      id: null,
      type: "tool",
      heading: "icon://construction AM0: Using tool 'fpomcp.territory_alignment_tool'",
      content: "{\"status\":\"aligned\",\"roles\":[\"OS\",\"OCE\",\"FRM\",\"MSL\"]}",
      temp: false,
      kvps: {
        tool_type: "mcp",
        event_type: "tool",
        headline: "Using tool 'fpomcp.territory_alignment_tool'"
      }
    }
  },
  {
    event: "update",
    data: {
      no: 5,
      id: null,
      kvps: {
        thoughts: [
          "Territory alignment confirmed for Yale New Haven.",
          "All required roles (OS, OCE, FRM, MSL) are properly aligned.",
          "Moving to next step: confirming primary field force assignments.",
          "Will use fpomcp.field_force_assignment_tool to retrieve personnel assignments."
        ],
        headline: "Territory Aligned: Proceeding to Field Force Assignment Verification",
        event_type: "reasoning"
      }
    }
  },
  {
    event: "update",
    data: {
      no: 6,
      id: null,
      type: "tool",
      heading: "icon://construction AM0: Using tool 'fpomcp.field_force_assignment_tool'",
      content: "{\"assignments\":{\"OS\":\"Dr. Sarah Chen\",\"OCE\":\"Mark Rodriguez\",\"FRM\":\"Jennifer Wu\",\"MSL\":\"Dr. Robert Martinez\"}}",
      temp: false,
      kvps: {
        tool_type: "mcp",
        event_type: "tool",
        headline: "Using tool 'fpomcp.field_force_assignment_tool'"
      }
    }
  },
  {
    event: "update",
    data: {
      no: 7,
      id: null,
      kvps: {
        thoughts: [
          "Field force assignments retrieved successfully.",
          "Personnel identified: Dr. Sarah Chen (OS), Mark Rodriguez (OCE), Jennifer Wu (FRM), Dr. Robert Martinez (MSL).",
          "Next step: verify availability of all assigned personnel.",
          "This ensures they can engage with Yale New Haven in a timely manner."
        ],
        headline: "Field Force Identified: Verifying Personnel Availability",
        event_type: "reasoning"
      }
    }
  },
  {
    event: "update",
    data: {
      no: 8,
      id: null,
      type: "tool",
      heading: "icon://construction AM0: Using tool 'fpomcp.availability_verification'",
      content: "{\"message\":\"all_available\"}",
      temp: false,
      kvps: {
        tool_type: "mcp",
        event_type: "tool",
        headline: "Using tool 'fpomcp.availability_verification'"
      }
    }
  },
  {
    event: "update",
    data: {
      no: 9,
      id: null,
      kvps: {
        thoughts: [
          "Excellent! All assigned personnel are available for engagement.",
          "Now preparing to send notifications using compliance-approved templates.",
          "Each role will receive tailored information about the Yale New Haven first purchase.",
          "Using fpomcp.notification_service to deliver the notifications."
        ],
        headline: "All Personnel Available: Sending Engagement Notifications",
        event_type: "reasoning"
      }
    }
  },
  {
    event: "update",
    data: {
      no: 10,
      id: null,
      type: "tool",
      heading: "icon://construction AM0: Using tool 'fpomcp.notification_service'",
      content: "{\"notifications_sent\":4,\"status\":\"delivered\"}",
      temp: false,
      kvps: {
        tool_type: "mcp",
        event_type: "tool",
        headline: "Using tool 'fpomcp.notification_service'"
      }
    }
  },
  {
    event: "update",
    data: {
      no: 11,
      id: null,
      type: "response",
      heading: "First Purchase Orchestration Complete",
      content: "## Orchestration Summary\n\nI have successfully completed the First Purchase orchestration for **Yale New Haven** in the north-east region.\n\n### Actions Completed:\n1. ✅ Confirmed territory alignment for all required roles\n2. ✅ Retrieved primary field force assignments\n3. ✅ Verified availability of all assigned personnel\n4. ✅ Sent notifications to all roles with approved templates\n\n### Assigned Team:\n- **Oncology Specialist**: Dr. Sarah Chen (Available)\n- **Oncology Clinical Educator**: Mark Rodriguez (Available)\n- **Field Reimbursement Manager**: Jennifer Wu (Available)\n- **Medical Science Liaison**: Dr. Robert Martinez (Available)\n\n### Next Steps:\nThe assigned personnel have been notified and are ready to engage with Yale New Haven. The orchestration has been logged and is now ready for engagement execution and monitoring.\n\nAll compliance requirements have been met. The team can proceed with the first purchase engagement.",
      temp: false,
      kvps: {
        event_type: "response",
        headline: "First Purchase Orchestration Complete"
      }
    }
  },
  {
    event: "update",
    data: {
      no: 18,
      id: null,
      type: "workflow",
      heading: "{}",
      content: "",
      temp: false,
      kvps: {
        workflow_status: "completed",
        event_type: "workflow"
      }
    }
  }
];

export type EventCallback = (event: AgentEvent) => void;
export type CompleteCallback = () => void;

export class EventStreamService {
  private timeouts: NodeJS.Timeout[] = [];
  private isStreaming = false;
  private abortController: AbortController | null = null;
  private eventIdOffset = 0; // Counter to ensure unique event IDs across multiple streams

  /**
   * Start streaming events
   * Behavior controlled by USE_MOCK_EVENTS in config/environment.ts
   * @param onEvent - Callback fired when a new event arrives
   * @param onComplete - Callback fired when all events have been streamed
   */
  startStream(onEvent: EventCallback, onComplete: CompleteCallback, contextId?: string): void {
    // Clear any existing stream
    this.stopStream();
    
    this.isStreaming = true;

    // Production mode (USE_MOCK_EVENTS = false): only connect if context ID provided
    if (!USE_MOCK_EVENTS) {
      if (contextId) {
        console.log("[EventStream] Using REAL API streaming");
        this.startRealAPIStream(contextId, onEvent, onComplete);
        return;
      } else {
        console.log("[EventStream] Production mode: No context ID provided. Not connecting.");
        this.isStreaming = false;
        return;
      }
    }
    
    // Testing mode (USE_MOCK_EVENTS = true): use mock events
    console.log(`[EventStream] Using MOCK events for testing (offset: ${this.eventIdOffset})`);
    // MOCK: Stream events with realistic delays
    let cumulativeDelay = 0;
    
    NDJSON_EVENTS.forEach((ndjsonEvent, index) => {
      // Transform NDJSON event to internal format
      const event = transformNDJSONEvent(ndjsonEvent);
      
      // Skip if transformation returned null (invalid event)
      if (!event) {
        return;
      }
      
      // Apply unique ID offset to ensure no duplicate keys across multiple runs
      const uniqueEvent = {
        ...event,
        no: event.no + this.eventIdOffset
      };
      
      // Variable delays based on event type to simulate realistic processing
      let delay = 0;
      
      if (event.type === "workflow") {
        // Workflow events are immediate
        delay = 500;
      } else if (event.type === "reasoning") {
        // Reasoning takes longer (2-4 seconds)
        delay = 2000 + Math.random() * 2000;
      } else if (event.type === "tool") {
        // Tool calls are faster (1-2 seconds)
        delay = 1000 + Math.random() * 1000;
      } else if (event.type === "response") {
        // Final response takes a bit longer (2-3 seconds)
        delay = 2000 + Math.random() * 1000;
      }
      
      cumulativeDelay += delay;
      
      const timeout = setTimeout(() => {
        if (this.isStreaming) {
          onEvent(uniqueEvent);
          
          // Check if this is the last event
          if (index === NDJSON_EVENTS.length - 1) {
            this.isStreaming = false; // Mark as complete
            // Increment offset for next stream to ensure unique IDs
            this.eventIdOffset += 1000; // Add 1000 to ensure no overlap
            console.log(`[EventStream] Mock stream complete. Next offset will be: ${this.eventIdOffset}`);
            onComplete();
          }
        }
      }, cumulativeDelay);
      
      this.timeouts.push(timeout);
    });
  }

  /**
   * Start streaming from real API endpoint
   * Automatically used when USE_MOCK_EVENTS = false in config
   * @param contextId - The context ID to stream events from
   * @param onEvent - Callback fired when a new event arrives
   * @param onComplete - Callback fired when stream completes
   */
  private async startRealAPIStream(
    contextId: string,
    onEvent: EventCallback,
    onComplete: CompleteCallback
  ): Promise<void> {
    try {
      this.abortController = new AbortController();
      const apiUrl = getEventStreamUrl(contextId);
      
      console.log(`🌐 Connecting to stream API: ${apiUrl}`);
      console.log(`📋 Request headers:`, EVENT_STREAM_API.headers);
      
      console.log(`📤 Sending GET request to: ${apiUrl}`);
      
      const response = await fetch(apiUrl, {
        method: 'GET',
        headers: EVENT_STREAM_API.headers,
        signal: this.abortController.signal,
      });

      console.log(`📥 Response status: ${response.status} ${response.statusText}`);

      if (!response.ok) {
        console.error(`❌ Stream API error: ${response.status} ${response.statusText}`);
        throw new Error(`Stream API error: ${response.status} ${response.statusText}`);
      }
      
      console.log(`✅ Stream connected successfully, starting to read...`);

      const reader = response.body?.getReader();
      if (!reader) {
        throw new Error('Failed to get response reader');
      }

      const decoder = new TextDecoder();
      let buffer = '';

      // Read stream chunk by chunk
      while (this.isStreaming) {
        const { done, value } = await reader.read();
        
        if (done) {
          console.log('Stream ended');
          onComplete();
          break;
        }

        // Decode chunk and add to buffer
        buffer += decoder.decode(value, { stream: true });

        // Process complete lines (NDJSON format)
        const lines = buffer.split('\n');
        buffer = lines.pop() || ''; // Keep incomplete line in buffer

        for (const line of lines) {
          const trimmedLine = line.trim();
          if (!trimmedLine) continue; // Skip empty lines

          try {
            // Parse NDJSON line
            const ndjsonEvent: NDJSONStreamEvent = JSON.parse(trimmedLine);
            
            // Transform to internal format
            const event = transformNDJSONEvent(ndjsonEvent);
            
            if (event) {
              console.log('📨 Received event:', event.type, event.heading);
              onEvent(event);
            } else {
              console.log('⚠️ Event transformation returned null for:', ndjsonEvent.event);
            }
          } catch (parseError) {
            console.error('Failed to parse NDJSON line:', trimmedLine, parseError);
          }
        }
      }
    } catch (error) {
      if (error instanceof Error && error.name === 'AbortError') {
        console.log('🛑 Stream aborted');
      } else {
        console.error('❌ Stream error:', error);
        if (error instanceof Error) {
          console.error('Error details:', {
            name: error.name,
            message: error.message,
            stack: error.stack
          });
        }
      }
      onComplete();
    } finally {
      console.log('🏁 Stream ended, cleaning up...');
      this.isStreaming = false;
      this.abortController = null;
    }
  }

  /**
   * Stop the current stream and clear all pending events
   */
  stopStream(): void {
    this.isStreaming = false;
    
    // Stop mock timers
    this.timeouts.forEach(timeout => clearTimeout(timeout));
    this.timeouts = [];
    
    // Abort real API stream
    if (this.abortController) {
      this.abortController.abort();
      this.abortController = null;
    }
  }

  /**
   * Check if currently streaming
   */
  isActive(): boolean {
    return this.isStreaming;
  }
}

// Export a singleton instance
export const eventStreamService = new EventStreamService();