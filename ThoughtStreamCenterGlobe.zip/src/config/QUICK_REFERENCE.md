# Configuration Quick Reference

One-page reference for all configuration settings.

## 📁 File Location
`/config/environment.ts`

## 🚀 Quick Start

### For Testing (Default)
```typescript
export const TESTING_MODE = true;
export const USE_MOCK_AUDIO = true;
export const USE_MOCK_EVENTS = true;
```
✅ No backend required  
✅ Manual activation button  
✅ Mock data and audio  

### For Production
```typescript
export const TESTING_MODE = false;
export const USE_MOCK_AUDIO = false;
export const USE_MOCK_EVENTS = false;

// Update these URLs:
export const EVENT_STREAM_API = {
  baseUrl: "https://your-api.com",
  // ...
};

export const TTS_API = {
  baseUrl: "https://your-tts.com",
  // ...
};
```
✅ Auto-activates on load  
✅ Real TTS API calls  
✅ Real event streaming  

## 🎯 Mode Flags

| Flag | `true` | `false` |
|------|--------|---------|
| `TESTING_MODE` | Manual button | Auto-activate |
| `USE_MOCK_AUDIO` | Mock audio file | Real TTS API |
| `USE_MOCK_EVENTS` | Hardcoded events | Real event stream |

## 🌐 API Configuration

### Event Stream API
```typescript
export const EVENT_STREAM_API = {
  baseUrl: "http://localhost:8000",
  streamPath: "/api/v1/contexts/{contextId}/log/stream",
  headers: {
    Accept: "text/event-stream",
    "Cache-Control": "no-cache",
  },
};
```

**Generates:**
```
http://localhost:8000/api/v1/contexts/ABC123/log/stream
```

### TTS API
```typescript
export const TTS_API = {
  baseUrl: "http://127.0.0.1:8080",
  streamPath: "/api/v1/tts/stream",
  params: {
    voice: "Danielle",      // Voice name
    engine: "long-form",    // Engine mode
    format: "mp3",          // Audio format
  },
};
```

**Generates:**
```
http://127.0.0.1:8080/api/v1/tts/stream?voice=Danielle&engine=long-form&format=mp3&text=...
```

## 🎤 TTS Voice Settings

### Common Voices
```typescript
voice: "Danielle"  // Female, professional
voice: "Matthew"   // Male, professional
voice: "Joanna"    // Female, conversational
```

### Engine Options
```typescript
engine: "long-form"  // Optimized for longer text
engine: "standard"   // Basic quality, faster
engine: "neural"     // Higher quality, more natural
```

### Format Options
```typescript
format: "mp3"   // Best browser compatibility ⭐
format: "wav"   // Higher quality, larger size
format: "ogg"   // Good compression
```

## 🎵 Mock Audio

### Configuration
```typescript
export const MOCK_AUDIO = {
  filePath: "/your-audio.mp3",  // Path or URL
  volume: 0.3,                   // 0.0 to 1.0
};
```

### Setup
1. Place audio file in `/public` folder
2. Update `filePath` to `"/filename.mp3"`
3. Or use remote URL

## ⏱️ Audio Timing

```typescript
export const AUDIO_TIMING = {
  wordsPerMinute: 150,   // Speaking rate
  minDuration: 1000,     // Min 1 second
  maxDuration: 10000,    // Max 10 seconds
};
```

## 🛠️ Helper Functions

### Get Current Environment
```typescript
getCurrentEnvironment()
// Returns: "development" | "staging" | "production" | "custom"
```

### Build Event Stream URL
```typescript
getEventStreamUrl("contextId123")
// Returns: "http://localhost:8000/api/v1/contexts/contextId123/log/stream"
```

### Build TTS URL
```typescript
TTS_API.getFullUrl("hello world")
// Returns: "http://127.0.0.1:8080/api/v1/tts/stream?voice=Danielle&engine=long-form&format=mp3&text=hello+world"
```

### Log Configuration
```typescript
logConfiguration()
// Prints configuration to browser console
```

## 📊 Configuration Matrix

| Scenario | TESTING_MODE | USE_MOCK_AUDIO | USE_MOCK_EVENTS | Use Case |
|----------|--------------|----------------|-----------------|----------|
| Local Dev | ✅ true | ✅ true | ✅ true | Frontend development |
| API Testing | ✅ true | ❌ false | ❌ false | Integration testing |
| QA/Staging | ✅ true | ❌ false | ❌ false | Manual QA testing |
| Production | ❌ false | ❌ false | ❌ false | Live deployment |

## 🔍 Debugging

### Check Console
Look for:
```
🔧 Savant Control Center - Configuration
Environment: DEVELOPMENT
Testing Mode: ✅ ENABLED
Mock Audio: ✅ ENABLED
Mock Events: ✅ ENABLED
TTS API: http://127.0.0.1:8080/api/v1/tts/stream
TTS Voice: Danielle
TTS Engine: long-form
TTS Format: mp3
Example URL: http://127.0.0.1:8080/api/v1/tts/stream?voice=...
```

### Check Network Tab
Filter by: `stream` or `tts`

Expected URL format:
```
http://127.0.0.1:8080/api/v1/tts/stream?voice=Danielle&engine=long-form&format=mp3&text=Received%20first%20purchase%20trigger...
```

### Check Status Badge
- Shows "• Audio & Events Mock" when using mocks
- Shows nothing when using real APIs

## ⚠️ Common Issues

| Issue | Solution |
|-------|----------|
| "Mock Audio" shows in production | Set `USE_MOCK_AUDIO = false` |
| No TTS requests in Network tab | Set `USE_MOCK_AUDIO = false` |
| TTS returns 404 | Check `baseUrl` and `streamPath` |
| TTS returns 400 | Check `params` match your API |
| Agent doesn't auto-start | Set `TESTING_MODE = false` |
| Events don't load | Set `USE_MOCK_EVENTS = false` |

## 📚 Documentation

- **Full Guide**: `/config/README.md`
- **TTS Examples**: `/config/TTS_EXAMPLES.md`
- **Testing**: `/config/TEST_CONFIG.md`
- **Migration**: `/CONFIGURATION_MIGRATION.md`

## 🎯 Most Common Changes

### Change TTS Voice
```typescript
TTS_API.params.voice = "Matthew";  // Male voice
```

### Change TTS Engine
```typescript
TTS_API.params.engine = "neural";  // Higher quality
```

### Change API Server
```typescript
TTS_API.baseUrl = "http://192.168.1.100:8080";  // Different server
```

### Switch to Production
```typescript
TESTING_MODE = false;
USE_MOCK_AUDIO = false;
USE_MOCK_EVENTS = false;
// Update API URLs
```

## 💡 Pro Tips

1. **Always test config changes in dev first**
2. **Use browser hard refresh after changes** (Ctrl+Shift+R)
3. **Check console for config log on startup**
4. **Use Network tab to verify URLs**
5. **Keep mock mode enabled for frontend development**
6. **Document custom configurations for your team**

## 🔗 URL Structure

### Current Setup
```
Base: http://127.0.0.1:8080
Path: /api/v1/tts/stream
Query Params:
  - voice=Danielle
  - engine=long-form
  - format=mp3
  - text=[urlencoded]

Full URL:
http://127.0.0.1:8080/api/v1/tts/stream?voice=Danielle&engine=long-form&format=mp3&text=hello%20world
```

### Adding Custom Parameters
```typescript
TTS_API.params.yourParam = "value";

// Update getQueryString() to include it:
getQueryString(text: string): string {
  const params = new URLSearchParams({
    voice: this.params.voice,
    engine: this.params.engine,
    format: this.params.format,
    yourParam: this.params.yourParam,  // Add here
    text: text,
  });
  return params.toString();
}
```

---

**Last Updated:** Configuration system v2.0 with full TTS parameter support

**Quick Start:** Just edit `/config/environment.ts` and refresh! 🚀
