import { useState, useEffect, useRef } from "react";
import { AnimatePresence, motion } from "motion/react";
import { MindSphere } from "./components/MindSphere";
import { ThoughtBubble } from "./components/ThoughtBubble";
import { ContentDisplay } from "./components/ContentDisplay";
import { PlaybookMemory } from "./components/PlaybookMemory";
import { Button } from "./components/ui/button";
import { RotateCcw } from "lucide-react";
import { eventQueue, type QueuedEvent } from "./services/eventQueue";
import { eventOrchestrator } from "./services/eventOrchestrator";
import { streamingTTS } from "./services/streamingTTS";
import { 
  TESTING_MODE, 
  USE_MOCK_AUDIO, 
  USE_MOCK_EVENTS,
  FONT_FAMILY,
  logConfiguration
} from "./config/environment";
import savantLogo from "figma:asset/06c2ebb669303822392fbcaf4b1f8838afc892de.png";
import jjLogo from "figma:asset/c4af0d119cc1d6eb95320454eb716e4e1c54afce.png";

export default function App() {
  // Configuration is now loaded from /config/environment.ts
  // Edit that file to change between environments
  
  // Apply font family from config to CSS variable
  useEffect(() => {
    document.documentElement.style.setProperty('--app-font-family', FONT_FAMILY);
  }, []);

  const [isActive, setIsActive] = useState(false);
  const [currentBubble, setCurrentBubble] = useState<QueuedEvent | null>(null);
  const [currentBubbleAngle, setCurrentBubbleAngle] = useState<number>(0);
  const [allEvents, setAllEvents] = useState<QueuedEvent[]>([]);
  const bubbleTimeoutRef = useRef<NodeJS.Timeout | null>(null); // Track bubble timeout for cleanup
  const [workflowCompleted, setWorkflowCompleted] = useState(false); // Track if workflow signaled completion
  const workflowCompletedRef = useRef(false); // Ref to track workflow completion without causing re-subscriptions
  const [isTyping, setIsTyping] = useState(false); // Track if any typing is happening
  const isTypingRef = useRef(false); // Ref to track typing state
  const usedAnglesRef = useRef<number[]>([]); // Track used angles to prevent overlap
  const deactivationTimeoutRef = useRef<NodeJS.Timeout | null>(null); // Track deactivation timeout
  const activationTimeRef = useRef<number>(0); // Track when sphere was last activated
  const [contextId, setContextId] = useState<string>(""); // Context ID from URL
  const [hasBeenActive, setHasBeenActive] = useState(false); // Track if agent has ever been activated (to keep UI visible)

  // Generate random angle for bubbles - randomly select from predefined angles
  // Specific angles: 245°, 250°, 260°, 270°, 280°, 290°, 295°
  const generateRandomAngle = () => {
    const allowedAngles = [245, 250, 260, 270, 280, 290, 295];
    
    // Randomly select one of the allowed angles
    const randomIndex = Math.floor(Math.random() * allowedAngles.length);
    const selectedAngle = allowedAngles[randomIndex];
    
    // Track this angle (keep only last 5 to allow reuse after some time)
    usedAnglesRef.current.push(selectedAngle);
    if (usedAnglesRef.current.length > 5) {
      usedAnglesRef.current.shift();
    }
    
    return (selectedAngle * Math.PI) / 180; // Convert to radians
  };

  // Subscribe to workflow state changes (sphere activation)
  useEffect(() => {
    const unsubscribe = eventQueue.subscribeToWorkflow((state) => {
      console.log("[App] Workflow state changed:", state.status);
      if (state.status === "active") {
        // Clear any existing bubble timeout
        if (bubbleTimeoutRef.current) {
          clearTimeout(bubbleTimeoutRef.current);
          bubbleTimeoutRef.current = null;
        }
        
        // Reset bubble state but KEEP previous events (append mode)
        setCurrentBubble(null);
        // Don't clear allEvents - keep accumulating across workflow runs
        // setAllEvents([]);
        usedAnglesRef.current = [];
        
        setIsActive(true);
        setHasBeenActive(true); // Mark that agent has been activated (keeps UI visible)
        setWorkflowCompleted(false);
        workflowCompletedRef.current = false;
        activationTimeRef.current = Date.now(); // Record activation time
        console.log("[App] Sphere activated at", new Date().toISOString(), "- keeping previous events");
        // Cancel any pending deactivation
        if (deactivationTimeoutRef.current) {
          console.log("[App] Canceling pending deactivation due to new workflow");
          clearTimeout(deactivationTimeoutRef.current);
          deactivationTimeoutRef.current = null;
        }
      } else if (state.status === "completed") {
        console.log("[App] ⚠️ Workflow COMPLETED event received - sphere will STAY ACTIVE until ALL typing finishes");
        setWorkflowCompleted(true);
        workflowCompletedRef.current = true;
        // IMPORTANT: Don't deactivate yet - wait for typing to finish
        // The sphere will only deactivate when typing state becomes false
      } else if (state.status === "idle") {
        console.log("[App] Workflow set to IDLE - deactivating immediately (manual reset)");
        setCurrentBubble(null); // Clear any visible bubble when deactivating
        setIsActive(false);
        workflowCompletedRef.current = false;
      }
    });

    return unsubscribe;
  }, []);
  
  // Subscribe to typing state changes - NO DEPENDENCIES to avoid re-subscription issues
  useEffect(() => {
    const unsubscribe = eventQueue.subscribeToTyping((state) => {
      const currentWorkflowCompleted = workflowCompletedRef.current;
      console.log("[App] Typing state changed:", state.isTyping ? "TYPING" : "IDLE", "Event:", state.eventNo, "Workflow completed (ref):", currentWorkflowCompleted);
      setIsTyping(state.isTyping);
      isTypingRef.current = state.isTyping;
      
      // CRITICAL: Only consider deactivation if typing has stopped
      if (state.isTyping) {
        console.log("[App] 🔵 TYPING IN PROGRESS - sphere must remain ACTIVE regardless of workflow status");
        // Cancel any pending deactivation if typing resumed
        if (deactivationTimeoutRef.current) {
          console.log("[App] Canceling pending deactivation - typing has resumed");
          clearTimeout(deactivationTimeoutRef.current);
          deactivationTimeoutRef.current = null;
        }
        return; // Exit early - don't even consider deactivation while typing
      }
      
      // If typing stopped AND workflow is completed, deactivate sphere
      if (!state.isTyping && currentWorkflowCompleted) {
        console.log("[App] ✅ BOTH conditions met: typing=false AND workflow=completed - scheduling sphere deactivation in 2.5s");
        
        // Clear any existing timeout
        if (deactivationTimeoutRef.current) {
          console.log("[App] Clearing previous deactivation timeout");
          clearTimeout(deactivationTimeoutRef.current);
        }
        
        deactivationTimeoutRef.current = setTimeout(() => {
          // Double-check conditions haven't changed
          const timeSinceActivation = Date.now() - activationTimeRef.current;
          const minActiveTime = 3000; // Minimum 3 seconds active time to prevent premature deactivation
          
          // CRITICAL CHECK: Verify typing is STILL not happening
          if (isTypingRef.current) {
            console.log("[App] ⚠️ Deactivation PREVENTED - typing resumed during delay period");
            deactivationTimeoutRef.current = null;
            return;
          }
          
          if (!isTypingRef.current && workflowCompletedRef.current) {
            // Extra safeguard: ensure sphere has been active for at least 3 seconds
            // This prevents premature deactivation in fresh tab loads
            if (timeSinceActivation < minActiveTime) {
              console.log("[App] ⚠️ Deactivation prevented - sphere activated too recently (", timeSinceActivation, "ms ago, need at least", minActiveTime, "ms)");
              deactivationTimeoutRef.current = null;
              return;
            }
            setCurrentBubble(null); // Clear any visible bubble when deactivating
            
            console.log("[App] ✓ Deactivating sphere NOW (verified both conditions still true, active for", timeSinceActivation, "ms)");
            setIsActive(false);
          } else {
            console.log("[App] ⚠️ Deactivation canceled - conditions changed:", {
              isTyping: isTypingRef.current,
              workflowCompleted: workflowCompletedRef.current
            });
          }
          deactivationTimeoutRef.current = null;
        }, 2500); // 2.5 seconds for extra safety
      } else if (!state.isTyping && !currentWorkflowCompleted) {
        console.log("[App] ⏸️ Typing finished but workflow NOT completed yet - sphere stays ACTIVE, waiting for more events");
      }
    });

    return () => {
      unsubscribe();
      // Clean up any pending timeout on unmount
      if (deactivationTimeoutRef.current) {
        clearTimeout(deactivationTimeoutRef.current);
        deactivationTimeoutRef.current = null;
      }
    };
  }, []); // Empty dependency array - use refs to avoid re-subscription

  // Subscribe to events (for bubbles and content)
  useEffect(() => {
    const unsubscribe = eventQueue.subscribeToEvents((event) => {
      console.log("[App] Event received:", event.heading);
      
      // Update activation time to prevent premature deactivation
      activationTimeRef.current = Date.now();
      
      // Cancel any pending deactivation when new event arrives
      if (deactivationTimeoutRef.current) {
        console.log("[App] New event received - canceling pending deactivation");
        clearTimeout(deactivationTimeoutRef.current);
        deactivationTimeoutRef.current = null;
      }
      
      // Add to all events list (for content display)
      setAllEvents((prev) => [...prev, event]);
      
      // Bubble display is controlled by onTypingStart/onTypingEnd callbacks
    });

    return unsubscribe;
  }, []);
  
  // Handle typing start - show bubble
  const handleTypingStart = (eventIndex: number) => {
    if (eventIndex < allEvents.length) {
      const event = allEvents[eventIndex];
      console.log(`[App] Typing started for event ${eventIndex}:`, event.heading);
      
      // Clear any existing timeout
      if (bubbleTimeoutRef.current) {
        clearTimeout(bubbleTimeoutRef.current);
        bubbleTimeoutRef.current = null;
      }
      
      // Show bubble with random angle
      setCurrentBubble(event);
      setCurrentBubbleAngle(generateRandomAngle());
    }
  };
  
  // Handle typing end - hide bubble
  const handleTypingEnd = (eventIndex: number) => {
    if (eventIndex < allEvents.length) {
      const event = allEvents[eventIndex];
      console.log(`[App] Typing ended for event ${eventIndex}:`, event.heading);
      
      // Hide bubble with a slight delay for smooth transition
      const timeout = setTimeout(() => {
        setCurrentBubble((current) => {
          // Only clear if it's still the same bubble
          if (current?.no === event.no) {
            return null;
          }
          return current;
        });
      }, 600); // Match fade out duration
      
      bubbleTimeoutRef.current = timeout;
      
      // Note: Sphere deactivation is now handled by typing state subscription
      // The sphere will stay active until all typing is complete
    }
  };
  
  // Subscribe to queue empty (for cleanup)
  useEffect(() => {
    const unsubscribe = eventQueue.subscribeToQueueEmpty(() => {
      console.log("[App] Queue empty - all events processed");
    });

    return unsubscribe;
  }, []);

  // Manual trigger for testing mode - starts mock stream
  const handleManualTrigger = () => {
    if (isActive) {
      console.log("Manual trigger ignored - sphere already active");
      return;
    }
    
    console.log("Manual trigger button clicked (TESTING MODE)");
    
    // Initialize audio on user interaction (button click)
    streamingTTS.initializeAudio().then((initialized) => {
      if (initialized) {
        console.log("Audio initialized via button click");
      }
    });
    
    // Reset bubble state but keep previous events (append mode)
    setCurrentBubble(null);
    // Don't clear events - keep accumulating across workflow runs
    // setAllEvents([]);
    usedAnglesRef.current = []; // Clear used angles
    
    // Use context ID from URL if available, otherwise use test ID
    const testContextId = contextId || 'test-context-123';
    console.log("[Test Mode] Starting with context ID:", testContextId, "- appending to existing events");
    
    // Start orchestrator - will use mock events if USE_MOCK_EVENTS is true
    eventOrchestrator.start(testContextId, false);
  };

  // Handle reset
  const handleReset = () => {
    console.log("Reset button clicked");
    
    // Stop orchestrator
    eventOrchestrator.stop();
    
    // Stop any ongoing TTS
    streamingTTS.stop();
    
    // Reset UI state
    setIsActive(false);
    setHasBeenActive(false); // Reset visibility flag
    setCurrentBubble(null);
    setAllEvents([]);
    setWorkflowCompleted(false);
    setIsTyping(false);
    
    // Clear used angles for fresh start
    usedAnglesRef.current = [];
  };

  // Set browser tab title and favicon
  useEffect(() => {
    document.title = "Savant Control Center";
    
    // Update or create favicon
    let favicon = document.querySelector("link[rel='icon']") as HTMLLinkElement;
    if (!favicon) {
      favicon = document.createElement('link');
      favicon.rel = 'icon';
      document.head.appendChild(favicon);
    }
    favicon.type = 'image/png';
    favicon.href = savantLogo;
  }, []);

  // Get context ID from URL and auto-start if present
  useEffect(() => {
    // Log configuration to console
    logConfiguration();
    
    // Configure mock audio mode
    streamingTTS.setMockMode(USE_MOCK_AUDIO);
    
    // Get context ID from URL parameter
    const urlParams = new URLSearchParams(window.location.search);
    const urlContextId = urlParams.get('context_id') || urlParams.get('contextId') || '';
    
    console.log('🔍 URL Parsing Debug:', {
      fullUrl: window.location.href,
      searchParams: window.location.search,
      parsedContextId: urlContextId,
      testingMode: TESTING_MODE,
      useMockEvents: USE_MOCK_EVENTS
    });
    
    if (urlContextId) {
      console.log('✅ Context ID found in URL:', urlContextId);
      setContextId(urlContextId);
      
      // Auto-start if not in testing mode (production mode)
      if (!TESTING_MODE) {
        console.log('🚀 Production mode detected - Auto-starting event stream with context ID:', urlContextId);
        handleStartListening(urlContextId);
      } else {
        console.log('⏸️ Testing mode - Context ID loaded but NOT auto-starting (use manual button)');
      }
    } else {
      console.log('⚠️ No context ID in URL. Waiting for manual activation.');
      console.log('💡 To auto-start, add ?contextId=YOUR_ID to the URL');
    }
  }, []);

  // Handle start listening with context ID
  const handleStartListening = async (ctxId: string) => {
    console.log("📡 Starting event stream with context ID:", ctxId);
    console.log("🔧 Configuration:", {
      testingMode: TESTING_MODE,
      useMockEvents: USE_MOCK_EVENTS,
      useMockAudio: USE_MOCK_AUDIO
    });
    
    // Try to initialize audio, but don't block if it fails (autoplay policy)
    // Audio will be initialized lazily when user interacts or when first audio plays
    streamingTTS.initializeAudio().then((success) => {
      if (success) {
        console.log("✅ Audio initialized successfully");
      } else {
        console.log("⚠️ Audio initialization deferred (requires user interaction)");
      }
    }).catch((error) => {
      console.log("⚠️ Audio initialization failed (will retry on user interaction):", error);
    });
    
    // Reset bubble state but keep events (append mode for continuous workflows)
    setCurrentBubble(null);
    // Don't clear events on auto-start - allow accumulation across multiple workflow runs
    // Only clear events when user explicitly presses Reset button
    // setAllEvents([]);
    usedAnglesRef.current = [];
    setWorkflowCompleted(false);
    setIsTyping(false);
    
    console.log("🎬 Calling eventOrchestrator.start() with context ID:", ctxId, "- appending to existing events");
    
    // Start orchestrator with context ID - DON'T wait for audio
    // In production mode, this will connect to real API
    // In testing mode with USE_MOCK_EVENTS=true, it will use mock data
    eventOrchestrator.start(ctxId, false);
  };

  return (
    <div className="h-screen w-screen bg-white flex overflow-hidden fixed inset-0">
      {/* Zone 1: Mind Sphere Visualization - Full width initially, then shrinks when active */}
      <motion.div 
        className="relative flex flex-col bg-white flex-shrink-0 overflow-visible"
        initial={false}
        animate={{
          width: hasBeenActive ? '70%' : '100%'
        }}
        transition={{
          duration: 0.8,
          ease: "easeInOut"
        }}
      >

        {/* Header - positioned at top - matches Intelligence Stream height */}
        <div className="relative z-10 px-8 py-4 flex-shrink-0 flex items-center">
          {/* J&J Logo and Savant branding - left aligned with pipe delimiter */}
          <div className="flex items-center gap-3">
            <img 
              src={jjLogo} 
              alt="Johnson & Johnson Logo" 
              className="h-6 object-contain"
            />
            
            {/* Pipe delimiter */}
            <div className="h-6 w-px bg-gray-300"></div>
            
            {/* Savant Logo and Title */}
            <div className="flex items-center gap-1.5">
              <img 
                src={savantLogo} 
                alt="Savant Logo" 
                className="h-5 w-5 object-contain"
              />
              <h1 className="text-[#D71500] text-xs uppercase tracking-widest opacity-80 font-semibold">
                Savant Control Center
              </h1>
            </div>
          </div>
        </div>

        {/* Main content - centered with fixed positioning */}
        <div className="relative z-10 flex-1 flex items-center justify-center overflow-visible px-2 lg:px-4">
          {/* Playbook Memory - absolute positioned from top to original bottom position */}
          <div className="absolute left-8 top-0 bottom-[35%] w-[220px]">
            <AnimatePresence mode="wait">
              {hasBeenActive && <PlaybookMemory isActive={isActive} />}
            </AnimatePresence>
          </div>

          {/* Sphere and thoughts visualization - absolute positioned to center properly */}
          <div className="absolute inset-0 flex items-center justify-center overflow-visible">
            <div className="relative w-full h-[400px] lg:h-[450px] xl:h-[500px] max-w-7xl flex items-center justify-center overflow-visible">
              {/* Playbook placeholder to maintain spacing - only when visible */}
              {hasBeenActive && (
                <div className="absolute left-0 top-0 bottom-0 w-[220px]"></div>
              )}
              
              {/* Sphere - smoothly animated position based on state */}
              <motion.div 
                className="absolute top-0 bottom-0 flex items-center justify-center"
                initial={false}
                animate={{
                  left: hasBeenActive ? 220 : 0,
                  right: 0,
                  scale: hasBeenActive ? 1.0 : 1.5
                }}
                transition={{
                  duration: 0.8,
                  ease: "easeInOut"
                }}
              >
                <MindSphere 
                  isActive={isActive} 
                  hasBubble={currentBubble !== null} 
                  bubbleAngle={currentBubbleAngle}
                  hasBeenActive={hasBeenActive}
                />
              </motion.div>
              
              {/* Render current thought bubble */}
              <AnimatePresence mode="wait">
                {currentBubble && (
                  <ThoughtBubble
                    key={currentBubble.no}
                    type={currentBubble.type}
                    heading={currentBubble.heading}
                    index={currentBubble.no}
                    angle={currentBubbleAngle}
                    onReachStatic={() => {}}
                    onComplete={() => {}}
                  />
                )}
              </AnimatePresence>
            </div>
          </div>

          {/* Control buttons - Only in testing mode - fixed position below sphere */}
          {TESTING_MODE && (
            <div className="absolute bottom-8 left-0 right-0 flex flex-col items-center gap-2 lg:gap-3 z-20">
              <div className="flex gap-2 lg:gap-3">
                <Button
                  onClick={handleManualTrigger}
                  disabled={isActive}
                  className="bg-[#D71500] hover:bg-[#B01200] disabled:opacity-50 text-white shadow-lg"
                >
                  {USE_MOCK_EVENTS ? "Activate Agent (Mock)" : "Activate Agent"}
                </Button>
                
                <Button
                  onClick={handleReset}
                  variant="outline"
                  className="border-[#D71500]/30 text-gray-700 hover:bg-red-50"
                >
                  <RotateCcw className="w-4 h-4 mr-2" />
                  Reset
                </Button>
              </div>
              
              {/* Stream status indicator */}
              <div className="h-5 flex items-center justify-center">
                {isActive ? (
                  <div className="text-xs text-gray-500 flex items-center gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-[#D71500] animate-pulse" />
                    <span>
                      {isTyping ? `Typing... (${allEvents.length} events)` : `Processing... (${allEvents.length} events)`}
                    </span>
                    {(USE_MOCK_AUDIO || USE_MOCK_EVENTS) && (
                      <span className="text-[#D71500]/70">
                        • {[USE_MOCK_AUDIO && "Audio", USE_MOCK_EVENTS && "Events"].filter(Boolean).join(" & ")} Mock
                      </span>
                    )}
                  </div>
                ) : (
                  <div className="text-xs text-gray-400 flex items-center gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-gray-300 animate-pulse" />
                    <span>Ready to activate...</span>
                    {(USE_MOCK_AUDIO || USE_MOCK_EVENTS) && (
                      <span className="text-[#D71500]/70">
                        • {[USE_MOCK_AUDIO && "Audio", USE_MOCK_EVENTS && "Events"].filter(Boolean).join(" & ")} Mock
                      </span>
                    )}
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </motion.div>

      {/* Zone 2: Content Display with slide-in animation */}
      <ContentDisplay 
        events={allEvents} 
        workflowCompleted={workflowCompleted}
        onTypingStart={handleTypingStart} 
        onTypingEnd={handleTypingEnd}
        isActive={isActive}
        hasBeenActive={hasBeenActive}
      />
    </div>
  );
}