
  # LiveThoughtStreamTTSScanner

  This is a code bundle for LiveThoughtStreamTTSScanner. The original project is available at https://www.figma.com/design/0vQBGOBtz9ala3zjaF7oB7/LiveThoughtStreamTTSScanner.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  