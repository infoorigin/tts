import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Link2, X, Radio } from "lucide-react";
import { Input } from "./ui/input";

interface ContextIdInputProps {
  onStartListening: (contextId: string) => void;
  onDisconnect: () => void;
  isListening: boolean;
  isExpanded: boolean;
  onToggleExpand: () => void;
  currentContextId?: string;
}

export function ContextIdInput({ 
  onStartListening,
  onDisconnect,
  isListening, 
  isExpanded, 
  onToggleExpand,
  currentContextId
}: ContextIdInputProps) {
  const [contextId, setContextId] = useState("");

  const handleSubmit = () => {
    if (!contextId.trim()) return;
    onStartListening(contextId.trim());
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      handleSubmit();
    }
  };

  return (
    <div className="px-8 py-3 border-b border-gray-100">
      <AnimatePresence mode="wait">
        {isListening && currentContextId ? (
          /* Connected State - Show Context ID with Disconnect */
          <motion.div
            key="connected"
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="flex items-center justify-between gap-3"
          >
            <div className="flex items-center gap-2 min-w-0">
              <Radio className="w-3.5 h-3.5 text-[#CC0000] flex-shrink-0 animate-pulse" />
              <div className="flex items-baseline gap-1.5 min-w-0">
                <span className="text-xs text-gray-500 flex-shrink-0">
                  Connected to
                </span>
                <span className="text-xs text-gray-700 font-medium truncate">
                  {currentContextId}
                </span>
              </div>
            </div>
            <button
              onClick={onDisconnect}
              className="flex-shrink-0 w-5 h-5 rounded-full hover:bg-gray-100 flex items-center justify-center group transition-colors"
              title="Disconnect and change context"
            >
              <X className="w-3 h-3 text-gray-400 group-hover:text-[#CC0000] transition-colors" />
            </button>
          </motion.div>
        ) : !isExpanded ? (
          /* Collapsed State - Clean Button */
          <motion.button
            key="collapsed"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onToggleExpand}
            className="w-full flex items-center gap-2.5 px-3 py-2 rounded-md hover:bg-gray-50/80 transition-all group"
          >
            <Link2 className="w-3.5 h-3.5 text-gray-400 group-hover:text-[#CC0000] transition-colors" />
            <span className="text-xs text-gray-500 group-hover:text-gray-700 transition-colors">
              Connect to Context
            </span>
          </motion.button>
        ) : (
          /* Expanded State - Inline Input */
          <motion.div
            key="expanded"
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="flex items-center gap-2"
          >
            <Input
              type="text"
              placeholder="Enter context ID..."
              value={contextId}
              onChange={(e) => setContextId(e.target.value)}
              onKeyPress={handleKeyPress}
              onBlur={() => {
                // Close if empty and user clicks away
                if (!contextId.trim()) {
                  onToggleExpand();
                }
              }}
              className="h-8 text-xs border-gray-200 focus:border-[#CC0000] focus:ring-[#CC0000] flex-1"
              autoFocus
            />
            <button
              onClick={handleSubmit}
              disabled={!contextId.trim()}
              className="h-8 px-3 rounded-md bg-[#CC0000] hover:bg-[#CC0000]/90 disabled:bg-gray-200 disabled:cursor-not-allowed text-white text-xs font-medium transition-colors"
            >
              Connect
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
