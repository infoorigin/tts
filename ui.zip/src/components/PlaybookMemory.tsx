import { motion, AnimatePresence } from "motion/react";
import { BookOpen } from "lucide-react";
import { useState, useEffect, useRef } from "react";

interface PlaybookMemoryProps {
  isActive: boolean;
}

interface Playbook {
  id: number;
  name: string;
  type: "trigger" | "barrier";
}

const PLAYBOOKS: Playbook[] = [
  { id: 1, name: "Inlexzo First Purchase", type: "trigger" },
  { id: 2, name: "Territory Alignment", type: "barrier" },
  { id: 3, name: "Field Force Notification", type: "trigger" },
  { id: 4, name: "Engagement Monitor", type: "trigger" },
  { id: 5, name: "Compliance Check", type: "barrier" },
];

const ITEM_HEIGHT = 37; // Height of each item including margin

export function PlaybookMemory({ isActive }: PlaybookMemoryProps) {
  const [offset, setOffset] = useState(0);
  const [selectedPlaybookId, setSelectedPlaybookId] = useState<number | null>(null);
  const animationRef = useRef<number | null>(null);
  const startTimeRef = useRef<number>(Date.now());

  // Continuous smooth upward scrolling - never stops
  useEffect(() => {
    const animate = () => {
      const elapsed = Date.now() - startTimeRef.current;
      // Move 1 item every 800ms = 1/800 items per ms
      const newOffset = elapsed / 800;
      setOffset(newOffset);
      animationRef.current = requestAnimationFrame(animate);
    };

    animationRef.current = requestAnimationFrame(animate);

    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, []);

  // Select playbook #1 immediately when sphere is active, unselect when inactive
  useEffect(() => {
    if (isActive) {
      setSelectedPlaybookId(1); // Select Inlexzo First Purchase immediately
    } else {
      setSelectedPlaybookId(null); // Unselect when sphere is inactive
    }
  }, [isActive]);

  // Generate enough items to fill the viewport with seamless looping
  const renderItems = () => {
    const items = [];
    const viewportStart = -100; // Start rendering a bit before viewport
    const viewportEnd = 340; // End rendering a bit after viewport
    
    // Calculate which items should be visible
    const scrollY = offset * ITEM_HEIGHT;
    const startIndex = Math.floor((scrollY + viewportStart) / ITEM_HEIGHT);
    const endIndex = Math.ceil((scrollY + viewportEnd) / ITEM_HEIGHT);
    
    for (let i = startIndex; i <= endIndex; i++) {
      const playbookIndex = ((i % PLAYBOOKS.length) + PLAYBOOKS.length) % PLAYBOOKS.length;
      const playbook = PLAYBOOKS[playbookIndex];
      const yPosition = i * ITEM_HEIGHT - scrollY;
      
      // Calculate opacity based on distance from center
      const centerY = 120;
      const distance = Math.abs(yPosition - centerY);
      const maxDistance = 120;
      const opacity = distance < maxDistance 
        ? Math.max(0.3, 1 - (distance / maxDistance) * 0.7)
        : 0.3;
      
      // Check if this should be highlighted
      // When active and playbook is selected, keep it highlighted always
      const isHighlighted = selectedPlaybookId !== null && 
                           playbook.id === selectedPlaybookId;
      
      items.push({
        key: `playbook-${i}`,
        playbook,
        yPosition,
        opacity,
        isHighlighted,
      });
    }
    
    return items;
  };

  const visibleItems = renderItems();

  return (
    <motion.div
      className="absolute left-0 top-1/2 -translate-y-1/2 w-[200px] bg-white/90 backdrop-blur-sm rounded-lg border border-red-100 shadow-sm overflow-hidden z-10"
      initial={{ opacity: 0, x: -20, scale: 0.95 }}
      animate={{ 
        opacity: 1,
        x: 0,
        scale: 1
      }}
      transition={{ 
        duration: 0.8,
        ease: [0.4, 0, 0.2, 1]
      }}
    >
      {/* Header */}
      <div className="p-3 pb-2 border-b border-red-100">
        <div className="flex items-center gap-1.5">
          <BookOpen className="w-3.5 h-3.5 text-[#CC0000]" />
          <h4 className="text-[#CC0000] text-xs">Playbooks</h4>
          {isActive && (
            <motion.div
              className="ml-auto w-1 h-1 rounded-full bg-[#CC0000]"
              animate={{ opacity: [0.5, 1, 0.5] }}
              transition={{ duration: 0.5, repeat: Infinity }}
            />
          )}
        </div>
      </div>

      {/* Playbooks Rotating List */}
      <div className="relative h-[240px] overflow-hidden">
        {/* Gradient masks for top and bottom fade */}
        <div className="absolute top-0 left-0 right-0 h-8 bg-gradient-to-b from-white/90 to-transparent z-10 pointer-events-none" />
        <div className="absolute bottom-0 left-0 right-0 h-8 bg-gradient-to-t from-white/90 to-transparent z-10 pointer-events-none" />
        
        {/* Selection highlight box at center - only show when scanning (no playbook selected yet) */}
        <AnimatePresence>
          {selectedPlaybookId === null && isActive && (
            <motion.div 
              className="absolute left-3 right-3 top-1/2 -translate-y-1/2 h-[33px] border-2 border-[#CC0000]/50 bg-[#CC0000]/5 rounded pointer-events-none z-20 shadow-sm"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              transition={{ duration: 0.4 }}
            />
          )}
        </AnimatePresence>

        {/* Scrolling container */}
        <div className="absolute left-0 right-0 px-3 top-0">
          {visibleItems.map(({ key, playbook, yPosition, opacity, isHighlighted }) => (
            <div
              key={key}
              className={`px-2 py-1.5 rounded text-xs transition-all ${
                isHighlighted
                  ? "bg-red-50 border border-[#CC0000]"
                  : "bg-gray-50 border border-transparent"
              }`}
              style={{
                position: 'absolute',
                top: `${yPosition}px`,
                left: '12px',
                right: '12px',
                opacity,
                height: "33px",
                transform: isHighlighted ? 'scale(1.02)' : 'scale(1)',
                transition: 'opacity 0.3s ease-out, transform 0.5s ease-out, background-color 0.5s ease-out, border-color 0.5s ease-out',
              }}
            >
              <div className="flex items-center justify-between gap-2 mb-0.5">
                <span 
                  className={`truncate text-[11px] leading-tight ${
                    isHighlighted ? "text-[#CC0000]" : "text-gray-700"
                  }`}
                >
                  {playbook.name}
                </span>
                {isHighlighted && (
                  <motion.div
                    className="w-1.5 h-1.5 rounded-full bg-[#CC0000] flex-shrink-0"
                    initial={{ scale: 0, opacity: 0 }}
                    animate={{ 
                      scale: 1,
                      opacity: [0.5, 1, 0.5] 
                    }}
                    exit={{ scale: 0, opacity: 0 }}
                    transition={{ 
                      scale: { duration: 0.5, ease: "easeOut" },
                      opacity: { duration: 1.5, repeat: Infinity }
                    }}
                  />
                )}
              </div>
              <div>
                <span
                  className={`text-[9px] px-1.5 py-0.5 rounded-full ${
                    playbook.type === "trigger"
                      ? "bg-blue-100 text-blue-600"
                      : "bg-purple-100 text-purple-600"
                  }`}
                >
                  {playbook.type}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Status indicator */}
      <AnimatePresence>
        {isActive && (
          <motion.div
            className="px-3 py-2 border-t border-red-100"
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
          >
            <div className="text-[10px] text-gray-600 flex items-center gap-1">
              {!selectedPlaybookId ? (
                <>
                  <motion.div
                    className="w-1 h-1 rounded-full bg-[#CC0000]"
                    animate={{ scale: [1, 1.3, 1] }}
                    transition={{ duration: 0.8, repeat: Infinity }}
                  />
                  Scanning...
                </>
              ) : (
                <>
                  <motion.div
                    className="w-1 h-1 rounded-full bg-[#00A758]"
                    animate={{ opacity: [0.5, 1, 0.5] }}
                    transition={{ duration: 1.5, repeat: Infinity }}
                  />
                  Playbook Active
                </>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}
