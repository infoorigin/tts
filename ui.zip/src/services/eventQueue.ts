/**
 * Centralized Event Queue Service
 * Single source of truth for all events - both bubbles and content display subscribe to this
 */

export interface QueuedEvent {
  no: number;
  id: string | null;
  type: "thought" | "tool" | "response";
  heading: string;
  content: string[];
}

export interface WorkflowState {
  status: "idle" | "active" | "completed";
}

export interface TypingState {
  isTyping: boolean;
  eventNo: number | null;
}

type EventSubscriber = (event: QueuedEvent) => void;
type WorkflowSubscriber = (state: WorkflowState) => void;
type QueueEmptySubscriber = () => void;
type TypingSubscriber = (state: TypingState) => void;

/**
 * Simple event queue with pub/sub pattern
 * No complex state management - just emit events to subscribers
 */
export class EventQueue {
  private eventSubscribers: Set<EventSubscriber> = new Set();
  private workflowSubscribers: Set<WorkflowSubscriber> = new Set();
  private queueEmptySubscribers: Set<QueueEmptySubscriber> = new Set();
  private typingSubscribers: Set<TypingSubscriber> = new Set();
  
  private workflowState: WorkflowState = { status: "idle" };
  private typingState: TypingState = { isTyping: false, eventNo: null };
  
  /**
   * Subscribe to individual events (for bubbles and content display)
   */
  subscribeToEvents(callback: EventSubscriber): () => void {
    this.eventSubscribers.add(callback);
    return () => this.eventSubscribers.delete(callback);
  }
  
  /**
   * Subscribe to workflow state changes (for sphere activation)
   */
  subscribeToWorkflow(callback: WorkflowSubscriber): () => void {
    this.workflowSubscribers.add(callback);
    // Immediately call with current state
    callback(this.workflowState);
    return () => this.workflowSubscribers.delete(callback);
  }
  
  /**
   * Subscribe to queue empty events (for completion handling)
   */
  subscribeToQueueEmpty(callback: QueueEmptySubscriber): () => void {
    this.queueEmptySubscribers.add(callback);
    return () => this.queueEmptySubscribers.delete(callback);
  }
  
  /**
   * Subscribe to typing state changes (for sphere activation)
   */
  subscribeToTyping(callback: TypingSubscriber): () => void {
    this.typingSubscribers.add(callback);
    // Immediately call with current state
    callback(this.typingState);
    return () => this.typingSubscribers.delete(callback);
  }
  
  /**
   * Publish a workflow state change
   */
  publishWorkflowState(status: "idle" | "active" | "completed") {
    this.workflowState = { status };
    console.log(`[EventQueue] Workflow state: ${status}`);
    this.workflowSubscribers.forEach(callback => callback(this.workflowState));
  }
  
  /**
   * Publish an event to all subscribers
   */
  publishEvent(event: QueuedEvent) {
    console.log(`[EventQueue] Publishing event: ${event.heading} (ID: ${event.no})`);
    this.eventSubscribers.forEach(callback => callback(event));
  }
  
  /**
   * Notify that queue is empty
   */
  publishQueueEmpty() {
    console.log(`[EventQueue] Queue empty`);
    this.queueEmptySubscribers.forEach(callback => callback());
  }
  
  /**
   * Publish typing state change
   */
  publishTypingState(isTyping: boolean, eventNo: number | null) {
    const timestamp = new Date().toISOString().substr(11, 12); // HH:MM:SS.mmm
    this.typingState = { isTyping, eventNo };
    console.log(`[EventQueue @ ${timestamp}] Typing state: ${isTyping ? 'TYPING' : 'IDLE'} (event: ${eventNo})`);
    this.typingSubscribers.forEach(callback => callback(this.typingState));
  }
  
  /**
   * Reset the queue (for manual reset button)
   */
  reset() {
    console.log(`[EventQueue] Reset`);
    this.workflowState = { status: "idle" };
    this.typingState = { isTyping: false, eventNo: null };
    // Don't clear subscribers - they should persist across resets
    // this.eventSubscribers.clear();
    // this.workflowSubscribers.clear();
    // this.queueEmptySubscribers.clear();
    // this.typingSubscribers.clear();
  }
}

// Singleton instance
export const eventQueue = new EventQueue();