/**
 * ============================================================================
 * ENVIRONMENT CONFIGURATION
 * ============================================================================
 * 
 * Centralized configuration for all environment-specific settings.
 * Update these values to switch between development, staging, and production
 * environments without touching the core application code.
 * 
 * QUICK START:
 * ------------
 * 1. TESTING MODE (Local Development):
 *    - Set TESTING_MODE = true
 *    - Set USE_MOCK_AUDIO = true
 *    - Set USE_MOCK_EVENTS = true
 *    - Click "Activate Agent" button to test with mock data
 * 
 * 2. PRODUCTION MODE (Real API):
 *    - Set TESTING_MODE = false
 *    - Set USE_MOCK_AUDIO = false
 *    - Set USE_MOCK_EVENTS = false
 *    - Configure EVENT_STREAM_API with your production URLs
 *    - Enter Context ID in Intelligence Stream input to start listening
 * 
 * ============================================================================
 */

// ============================================================================
// MODE CONFIGURATION
// ============================================================================

/**
 * TESTING_MODE
 * When true: Shows manual "Activate Agent" button for testing with mock data
 * When false: Shows Context ID input for production use
 */
export const TESTING_MODE = false;

/**
 * USE_MOCK_AUDIO
 * When true: Uses mock audio file for TTS simulation
 * When false: Uses real TTS API endpoint
 */
export const USE_MOCK_AUDIO = false;

/**
 * USE_MOCK_EVENTS
 * When true: Uses hardcoded mock events for testing
 * When false: Connects to real event stream API
 */
export const USE_MOCK_EVENTS = false;

// ============================================================================
// API ENDPOINTS
// ============================================================================

/**
 * Event Stream API Configuration
 * Used when USE_MOCK_EVENTS = false
 */
export const EVENT_STREAM_API = {
  /**
   * Base URL for event stream API
   * Example: "https://api.yourdomain.com" or "http://localhost:8000"
   */
  baseUrl: "http://localhost:8000",
  
  /**
   * API path template for streaming events
   * {contextId} will be replaced with actual context ID
   */
  streamPath: "/api/v1/contexts/{contextId}/log/stream",
  
  /**
   * Request headers for event stream
   */
  headers: {
    Accept: "text/event-stream",
    "Cache-Control": "no-cache",
  },
};

/**
 * Text-to-Speech API Configuration
 * Used when USE_MOCK_AUDIO = false
 */
export const TTS_API = {
  /**
   * Base URL for TTS streaming API
   * Example: "https://tts.yourdomain.com" or "http://127.0.0.1:8000"
   */
  baseUrl: "http://127.0.0.1:8080",
  
  /**
   * API path for TTS streaming
   * Text will be appended as query parameter automatically
   */
  streamPath: "/api/v1/tts/stream",
  
  /**
   * TTS Voice Parameters
   * Customize voice settings for your TTS engine
   * Example API call: /api/v1/tts/stream?voice=Danielle&engine=long-form&format=mp3&text=hello
   */
  params: {
    /**
     * Voice to use for speech synthesis
     * Common options: "Danielle", "Matthew", "Joanna", etc.
     */
    voice: "Danielle",
    
    /**
     * TTS engine mode
     * Options: "long-form", "standard", "neural", etc.
     */
    engine: "generative",
    
    /**
     * Audio format
     * Options: "mp3", "wav", "ogg", etc.
     */
    format: "mp3",
  },
  
  /**
   * Get full TTS URL with parameters (don't modify this unless you change API format)
   */
  get url() {
    return `${this.baseUrl}${this.streamPath}`;
  },
  
  /**
   * Build query string from params
   */
  getQueryString(text: string): string {
    const params = new URLSearchParams({
      voice: this.params.voice,
      engine: this.params.engine,
      format: this.params.format,
      text: text,
    });
    return params.toString();
  },
  
  /**
   * Get full URL with all parameters
   */
  getFullUrl(text: string): string {
    return `${this.url}?${this.getQueryString(text)}`;
  },
};

// ============================================================================
// MOCK AUDIO CONFIGURATION
// ============================================================================

/**
 * Mock Audio File Configuration
 * Used when USE_MOCK_AUDIO = true
 * 
 * SETUP INSTRUCTIONS:
 * 1. Place your audio file in the /public folder
 *    Example: /public/test-voice.mp3
 * 
 * 2. Update the path below to match your file
 *    Example: "/test-voice.mp3"
 * 
 * 3. Or use a remote URL for testing
 *    Example: "https://example.com/audio.mp3"
 */
export const MOCK_AUDIO = {
  /**
   * Path to mock audio file
   * Use local path (starts with /) for files in /public folder
   * Or use full URL for remote files
   */
  filePath: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3",
  
  /**
   * Volume level for mock audio (0.0 to 1.0)
   */
  volume: 0.3,
};

// ============================================================================
// AUDIO TIMING CONFIGURATION
// ============================================================================

/**
 * Audio Duration Calculation Settings
 * Controls how long mock audio plays based on text length
 */
export const AUDIO_TIMING = {
  /**
   * Average speaking rate in words per minute
   * Standard conversational speech: 140-160 WPM
   * Professional narration: 150-160 WPM
   */
  wordsPerMinute: 150,
  
  /**
   * Minimum duration for any audio in milliseconds
   */
  minDuration: 1000, // 1 second
  
  /**
   * Maximum duration for any audio in milliseconds
   */
  maxDuration: 10000, // 10 seconds
};

// ============================================================================
// ENVIRONMENT PRESETS
// ============================================================================

/**
 * Quick environment switching
 * Uncomment one of these to switch environments instantly
 */

// LOCAL DEVELOPMENT
export const ENV_PRESETS = {
  development: {
    TESTING_MODE: true,
    USE_MOCK_AUDIO: true,
    USE_MOCK_EVENTS: true,
    EVENT_STREAM_API: {
      baseUrl: "http://localhost:8000",
    },
    TTS_API: {
      baseUrl: "http://127.0.0.1:8000",
    },
  },
  
  // STAGING
  staging: {
    TESTING_MODE: true,
    USE_MOCK_AUDIO: false,
    USE_MOCK_EVENTS: false,
    EVENT_STREAM_API: {
      baseUrl: "https://staging-api.yourdomain.com",
    },
    TTS_API: {
      baseUrl: "https://staging-tts.yourdomain.com",
    },
  },
  
  // PRODUCTION
  production: {
    TESTING_MODE: false,
    USE_MOCK_AUDIO: false,
    USE_MOCK_EVENTS: false,
    EVENT_STREAM_API: {
      baseUrl: "https://api.yourdomain.com",
    },
    TTS_API: {
      baseUrl: "https://tts.yourdomain.com",
    },
  },
};

// ============================================================================
// HELPER FUNCTIONS
// ============================================================================

/**
 * Get the current environment name based on configuration
 */
export function getCurrentEnvironment(): "development" | "staging" | "production" | "custom" {
  if (TESTING_MODE && USE_MOCK_AUDIO && USE_MOCK_EVENTS) {
    return "development";
  }
  if (!TESTING_MODE && !USE_MOCK_AUDIO && !USE_MOCK_EVENTS) {
    return "production";
  }
  return "custom";
}

/**
 * Get full event stream URL for a given context ID
 */
export function getEventStreamUrl(contextId: string): string {
  const path = EVENT_STREAM_API.streamPath.replace("{contextId}", contextId);
  return `${EVENT_STREAM_API.baseUrl}${path}`;
}

/**
 * Log current configuration to console
 */
export function logConfiguration(): void {
  console.group("🔧 Savant Control Center - Configuration");
  console.log("Environment:", getCurrentEnvironment().toUpperCase());
  console.log("Testing Mode:", TESTING_MODE ? "✅ ENABLED" : "❌ DISABLED");
  console.log("Mock Audio:", USE_MOCK_AUDIO ? "✅ ENABLED" : "❌ DISABLED");
  console.log("Mock Events:", USE_MOCK_EVENTS ? "✅ ENABLED" : "❌ DISABLED");
  
  if (USE_MOCK_EVENTS) {
    console.log("Event Source: Mock Data (Hardcoded)");
  } else {
    console.log("Event Stream API:", EVENT_STREAM_API.baseUrl);
    console.log("💡 Enter Context ID in the Intelligence Stream to start listening");
  }
  
  if (USE_MOCK_AUDIO) {
    console.log("Audio Source:", MOCK_AUDIO.filePath);
    console.log("Audio Volume:", MOCK_AUDIO.volume);
  } else {
    console.log("TTS API:", TTS_API.url);
    console.log("TTS Voice:", TTS_API.params.voice);
    console.log("TTS Engine:", TTS_API.params.engine);
    console.log("TTS Format:", TTS_API.params.format);
    console.log("Example URL:", TTS_API.getFullUrl("hello world"));
  }
  
  console.groupEnd();
}
