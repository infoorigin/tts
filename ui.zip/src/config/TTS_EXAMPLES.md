# TTS Configuration Examples

This guide shows common TTS API configurations for popular providers.

## Your Current TTS API

Based on your endpoint format:
```
http://127.0.0.1:8080/api/v1/tts/stream?voice=Danielle&engine=long-form&format=mp3&text=hello%20world
```

**Configuration:**
```typescript
export const TTS_API = {
  baseUrl: "http://127.0.0.1:8080",
  streamPath: "/api/v1/tts/stream",
  params: {
    voice: "Danielle",
    engine: "long-form",
    format: "mp3",
  },
};
```

## Common TTS Providers

### OpenAI TTS
```typescript
export const TTS_API = {
  baseUrl: "https://api.openai.com/v1",
  streamPath: "/audio/speech",
  params: {
    voice: "alloy",      // alloy, echo, fable, onyx, nova, shimmer
    engine: "tts-1",     // tts-1 or tts-1-hd
    format: "mp3",       // mp3, opus, aac, flac
  },
};
```

**Available voices:** alloy, echo, fable, onyx, nova, shimmer

### AWS Amazon Polly
```typescript
export const TTS_API = {
  baseUrl: "https://polly.us-east-1.amazonaws.com",
  streamPath: "/v1/speech",
  params: {
    voice: "Joanna",           // See AWS docs for full list
    engine: "neural",          // neural or standard
    format: "mp3",             // mp3, ogg_vorbis, pcm
  },
};
```

**Popular voices:**
- English (US): Joanna, Matthew, Ivy, Kendra, Kimberly
- English (UK): Amy, Brian, Emma
- Neural voices: Olivia, Gregory, Ruth, Stephen

### Google Cloud TTS
```typescript
export const TTS_API = {
  baseUrl: "https://texttospeech.googleapis.com/v1",
  streamPath: "/text:synthesize",
  params: {
    voice: "en-US-Wavenet-D",  // Voice ID
    engine: "wavenet",          // wavenet, standard, neural2
    format: "mp3",              // mp3, linear16, ogg_opus
  },
};
```

**Voice formats:**
- WaveNet: High quality (e.g., en-US-Wavenet-D)
- Standard: Basic quality (e.g., en-US-Standard-A)
- Neural2: Latest neural (e.g., en-US-Neural2-A)

### Microsoft Azure TTS
```typescript
export const TTS_API = {
  baseUrl: "https://YOUR_REGION.tts.speech.microsoft.com",
  streamPath: "/cognitiveservices/v1",
  params: {
    voice: "en-US-JennyNeural",  // Neural voice name
    engine: "neural",             // neural or standard
    format: "audio-24khz-48kbitrate-mono-mp3",
  },
};
```

**Popular voices:**
- en-US-JennyNeural (Female)
- en-US-GuyNeural (Male)
- en-US-AriaNeural (Female)
- en-GB-SoniaNeural (British Female)

### ElevenLabs
```typescript
export const TTS_API = {
  baseUrl: "https://api.elevenlabs.io/v1",
  streamPath: "/text-to-speech/VOICE_ID",
  params: {
    voice: "21m00Tcm4TlvDq8ikWAM",  // Rachel voice ID
    engine: "eleven_monolingual_v1", // Model ID
    format: "mp3_44100_128",         // Format with sample rate
  },
};
```

**Note:** ElevenLabs uses voice IDs instead of names. Common voices:
- Rachel: 21m00Tcm4TlvDq8ikWAM
- Drew: 29vD33N1CtxCmqQRPOHJ
- Clyde: 2EiwWnXFnvU5JabPnv8n

### Coqui TTS (Self-hosted)
```typescript
export const TTS_API = {
  baseUrl: "http://localhost:5002",
  streamPath: "/api/tts",
  params: {
    voice: "default",        // Speaker name
    engine: "tacotron2",     // Model type
    format: "wav",           // wav or mp3
  },
};
```

### Custom/Generic TTS API
```typescript
export const TTS_API = {
  baseUrl: "http://your-tts-server.com",
  streamPath: "/synthesize",
  params: {
    voice: "custom-voice-id",
    engine: "your-engine",
    format: "mp3",
    // Add any custom parameters your API needs
  },
};
```

## Voice Quality Comparison

| Provider | Quality | Speed | Cost | Best For |
|----------|---------|-------|------|----------|
| OpenAI TTS | ⭐⭐⭐⭐ | Fast | $$ | General use, quick setup |
| ElevenLabs | ⭐⭐⭐⭐⭐ | Medium | $$$ | Premium quality, audiobooks |
| AWS Polly (Neural) | ⭐⭐⭐⭐ | Fast | $$ | Production apps, scale |
| Google Cloud (WaveNet) | ⭐⭐⭐⭐ | Fast | $$ | Enterprise apps |
| Azure (Neural) | ⭐⭐⭐⭐ | Fast | $$ | Microsoft ecosystem |
| Coqui (Self-hosted) | ⭐⭐⭐ | Slow | $ (hosting) | Privacy, offline use |

## Parameter Customization

### Changing Voice Mid-Runtime

If you need to change voices dynamically, you can modify the config:

```typescript
// In your component or service
import { TTS_API } from "./config/environment";

// Change voice at runtime
TTS_API.params.voice = "Matthew";  // Switch to male voice
TTS_API.params.engine = "neural";  // Upgrade to neural engine
```

**Note:** This modifies the global config. For production, consider making voice a parameter passed to the TTS service.

### Adding Custom Parameters

If your TTS API requires additional parameters:

```typescript
export const TTS_API = {
  baseUrl: "http://127.0.0.1:8080",
  streamPath: "/api/v1/tts/stream",
  params: {
    voice: "Danielle",
    engine: "long-form",
    format: "mp3",
    // Add custom parameters
    speed: "1.0",           // Playback speed
    pitch: "0",             // Pitch adjustment
    sample_rate: "24000",   // Audio sample rate
    language: "en-US",      // Language code
  },
};
```

The `getQueryString()` method will automatically include all parameters.

### Different Parameters Per Environment

```typescript
// Development - faster, lower quality
export const TTS_API = {
  baseUrl: "http://localhost:8080",
  params: {
    voice: "Danielle",
    engine: "standard",    // Faster processing
    format: "mp3",
  },
};

// Production - higher quality
export const TTS_API = {
  baseUrl: "https://tts.production.com",
  params: {
    voice: "Danielle",
    engine: "neural",      // Better quality
    format: "mp3",
  },
};
```

## Testing Your Configuration

### 1. Check the Console
When the app loads, you'll see:
```
🔧 Savant Control Center - Configuration
...
TTS API: http://127.0.0.1:8080/api/v1/tts/stream
```

### 2. Inspect Network Tab
1. Open browser DevTools → Network tab
2. Filter by "stream" or "tts"
3. Click "Activate Agent"
4. Look for the TTS request
5. Check the full URL with parameters

**Expected URL:**
```
http://127.0.0.1:8080/api/v1/tts/stream?voice=Danielle&engine=long-form&format=mp3&text=Received%20first%20purchase...
```

### 3. Manual Test
You can test your TTS endpoint directly:
```bash
curl "http://127.0.0.1:8080/api/v1/tts/stream?voice=Danielle&engine=long-form&format=mp3&text=hello%20world" --output test.mp3
```

## Troubleshooting

### Issue: TTS returns 404
**Check:**
- `baseUrl` is correct
- `streamPath` matches your API
- API server is running

### Issue: TTS returns 400 Bad Request
**Check:**
- Parameter names match your API (e.g., some APIs use "model" not "engine")
- Voice name is valid for your TTS provider
- Format is supported by your API

### Issue: Audio plays but sounds wrong
**Check:**
- Voice parameter is correct
- Engine/model parameter is valid
- Format is compatible with browser (use mp3 for best compatibility)

### Issue: Audio doesn't load in browser
**Check:**
- CORS is enabled on your TTS API
- Audio format is browser-compatible
- Network tab shows successful response (status 200)
- Response Content-Type is correct (e.g., "audio/mpeg" for mp3)

## Best Practices

1. **Use MP3 for compatibility** - All browsers support MP3
2. **Test with short phrases first** - Easier to debug
3. **Cache TTS responses** - Consider adding caching for repeated phrases
4. **Handle errors gracefully** - TTS failures shouldn't break the app
5. **Monitor costs** - Some providers charge per character
6. **Respect rate limits** - Add throttling if needed

## Need Help?

- See `/config/README.md` for general configuration guide
- See `/TTS_INTEGRATION.md` for TTS implementation details
- See `/CONFIGURATION_MIGRATION.md` for migration guide
