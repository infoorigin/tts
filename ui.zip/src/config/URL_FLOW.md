# TTS URL Construction Flow

Visual guide showing how the TTS URL is built from configuration.

## Configuration → URL Flow

```
┌─────────────────────────────────────────────────────────────┐
│ /config/environment.ts                                      │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  export const TTS_API = {                                  │
│    baseUrl: "http://127.0.0.1:8080",          ─────┐       │
│    streamPath: "/api/v1/tts/stream",          ────┐│       │
│    params: {                                       ││       │
│      voice: "Danielle",                  ─────┐   ││       │
│      engine: "long-form",                ────┐│   ││       │
│      format: "mp3",                      ───┐││   ││       │
│    },                                        │││   ││       │
│  };                                          │││   ││       │
│                                              │││   ││       │
└──────────────────────────────────────────────┼┼┼───┼┼───────┘
                                               │││   ││
                                               │││   ││
┌──────────────────────────────────────────────┼┼┼───┼┼───────┐
│ URL Building Process                         │││   ││       │
├──────────────────────────────────────────────┼┼┼───┼┼───────┤
│                                              │││   ││       │
│  Step 1: Base URL + Path                    │││   ││       │
│  ──────────────────────────                 │││   ││       │
│  baseUrl ────────────────────────────────────┘││   ││       │
│       +                                       ││   ││       │
│  streamPath ──────────────────────────────────┘│   ││       │
│       =                                         │   ││       │
│  "http://127.0.0.1:8080/api/v1/tts/stream"     │   ││       │
│                                                 │   ││       │
│                                                 │   ││       │
│  Step 2: Add Query Parameters                  │   ││       │
│  ────────────────────────────                  │   ││       │
│  URLSearchParams({                              │   ││       │
│    voice: "Danielle",    ◄──────────────────────┘   ││       │
│    engine: "long-form",  ◄──────────────────────────┘│       │
│    format: "mp3",        ◄───────────────────────────┘       │
│    text: "hello world",  ◄─── (from function argument)      │
│  })                                                          │
│       =                                                      │
│  "voice=Danielle&engine=long-form&format=mp3&text=hello..."│
│                                                              │
│                                                              │
│  Step 3: Combine                                            │
│  ───────────────                                            │
│  base + "?" + queryString                                   │
│       =                                                     │
│  "http://127.0.0.1:8080/api/v1/tts/stream?voice=..."       │
│                                                             │
└─────────────────────────────────────────────────────────────┘
                              │
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│ Final URL Sent to TTS API                                   │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  http://127.0.0.1:8080/api/v1/tts/stream?                  │
│    voice=Danielle&                                          │
│    engine=long-form&                                        │
│    format=mp3&                                              │
│    text=hello%20world                                       │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

## Code Example

### Configuration (Input)
```typescript
// /config/environment.ts
export const TTS_API = {
  baseUrl: "http://127.0.0.1:8080",
  streamPath: "/api/v1/tts/stream",
  params: {
    voice: "Danielle",
    engine: "long-form",
    format: "mp3",
  },
  
  getFullUrl(text: string): string {
    return `${this.url}?${this.getQueryString(text)}`;
  },
  
  getQueryString(text: string): string {
    const params = new URLSearchParams({
      voice: this.params.voice,
      engine: this.params.engine,
      format: this.params.format,
      text: text,
    });
    return params.toString();
  },
};
```

### Usage (Processing)
```typescript
// /services/streamingTTS.ts
import { TTS_API } from "../config/environment";

async speak(text: string): Promise<void> {
  // Automatically builds full URL with all parameters
  const streamUrl = TTS_API.getFullUrl(text);
  
  // streamUrl = "http://127.0.0.1:8080/api/v1/tts/stream?voice=Danielle&engine=long-form&format=mp3&text=hello%20world"
  
  this.audio = new Audio(streamUrl);
  await this.audio.play();
}
```

### Result (Output)
```
Browser makes GET request to:
http://127.0.0.1:8080/api/v1/tts/stream?voice=Danielle&engine=long-form&format=mp3&text=hello%20world

Server receives:
{
  voice: "Danielle",
  engine: "long-form",
  format: "mp3",
  text: "hello world"
}

Server responds with:
Content-Type: audio/mpeg
[MP3 audio data]
```

## URL Components Breakdown

```
http://127.0.0.1:8080/api/v1/tts/stream?voice=Danielle&engine=long-form&format=mp3&text=hello%20world
│      │             │  │                 │                                                           │
│      │             │  │                 └─ Query Parameters ──────────────────────────────────────┘
│      │             │  │                    (built from TTS_API.params + text)
│      │             │  │
│      │             │  └─ Stream Path
│      │             │     (TTS_API.streamPath)
│      │             │
│      └─ Port       └─ Base Path
│                       (from TTS_API.baseUrl)
│
└─ Protocol + Host
   (from TTS_API.baseUrl)
```

## Parameter Details

### Base URL
```typescript
baseUrl: "http://127.0.0.1:8080"
         └─────┬─────┘ └──┬──┘ └┬┘
          Protocol    Host   Port
```

**Examples:**
- Local: `http://127.0.0.1:8080`
- Network: `http://192.168.1.100:8080`
- Production: `https://tts.yourcompany.com`

### Stream Path
```typescript
streamPath: "/api/v1/tts/stream"
            └───────┬──────────┘
              API Endpoint Path
```

**Examples:**
- Standard: `/api/v1/tts/stream`
- Custom: `/synthesize`
- OpenAI: `/v1/audio/speech`

### Voice Parameter
```typescript
params: {
  voice: "Danielle"
         └───┬───┘
           Voice ID
}
```

**Becomes:**
`?voice=Danielle`

**Examples:**
- `voice=Danielle` - Female voice
- `voice=Matthew` - Male voice
- `voice=en-US-Wavenet-D` - Google Cloud voice

### Engine Parameter
```typescript
params: {
  engine: "long-form"
          └────┬────┘
            Engine Mode
}
```

**Becomes:**
`&engine=long-form`

**Examples:**
- `engine=long-form` - Optimized for longer text
- `engine=standard` - Basic quality
- `engine=neural` - Neural network based

### Format Parameter
```typescript
params: {
  format: "mp3"
          └─┬─┘
          Audio Format
}
```

**Becomes:**
`&format=mp3`

**Examples:**
- `format=mp3` - MPEG audio
- `format=wav` - WAV audio
- `format=ogg` - OGG Vorbis

### Text Parameter
```typescript
// Runtime value passed to function
speak("hello world")
      └─────┬──────┘
         Input Text
```

**Becomes:**
`&text=hello%20world`  
(URL encoded automatically)

## Adding Custom Parameters

### 1. Add to Configuration
```typescript
// /config/environment.ts
export const TTS_API = {
  params: {
    voice: "Danielle",
    engine: "long-form",
    format: "mp3",
    speed: "1.0",        // ← New parameter
    language: "en-US",   // ← New parameter
  },
```

### 2. Update Query String Builder
```typescript
  getQueryString(text: string): string {
    const params = new URLSearchParams({
      voice: this.params.voice,
      engine: this.params.engine,
      format: this.params.format,
      speed: this.params.speed,        // ← Add here
      language: this.params.language,  // ← Add here
      text: text,
    });
    return params.toString();
  },
```

### 3. Result
```
http://127.0.0.1:8080/api/v1/tts/stream?
  voice=Danielle&
  engine=long-form&
  format=mp3&
  speed=1.0&           ← New
  language=en-US&      ← New
  text=hello%20world
```

## URL Encoding

Text is automatically URL encoded:

| Input | Encoded |
|-------|---------|
| `hello world` | `hello%20world` |
| `Hello, World!` | `Hello%2C%20World%21` |
| `café` | `caf%C3%A9` |
| `price=$10` | `price%3D%2410` |

This is handled automatically by `URLSearchParams`.

## Network Tab Verification

When you activate the agent, check Network tab in DevTools:

```
Name: stream?voice=Danielle&engine=long-form&format=mp3&text=...
Status: 200 OK
Type: media
Size: 45.2 KB
Time: 1.23 s

Request URL:
http://127.0.0.1:8080/api/v1/tts/stream?voice=Danielle&engine=long-form&format=mp3&text=Received%20first%20purchase%20trigger%20for%20account%20Yale%20New%20Haven....

Request Headers:
Accept: */*
Origin: http://localhost:3000
Referer: http://localhost:3000/

Response Headers:
Content-Type: audio/mpeg
Content-Length: 46234
Access-Control-Allow-Origin: *
```

## Common URL Patterns

### Your Current Setup
```
http://127.0.0.1:8080/api/v1/tts/stream?voice=Danielle&engine=long-form&format=mp3&text=...
```

### OpenAI Pattern
```
https://api.openai.com/v1/audio/speech?model=tts-1&voice=alloy&input=...
```

### AWS Polly Pattern
```
https://polly.us-east-1.amazonaws.com/v1/speech?VoiceId=Joanna&OutputFormat=mp3&Text=...
```

### Google Cloud Pattern
```
https://texttospeech.googleapis.com/v1/text:synthesize?voice=en-US-Wavenet-D&audioEncoding=MP3&input=...
```

## Troubleshooting URLs

### Issue: 404 Not Found
```
❌ http://127.0.0.1:8080/wrong/path?voice=Danielle...
✅ http://127.0.0.1:8080/api/v1/tts/stream?voice=Danielle...
```
→ Check `streamPath` in config

### Issue: Connection Refused
```
❌ http://127.0.0.1:9999/api/v1/tts/stream?voice=Danielle...
✅ http://127.0.0.1:8080/api/v1/tts/stream?voice=Danielle...
```
→ Check `baseUrl` port number

### Issue: 400 Bad Request
```
❌ ...?voice=InvalidVoice&engine=...
✅ ...?voice=Danielle&engine=...
```
→ Check parameter values in `params`

### Issue: Wrong Parameter Names
```
❌ ...?speaker=Danielle&mode=long-form...
✅ ...?voice=Danielle&engine=long-form...
```
→ Check parameter names in `getQueryString()`

## Quick Reference

| Component | Config Location | Example |
|-----------|----------------|---------|
| Protocol + Host + Port | `TTS_API.baseUrl` | `http://127.0.0.1:8080` |
| Path | `TTS_API.streamPath` | `/api/v1/tts/stream` |
| Voice | `TTS_API.params.voice` | `Danielle` |
| Engine | `TTS_API.params.engine` | `long-form` |
| Format | `TTS_API.params.format` | `mp3` |
| Text | Function argument | `hello world` |

**Result:**
```
http://127.0.0.1:8080/api/v1/tts/stream?voice=Danielle&engine=long-form&format=mp3&text=hello+world
```

---

**Edit `/config/environment.ts` to change any part of this URL! 🚀**
