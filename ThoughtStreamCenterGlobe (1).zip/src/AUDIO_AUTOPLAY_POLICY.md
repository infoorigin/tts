# Browser Autoplay Policy & Audio Handling

## Overview
Modern browsers block automatic audio playback to prevent intrusive user experiences. This document explains how the Savant Control Center handles browser autoplay restrictions.

## The Problem

When you try to play audio automatically (without user interaction), browsers will block it with an error:

```
NotAllowedError: play() failed because the user didn't interact with the document first.
```

This happens in:
- **Production mode** when the sphere auto-activates on page load
- **Any scenario** where audio attempts to play before user interaction

## Our Solution

### 1. User Interaction Detection
We track whether the user has interacted with the page before attempting audio playback.

**Implementation:**
```typescript
// In streamingTTS.ts
private userInteracted = false;
private audioContext: AudioContext | null = null;
```

### 2. Audio Initialization
Audio is initialized when the user:
- **Clicks the "Activate Agent" button** (Testing mode)
- **Toggles the audio switch** (Production or Testing mode)

**Implementation:**
```typescript
async initializeAudio(): Promise<boolean> {
  // Creates AudioContext and resumes it
  // Marks user interaction as detected
  this.userInteracted = true;
}
```

### 3. Graceful Fallback
If audio hasn't been initialized, we skip audio playback but continue with the visual experience:

```typescript
async speak(text: string): Promise<void> {
  if (!this.canPlayAudio()) {
    console.warn("Cannot play audio - no user interaction detected");
    return Promise.resolve(); // Skip audio, continue typewriter
  }
  // ... play audio
}
```

## User Experience Flows

### Testing Mode (Manual Activation)

1. **User lands on page**
   - Audio: ❌ Not initialized
   - Sphere: Idle, waiting

2. **User clicks "Activate Agent"**
   - Audio: ✅ Initialized (button click = interaction)
   - Sphere: Activates
   - Events: Stream with audio

3. **First event with audio**
   - Audio: ✅ Plays successfully
   - Text: Types simultaneously

### Production Mode (Auto-activation)

1. **User lands on page with ?context_id=xxx**
   - Audio: ❌ Not initialized
   - Sphere: Auto-activates
   - Events: Begin streaming

2. **First event attempts audio**
   - Audio: ❌ Blocked (no user interaction yet)
   - Text: ✅ Types normally
   - Console: "Cannot play audio - no user interaction detected"

3. **User toggles audio switch ON**
   - Audio: ✅ Initialized (switch toggle = interaction)

4. **Next event with audio**
   - Audio: ✅ Plays successfully
   - Text: Types simultaneously

### Recommended Production UX

For the best user experience in production mode:

**Option 1: Audio Toggle (Current Implementation)**
- Audio toggle starts in ON position
- User must toggle it to initialize audio
- Clear visual indicator (Volume icon)

**Option 2: Audio Consent Overlay (Future Enhancement)**
```typescript
// Show overlay on first load
<AudioConsentOverlay onAccept={() => {
  streamingTTS.initializeAudio();
  startWorkflow();
}} />
```

**Option 3: Click-to-Start (Alternative)**
```typescript
// Require initial click to start
<div onClick={() => {
  streamingTTS.initializeAudio();
  startWorkflow();
}}>
  Click to Start →
</div>
```

## Testing

### Test in Testing Mode
```bash
# 1. Set TESTING_MODE = true in /config/environment.ts
# 2. Open app
# 3. Click "Activate Agent" button
# 4. ✅ Audio should play for thought/response events
```

### Test in Production Mode
```bash
# 1. Set TESTING_MODE = false, USE_MOCK_EVENTS = false
# 2. Open app with ?context_id=test123
# 3. First event: ❌ Audio blocked (expected)
# 4. Toggle audio switch
# 5. Next event: ✅ Audio plays
```

### Console Messages

**No interaction detected:**
```
[StreamingTTS] Cannot play audio - no user interaction detected. Skipping audio playback.
```

**Audio initialized:**
```
[StreamingTTS] Audio initialized - user interaction detected
[ContentDisplay] Audio enabled and initialized
```

**Audio playing:**
```
[StreamingTTS] Starting TTS for text: ...
[StreamingTTS] Audio playback started
```

## Browser Compatibility

### Autoplay Policies by Browser

| Browser | Policy | Notes |
|---------|--------|-------|
| Chrome 66+ | Strict | Requires user gesture |
| Firefox 66+ | Strict | Requires user gesture |
| Safari 11+ | Very Strict | Requires user gesture + visible element |
| Edge 79+ | Strict | Requires user gesture |

### What Counts as "User Interaction"?

✅ **Valid interactions:**
- Click
- Tap (mobile)
- Key press
- Toggle switch

❌ **Not valid interactions:**
- Page load
- Mouse hover
- Scroll
- Timer/setTimeout

## Debugging

### Check Audio State
Open browser console and check:

```javascript
// Check if audio is initialized
streamingTTS.canPlayAudio() // Should return true after interaction

// Check AudioContext state
streamingTTS.audioContext.state // Should be 'running' after initialization
```

### Common Issues

**Issue:** Audio still blocked after toggle
- **Cause:** Browser security settings too strict
- **Solution:** Check browser console for specific error, may need to enable audio in browser settings

**Issue:** Audio plays in Testing but not Production
- **Cause:** No user interaction in Production mode before audio attempts
- **Solution:** User must interact (toggle audio) before events with audio arrive

**Issue:** Mock audio works but real TTS doesn't
- **Cause:** Mock audio has fallback behavior (timeout-based)
- **Solution:** Real TTS needs network connection + proper API endpoint

## Best Practices

### ✅ DO:
- Initialize audio on explicit user action (button, toggle)
- Provide clear visual indicator for audio state
- Gracefully degrade when audio is blocked
- Log helpful messages for debugging
- Test in all target browsers

### ❌ DON'T:
- Try to bypass autoplay policy (it won't work)
- Block UI waiting for audio initialization
- Show error messages for expected autoplay blocks
- Require audio for core functionality

## Related Files
- `/services/streamingTTS.ts` - Audio initialization logic
- `/components/ContentDisplay.tsx` - Audio toggle UI
- `/App.tsx` - Button click initialization
- `/config/environment.ts` - Audio configuration

## Additional Resources
- [Chrome Autoplay Policy](https://developer.chrome.com/blog/autoplay/)
- [MDN: Autoplay Guide](https://developer.mozilla.org/en-US/docs/Web/Media/Autoplay_guide)
- [Web Audio API](https://developer.mozilla.org/en-US/docs/Web/API/Web_Audio_API)
