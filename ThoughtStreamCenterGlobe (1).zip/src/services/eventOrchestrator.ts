/**
 * Event Orchestrator
 * Manages the flow from stream → queue → components with sequential processing
 */

import { eventQueue, type QueuedEvent } from "./eventQueue";
import { eventStreamService, type AgentEvent } from "./eventStream";
import { USE_MOCK_EVENTS } from "../config/environment";

class EventOrchestrator {
  private eventQueue: QueuedEvent[] = [];
  private isProcessing = false;
  private processingTimeout: NodeJS.Timeout | null = null;
  private testingMode = false; // Track if we're in testing mode
  
  /**
   * Start the orchestrator - begins listening to stream and processing events
   */
  start(contextId?: string, testingMode = false) {
    console.log("[Orchestrator] Starting...", { 
      contextId, 
      testingMode, 
      useMockEvents: USE_MOCK_EVENTS 
    });
    
    this.testingMode = testingMode;
    
    // Reset state
    this.eventQueue = [];
    this.isProcessing = false;
    if (this.processingTimeout) {
      clearTimeout(this.processingTimeout);
      this.processingTimeout = null;
    }
    
    // In testing mode, activate immediately (don't wait for workflow event)
    if (testingMode) {
      console.log("[Orchestrator] Testing mode - activating sphere immediately");
      eventQueue.publishWorkflowState("active");
    }
    
    // Start the event stream
    // Note: USE_MOCK_EVENTS is checked in eventStreamService.startStream()
    // If USE_MOCK_EVENTS is true, it uses mock data
    // If false and contextId is provided, it connects to real API
    eventStreamService.startStream(
      (event) => this.handleIncomingEvent(event),
      () => this.handleStreamComplete(),
      contextId
    );
  }
  
  /**
   * Stop the orchestrator
   */
  stop() {
    console.log("[Orchestrator] Stopping...");
    eventStreamService.stopStream();
    this.reset();
  }
  
  /**
   * Reset the orchestrator state
   */
  reset() {
    console.log("[Orchestrator] Resetting...");
    this.eventQueue = [];
    this.isProcessing = false;
    if (this.processingTimeout) {
      clearTimeout(this.processingTimeout);
      this.processingTimeout = null;
    }
    eventQueue.reset();
  }
  
  /**
   * Handle incoming event from stream
   */
  private handleIncomingEvent(event: AgentEvent) {
    console.log(`[Orchestrator] Received: ${event.heading} (type: ${event.type})`);
    
    // Handle workflow events
    if (event.type === "workflow" && event.kvps?.workflow_status) {
      if (event.kvps.workflow_status === "started") {
        eventQueue.publishWorkflowState("active");
      } else if (event.kvps.workflow_status === "completed") {
        eventQueue.publishWorkflowState("completed");
      }
      return; // Don't queue workflow events
    }
    
    // Handle response events - split into thinking + response
    if (event.type === "response") {
      console.log("[Orchestrator] Splitting response into thinking + response");
      
      // Create thinking event
      const thinkingEvent: QueuedEvent = {
        no: event.no * 1000, // Unique ID
        id: event.id,
        type: "thought",
        heading: "Agent Thinking",
        content: ["Analyzing information and formulating response..."],
      };
      
      // Create response event
      const responseEvent: QueuedEvent = {
        no: event.no,
        id: event.id,
        type: "response",
        heading: event.heading,
        content: Array.isArray(event.content) ? event.content : [event.content],
      };
      
      // Queue both events
      this.eventQueue.push(thinkingEvent);
      this.eventQueue.push(responseEvent);
    } else {
      // Regular event - convert to QueuedEvent
      const queuedEvent: QueuedEvent = {
        no: event.no,
        id: event.id,
        type: event.type === "reasoning" ? "thought" : event.type as "tool" | "response",
        heading: event.heading,
        content: Array.isArray(event.content) ? event.content : [event.content],
      };
      
      this.eventQueue.push(queuedEvent);
    }
    
    // Start processing if not already processing
    if (!this.isProcessing) {
      this.processNextEvent();
    }
  }
  
  /**
   * Handle stream completion
   */
  private handleStreamComplete() {
    console.log("[Orchestrator] Stream completed");
    // Don't do anything here - let the queue finish processing
  }
  
  /**
   * Process the next event in the queue
   */
  private processNextEvent() {
    const nextEvent = this.eventQueue.shift();
    
    if (!nextEvent) {
      console.log("[Orchestrator] Queue empty");
      this.isProcessing = false;
      eventQueue.publishQueueEmpty();
      return;
    }
    
    console.log(`[Orchestrator] Processing event: ${nextEvent.heading}`);
    this.isProcessing = true;
    
    // Publish event to subscribers (bubble + content display)
    eventQueue.publishEvent(nextEvent);
    
    // Calculate processing time based on content length
    const totalChars = nextEvent.content.reduce((sum, line) => sum + line.length, 0);
    const typingTime = (totalChars * 8) + (nextEvent.content.length * 20); // 8ms per char + 20ms per line
    const bubbleTime = 900; // Time for bubble to reach static position
    const fadeTime = 500; // Time for bubble to fade out
    const processingTime = Math.max(bubbleTime + typingTime + fadeTime, 2000); // Min 2s
    
    console.log(`[Orchestrator] Event will take ~${processingTime}ms to process`);
    
    // Schedule next event after this one completes
    this.processingTimeout = setTimeout(() => {
      console.log(`[Orchestrator] Event completed: ${nextEvent.heading}`);
      this.processNextEvent();
    }, processingTime);
  }
}

// Singleton instance
export const eventOrchestrator = new EventOrchestrator();