# Testing TTS Configuration

Quick guide to verify your TTS configuration is working correctly.

## Test 1: Console Verification

When you open the application, you should see in the browser console:

```
🔧 Savant Control Center - Configuration
Environment: DEVELOPMENT
Testing Mode: ✅ ENABLED
Mock Audio: ✅ ENABLED
Mock Events: ✅ ENABLED
Event Source: Mock Data (Hardcoded)
Audio Source: https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3
```

## Test 2: URL Generation Test

Open browser console and run:

```javascript
// Import the config (in browser console, you can access via window)
// Or test in your code:
import { TTS_API } from './config/environment';

// Test URL generation
const testText = "hello world";
const url = TTS_API.getFullUrl(testText);
console.log("Generated URL:", url);

// Expected output:
// http://127.0.0.1:8080/api/v1/tts/stream?voice=Danielle&engine=long-form&format=mp3&text=hello+world
```

## Test 3: Network Tab Verification

1. Open DevTools → Network tab
2. Set `USE_MOCK_AUDIO = false` in `/config/environment.ts`
3. Click "Activate Agent" button
4. Look for TTS requests in Network tab
5. Verify URL format matches:

```
http://127.0.0.1:8080/api/v1/tts/stream?voice=Danielle&engine=long-form&format=mp3&text=Received%20first%20purchase%20trigger...
```

## Test 4: Direct API Test

Test your TTS endpoint directly with curl:

```bash
# Basic test
curl "http://127.0.0.1:8080/api/v1/tts/stream?voice=Danielle&engine=long-form&format=mp3&text=hello%20world" \
  --output test-tts.mp3

# Play the audio (macOS)
afplay test-tts.mp3

# Play the audio (Linux)
mpg123 test-tts.mp3

# Play the audio (Windows)
start test-tts.mp3
```

## Test 5: Different Voice Parameters

Test different voices by modifying `/config/environment.ts`:

```typescript
// Test 1: Different voice
export const TTS_API = {
  // ...
  params: {
    voice: "Matthew",  // Try a different voice
    engine: "long-form",
    format: "mp3",
  },
};

// Test 2: Different engine
export const TTS_API = {
  // ...
  params: {
    voice: "Danielle",
    engine: "neural",  // Try neural engine
    format: "mp3",
  },
};

// Test 3: Different format
export const TTS_API = {
  // ...
  params: {
    voice: "Danielle",
    engine: "long-form",
    format: "wav",  // Try WAV format
  },
};
```

After each change:
1. Save the file
2. Refresh the browser
3. Check console for new configuration
4. Activate agent and verify audio

## Test 6: Custom Parameters

If your TTS API needs custom parameters, add them:

```typescript
export const TTS_API = {
  baseUrl: "http://127.0.0.1:8080",
  streamPath: "/api/v1/tts/stream",
  params: {
    voice: "Danielle",
    engine: "long-form",
    format: "mp3",
    // Add custom parameters
    speed: "1.0",
    pitch: "0",
    custom_param: "test",
  },
  
  // Update getQueryString to include new params
  getQueryString(text: string): string {
    const params = new URLSearchParams({
      voice: this.params.voice,
      engine: this.params.engine,
      format: this.params.format,
      speed: this.params.speed,        // Add custom params
      pitch: this.params.pitch,
      custom_param: this.params.custom_param,
      text: text,
    });
    return params.toString();
  },
};
```

## Troubleshooting Tests

### Console shows "Mock Audio" but you set USE_MOCK_AUDIO = false

**Fix:**
1. Hard refresh browser: Ctrl+Shift+R (Windows/Linux) or Cmd+Shift+R (Mac)
2. Clear browser cache
3. Check you saved `/config/environment.ts`

### Network tab shows no TTS requests

**Possible causes:**
1. `USE_MOCK_AUDIO` is still `true`
2. Audio is disabled
3. Only "tool" events are being processed (TTS only works for "thought" and "response" events)

**Fix:**
1. Verify `USE_MOCK_AUDIO = false` in config
2. Check ContentDisplay is receiving thought/response events
3. Check console for `[StreamingTTS]` logs

### URL looks wrong in Network tab

**Check:**
1. `baseUrl` is correct (including port number)
2. `streamPath` matches your API
3. Parameter names match your API requirements

### Audio returns 404

**Check:**
1. TTS server is running on port 8080
2. Path `/api/v1/tts/stream` is correct
3. Try accessing the URL directly in browser

### Audio returns 400 Bad Request

**Common issues:**
1. Parameter names don't match API (e.g., API expects "model" not "engine")
2. Voice name is invalid
3. Format is not supported
4. Missing required parameters

**Fix:**
Check your TTS API documentation for correct parameter names.

### Audio returns 200 but doesn't play

**Check:**
1. Response Content-Type is audio/* (e.g., "audio/mpeg")
2. Response actually contains audio data (check size > 0)
3. Browser supports the format (MP3 is most compatible)
4. Check browser console for playback errors

## Expected Behavior

### With Mock Audio (Default)
✅ Should see: "Mock Audio" badge  
✅ Console: "Audio Source: https://www.soundhelix.com/..."  
✅ Network: No TTS API calls  
✅ Audio: Plays test music file  

### With Real TTS API
✅ Should see: Status indicator without "Mock Audio"  
✅ Console: "TTS API: http://127.0.0.1:8080/api/v1/tts/stream"  
✅ Network: TTS requests with full query params  
✅ Audio: Plays synthesized speech  

## Performance Tests

### Test Audio Timing

The mock audio duration is calculated based on text length. Test with:

```typescript
// Short text (should be ~1 second minimum)
"Hello"

// Medium text (should be ~3-4 seconds)
"This is a test of the text to speech system with medium length content"

// Long text (should be capped at 10 seconds)
"Lorem ipsum dolor sit amet, consectetur adipiscing elit... [very long text]"
```

Check console for:
```
[StreamingTTS] Mock audio: 5 words, duration: 2000ms
```

### Test Simultaneous Audio & Typing

When an event activates:
1. Audio should start immediately
2. Typewriter should start simultaneously
3. Both should run in parallel
4. Next event should wait for BOTH to complete

Check console for:
```
[ContentItem 1] Starting TTS and typewriter SIMULTANEOUSLY for thought event
[ContentItem 1] Typing complete, checking if audio is also done
[ContentItem 1] Audio playback completed
[ContentItem 1] Both audio and typing complete, moving to next event
```

## Validation Checklist

- [ ] Configuration loads without errors
- [ ] Console shows correct environment
- [ ] URL generation produces correct format
- [ ] Mock audio plays when `USE_MOCK_AUDIO = true`
- [ ] Real TTS calls API when `USE_MOCK_AUDIO = false`
- [ ] Query parameters are correct in Network tab
- [ ] Different voices work when changed
- [ ] Audio and typing run simultaneously
- [ ] Events wait for both audio and typing completion
- [ ] No console errors during playback

## Need Help?

If tests fail:
1. Check `/config/README.md` for configuration guide
2. Check `/config/TTS_EXAMPLES.md` for provider-specific examples
3. Check browser console for detailed error messages
4. Check Network tab for failed requests
5. Verify TTS server is running and accessible
