# Production Setup Guide

## Quick Setup (3 Steps)

### Step 1: Configure Your API Endpoint
Edit `/config/environment.ts`:

```typescript
export const EVENT_STREAM_API = {
  baseUrl: "https://your-api.com",  // ← Change this
  streamPath: "/api/v1/contexts/{contextId}/log/stream",
  headers: {
    Accept: "text/event-stream",
    "Cache-Control": "no-cache",
  },
};

export const TTS_API = {
  baseUrl: "https://your-tts-api.com",  // ← Change this
  streamPath: "/api/v1/tts/stream",
  // ... rest of config
};
```

### Step 2: Set Production Mode
In the same file:

```typescript
export const TESTING_MODE = false;     // ← Already set
export const USE_MOCK_AUDIO = false;   // ← Already set
export const USE_MOCK_EVENTS = false;  // ← Already set
```

### Step 3: Deploy & Share
```bash
npm run build
# Deploy to your hosting service
# Share base URL: https://your-app.com/
```

## How Users Use It

1. **User opens the app**
   - Sees "Intelligence Stream" panel
   - Sees "Enter Context ID to Start Listening"

2. **User clicks to expand**
   - Input field appears
   - Helper text explains what to do

3. **User enters context ID**
   - Types their workflow context ID
   - Example: `abc123xyz`

4. **User clicks "Start Listening"**
   - ✅ Audio initialized (no browser blocking!)
   - ✅ Connects to API with their context ID
   - ✅ MindSphere activates
   - ✅ Events stream in real-time

## Configuration Checklist

### ✅ Production Ready
- [ ] `TESTING_MODE = false`
- [ ] `USE_MOCK_EVENTS = false`
- [ ] `USE_MOCK_AUDIO = false`
- [ ] `EVENT_STREAM_API.baseUrl` set to production URL
- [ ] `TTS_API.baseUrl` set to production URL
- [ ] CORS enabled on your API
- [ ] API returns NDJSON format
- [ ] TTS API streaming working

### ✅ Testing Locally
- [ ] Set API URLs to `http://localhost:8000`
- [ ] Backend running on configured port
- [ ] Can access API endpoints
- [ ] Events stream successfully
- [ ] Audio plays when enabled

## Environment Variables (Optional)

If you want to use environment variables instead:

```typescript
// .env.production
VITE_API_BASE_URL=https://your-api.com
VITE_TTS_BASE_URL=https://your-tts-api.com

// config/environment.ts
export const EVENT_STREAM_API = {
  baseUrl: import.meta.env.VITE_API_BASE_URL || "http://localhost:8000",
  // ...
};
```

## Deployment Platforms

### Vercel
```bash
npm run build
vercel deploy
```

### Netlify
```bash
npm run build
netlify deploy --prod --dir=dist
```

### AWS S3 + CloudFront
```bash
npm run build
aws s3 sync dist/ s3://your-bucket/
```

### Docker
```dockerfile
FROM node:18-alpine
WORKDIR /app
COPY package*.json ./
RUN npm install
COPY . .
RUN npm run build
EXPOSE 3000
CMD ["npm", "run", "preview"]
```

## API Requirements

Your backend must provide:

### Event Stream Endpoint
```
GET /api/v1/contexts/{contextId}/log/stream

Response:
- Content-Type: text/event-stream
- Format: NDJSON (Newline-Delimited JSON)
- CORS headers enabled
```

**Example Response:**
```json
{"event":"update","data":{"no":1,"id":null,"kvps":{"workflow_status":"started","event_type":"workflow"}}}
{"event":"update","data":{"no":2,"id":null,"kvps":{"event_type":"reasoning","headline":"Starting process","thoughts":["Step 1","Step 2"]}}}
```

### TTS Endpoint (Optional)
```
GET /api/v1/tts/stream?voice=Danielle&engine=long-form&format=mp3&text=Hello

Response:
- Content-Type: audio/mpeg
- Format: Streaming audio
```

## CORS Configuration

Your API must allow:

```javascript
// Express.js example
app.use(cors({
  origin: 'https://your-app.com',
  methods: ['GET'],
  credentials: true
}));
```

## Troubleshooting

### Events Not Streaming
**Check:**
1. Is API URL correct in config?
2. Is CORS enabled on backend?
3. Is context ID valid?
4. Check browser console for errors

**Console should show:**
```
[EventStream] Using REAL API streaming
Connecting to stream API: https://your-api.com/api/v1/contexts/abc123/log/stream
```

### Audio Not Playing
**Check:**
1. Is audio toggle enabled (top right)?
2. Was "Start Listening" clicked (user interaction)?
3. Is TTS API URL correct?
4. Check browser console for TTS errors

**Console should show:**
```
[StreamingTTS] Audio initialized - user interaction detected
[StreamingTTS] Starting TTS for text: ...
```

### Input Not Showing
**Check:**
1. Is `TESTING_MODE = false`?
2. Have you already started listening?
3. Try clicking Reset button

## Monitoring

### Console Logs
Open browser console to see:
- Configuration summary
- API connection status
- Event stream progress
- Audio playback status

### Example Console Output
```
🔧 Savant Control Center - Configuration
Environment: PRODUCTION
Testing Mode: ❌ DISABLED
Mock Events: ❌ DISABLED
Event Stream API: https://your-api.com
💡 Enter Context ID in the Intelligence Stream to start listening

[EventStream] Using REAL API streaming
[Orchestrator] Starting... { contextId: 'abc123', testingMode: false }
[ContentItem 1] Activated, starting sequence
[StreamingTTS] Audio initialized - user interaction detected
```

## Security Best Practices

### ✅ DO:
- Use HTTPS for production
- Enable CORS only for your domain
- Validate context IDs on backend
- Rate limit API endpoints
- Monitor API usage
- Use authentication if needed

### ❌ DON'T:
- Expose API keys in frontend
- Allow public access to sensitive contexts
- Share context IDs in URLs
- Log sensitive data to console in production
- Skip input validation

## Performance Optimization

### Reduce Bundle Size
```bash
# Analyze bundle
npm run build -- --analyze

# Use production build
npm run build
```

### Optimize API
- Use CDN for static assets
- Enable gzip compression
- Minimize event payload size
- Use WebSocket if needed (future)

### Browser Caching
```nginx
# nginx example
location /assets/ {
  expires 1y;
  add_header Cache-Control "public, immutable";
}
```

## Support & Documentation

### User Documentation
Share this with users:
1. Open the app URL
2. Click "Enter Context ID to Start Listening"
3. Enter your workflow context ID
4. Click "Start Listening"
5. Toggle audio on/off as needed

### Developer Documentation
- `/ARCHITECTURE.md` - System architecture
- `/CONTEXT_ID_QUICK_START.md` - Context ID guide
- `/AUDIO_AUTOPLAY_POLICY.md` - Audio handling
- `/config/README.md` - Configuration guide

## Rollback Plan

If you need to rollback to testing mode:

```typescript
// config/environment.ts
export const TESTING_MODE = true;
export const USE_MOCK_EVENTS = true;
export const USE_MOCK_AUDIO = true;

// Redeploy - will show "Activate Agent" button with mock data
```

## Success Metrics

Monitor these to ensure production success:

- [ ] Users can connect without errors
- [ ] Events stream in real-time
- [ ] Audio plays when enabled
- [ ] No console errors
- [ ] Sphere activates correctly
- [ ] Events display properly
- [ ] Reset works correctly
- [ ] Multiple sessions work

## Next Steps

1. ✅ Configure production URLs
2. ✅ Test with real API locally
3. ✅ Deploy to staging environment
4. ✅ Test end-to-end with users
5. ✅ Deploy to production
6. ✅ Share URL with users
7. ✅ Monitor and support

## Need Help?

Check these resources:
- Console logs for errors
- Network tab for API calls
- `/SMART_CONTEXT_ID_IMPLEMENTATION.md` for details
- Backend API logs for server-side issues

---

**You're ready for production!** 🚀

The smart context ID input provides a professional, secure, and user-friendly way to connect to your agent workflows.
