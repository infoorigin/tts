import { motion } from "motion/react";
import { useEffect, useState } from "react";

interface MindSphereProps {
  isActive: boolean;
  hasBubble: boolean;
  bubbleAngle: number; // Angle in radians for particle emission direction
}

const PLAYBOOK_WORDS = [
  "Inlexzo First Purchase",
  "Territory Alignment",
  "Field Force Notification",
  "Engagement Monitor",
  "Compliance Check",
  "Inlexzo",
  "Territory",
  "Field Force",
  "Engagement",
  "Compliance",
  "First Purchase",
  "Alignment",
  "Notification",
  "Monitor",
  "Check",
];

export function MindSphere({ isActive, hasBubble, bubbleAngle }: MindSphereProps) {
  const [pulseIntensity, setPulseIntensity] = useState(1);
  const [scanLineY, setScanLineY] = useState(100); // Start at exact middle (100 out of 200px height)

  useEffect(() => {
    if (!isActive) {
      const interval = setInterval(() => {
        setPulseIntensity(prev => (prev === 1 ? 1.15 : 1));
      }, 1500);
      return () => clearInterval(interval);
    }
  }, [isActive]);

  // Generate random Y position for scan line restart - mostly centered
  useEffect(() => {
    if (isActive) {
      const interval = setInterval(() => {
        // Keep it centered around 100 (middle of 200px height)
        // Random range from 95 to 105 for a very tightly centered wave
        setScanLineY(95 + Math.random() * 10);
      }, 4000); // Match the duration of the scan animation
      return () => clearInterval(interval);
    }
  }, [isActive]);

  return (
    <div className="relative flex flex-col items-center justify-center">
      {/* Lake of words flowing - transitions from full screen to Zone 1 width */}
      <motion.div 
        className="fixed top-1/2 left-0 h-[160px] sm:h-[180px] lg:h-[200px] xl:h-[220px] pointer-events-none overflow-hidden z-0"
        initial={false}
        animate={{
          width: isActive ? '68vw' : '100vw',
        }}
        transition={{
          duration: 0.6,
          ease: "easeInOut"
        }}
        style={{ 
          // Keep constant position - maintain height during active/inactive modes
          // Fixed at 190px for consistent positioning
          marginTop: '190px',
        }}
      >
        {/* Water surface effect with gradient */}
        <div 
          className="absolute inset-0 pointer-events-none"
          style={{
            background: "linear-gradient(to right, transparent 0%, rgba(204, 0, 0, 0.06) 20%, rgba(204, 0, 0, 0.08) 50%, rgba(204, 0, 0, 0.06) 80%, transparent 100%)",
          }}
        />
        
        {/* Flowing words in multiple rows (like waves) - all flowing left to right */}
        {[0, 1, 2, 3, 4, 5].map((row) => {
          // Create random seed based on row for consistent randomness
          const rowSeed = row * 123.456;
          
          return (
            <div key={`row-${row}`} className="absolute w-full overflow-hidden" style={{ top: `${row * 35}px`, height: '40px' }}>
              {/* Create multiple instances of words with proper spacing to prevent overlap */}
              {PLAYBOOK_WORDS.map((word, i) => {
                // All rows flow left to right (toward Intelligence Stream)
                const speed = 16 + (row * 2.5); // Different speeds per row
                
                // Calculate proper spacing with randomness - ensure minimum spacing to prevent overlap
                const baseSpacing = 220; // Increased spacing to prevent overlap
                const randomOffset = ((i + rowSeed) * 37) % 50; // Pseudo-random offset 0-50
                const wordSpacing = baseSpacing + randomOffset;
                const startOffset = i * wordSpacing;
                
                // Add random vertical jitter within the row
                const yJitter = ((i * 47 + rowSeed) % 20) - 10; // -10 to +10 px
                
                const startX = -800 + startOffset;
                const endX = 1600 + startOffset;
                
                return (
                  <motion.div
                    key={`lake-word-${row}-${i}`}
                    className={`absolute whitespace-nowrap pointer-events-none ${
                      isActive ? "text-[#CC0000]/40 font-medium" : "text-gray-500/40"
                    }`}
                    style={{
                      fontSize: `${9 + row * 0.8}px`, // Reduced font size
                      left: 0,
                      top: `${yJitter}px`,
                    }}
                    initial={{ x: startX }}
                    animate={{
                      x: [startX, endX],
                      opacity: isActive ? [0.3, 0.5, 0.3] : [0.25, 0.4, 0.25],
                    }}
                    transition={{
                      duration: speed,
                      repeat: Infinity,
                      ease: "linear",
                      repeatDelay: 0,
                    }}
                  >
                    {word}
                  </motion.div>
                );
              })}
            </div>
          );
        })}
        
        {/* Vertical scanning beam effect - vertical line sweeps left to right */}
        {isActive && (
          <motion.div
            className="absolute left-0 w-full h-full pointer-events-none overflow-hidden"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.3 }}
          >
            {/* Main vertical scan line */}
            <motion.div
              className="absolute top-0 w-[3px] h-full"
              style={{
                background: "linear-gradient(to bottom, transparent 0%, rgba(204, 0, 0, 0.3) 20%, rgba(204, 0, 0, 0.8) 50%, rgba(204, 0, 0, 0.3) 80%, transparent 100%)",
                boxShadow: "0 0 12px rgba(204, 0, 0, 0.6), 0 0 24px rgba(204, 0, 0, 0.4)",
              }}
              animate={{
                left: ["0%", "100%"],
              }}
              transition={{
                duration: 4,
                repeat: Infinity,
                ease: "linear",
              }}
            />
            
            {/* Trailing glow effect */}
            <motion.div
              className="absolute top-0 w-[40px] h-full"
              style={{
                background: "linear-gradient(to right, rgba(204, 0, 0, 0.4) 0%, rgba(204, 0, 0, 0.2) 30%, transparent 100%)",
                filter: "blur(8px)",
              }}
              animate={{
                left: ["0%", "100%"],
              }}
              transition={{
                duration: 4,
                repeat: Infinity,
                ease: "linear",
              }}
            />
            
            {/* Secondary scan line (delayed) */}
            <motion.div
              className="absolute top-0 w-[2px] h-full"
              style={{
                background: "linear-gradient(to bottom, transparent 0%, rgba(255, 100, 100, 0.2) 20%, rgba(255, 100, 100, 0.5) 50%, rgba(255, 100, 100, 0.2) 80%, transparent 100%)",
                boxShadow: "0 0 8px rgba(255, 100, 100, 0.4)",
              }}
              animate={{
                left: ["0%", "100%"],
              }}
              transition={{
                duration: 4,
                repeat: Infinity,
                ease: "linear",
                delay: 2,
              }}
            />
          </motion.div>
        )}
      </motion.div>
      
      {/* Sphere container */}
      <div className="relative flex items-center justify-center z-20">
      {/* Outer glow rings - LISTENER MODE: slow gentle pulse */}
      <motion.div
        className="absolute w-[320px] h-[320px] lg:w-[360px] lg:h-[360px] xl:w-[400px] xl:h-[400px] rounded-full"
        style={{
          background: isActive 
            ? "radial-gradient(circle, rgba(204, 0, 0, 0.35) 0%, transparent 70%)"
            : "radial-gradient(circle, rgba(204, 0, 0, 0.12) 0%, transparent 70%)",
        }}
        animate={{
          scale: isActive ? [1, 1.8, 1] : pulseIntensity,
          opacity: isActive ? [0.7, 0.3, 0.7] : [0.4, 0.6, 0.4],
        }}
        transition={{
          duration: isActive ? 2.5 : 3,
          repeat: Infinity,
          ease: "easeInOut",
        }}
      />

      {/* Middle glow ring */}
      <motion.div
        className="absolute w-[256px] h-[256px] lg:w-[288px] lg:h-[288px] xl:w-[320px] xl:h-[320px] rounded-full"
        style={{
          background: isActive
            ? "radial-gradient(circle, rgba(220, 20, 20, 0.4) 0%, transparent 70%)"
            : "radial-gradient(circle, rgba(204, 0, 0, 0.15) 0%, transparent 70%)",
        }}
        animate={{
          scale: isActive ? [1, 1.5, 1] : pulseIntensity,
          opacity: isActive ? [0.8, 0.4, 0.8] : [0.5, 0.7, 0.5],
        }}
        transition={{
          duration: isActive ? 2.5 : 3,
          repeat: Infinity,
          ease: "easeInOut",
          delay: isActive ? 0.3 : 0.5,
        }}
      />

      {/* Active mode red/clinical ring */}
      {isActive && (
        <motion.div
          className="absolute w-[224px] h-[224px] lg:w-[252px] lg:h-[252px] xl:w-[280px] xl:h-[280px] rounded-full"
          style={{
            background: "radial-gradient(circle, rgba(204, 0, 0, 0.3) 0%, rgba(220, 20, 20, 0.15) 50%, transparent 70%)",
            border: "2px solid rgba(204, 0, 0, 0.4)",
          }}
          animate={{
            scale: [1, 1.2, 1],
            opacity: [0.6, 0.9, 0.6],
            rotate: [0, 360],
          }}
          transition={{
            scale: {
              duration: 2.5,
              repeat: Infinity,
              ease: "easeInOut",
            },
            opacity: {
              duration: 2.5,
              repeat: Infinity,
              ease: "easeInOut",
            },
            rotate: {
              duration: 8,
              repeat: Infinity,
              ease: "linear",
            },
          }}
        />
      )}

      {/* Active mode - energy particles emanating toward bubbles (315-degree angle) */}
      {isActive && (
        <>
          {/* Curved particles moving toward bubble zone - only visible when bubble is present */}
          {hasBubble && [...Array(12)].map((_, i) => {
            const angle = bubbleAngle; // Use the provided bubble angle
            const distance = 220; // Travel distance toward bubble area
            const endX = Math.cos(angle) * distance;
            const endY = Math.sin(angle) * distance;
            
            // Create curved path by adding perpendicular offset at midpoint
            const curveOffset = (i % 2 === 0 ? 40 : -40); // Alternate curve direction
            const midX = (endX / 2) + Math.cos(angle + Math.PI / 2) * curveOffset;
            const midY = (endY / 2) + Math.sin(angle + Math.PI / 2) * curveOffset;
            
            return (
              <motion.div
                key={`particle-${i}`}
                className="absolute w-3 h-3 rounded-full bg-white"
                style={{
                  left: "50%",
                  top: "50%",
                  marginLeft: "-6px",
                  marginTop: "-6px",
                  boxShadow: "0 0 12px rgba(255, 255, 255, 0.9), 0 0 20px rgba(204, 0, 0, 0.6)",
                }}
                animate={{
                  x: [0, midX, endX],
                  y: [0, midY, endY],
                  opacity: [0, 1, 1, 0],
                  scale: [0.5, 1.2, 1, 0.8],
                }}
                transition={{
                  duration: 2.5,
                  repeat: Infinity,
                  delay: i * 0.2,
                  ease: "easeInOut",
                }}
              />
            );
          })}
          
          {/* Additional faster particles for more prominent effect - only visible when bubble is present */}
          {hasBubble && [...Array(8)].map((_, i) => {
            const angle = bubbleAngle;
            const distance = 200;
            const endX = Math.cos(angle) * distance;
            const endY = Math.sin(angle) * distance;
            
            return (
              <motion.div
                key={`fast-particle-${i}`}
                className="absolute w-2 h-2 rounded-full bg-red-400"
                style={{
                  left: "50%",
                  top: "50%",
                  marginLeft: "-4px",
                  marginTop: "-4px",
                  boxShadow: "0 0 8px rgba(204, 0, 0, 0.8)",
                }}
                animate={{
                  x: [0, endX],
                  y: [0, endY],
                  opacity: [0, 0.8, 0.6, 0],
                  scale: [0.3, 1, 0.7],
                }}
                transition={{
                  duration: 1.8,
                  repeat: Infinity,
                  delay: i * 0.22,
                  ease: "easeOut",
                }}
              />
            );
          })}
        </>
      )}

      {/* Main sphere */}
      <motion.div
        className="relative w-[192px] h-[192px] lg:w-[216px] lg:h-[216px] xl:w-[240px] xl:h-[240px] rounded-full overflow-hidden"
        style={{
          background: isActive
            ? "radial-gradient(circle at 35% 35%, #fca5a5, #f87171, #dc2626, #b91c1c, #7f1d1d)"
            : "radial-gradient(circle at 35% 35%, #fecaca, #f87171, #dc2626, #b91c1c, #7f1d1d)",
          boxShadow: isActive
            ? `
                0 0 80px rgba(220, 38, 38, 0.5),
                0 0 120px rgba(204, 0, 0, 0.3),
                inset -30px -30px 80px rgba(0, 0, 0, 0.6),
                inset 30px 30px 80px rgba(255, 200, 200, 0.5),
                inset 0 0 100px rgba(220, 38, 38, 0.3)
              `
            : `
                0 0 50px rgba(220, 38, 38, 0.4),
                0 0 80px rgba(204, 0, 0, 0.2),
                inset -25px -25px 70px rgba(0, 0, 0, 0.5),
                inset 25px 25px 70px rgba(255, 200, 200, 0.4),
                inset 0 0 80px rgba(220, 38, 38, 0.2)
              `,
        }}
        animate={{
          scale: isActive ? [1, 1.15, 1] : pulseIntensity,
          rotate: 360,
        }}
        transition={{
          scale: {
            duration: isActive ? 2.5 : 3,
            repeat: Infinity,
            ease: "easeInOut",
          },
          rotate: {
            duration: isActive ? 20 : 40,
            repeat: Infinity,
            ease: "linear",
          },
        }}

      >
        {/* Primary highlight - top left */}
        <div
          className="absolute top-[30px] left-[48px] w-[96px] h-[96px] rounded-full pointer-events-none"
          style={{
            background: "radial-gradient(circle, rgba(255, 255, 255, 0.8) 0%, rgba(255, 255, 255, 0.4) 30%, transparent 70%)",
          }}
        />
        
        {/* Globe meridian lines - vertical stripes that rotate horizontally */}
        {[...Array(8)].map((_, i) => (
          <div
            key={`meridian-${i}`}
            className="absolute top-0 left-1/2 w-px h-full -translate-x-1/2 pointer-events-none"
            style={{
              background: "linear-gradient(to bottom, transparent, rgba(255, 255, 255, 0.15) 20%, rgba(255, 255, 255, 0.15) 80%, transparent)",
              transformOrigin: "center",
            }}
          />
        ))}
        
        {/* Globe latitude circles - horizontal bands */}
        {[...Array(5)].map((_, i) => {
          const size = 224 - Math.abs(i - 2) * 48;
          const top = 8 + i * 56;
          return (
            <div
              key={`latitude-${i}`}
              className="absolute left-1/2 -translate-x-1/2 rounded-full border border-white/12 pointer-events-none"
              style={{
                width: `${size}px`,
                height: `${size * 0.25}px`,
                top: `${top}px`,
              }}
            />
          );
        })}



        {/* 3D Mesh Network Core - replaces white ring */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[144px] h-[144px] pointer-events-none">
          {/* Central glow */}
          <motion.div
            className="absolute inset-0 rounded-full"
            style={{
              background: "radial-gradient(circle, rgba(255, 255, 255, 0.3) 0%, transparent 70%)",
            }}
            animate={{
              scale: isActive ? [1, 1.2, 1] : [1, 1.05, 1],
              opacity: isActive ? [0.6, 0.9, 0.6] : [0.4, 0.6, 0.4],
            }}
            transition={{
              duration: isActive ? 2 : 3,
              repeat: Infinity,
              ease: "easeInOut",
            }}
          />
          
          {/* 3D Mesh Grid - Only lines, no particles */}
          {!isActive && (
            <>
              {/* Rotating mesh lines - horizontal rotation only */}
              {[...Array(6)].map((_, lineIndex) => (
                <motion.div
                  key={`v-line-${lineIndex}`}
                  className="absolute top-1/2 left-1/2 w-px h-[128px] -translate-x-1/2 -translate-y-1/2 pointer-events-none"
                  style={{
                    background: "linear-gradient(to bottom, transparent, rgba(255, 255, 255, 0.4) 50%, transparent)",
                    transformOrigin: "center",
                  }}
                  animate={{
                    rotate: [lineIndex * 30, lineIndex * 30 + 360],
                  }}
                  transition={{
                    duration: 10,
                    repeat: Infinity,
                    ease: "linear",
                  }}
                />
              ))}
            </>
          )}
          
          {/* Active mode - neural network effect */}
          {isActive && (
            <>
              {/* Pulsing neural nodes */}
              {[...Array(12)].map((_, i) => {
                const angle = (i / 12) * Math.PI * 2;
                const radius = 48;
                return (
                  <motion.div
                    key={`node-${i}`}
                    className="absolute w-2 h-2 rounded-full bg-white"
                    style={{
                      left: `calc(50% + ${Math.cos(angle) * radius}px)`,
                      top: `calc(50% + ${Math.sin(angle) * radius}px)`,
                      boxShadow: "0 0 8px rgba(255, 255, 255, 1)",
                    }}
                    animate={{
                      scale: [1, 1.5, 1],
                      opacity: [0.6, 1, 0.6],
                    }}
                    transition={{
                      duration: 1.5,
                      repeat: Infinity,
                      delay: i * 0.1,
                      ease: "easeInOut",
                    }}
                  />
                );
              })}
              
              {/* Connection lines between nodes */}
              {[...Array(6)].map((_, i) => (
                <motion.div
                  key={`connection-${i}`}
                  className="absolute top-1/2 left-1/2 w-[96px] h-px -translate-x-1/2 -translate-y-1/2"
                  style={{
                    background: "linear-gradient(to right, transparent, rgba(255, 255, 255, 0.6) 50%, transparent)",
                    transformOrigin: "center",
                  }}
                  animate={{
                    rotate: [i * 30, i * 30 + 360],
                    opacity: [0.3, 0.8, 0.3],
                  }}
                  transition={{
                    rotate: {
                      duration: 8,
                      repeat: Infinity,
                      ease: "linear",
                    },
                    opacity: {
                      duration: 2,
                      repeat: Infinity,
                      ease: "easeInOut",
                      delay: i * 0.2,
                    },
                  }}
                />
              ))}
              

            </>
          )}
          

        </div>
      </motion.div>
      </div>

      {/* Activation status text - conditional positioning */}
      {isActive ? (
        // Active state: position in the gap between sphere and word lake, to the right
        <motion.div
          className="absolute right-[-120px] lg:right-[-140px] xl:right-[-160px] top-[160px] lg:top-[180px] xl:top-[200px] text-right"
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: 20 }}
          transition={{ delay: 0.3 }}
        >
          <p className="text-gray-700 flex items-center gap-1 whitespace-nowrap text-sm lg:text-base">
            ⚡ SAVANT ACTIVE
          </p>
        </motion.div>
      ) : (
        // Listening state: same position as Agent Active
        <motion.div
          className="absolute right-[-120px] lg:right-[-140px] xl:right-[-160px] top-[160px] lg:top-[180px] xl:top-[200px] text-right"
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.5 }}
        >
          <p className="text-gray-700 flex items-center gap-1 whitespace-nowrap text-sm lg:text-base">
            Listening
            <span className="inline-flex gap-1">
              <motion.span
                className="text-2xl leading-none"
                animate={{ opacity: [0.2, 1, 0.2] }}
                transition={{ duration: 1.2, repeat: Infinity, delay: 0 }}
              >
                •
              </motion.span>
              <motion.span
                className="text-2xl leading-none"
                animate={{ opacity: [0.2, 1, 0.2] }}
                transition={{ duration: 1.2, repeat: Infinity, delay: 0.3 }}
              >
                •
              </motion.span>
              <motion.span
                className="text-2xl leading-none"
                animate={{ opacity: [0.2, 1, 0.2] }}
                transition={{ duration: 1.2, repeat: Infinity, delay: 0.6 }}
              >
                •
              </motion.span>
            </span>
          </p>
        </motion.div>
      )}
    </div>
  );
}