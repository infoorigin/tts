import { motion } from "motion/react";
import { Brain, Wrench, MessageSquare } from "lucide-react";
import { useEffect, useState } from "react";

interface ThoughtBubbleProps {
  type: "thought" | "tool" | "response";
  heading: string;
  index: number;
  angle: number;
  onReachStatic: () => void;
  onComplete: () => void;
}

export function ThoughtBubble({ type, heading, angle, onReachStatic }: ThoughtBubbleProps) {
  const distance = 350; // Distance to travel horizontally
  const endX = Math.cos(angle) * distance; // X position based on angle
  // Fixed Y position: 20px above playbook memory top edge
  // Playbook total height when active: Header(40px) + Content(240px) + Footer(32px) = 312px
  // Playbook is centered, so top edge is at: center - (312/2) = -156px
  // Bubble height is ~60-70px, so we need to account for that too
  // To ensure bottom of bubble is 20px above playbook top: -156 - 20 - 70 = -246px
  const endY = -250; // Fixed at 20px above playbook top (accounting for bubble height)
  const [hasReachedStatic, setHasReachedStatic] = useState(false);

  // Call onReachStatic after bubble reaches static position (15% of animation = 900ms)
  useEffect(() => {
    const timer = setTimeout(() => {
      if (!hasReachedStatic) {
        setHasReachedStatic(true);
        onReachStatic();
      }
    }, 900);
    
    return () => clearTimeout(timer);
  }, [onReachStatic, hasReachedStatic]);

  const getTypeConfig = () => {
    switch (type) {
      case "thought":
        return {
          Icon: Brain,
          bgClass: "border-2",
          iconBg: "bg-[#CC0000]",
          textClass: "text-[#CC0000]",
          label: "💭 Reasoning",
          shadowColor: "rgba(204, 0, 0, 0.4)",
          trailClass: "bg-[#CC0000]/20",
          borderColor: "rgba(204, 0, 0, 0.4)",
          backgroundColor: "rgba(204, 0, 0, 0.05)",
        };
      case "tool":
        return {
          Icon: Wrench,
          bgClass: "border-2",
          iconBg: "bg-gray-600",
          textClass: "text-gray-700",
          label: "🔧 Tool Call",
          shadowColor: "rgba(75, 85, 99, 0.4)",
          trailClass: "bg-gray-600/20",
          borderColor: "rgba(75, 85, 99, 0.4)",
          backgroundColor: "rgba(75, 85, 99, 0.05)",
        };
      case "response":
        return {
          Icon: MessageSquare,
          bgClass: "border-2",
          iconBg: "bg-[#CC0000]",
          textClass: "text-[#CC0000]",
          label: "💬 Response",
          shadowColor: "rgba(204, 0, 0, 0.5)",
          trailClass: "bg-[#CC0000]/20",
          borderColor: "rgba(204, 0, 0, 0.5)",
          backgroundColor: "rgba(204, 0, 0, 0.05)",
        };
    }
  };

  const config = getTypeConfig();
  const { Icon } = config;
  
  return (
    <motion.div
      className="absolute top-1/2 left-1/2 z-50"
      style={{
        transformOrigin: "center",
      }}
      initial={{
        x: 0,
        y: 0,
        opacity: 0,
        scale: 0,
      }}
      animate={{
        x: endX,
        y: endY,
        opacity: 1,
        scale: 1,
      }}
      exit={{
        opacity: 0,
        scale: 0.8,
      }}
      transition={{
        duration: 0.6,
        ease: "easeOut",
      }}
    >
      <div
        className={`relative px-5 py-3 rounded-2xl backdrop-blur-md ${config.bgClass}`}
        style={{
          boxShadow: `0 0 30px ${config.shadowColor}`,
          borderColor: config.borderColor,
          backgroundColor: "rgba(255, 255, 255, 0.95)",
          minWidth: "200px",
          maxWidth: "250px",
        }}
      >
        {/* Icon */}
        <motion.div
          className={`absolute -top-3 -left-3 p-2 rounded-full ${config.iconBg}`}
          animate={{
            rotate: 360,
          }}
          transition={{
            duration: 2,
            repeat: Infinity,
            ease: "linear",
          }}
        >
          <Icon className="w-4 h-4 text-white" />
        </motion.div>

        {/* Label */}
        <div className={`text-xs uppercase tracking-wider mb-1 ${config.textClass}`}>
          {config.label}
        </div>

        {/* Heading (truncated) with better contrast */}
        <div className="text-gray-900 text-sm truncate drop-shadow-sm">
          {heading.length > 30 ? heading.substring(0, 30) + "..." : heading}
        </div>

        {/* Energy trail */}
        <motion.div
          className={`absolute inset-0 rounded-2xl ${config.trailClass}`}
          animate={{
            opacity: [0.5, 0, 0.5],
            scale: [1, 1.1, 1],
          }}
          transition={{
            duration: 1.5,
            repeat: Infinity,
            ease: "easeInOut",
          }}
        />
      </div>
    </motion.div>
  );
}