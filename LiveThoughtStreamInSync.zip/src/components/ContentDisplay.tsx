import { motion, AnimatePresence } from "motion/react";
import { Brain, Wrench, MessageSquare, Volume2, VolumeX } from "lucide-react";
import { useState, useEffect, useRef, forwardRef } from "react";
import ReactMarkdown from "react-markdown";
import { eventQueue, type QueuedEvent } from "../services/eventQueue";
import { streamingTTS } from "../services/streamingTTS";
import { Switch } from "./ui/switch";

interface ContentDisplayProps {
  events: QueuedEvent[];
  workflowCompleted: boolean; // Whether workflow has signaled completion
  onTypingStart?: (eventIndex: number) => void; // Called when typing starts for an event
  onTypingEnd?: (eventIndex: number) => void; // Called when typing ends for an event
  isActive: boolean; // Whether the agent is active
  hasBeenActive: boolean; // Whether the agent has ever been activated (keeps UI visible)
}

interface ContentItemProps {
  event: QueuedEvent;
  eventIndex: number;
  isActive: boolean; // Only the active item should type
  onComplete: () => void; // Notify parent when typing is complete
  onTypingStart?: (eventIndex: number) => void; // Called when typing starts
  onTypingEnd?: (eventIndex: number) => void; // Called when typing ends
  audioEnabled?: boolean; // Whether audio is enabled
}

const ContentItem = forwardRef<HTMLDivElement, ContentItemProps>(
  function ContentItem({ event, eventIndex, isActive, onComplete, onTypingStart, onTypingEnd, audioEnabled = true }, ref) {
  const [displayedText, setDisplayedText] = useState("");
  const [currentLineIndex, setCurrentLineIndex] = useState(0);
  const [currentCharIndex, setCurrentCharIndex] = useState(0);
  const [isTyping, setIsTyping] = useState(false);
  const [isComplete, setIsComplete] = useState(false);
  const itemRef = useRef<HTMLDivElement>(null);
  const hasCalledComplete = useRef(false);
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);
  const audioCompleted = useRef(false);
  const typingCompleted = useRef(false);
  
  // Function to check if both audio and typing are done
  const checkBothComplete = () => {
    const audioIsDone = audioCompleted.current;
    const typingIsDone = typingCompleted.current;
    
    console.log(`[ContentItem ${event.no}] Checking completion - Audio: ${audioIsDone}, Typing: ${typingIsDone}`);
    
    if (audioIsDone && typingIsDone && !hasCalledComplete.current) {
      hasCalledComplete.current = true;
      console.log(`[ContentItem ${event.no}] Both audio and typing complete, notifying parent`);
      setTimeout(() => {
        onComplete();
        if (onTypingEnd) {
          onTypingEnd(eventIndex);
        }
      }, 100);
    }
  };

  // Start typing when this item becomes active
  useEffect(() => {
    if (isActive && !isComplete && !isTyping) {
      console.log(`[ContentItem ${event.no}] Activated, starting sequence`);
      
      // Check if this event should use TTS (thought or response, not tool)
      const shouldUseTTS = audioEnabled && (event.type === "thought" || event.type === "response");
      
      if (shouldUseTTS) {
        // Get the full text content for TTS
        const fullText = event.content.join(" ");
        console.log(`[ContentItem ${event.no}] Starting TTS and typewriter SIMULTANEOUSLY for ${event.type} event`);
        setIsPlayingAudio(true);
        
        // Start TTS in background
        streamingTTS.speak(fullText).then(() => {
          console.log(`[ContentItem ${event.no}] Audio playback completed`);
          setIsPlayingAudio(false);
          audioCompleted.current = true;
          checkBothComplete();
        });
        
        // Start typing immediately (not waiting for audio)
        setIsTyping(true);
        if (onTypingStart) {
          onTypingStart(eventIndex);
        }
      } else {
        // Tool events - start typing immediately without TTS
        console.log(`[ContentItem ${event.no}] Starting typewriter (no TTS for tool events)`);
        audioCompleted.current = true; // Mark as done since we're not using audio
        setIsTyping(true);
        if (onTypingStart) {
          onTypingStart(eventIndex);
        }
      }
    }
  }, [isActive, isComplete, isTyping, event.no, event.type, event.content, onTypingStart, eventIndex, audioEnabled]);
  
  // Scroll into view when this item becomes active
  useEffect(() => {
    if (itemRef.current && isActive) {
      setTimeout(() => {
        itemRef.current?.scrollIntoView({ 
          behavior: 'smooth', 
          block: 'start',
          inline: 'nearest'
        });
      }, 100);
    }
  }, [isActive]);
  
  // Cleanup audio on unmount
  useEffect(() => {
    return () => {
      // Stop any ongoing audio for this event
      if (isPlayingAudio) {
        streamingTTS.stop();
      }
    };
  }, [isPlayingAudio]);

  // Typewriter effect
  useEffect(() => {
    if (!isTyping) return;
    
    // Safety check for empty content
    if (!event.content || event.content.length === 0) {
      console.log(`[ContentItem ${event.no}] Empty content, completing immediately`);
      setIsTyping(false);
      setIsComplete(true);
      typingCompleted.current = true;
      checkBothComplete();
      return;
    }
    
    // Check if we've finished all lines
    if (currentLineIndex >= event.content.length) {
      console.log(`[ContentItem ${event.no}] Typing complete, checking if audio is also done`);
      setIsTyping(false);
      setIsComplete(true);
      typingCompleted.current = true;
      checkBothComplete();
      return;
    }
    
    const currentLine = event.content[currentLineIndex] || "";
    
    // Check if we've finished current line
    if (currentCharIndex < currentLine.length) {
      // Type next character
      const timeout = setTimeout(() => {
        setDisplayedText(prev => prev + currentLine[currentCharIndex]);
        setCurrentCharIndex(prev => prev + 1);
      }, 8); // 8ms per character
      
      return () => clearTimeout(timeout);
    } else {
      // Move to next line
      const timeout = setTimeout(() => {
        if (currentLineIndex < event.content.length - 1) {
          setDisplayedText(prev => prev + "\n");
          setCurrentLineIndex(prev => prev + 1);
          setCurrentCharIndex(0);
        } else {
          setIsTyping(false);
          setIsComplete(true);
          typingCompleted.current = true;
          console.log(`[ContentItem ${event.no}] Typing complete, checking if audio is also done`);
          checkBothComplete();
        }
      }, 20); // Pause between lines
      
      return () => clearTimeout(timeout);
    }
  }, [currentCharIndex, currentLineIndex, event.content, isTyping, event.no, onComplete, onTypingEnd, eventIndex]);

  const getTypeConfig = () => {
    switch (event.type) {
      case "thought":
        return {
          Icon: Brain,
          label: "COGNITIVE ANALYSIS",
          color: "#CC0000",
          colorLight: "rgba(204, 0, 0, 0.08)",
        };
      case "tool":
        return {
          Icon: Wrench,
          label: "TOOL EXECUTION",
          color: "#6B7280",
          colorLight: "rgba(107, 114, 128, 0.08)",
        };
      case "response":
        return {
          Icon: MessageSquare,
          label: "AGENT RESPONSE",
          color: "#CC0000",
          colorLight: "rgba(204, 0, 0, 0.08)",
        };
    }
  };

  const config = getTypeConfig();
  const { Icon } = config;

  return (
    <motion.div
      ref={itemRef}
      initial={{ opacity: 0, x: -10 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.5, ease: "easeOut" }}
      className="mb-6 relative group"
    >
      {/* Subtle vertical line connector */}
      <div className="absolute left-0 top-0 bottom-0 w-px bg-gradient-to-b from-transparent via-gray-200 to-transparent opacity-40" />
      
      {/* Subtle glow indicator when typing */}
      {isTyping && (
        <motion.div
          className="absolute left-0 top-0 bottom-0 w-px"
          style={{ backgroundColor: config.color }}
          initial={{ opacity: 0 }}
          animate={{ opacity: [0.3, 0.6, 0.3] }}
          transition={{ duration: 2, repeat: Infinity }}
        />
      )}
      
      {/* Main content area */}
      <div className="pl-5 pr-4 py-3 relative">
        {/* Type indicator dot */}
        <motion.div
          className="absolute left-[-4px] top-5 w-2 h-2 rounded-full border-2 border-white shadow-sm"
          style={{ backgroundColor: config.color }}
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ delay: 0.2 }}
        />
        
        {/* Content wrapper */}
        <div className="relative">
          {/* Subtle header */}
          <div className="flex items-center gap-3 mb-2">
            <div 
              className="p-1.5 rounded-md"
              style={{ backgroundColor: config.colorLight }}
            >
              <Icon className="w-3.5 h-3.5" style={{ color: config.color }} />
            </div>
            <div className="flex items-center gap-2 flex-1">
              <span 
                className="text-[10px] tracking-widest opacity-50"
                style={{ color: config.color }}
              >
                {config.label}
              </span>
              <span className="text-xs text-gray-400">·</span>
              <span className="text-xs text-gray-500">{event.heading}</span>
            </div>
            {isPlayingAudio && (
              <div className="flex items-center gap-1.5">
                <span className="text-xs text-gray-400">Audio streaming</span>
                <motion.div
                  className="w-1.5 h-1.5 rounded-full"
                  style={{ backgroundColor: config.color }}
                  animate={{ opacity: [0.4, 1, 0.4] }}
                  transition={{ duration: 1.5, repeat: Infinity }}
                />
              </div>
            )}
            {isTyping && !isPlayingAudio && (
              <motion.div
                className="w-1.5 h-1.5 rounded-full"
                style={{ backgroundColor: config.color }}
                animate={{ opacity: [0.4, 1, 0.4] }}
                transition={{ duration: 1.5, repeat: Infinity }}
              />
            )}
          </div>
          
          {/* Content text */}
          <div className="pl-5 text-gray-700 text-sm leading-relaxed prose prose-sm max-w-none prose-headings:text-gray-700 prose-p:text-gray-700 prose-p:my-1.5 prose-strong:text-gray-800 prose-code:text-gray-700 prose-code:bg-gray-100/50 prose-code:px-1.5 prose-code:py-0.5 prose-code:rounded prose-ul:text-gray-700 prose-ol:text-gray-700 prose-li:text-gray-700 prose-li:my-0.5">
            {isPlayingAudio && (
              <div className="flex items-center gap-2 text-gray-500 italic mb-2">
                <motion.div
                  className="flex gap-1"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                >
                  {[0, 1, 2].map((i) => (
                    <motion.div
                      key={i}
                      className="w-1 h-3 rounded-full"
                      style={{ backgroundColor: config.color }}
                      animate={{
                        scaleY: [1, 1.5, 1],
                        opacity: [0.5, 1, 0.5]
                      }}
                      transition={{
                        duration: 1,
                        repeat: Infinity,
                        delay: i * 0.15
                      }}
                    />
                  ))}
                </motion.div>
                <span className="text-xs">Streaming thoughts...</span>
              </div>
            )}
            <ReactMarkdown>{displayedText}</ReactMarkdown>
            {isTyping && !isPlayingAudio && (
              <motion.span
                className="inline-block w-1 h-3.5 ml-0.5 align-middle"
                style={{ backgroundColor: config.color }}
                animate={{ opacity: [1, 0.2, 1] }}
                transition={{ duration: 0.8, repeat: Infinity }}
              />
            )}
          </div>
        </div>
      </div>
      
      {/* Subtle bottom divider */}
      <div className="absolute bottom-0 left-5 right-4 h-px bg-gradient-to-r from-transparent via-gray-200/0 to-transparent group-hover:via-gray-200/40 transition-all duration-300" />
    </motion.div>
  );
});

export function ContentDisplay({ 
  events, 
  workflowCompleted, 
  onTypingStart, 
  onTypingEnd,
  isActive,
  hasBeenActive
}: ContentDisplayProps) {
  const scrollRef = useRef<HTMLDivElement>(null);
  const [activeIndex, setActiveIndex] = useState(0);
  const isTypingRef = useRef(false);
  const completionTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const hasStartedTypingRef = useRef(false); // Track if we've ever started typing in this session
  const [audioEnabled, setAudioEnabled] = useState(false); // Audio toggle state - OFF by default to require user interaction
  const previousEventsLengthRef = useRef(0); // Track previous events length to detect new events
  
  // Handle audio toggle - initialize audio on first enable
  const handleAudioToggle = async (enabled: boolean) => {
    setAudioEnabled(enabled);
    
    if (enabled) {
      // Initialize audio context when user enables audio
      // This counts as a user interaction for browser autoplay policy
      const initialized = await streamingTTS.initializeAudio();
      if (initialized) {
        console.log('[ContentDisplay] Audio enabled and initialized');
      } else {
        console.warn('[ContentDisplay] Audio enabled but initialization failed');
      }
    }
  };
  
  // Reset activeIndex when events array is emptied (reset scenario)
  useEffect(() => {
    if (events.length === 0) {
      console.log('[ContentDisplay] Events cleared, resetting all state');
      setActiveIndex(0);
      isTypingRef.current = false;
      hasStartedTypingRef.current = false;
      previousEventsLengthRef.current = 0;
      eventQueue.publishTypingState(false, null);
      if (completionTimeoutRef.current) {
        clearTimeout(completionTimeoutRef.current);
        completionTimeoutRef.current = null;
      }
    }
  }, [events.length]);
  
  // CENTRALIZED EVENT PROCESSING - detect new events and start typing
  useEffect(() => {
    const currentLength = events.length;
    const previousLength = previousEventsLengthRef.current;
    
    // Detect if new events were added
    if (currentLength > previousLength) {
      console.log(`[ContentDisplay] 📥 New events detected: ${previousLength} -> ${currentLength}`);
      previousEventsLengthRef.current = currentLength;
      
      // If we're not currently typing and there are events to process, start typing
      if (!isTypingRef.current && activeIndex < currentLength) {
        console.log(`[ContentDisplay] 🔵 STARTING typing for event ${activeIndex} (event #${events[activeIndex]?.no})`);
        isTypingRef.current = true;
        hasStartedTypingRef.current = true;
        eventQueue.publishTypingState(true, events[activeIndex]?.no || null);
        
        // Trigger bubble display
        if (onTypingStart) {
          onTypingStart(activeIndex);
        }
      }
    }
  }, [events.length, activeIndex, events, onTypingStart]);

  // Handle when an item completes typing
  const handleItemComplete = (eventIndex: number) => {
    const event = events[eventIndex];
    console.log(`[ContentDisplay] ✅ Item ${eventIndex} (event #${event?.no}) completed typing`);
    
    // Hide bubble for this event
    if (onTypingEnd) {
      onTypingEnd(eventIndex);
    }
    
    const nextIndex = eventIndex + 1;
    
    // Check if there are more events to type
    const hasMoreEvents = nextIndex < events.length;
    
    if (hasMoreEvents) {
      console.log(`[ContentDisplay] ➡️ Moving to next event (${nextIndex}/${events.length})`);
      
      // Immediately start next event's bubble
      if (onTypingStart) {
        onTypingStart(nextIndex);
      }
      
      setActiveIndex(nextIndex);
      // Keep typing state as true - next item will start immediately
    } else {
      // No more events in current queue
      console.log(`[ContentDisplay] ⏸️ Reached end of current events (${nextIndex}/${events.length}), workflow completed: ${workflowCompleted}`);
      
      if (workflowCompleted) {
        // Workflow is done AND we've typed all events - schedule deactivation
        console.log(`[ContentDisplay] 🏁 FINAL EVENT TYPED + WORKFLOW COMPLETED - scheduling typing=false`);
        
        // Clear any existing timeout
        if (completionTimeoutRef.current) {
          clearTimeout(completionTimeoutRef.current);
        }
        
        completionTimeoutRef.current = setTimeout(() => {
          // Double-check no new events arrived during delay
          if (nextIndex >= events.length && workflowCompleted) {
            console.log(`[ContentDisplay] ✅ CONFIRMED: All typing complete - publishing typing=false`);
            isTypingRef.current = false;
            eventQueue.publishTypingState(false, null);
          } else {
            console.log(`[ContentDisplay] ⚠️ Conditions changed during delay - NOT deactivating`);
          }
          completionTimeoutRef.current = null;
        }, 1500); // Give time for visual animations to complete
        
        setActiveIndex(nextIndex);
      } else {
        // Workflow not completed - more events may be coming
        console.log(`[ContentDisplay] ⏳ Waiting for more events (workflow still active)`);
        setActiveIndex(nextIndex);
        // Keep typing=true so sphere stays active
      }
    }
  };

  // Cleanup timeout on unmount
  useEffect(() => {
    return () => {
      if (completionTimeoutRef.current) {
        clearTimeout(completionTimeoutRef.current);
      }
    };
  }, []);

  // Only show events up to activeIndex (currently typing) - don't show future events yet
  const visibleEvents = events.slice(0, activeIndex + 1);

  return (
    <>
      {/* Audio Controls - Always visible, floating at header height */}
      <div className="fixed top-[18px] right-8 z-50 flex items-center gap-2">
        {audioEnabled ? (
          <Volume2 className="w-3.5 h-3.5 text-[#CC0000]/60" />
        ) : (
          <VolumeX className="w-3.5 h-3.5 text-gray-400" />
        )}
        <Switch
          checked={audioEnabled}
          onCheckedChange={handleAudioToggle}
          className="data-[state=checked]:bg-[#CC0000]"
        />
      </div>

      {/* Intelligence Stream Panel - Slides in from right when active */}
      <AnimatePresence>
        {hasBeenActive && (
          <>
            {/* Dividing line */}
            <motion.div 
              className="w-px bg-gradient-to-b from-transparent via-gray-200 to-transparent"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.3 }}
            />

            {/* Zone 2: Intelligence Stream Panel */}
            <motion.div 
              className="w-[35%] lg:w-[32%] xl:w-[28%] h-screen bg-gradient-to-br from-white via-gray-50/30 to-white flex-shrink-0 flex flex-col overflow-hidden relative z-10"
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ 
                type: "spring",
                stiffness: 120,
                damping: 25,
                mass: 1
              }}
            >
              {/* Header with J&J branding */}
              <div className="px-3 py-4 flex-shrink-0 relative">
                <h3 className="text-[#CC0000] text-xs uppercase tracking-widest opacity-80">
                  Intelligence Stream
                </h3>
                <div className="absolute bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-[#CC0000]/20 to-transparent" />
              </div>
              
              {/* Streaming content area */}
              <div ref={scrollRef} className="flex-1 overflow-auto px-3 py-4 relative">
                {/* Subtle ambient glow effect */}
                <div className="absolute top-0 left-1/2 -translate-x-1/2 w-3/4 h-24 bg-gradient-to-b from-gray-100/30 to-transparent blur-2xl pointer-events-none" />
                
                {visibleEvents.length === 0 && (
                  <div className="text-gray-400 text-sm flex items-center gap-2">
                    <div className="w-1 h-1 rounded-full bg-[#CC0000]/60 animate-pulse" />
                    Listening for events...
                  </div>
                )}
                <div className="min-h-full flex flex-col relative">
                  <AnimatePresence mode="popLayout">
                    {visibleEvents.map((event, index) => (
                      <ContentItem
                        key={event.no}
                        event={event}
                        eventIndex={index}
                        isActive={index === activeIndex}
                        onComplete={() => handleItemComplete(index)}
                        onTypingStart={onTypingStart}
                        onTypingEnd={onTypingEnd}
                        audioEnabled={audioEnabled}
                      />
                    ))}
                  </AnimatePresence>
                  {/* Spacer to ensure active items can scroll to center */}
                  <div className="flex-1 min-h-[50vh]" />
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  );
}