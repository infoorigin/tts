# Real API Streaming Setup Guide

This guide explains how to enable real API streaming in your Savant Agentic Platform.

## Current State
- **Testing Mode**: Currently set to `TESTING_MODE = true` in App.tsx
- **Mock Data**: The application currently uses mock/simulated NDJSON events
- **Real API Code**: Available but commented out in the codebase
- **Auto-Start**: The stream starts automatically when the page loads
- **Manual Activation** (Testing Mode): "Activate Agent" button is visible and required to activate the sphere
- **Auto-Activation** (Production Mode): The sphere activates when `workflow_status: "started"` event is received
- **Auto-Deactivation**: The sphere deactivates when `workflow_status: "completed"` event is received

## How to Enable Real API Streaming

### Step 1: Uncomment URL Parameter Parsing (App.tsx)

In `/App.tsx`, find this section and **uncomment it**:

```typescript
// ========== UNCOMMENT BELOW TO GET CONTEXT ID FROM URL ==========
/*
// Extract context ID from URL parameters
// Example URL: http://localhost:3000/?contextId=dr989r6
const getContextIdFromURL = (): string | null => {
  const params = new URLSearchParams(window.location.search);
  return params.get('contextId');
};

const contextId = getContextIdFromURL();

// Log context ID for debugging
useEffect(() => {
  if (contextId) {
    console.log('Context ID from URL:', contextId);
  } else {
    console.log('No context ID found in URL. Using mock data.');
  }
}, [contextId]);
*/
// ================================================================
```

**After uncommenting**, also **comment out or remove** this line:
```typescript
const contextId = null; // MOCK: Set to null to use mock data
```

### Step 2: Uncomment Real API Code (eventStream.ts)

In `/services/eventStream.ts`, find and **uncomment** two sections:

#### Section 1: Enable real API routing
```typescript
// ========== UNCOMMENT BELOW FOR REAL API STREAMING ==========
/*
// Use real API if contextId is provided
if (contextId) {
  this.startRealAPIStream(contextId, onEvent, onComplete);
  return;
}
*/
// ============================================================
```

#### Section 2: Enable real API implementation
Find the `startRealAPIStream` method and **uncomment the entire try-catch block** inside it.

### Step 3: Update API URL (if needed)

In `/services/eventStream.ts`, find this line in the `startRealAPIStream` method:

```typescript
const apiUrl = `http://localhost:8000/api/v1/contexts/${contextId}/log/stream`;
```

Update the base URL if your API is hosted elsewhere:
- Change `http://localhost:8000` to your API server URL
- Keep the path structure: `/api/v1/contexts/${contextId}/log/stream`

### Step 4: Access with Context ID

Open your application with the context ID in the URL:

```
http://localhost:3000/?contextId=dr989r6
```

Replace `dr989r6` with your actual context ID.

**Important**: The stream will start automatically when the page loads. The sphere will remain in "waiting" mode (gentle pulse) until it receives the `workflow_status: "started"` event, at which point it will activate and begin processing events.

## API Requirements

Your streaming API endpoint must:

1. **Accept GET requests** at: `/api/v1/contexts/{contextId}/log/stream`
2. **Return NDJSON format** (newline-delimited JSON)
3. **Send events** in this format:

```json
{"event": "update", "data": {"no": 1, "id": null, "type": "workflow", "heading": "{}", "content": "", "temp": false, "kvps": {"workflow_status": "started", "event_type": "workflow"}}}
{"event": "update", "data": {"no": 3, "id": null, "kvps": {"thoughts": ["Thought 1", "Thought 2"], "headline": "Event Headline", "event_type": "reasoning"}}}
{"event": "update", "data": {"no": 4, "id": null, "type": "tool", "heading": "Using tool", "content": "{}", "temp": false, "kvps": {"event_type": "tool", "headline": "Tool Headline"}}}
```

## Event Type Mapping

The transformation function expects:

| API Field | Internal Usage |
|-----------|---------------|
| `event` | Must be `"update"` (others are ignored) |
| `data.kvps.event_type` | Event type: `"workflow"`, `"reasoning"`, `"tool"`, `"response"` |
| `data.kvps.headline` | Event heading/title (fallback to `data.heading`) |
| `data.kvps.thoughts` | Content array for `"reasoning"` events |
| `data.content` | Content for `"tool"` and `"response"` events |
| `data.kvps.workflow_status` | **`"started"`** activates sphere, **`"completed"`** deactivates sphere |

## Workflow Control

The sphere activation is controlled by workflow events in production:

1. **Page Load**: Stream starts automatically, sphere waits in idle mode
2. **Workflow Start**: When `{"event_type": "workflow", "workflow_status": "started"}` arrives → Sphere activates
3. **Event Processing**: Sphere processes all reasoning, tool, and response events
4. **Workflow Complete**: When `{"event_type": "workflow", "workflow_status": "completed"}` arrives → Sphere deactivates after all events finish

### Testing vs Production

**TESTING MODE** (`TESTING_MODE = true` in App.tsx):
- The "Activate Agent" button is visible
- The event stream **does not start** until you click the button
- When you click the button:
  1. The stream starts
  2. The sphere activates immediately
  3. Events are processed and displayed as they arrive
- Perfect for manual testing and controlling when events start flowing

**PRODUCTION MODE** (`TESTING_MODE = false`):
- The "Activate Agent" button is **hidden**
- `workflow_status: "started"` events **automatically activate** the sphere
- Fully event-driven workflow

**To Switch to Production Mode**:
1. In `/App.tsx`, change the `TESTING_MODE` flag from `true` to `false`:
   ```typescript
   const TESTING_MODE = false; // Change this line
   ```
2. That's it! The button will disappear and auto-activation will be enabled.

## Testing

1. **With Context ID**: Application will connect to real API
   ```
   http://localhost:3000/?contextId=dr989r6
   ```

2. **Without Context ID**: Application will use mock data
   ```
   http://localhost:3000/
   ```

## Troubleshooting

### CORS Issues
If you see CORS errors, ensure your API server allows requests from your frontend origin:

```javascript
// Example Express.js CORS setup
app.use(cors({
  origin: 'http://localhost:3000',
  credentials: true
}));
```

### Connection Errors
- Check that your API server is running on port 8000 (or update the URL)
- Verify the context ID exists in your system
- Check browser console for detailed error messages

### No Events Appearing
- Open browser DevTools → Network tab
- Look for the stream request to `/api/v1/contexts/{contextId}/log/stream`
- Check the response to ensure NDJSON events are being sent
- Verify each event has `"event": "update"` and `data.kvps.event_type`

## Switching Back to Mock Data

To revert to mock data:

1. Comment out the real API sections in both files
2. Set `const contextId = null;` in App.tsx
3. Refresh the application

The application will seamlessly switch back to simulated events.
