# Layout & Flow Update

## Overview
Updated the Savant Control Center layout to optimize space usage and improve visual flow from left to right toward the Intelligence Stream.

---

## Major Changes

### 1. Playbook Position - Moved to Far Left

**Before:**
```
┌────────────────────────────────────────┐
│                                        │
│     [Playbook]    [Sphere]             │
│                                        │
└────────────────────────────────────────┘
```

**After:**
```
┌────────────────────────────────────────┐
│                                        │
│[Playbook]        [Sphere]              │
│                                        │
└────────────────────────────────────────┘
```

**Changes:**
- Changed from `left-8` to `left-0` in PlaybookMemory
- Added absolute positioning container in App.tsx
- Playbook now starts at the very left edge
- Better use of available space

---

### 2. Thought Bubbles - Flow Toward Intelligence Stream

**Before (Upper-Left Quadrant):**
```
        Bubbles ←╮
                 │
            [Sphere]
```
Angle range: 225° - 315° (upper-left)

**After (Right-ward Direction):**
```
[Sphere] → Bubbles → [Intelligence Stream]
```
Angle range: 315° - 45° (toward right side)

**Changes:**
- Updated `generateRandomAngle()` in App.tsx
- New range: 315° to 360° (upper right) and 0° to 45° (right to lower right)
- Improved angle normalization to handle 360° wraparound
- Increased bubble distance from 280px to 350px
- Bubbles now travel toward Intelligence Stream

---

### 3. Lake Cloud - Left to Right Flow

**Before:**
```
┌──────────────────────────────────────┐
│         ← word word word →           │
│         → word word word ←           │  Alternating
│         ← word word word →           │  directions
└──────────────────────────────────────┘
```

**After:**
```
┌──────────────────────────────────────┐
│  → word word word word word → →     │
│  → word word word word word → →     │  All flowing
│  → word word word word word → →     │  left to right
└──────────────────────────────────────┘
```

**Changes:**
- Changed container from `left-1/2 -translate-x-1/2` to `left-0 w-full`
- All rows now flow left to right (removed alternating pattern)
- Gradient changed from `to bottom` to `to right`
- Updated startX/endX coordinates for proper flow
- Increased from 3 to 4 word sets for better coverage

---

### 4. Binary Beam - Left to Right Stream

**Before:**
```
Binary stream scattered in various positions
```

**After:**
```
000111 → → → → 111000 → → → (flowing toward Intelligence Stream)
```

**Changes:**
- Increased from 80 to 120 binary digits
- All digits flow left to right
- Color interpolation updated: red (left) → white (right)
- Fade out effect toward right side
- Better wave motion with adjusted frequency

---

## Technical Details

### Bubble Angle Generation

```typescript
// Old (Upper-Left Quadrant)
const minAngle = 225;
const maxAngle = 315;

// New (Right-ward Direction)
const useUpperRange = Math.random() > 0.5;
const minAngle = useUpperRange ? 315 : 0;
const maxAngle = useUpperRange ? 360 : 45;

// Handle 360° wraparound
let diff = Math.abs(randomAngle - usedAngle);
if (diff > 180) diff = 360 - diff;
```

### Lake Cloud Flow

```typescript
// Old (Alternating)
const isRightToLeft = row % 2 === 0;
const startX = isRightToLeft ? 800 : -400;
const endX = isRightToLeft ? -400 : 800;

// New (All Left to Right)
const startX = -600 - (setIndex * 1200);
const endX = 1400 - (setIndex * 1200);
```

### Layout Structure

```typescript
// Old Layout
<div className="w-full max-w-[800px] flex justify-end pr-16">
  <PlaybookMemory /> {/* left-8 */}
  <MindSphere />
</div>

// New Layout
<div className="w-full flex justify-center">
  <div className="absolute left-0 w-[220px]">
    <PlaybookMemory /> {/* left-0 */}
  </div>
  <MindSphere />
</div>
```

---

## Visual Flow Diagram

### Complete Left-to-Right Flow

```
┌───────────────────────────────────────────────────────────────────┐
│ Savant Control Center                                             │
├───────────────────────────────────────────────────────────────────┤
│                                                                   │
│ [Playbook]                                          [Intelligence │
│  Memory        [Sphere] → Bubbles →                  Stream]     │
│                                                      │            │
│                ↓ Lake Cloud → → →                   │            │
│                000111 → → → 111000 →                 │            │
│                                                      │            │
└───────────────────────────────────────────────────────────────────┘
```

### Flow Elements

1. **Playbook Memory** (far left)
   - Positioned at left edge
   - Always visible
   - Scanning/selecting playbooks

2. **Mind Sphere** (center-left)
   - Main visualization
   - Emits particles toward bubbles
   - Central focus point

3. **Thought Bubbles** (moving right)
   - Emanate from sphere
   - Travel toward Intelligence Stream
   - Angle: 315° - 45° (right-ward)
   - Distance: 350px

4. **Lake Cloud** (below sphere)
   - Flows left to right
   - All rows move in same direction
   - Words + binary digits
   - Continuous stream

5. **Intelligence Stream** (right panel)
   - Destination of visual flow
   - Shows event details
   - Never overlapped by bubbles

---

## Bubble Overlap Prevention

### Intelligence Stream Protection

**Header Position:**
- Intelligence Stream header at top of right panel
- Height: ~52px (py-4 + text)

**Bubble Angles:**
- 315° to 360°: Upper right (above header)
- 0° to 45°: Right to lower right (below header)
- Avoids straight right (0°/360°) which might overlap header

**Bubble Distance:**
- 350px from sphere center
- Ends before reaching Intelligence Stream panel
- Fades out before overlap possible

### Angle Distribution

```
        350° ←  bubbles  → 10°
             ╲         ╱
              ╲       ╱
           340°╲     ╱20°
                ╲   ╱
           330°  [S] 30°
                     
                 320° 40°
                 
        315°           45°
```

**Sweet Spots:**
- 320° - 340° (upper right diagonal)
- 0° - 20° (straight right)
- 20° - 40° (lower right diagonal)

---

## Responsive Behavior

### Desktop (Full Width)
```
[Playbook:220px] [Sphere Area:~600px] | [Stream:28%]
```

### Tablet (Medium Width)
```
[PB:220px] [Sphere:~450px] | [Stream:32%]
```

### Mobile Adjustments
- Playbook scales down
- Sphere size adjusts
- Bubble distances adjust
- Flow maintains left-to-right

---

## Performance Optimizations

### Lake Cloud
- 4 word sets (was 3) for smoother coverage
- Longer animation duration (18-25s) for efficiency
- Proper position calculations prevent re-renders

### Binary Beam
- 120 digits (was 80) for denser effect
- Staggered delays (i * 0.04) for smooth flow
- Opacity optimizations for fade effects

### Bubble Generation
- Smart angle tracking (last 5 angles)
- 15° minimum separation
- Maximum 20 attempts to find valid angle
- Efficient wraparound handling

---

## Testing Checklist

- [x] Playbook positioned at far left edge
- [x] Bubbles flow toward right (Intelligence Stream)
- [x] Lake cloud flows left to right continuously
- [x] Binary beam flows left to right
- [x] No overlap with Intelligence Stream header
- [x] Bubbles maintain proper spacing
- [x] Responsive layout works at all sizes
- [x] Smooth animations throughout
- [x] Proper angle wraparound handling
- [x] Visual flow feels natural

---

## Before/After Comparison

### Before
```
┌─────────────────────────────────────────────┐
│                                             │
│    [Playbook]  [Sphere]                     │
│                   ↖                         │
│                 Bubbles                     │
│                (upper-left)                 │
│                   ↙                         │
│            ← Lake → Cloud ←                 │
│                                             │
└─────────────────────────────────────────────┘
```

**Issues:**
- Wasted space on left
- Bubbles moved away from Intelligence Stream
- Lake cloud alternated directions (chaotic)
- No clear visual flow

### After
```
┌─────────────────────────────────────────────┐
│                                             │
│[Playbook] [Sphere] → Bubbles → [Stream]    │
│                                             │
│          Lake Cloud → → → →                 │
│          Binary → → → →                     │
│                                             │
└─────────────────────────────────────────────┘
```

**Improvements:**
- ✅ Playbook uses left edge (no wasted space)
- ✅ Clear left-to-right flow
- ✅ Bubbles move toward Intelligence Stream
- ✅ Lake cloud flows in one direction
- ✅ Binary beam reinforces direction
- ✅ Visual hierarchy guides eye naturally

---

## Key Benefits

### 1. Better Space Utilization
- Playbook at left edge frees up center space
- Sphere can be more centered
- More room for bubble travel

### 2. Clearer Visual Flow
- Everything flows left → right
- Natural reading direction
- Guides eye to Intelligence Stream

### 3. Improved UX
- Visual elements point to data destination
- Flow matches mental model
- More intuitive to understand

### 4. No Overlaps
- Bubbles stay clear of Intelligence Stream header
- Lake cloud contained in lower area
- Clean separation of zones

### 5. Professional Appearance
- Organized layout
- Consistent direction
- Polished feel

---

## Configuration

### Adjustable Parameters

**Bubble Flow:**
```typescript
// App.tsx - generateRandomAngle()
const minAngle = useUpperRange ? 315 : 0;
const maxAngle = useUpperRange ? 360 : 45;
const minSeparation = 15;
```

**Bubble Distance:**
```typescript
// ThoughtBubble.tsx
const distance = 350; // px from sphere
```

**Lake Cloud Speed:**
```typescript
// MindSphere.tsx
const speed = 18 + (row * 3); // seconds per cycle
```

**Binary Beam:**
```typescript
// MindSphere.tsx
Array.from({ length: 120 }) // number of digits
const frequency = 3; // wave frequency
const amplitude = 20; // wave amplitude
```

---

## Future Enhancements

### Potential Improvements

1. **Dynamic Bubble Targeting**
   - Calculate exact angle to current event
   - Bubbles point to their corresponding stream item

2. **Flow Speed Control**
   - User adjustable flow speed
   - Pause/resume lake cloud

3. **Bubble Trails**
   - Leave subtle trails from sphere to stream
   - Visual connection between zones

4. **Lake Cloud Themes**
   - Different word sets based on context
   - Animated word morphing

5. **Collision Avoidance**
   - Advanced overlap detection
   - Bubbles avoid each other dynamically

---

## Summary

**Major Changes:**
1. ✅ Playbook moved to far left (left-0)
2. ✅ Bubbles flow right toward Intelligence Stream (315°-45°)
3. ✅ Lake cloud flows left to right (all rows)
4. ✅ Binary beam flows left to right
5. ✅ No overlap with Intelligence Stream

**Result:**
A cohesive left-to-right visual flow that guides the user's attention from the Playbook through the Mind Sphere to the Intelligence Stream, creating a natural and intuitive information flow pattern.

---

**Flow perfected! Everything now moves toward the Intelligence Stream.** 🎯
