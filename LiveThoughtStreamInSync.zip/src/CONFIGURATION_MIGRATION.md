# Configuration Migration Guide

This guide helps you migrate from the old inline configuration to the new centralized `/config/environment.ts` system.

## What Changed?

Previously, configuration was scattered across multiple files:
- Testing flags in `App.tsx`
- API URLs in `streamingTTS.ts` and `eventStream.ts`
- Mock settings hardcoded in service files

Now, everything is centralized in one file: `/config/environment.ts`

## Migration Steps

### Step 1: Remove Old Configuration

❌ **OLD** - These settings are now managed in `/config/environment.ts`:

**In `App.tsx`:**
```typescript
// REMOVE THESE LINES (now in /config/environment.ts)
const TESTING_MODE = true;
const USE_MOCK_AUDIO = true;
```

**In `services/streamingTTS.ts`:**
```typescript
// REMOVE THESE LINES (now in /config/environment.ts)
private apiBaseUrl = "http://127.0.0.1:8000/api/v1/tts/stream";
private useMockAudio = true;
private mockAudioFile = "...";
```

**In `services/eventStream.ts`:**
```typescript
// REMOVE THESE LINES (now in /config/environment.ts)
const apiUrl = `http://localhost:8000/api/v1/contexts/${contextId}/log/stream`;
```

### Step 2: Configure Environment

✅ **NEW** - Update `/config/environment.ts`:

```typescript
// Mode Configuration
export const TESTING_MODE = true;        // Was in App.tsx
export const USE_MOCK_AUDIO = true;      // Was in App.tsx
export const USE_MOCK_EVENTS = true;     // New flag for event mocking

// API Endpoints (were scattered in service files)
export const EVENT_STREAM_API = {
  baseUrl: "http://localhost:8000",
  streamPath: "/api/v1/contexts/{contextId}/log/stream",
  // ...
};

export const TTS_API = {
  baseUrl: "http://127.0.0.1:8000",
  streamPath: "/api/v1/tts/stream",
  // ...
};

// Mock Audio (was in streamingTTS.ts)
export const MOCK_AUDIO = {
  filePath: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3",
  volume: 0.3,
};
```

### Step 3: Verify Import Changes

The updated files now import from the config:

**`App.tsx`:**
```typescript
import { 
  TESTING_MODE, 
  USE_MOCK_AUDIO, 
  USE_MOCK_EVENTS,
  logConfiguration 
} from "./config/environment";
```

**`services/streamingTTS.ts`:**
```typescript
import { TTS_API, MOCK_AUDIO, AUDIO_TIMING } from "../config/environment";
```

**`services/eventStream.ts`:**
```typescript
import { getEventStreamUrl, EVENT_STREAM_API, USE_MOCK_EVENTS } from "../config/environment";
```

## Benefits of New System

### 1. Single Source of Truth
All environment settings in one file instead of scattered across the codebase.

### 2. Environment Presets
Quick switching between development, staging, and production:
```typescript
ENV_PRESETS.development   // Local testing
ENV_PRESETS.staging       // QA environment
ENV_PRESETS.production    // Live deployment
```

### 3. Better Documentation
Every setting is documented with comments and examples.

### 4. Easier Deployment
Change environments without touching core application code.

### 5. Configuration Logging
Automatic logging of current configuration on app start:
```typescript
logConfiguration(); // Shows all active settings
```

### 6. Configurable TTS Parameters (NEW!)
Now you can configure TTS voice, engine, and format without code changes:
```typescript
export const TTS_API = {
  baseUrl: "http://127.0.0.1:8080",
  streamPath: "/api/v1/tts/stream",
  params: {
    voice: "Danielle",      // Customize voice
    engine: "long-form",    // Engine mode
    format: "mp3",          // Audio format
  },
};
```

The application automatically builds the correct URL:
```
http://127.0.0.1:8080/api/v1/tts/stream?voice=Danielle&engine=long-form&format=mp3&text=...
```

## Configuration Mapping

Here's where old settings moved to:

| Old Location | New Location | Setting |
|--------------|--------------|---------|
| `App.tsx` | `/config/environment.ts` | `TESTING_MODE` |
| `App.tsx` | `/config/environment.ts` | `USE_MOCK_AUDIO` |
| N/A (new) | `/config/environment.ts` | `USE_MOCK_EVENTS` |
| `streamingTTS.ts` | `/config/environment.ts` | `TTS_API.baseUrl` |
| `streamingTTS.ts` | `/config/environment.ts` | `MOCK_AUDIO.filePath` |
| `streamingTTS.ts` | `/config/environment.ts` | `MOCK_AUDIO.volume` |
| `eventStream.ts` | `/config/environment.ts` | `EVENT_STREAM_API.baseUrl` |
| Hardcoded | `/config/environment.ts` | `AUDIO_TIMING.*` |

## Quick Test

After migration, test that everything works:

1. **Open browser console** - You should see:
   ```
   🔧 Savant Control Center - Configuration
   Environment: DEVELOPMENT
   Testing Mode: ✅ ENABLED
   Mock Audio: ✅ ENABLED
   Mock Events: ✅ ENABLED
   ```

2. **Click "Activate Agent"** - Should work exactly as before

3. **Check status badge** - Should show "• Audio & Events Mock" when using mocks

## Customization Examples

### Example 1: Use Real TTS but Mock Events
```typescript
export const TESTING_MODE = true;
export const USE_MOCK_AUDIO = false;  // Use real TTS API
export const USE_MOCK_EVENTS = true;   // Use mock events

export const TTS_API = {
  baseUrl: "http://your-tts-server:8000",
  // ...
};
```

### Example 2: Use Real APIs with Manual Activation
```typescript
export const TESTING_MODE = true;      // Keep manual button
export const USE_MOCK_AUDIO = false;   // Real TTS
export const USE_MOCK_EVENTS = false;  // Real events

// Update both API endpoints...
```

### Example 3: Full Production Mode
```typescript
export const TESTING_MODE = false;     // Auto-activate
export const USE_MOCK_AUDIO = false;   // Real TTS
export const USE_MOCK_EVENTS = false;  // Real events

export const EVENT_STREAM_API = {
  baseUrl: "https://api.production.com",
  // ...
};

export const TTS_API = {
  baseUrl: "https://tts.production.com",
  // ...
};
```

## Troubleshooting

### Issue: Application doesn't load after migration
**Fix:** Check browser console for import errors. Ensure `/config/environment.ts` exists.

### Issue: "Cannot find module" errors
**Fix:** The config is in `/config/` (not `/services/`). Update import paths:
```typescript
import { TESTING_MODE } from "./config/environment";  // From App.tsx
import { TTS_API } from "../config/environment";      // From services/
```

### Issue: Settings don't seem to apply
**Fix:** 
1. Hard refresh browser (Ctrl+Shift+R / Cmd+Shift+R)
2. Check console for configuration log
3. Verify you edited `/config/environment.ts` (not old files)

### Issue: TypeScript errors
**Fix:** Rebuild TypeScript cache:
```bash
rm -rf node_modules/.cache
npm start
```

## Rollback Plan

If you need to rollback to old configuration system:

1. Restore old flag constants in `App.tsx`
2. Restore old API URL strings in service files
3. Remove `/config/` folder
4. Remove imports from `config/environment`

However, the new system is backward compatible - your application behavior won't change, just the configuration location.

## Next Steps

1. ✅ Review `/config/README.md` for detailed configuration guide
2. ✅ Update your deployment scripts to use new config file
3. ✅ Document your team's custom configuration settings
4. ✅ Consider using environment variables for secrets in production

## Support

- Full configuration guide: `/config/README.md`
- API setup: `/API_SETUP.md`
- TTS integration: `/TTS_INTEGRATION.md`
- Architecture: `/ARCHITECTURE.md`
