# Configuration Guide

This folder contains all environment-specific configuration for the Savant Control Center application.

## Quick Start

### Testing Mode (Default)
The application is pre-configured for local testing:
- Manual activation button
- Mock audio playback
- Hardcoded sample events
- No external APIs required

**Just open the app and click "Activate Agent"!**

### Production Mode
To switch to production mode:

1. Open `/config/environment.ts`
2. Change the flags at the top:
   ```typescript
   export const TESTING_MODE = false;
   export const USE_MOCK_AUDIO = false;
   export const USE_MOCK_EVENTS = false;
   ```
3. Update API endpoints in the file:
   ```typescript
   export const EVENT_STREAM_API = {
     baseUrl: "https://your-api.com",
     // ...
   };
   
   export const TTS_API = {
     baseUrl: "https://your-tts-api.com",
     // ...
   };
   ```

## Configuration Files

### `environment.ts`
**Main configuration file** - Contains all environment settings:
- **Font configuration** (single font for entire app)
- Mode flags (testing vs production)
- API endpoints
- Mock audio settings
- Audio timing configuration
- Environment presets

### `FONT_GUIDE.md`
**Font configuration guide** - How to change the application font:
- Step-by-step instructions
- System font examples
- Google Fonts integration
- Custom font setup

## Configuration Options

### Mode Flags

#### `TESTING_MODE`
- **`true`**: Shows manual "Activate Agent" button for testing
- **`false`**: Auto-activates agent on page load (production behavior)

#### `USE_MOCK_AUDIO`
- **`true`**: Uses local/remote audio file for TTS simulation
- **`false`**: Connects to real TTS API endpoint

#### `USE_MOCK_EVENTS`
- **`true`**: Uses hardcoded sample events (no API calls)
- **`false`**: Connects to real event stream API

### API Configuration

#### Event Stream API
Configure where the application fetches agent events:
```typescript
export const EVENT_STREAM_API = {
  baseUrl: "http://localhost:8000",
  streamPath: "/api/v1/contexts/{contextId}/log/stream",
  headers: {
    Accept: "text/event-stream",
    "Cache-Control": "no-cache",
  },
};
```

#### TTS API
Configure the Text-to-Speech streaming endpoint and voice parameters:
```typescript
export const TTS_API = {
  baseUrl: "http://127.0.0.1:8080",
  streamPath: "/api/v1/tts/stream",
  
  // Voice configuration
  params: {
    voice: "Danielle",      // Voice name
    engine: "long-form",    // TTS engine mode
    format: "mp3",          // Audio format
  },
};
```

**Example API call generated:**
```
http://127.0.0.1:8080/api/v1/tts/stream?voice=Danielle&engine=long-form&format=mp3&text=hello%20world
```

**Customizing TTS Voice:**
Change the `params` object to match your TTS engine's requirements:
- `voice`: Voice identifier (e.g., "Danielle", "Matthew", "Joanna")
- `engine`: Engine mode (e.g., "long-form", "standard", "neural")
- `format`: Audio format (e.g., "mp3", "wav", "ogg")

### Mock Audio Configuration

When using mock audio mode:
```typescript
export const MOCK_AUDIO = {
  // Path to your audio file
  filePath: "/my-audio.mp3",  // Place in /public folder
  
  // Volume level (0.0 to 1.0)
  volume: 0.3,
};
```

**Setup instructions:**
1. Place your audio file in the `/public` folder (e.g., `/public/test-voice.mp3`)
2. Update `filePath` to match (e.g., `"/test-voice.mp3"`)
3. Or use a remote URL (e.g., `"https://example.com/audio.mp3"`)

### Audio Timing

Control how long mock audio plays based on text length:
```typescript
export const AUDIO_TIMING = {
  wordsPerMinute: 150,  // Speaking rate
  minDuration: 1000,    // Minimum 1 second
  maxDuration: 10000,   // Maximum 10 seconds
};
```

## Environment Presets

The file includes three ready-made presets:

### Development (Default)
```typescript
ENV_PRESETS.development
```
- Testing mode enabled
- Mock audio and events
- Local API endpoints

### Staging
```typescript
ENV_PRESETS.staging
```
- Testing mode enabled
- Real APIs (staging)
- Manual activation for QA

### Production
```typescript
ENV_PRESETS.production
```
- Testing mode disabled
- Real APIs (production)
- Auto-activation

*Note: Presets are reference examples. To use them, manually copy values to the main configuration.*

## Helper Functions

### `getCurrentEnvironment()`
Returns the current environment name:
```typescript
getCurrentEnvironment() // Returns: "development" | "staging" | "production" | "custom"
```

### `getEventStreamUrl(contextId)`
Generates the full event stream URL:
```typescript
getEventStreamUrl("abc123") // Returns: "http://localhost:8000/api/v1/contexts/abc123/log/stream"
```

### `logConfiguration()`
Logs current configuration to browser console:
```typescript
logConfiguration()
// Outputs:
// 🔧 Savant Control Center - Configuration
// Environment: DEVELOPMENT
// Testing Mode: ✅ ENABLED
// Mock Audio: ✅ ENABLED
// Mock Events: ✅ ENABLED
// ...
```

## Design System Configuration

### Changing the Application Font

The entire application uses **one single font** that can be changed from a single line in `/config/environment.ts`:

```typescript
export const FONT_FAMILY = "system-ui, -apple-system, sans-serif";
```

**Popular choices:**
```typescript
// System fonts (fastest, no download)
export const FONT_FAMILY = "system-ui, -apple-system, sans-serif";

// Google Font (requires adding <link> to HTML)
export const FONT_FAMILY = "'Inter', sans-serif";

// Custom font (requires @font-face definition)
export const FONT_FAMILY = "'MyCustomFont', sans-serif";
```

👉 **See `/config/FONT_GUIDE.md` for complete font setup instructions**

---

## Common Scenarios

### Scenario 1: Local Development with Mock Data
```typescript
export const TESTING_MODE = true;
export const USE_MOCK_AUDIO = true;
export const USE_MOCK_EVENTS = true;
```
**Use case:** Frontend development, no backend required

### Scenario 2: Testing with Real Backend
```typescript
export const TESTING_MODE = true;
export const USE_MOCK_AUDIO = false;
export const USE_MOCK_EVENTS = false;
// Update API endpoints to point to your backend
```
**Use case:** Integration testing with real APIs

### Scenario 3: Production Deployment
```typescript
export const TESTING_MODE = false;
export const USE_MOCK_AUDIO = false;
export const USE_MOCK_EVENTS = false;
// Update API endpoints to production URLs
```
**Use case:** Live production environment

### Scenario 4: QA/Staging Environment
```typescript
export const TESTING_MODE = true;  // Keep manual control
export const USE_MOCK_AUDIO = false;
export const USE_MOCK_EVENTS = false;
// Update API endpoints to staging URLs
```
**Use case:** QA testing with real APIs but manual control

### Scenario 5: Custom TTS Voice
```typescript
// Use different voice for different environments
export const TTS_API = {
  // ...
  params: {
    voice: "Matthew",        // Male voice
    engine: "neural",        // Higher quality
    format: "mp3",
  },
};
```
**Use case:** Changing voice characteristics or using premium voices

### Scenario 6: Different TTS Engines
```typescript
// Example: Using OpenAI TTS
export const TTS_API = {
  baseUrl: "https://api.openai.com/v1",
  streamPath: "/audio/speech",
  params: {
    voice: "alloy",
    engine: "tts-1",
    format: "mp3",
  },
};

// Example: Using AWS Polly
export const TTS_API = {
  baseUrl: "https://polly.us-east-1.amazonaws.com",
  streamPath: "/v1/speech",
  params: {
    voice: "Joanna",
    engine: "neural",
    format: "mp3",
  },
};
```
**Use case:** Integrating with different TTS providers

## Troubleshooting

### Issue: "Mock Audio" badge shows in production
**Solution:** Set `USE_MOCK_AUDIO = false` in environment.ts

### Issue: Events not loading from API
**Solution:** 
1. Check `USE_MOCK_EVENTS` is `false`
2. Verify `EVENT_STREAM_API.baseUrl` is correct
3. Check browser console for connection errors
4. Ensure backend API is running

### Issue: No audio playing
**Solution:**
- If using mock audio: Check `MOCK_AUDIO.filePath` is correct
- If using real TTS: Check `TTS_API.baseUrl` and verify API is running
- Verify TTS parameters are correct for your engine
- Check browser console for audio errors (look for 404 or URL issues)
- Some browsers block autoplay - check browser settings

### Issue: TTS API returns 400 Bad Request
**Solution:**
- Check that `TTS_API.params` match your TTS engine's expected parameters
- Verify parameter names (voice, engine, format) are correct for your API
- Check browser Network tab to see the actual URL being called
- Some TTS engines use different parameter names (e.g., "model" instead of "engine")

### Issue: Agent doesn't auto-activate in production
**Solution:** Ensure `TESTING_MODE = false`

## Best Practices

1. **Never commit API keys or secrets** to this file
2. **Use environment variables** for sensitive data in production
3. **Test configuration changes** in development first
4. **Document custom configurations** for your team
5. **Keep mock data up-to-date** with real API format

## Support

### Configuration Documentation
- **`QUICK_REFERENCE.md`** - One-page quick reference ⭐
- **`FONT_GUIDE.md`** - Font configuration guide 🎨
- **`URL_FLOW.md`** - Visual guide to URL construction
- **`TTS_EXAMPLES.md`** - TTS provider configurations
- **`TEST_CONFIG.md`** - Testing and validation guide

### Application Documentation
- `/CONFIG_SUMMARY.md` - Complete configuration system summary
- `/CONFIGURATION_MIGRATION.md` - Migration from old system
- `/API_SETUP.md` - Backend API setup guide
- `/TTS_INTEGRATION.md` - TTS integration details
- `/ARCHITECTURE.md` - Application architecture
