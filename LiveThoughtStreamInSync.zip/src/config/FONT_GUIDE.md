# Font Configuration Guide

## Overview
The entire application uses a **single font family** that can be changed from one central location: `/config/environment.ts`

## How to Change the Font

### Step 1: Edit the Configuration
Open `/config/environment.ts` and modify the `FONT_FAMILY` constant:

```typescript
export const FONT_FAMILY = "YOUR_FONT_HERE";
```

### Step 2: Save and Refresh
That's it! The font will update across the entire application.

---

## Font Examples

### System Fonts (No Import Needed)
```typescript
// Default - System font stack
export const FONT_FAMILY = "system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif";

// macOS/iOS optimized
export const FONT_FAMILY = "-apple-system, BlinkMacSystemFont, sans-serif";

// Windows optimized
export const FONT_FAMILY = "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif";
```

### Google Fonts
To use Google Fonts, you need to:

1. **Add the font to your HTML** (in `index.html` or similar):
```html
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
```

2. **Update the config**:
```typescript
export const FONT_FAMILY = "'Inter', sans-serif";
```

**Popular Google Fonts:**
```typescript
// Inter - Modern, clean
export const FONT_FAMILY = "'Inter', sans-serif";

// Roboto - Material Design
export const FONT_FAMILY = "'Roboto', sans-serif";

// Open Sans - Friendly, readable
export const FONT_FAMILY = "'Open Sans', sans-serif";

// Poppins - Geometric, modern
export const FONT_FAMILY = "'Poppins', sans-serif";

// Lato - Professional
export const FONT_FAMILY = "'Lato', sans-serif";

// Montserrat - Bold, geometric
export const FONT_FAMILY = "'Montserrat', sans-serif";
```

### Monospace Fonts
```typescript
// For code or technical interfaces
export const FONT_FAMILY = "'JetBrains Mono', 'Fira Code', 'Courier New', monospace";
```

### Custom Fonts
If you're using custom fonts:

1. **Add font files** to `/public/fonts/`

2. **Define @font-face** in `/styles/globals.css`:
```css
@font-face {
  font-family: 'MyCustomFont';
  src: url('/fonts/my-custom-font.woff2') format('woff2');
  font-weight: normal;
  font-style: normal;
}
```

3. **Update the config**:
```typescript
export const FONT_FAMILY = "'MyCustomFont', sans-serif";
```

---

## Technical Details

### How It Works
1. **Configuration**: The `FONT_FAMILY` constant is defined in `/config/environment.ts`
2. **CSS Variable**: On app initialization, the font is set as `--app-font-family` CSS variable
3. **Global Application**: The font is applied to the `<body>` element via `--font-family` in `/styles/globals.css`
4. **Inheritance**: All child elements inherit this font automatically

### Files Involved
- `/config/environment.ts` - Define the font here
- `/App.tsx` - Reads config and sets CSS variable
- `/styles/globals.css` - Uses the CSS variable for global styling

### Important Notes
- Always include fallback fonts (e.g., `sans-serif`, `serif`, `monospace`)
- Wrap font names with spaces in quotes (e.g., `'Open Sans'`)
- The font applies to the entire application - no need to set it in individual components
- System fonts are fastest as they don't require downloads

---

## Quick Test
To test if your font is working:

1. Change `FONT_FAMILY` in `/config/environment.ts`
2. Save the file
3. Refresh your browser
4. Open DevTools → Inspect any text element
5. Check the "Computed" tab → Look for "font-family"

You should see your configured font applied!
