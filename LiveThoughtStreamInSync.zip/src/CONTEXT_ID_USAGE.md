# Context ID Configuration

## Overview
The Savant Control Center can connect to real-time event streams using a `context_id` parameter. This allows the application to stream live agent events from your backend API.

## How to Use

### Production Mode (Real API)
When `USE_MOCK_EVENTS = false` in `/config/environment.ts`, the application will attempt to connect to the real event stream API.

**URL Format:**
```
https://your-app-url.com/?context_id=YOUR_CONTEXT_ID
```

**Alternative parameter name:**
```
https://your-app-url.com/?contextId=YOUR_CONTEXT_ID
```

### Examples

#### Example 1: With context_id
```
https://savant-control-center.com/?context_id=abc123xyz
```
✅ Will connect to: `http://localhost:8000/api/v1/contexts/abc123xyz/log/stream`

#### Example 2: Without context_id (fallback)
```
https://savant-control-center.com/
```
⚠️ Will fall back to mock events (no real API connection)

## Configuration Flow

### Step-by-Step

1. **Set Production Mode** (`/config/environment.ts`):
   ```typescript
   export const TESTING_MODE = false;
   export const USE_MOCK_EVENTS = false;
   ```

2. **Configure API Base URL** (`/config/environment.ts`):
   ```typescript
   export const EVENT_STREAM_API = {
     baseUrl: "https://api.yourdomain.com",
     streamPath: "/api/v1/contexts/{contextId}/log/stream",
     // ...
   };
   ```

3. **Pass Context ID in URL**:
   ```
   https://your-app.com/?context_id=abc123
   ```

4. **Application Auto-connects**:
   - Reads `context_id` from URL
   - Builds full API URL: `https://api.yourdomain.com/api/v1/contexts/abc123/log/stream`
   - Connects to event stream
   - Activates sphere when it receives `workflow_status: "started"` event

## Debugging

### Check Configuration
Open browser console to see configuration details:
```
🔧 Savant Control Center - Configuration
Environment: PRODUCTION
Testing Mode: ❌ DISABLED
Mock Events: ❌ DISABLED
Context ID: abc123
Event Stream URL: https://api.yourdomain.com/api/v1/contexts/abc123/log/stream
```

### Common Issues

**Issue:** "No context_id found in URL - will use mock events"
- **Cause:** URL doesn't contain `?context_id=xxx` parameter
- **Solution:** Add context_id to URL: `?context_id=YOUR_ID`

**Issue:** Events not streaming
- **Cause:** API endpoint not responding or incorrect URL
- **Solution:** Check EVENT_STREAM_API configuration in `/config/environment.ts`

**Issue:** Still seeing mock events
- **Cause:** `USE_MOCK_EVENTS = true` in config
- **Solution:** Set `USE_MOCK_EVENTS = false` in `/config/environment.ts`

## Testing Locally

### Step 1: Start your backend API
```bash
# Your backend API should be running on configured port
# Example: http://localhost:8000
```

### Step 2: Configure environment
```typescript
// /config/environment.ts
export const TESTING_MODE = false;
export const USE_MOCK_EVENTS = false;
export const EVENT_STREAM_API = {
  baseUrl: "http://localhost:8000",
  streamPath: "/api/v1/contexts/{contextId}/log/stream",
};
```

### Step 3: Load app with context_id
```
http://localhost:5173/?context_id=test123
```

### Step 4: Verify connection in console
```
[EventStream] Using REAL API streaming
Connecting to stream API: http://localhost:8000/api/v1/contexts/test123/log/stream
```

## API Requirements

Your backend API must:
1. Accept GET requests to the stream endpoint
2. Return NDJSON (Newline-Delimited JSON) format
3. Include proper CORS headers
4. Send events with the expected structure (see `/services/eventStream.ts`)

### Expected Event Format
```json
{
  "event": "update",
  "data": {
    "no": 1,
    "id": null,
    "kvps": {
      "event_type": "reasoning",
      "headline": "Starting process",
      "thoughts": ["Step 1", "Step 2"]
    }
  }
}
```

## Related Files
- `/config/environment.ts` - Configuration settings
- `/App.tsx` - Reads context_id from URL
- `/services/eventStream.ts` - Connects to API
- `/services/eventOrchestrator.ts` - Manages event flow
