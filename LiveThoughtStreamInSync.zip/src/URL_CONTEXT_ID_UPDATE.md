# URL Context ID Implementation

## Overview
Removed the context ID input component and implemented URL-based context ID loading. Added a test mode activate button that appears only when `TESTING_MODE = true`.

---

## Changes Made

### 1. Removed Context ID Input Component

**Files Modified:**
- `/App.tsx` - Removed import and usage of ContextIdInput
- `/components/ContentDisplay.tsx` - Removed context input props and rendering

**What Was Removed:**
- ✅ ContextIdInput component import from App.tsx
- ✅ All context input related state (`isListening`, `contextInputExpanded`, `currentContextId`)
- ✅ Context input props passed to ContentDisplay
- ✅ Context input rendering in ContentDisplay

---

### 2. URL Parameter Support

**Implementation in App.tsx:**

```tsx
// Get context ID from URL and auto-start if present
useEffect(() => {
  // Log configuration to console
  logConfiguration();
  
  // Configure mock audio mode
  streamingTTS.setMockMode(USE_MOCK_AUDIO);
  
  // Get context ID from URL parameter
  const urlParams = new URLSearchParams(window.location.search);
  const urlContextId = urlParams.get('context_id') || urlParams.get('contextId') || '';
  
  if (urlContextId) {
    console.log('Context ID found in URL:', urlContextId);
    setContextId(urlContextId);
    
    // Auto-start if not in testing mode (production mode)
    if (!TESTING_MODE) {
      console.log('Auto-starting event stream with URL context ID');
      handleStartListening(urlContextId);
    }
  } else {
    console.log('No context ID in URL. Waiting for manual activation.');
  }
}, []);
```

**Supported URL Formats:**
```
# Both formats supported
?context_id=abc-123-def-456
?contextId=abc-123-def-456

# Full URL examples
http://localhost:5173/?context_id=abc-123-def-456
https://savant.example.com/?contextId=xyz-789
```

---

### 3. Test Mode Activate Button

**Updated handleManualTrigger:**

```tsx
// Manual trigger for testing mode - starts mock stream
const handleManualTrigger = () => {
  if (isActive) {
    console.log("Manual trigger ignored - sphere already active");
    return;
  }
  
  console.log("Manual trigger button clicked (TESTING MODE)");
  
  // Initialize audio on user interaction (button click)
  streamingTTS.initializeAudio().then((initialized) => {
    if (initialized) {
      console.log("Audio initialized via button click");
    }
  });
  
  // Reset state
  setCurrentBubble(null);
  setAllEvents([]);
  usedAnglesRef.current = []; // Clear used angles
  
  // Use context ID from URL if available, otherwise use test ID
  const testContextId = contextId || 'test-context-123';
  console.log("[Test Mode] Starting with context ID:", testContextId);
  
  // Start orchestrator - will use mock events if USE_MOCK_EVENTS is true
  eventOrchestrator.start(testContextId, false);
};
```

**Button Appearance:**
```tsx
<Button
  onClick={handleManualTrigger}
  disabled={isActive}
  className="bg-[#CC0000] hover:bg-red-700 disabled:opacity-50 text-white shadow-lg"
>
  {USE_MOCK_EVENTS ? "Activate (Mock)" : "Activate"}
</Button>
```

**Button Behavior:**
- Only visible when `TESTING_MODE = true`
- Uses context ID from URL if present
- Falls back to `'test-context-123'` if no URL context ID
- Starts mock stream when `USE_MOCK_EVENTS = true`
- Starts real stream (with test context ID) when `USE_MOCK_EVENTS = false`

---

## Usage Scenarios

### Scenario 1: Production Mode (Real API)

**Configuration:**
```typescript
// In /config/environment.ts
export const TESTING_MODE = false;
export const USE_MOCK_AUDIO = false;
export const USE_MOCK_EVENTS = false;
```

**URL:**
```
https://savant.example.com/?context_id=real-context-456
```

**Behavior:**
1. App loads with context ID from URL
2. Automatically starts listening to real event stream API
3. No test buttons visible
4. Uses real TTS API for audio

**Console Output:**
```
Context ID found in URL: real-context-456
Auto-starting event stream with URL context ID
Starting event stream with context ID: real-context-456
```

---

### Scenario 2: Testing Mode with Mock Data

**Configuration:**
```typescript
// In /config/environment.ts
export const TESTING_MODE = true;
export const USE_MOCK_AUDIO = true;
export const USE_MOCK_EVENTS = true;
```

**URL (Optional):**
```
http://localhost:5173/?context_id=test-123
```

**Behavior:**
1. App loads with context ID from URL (if provided)
2. Shows "Activate (Mock)" button below sphere
3. User clicks button to start mock stream
4. Uses mock events and mock audio for testing

**Console Output:**
```
Context ID found in URL: test-123
No auto-start in testing mode. Use Activate button.
[User clicks Activate button]
Manual trigger button clicked (TESTING MODE)
[Test Mode] Starting with context ID: test-123
```

---

### Scenario 3: Testing Mode without URL Context ID

**Configuration:**
```typescript
export const TESTING_MODE = true;
export const USE_MOCK_EVENTS = true;
```

**URL:**
```
http://localhost:5173/
```

**Behavior:**
1. App loads without context ID
2. Shows "Activate (Mock)" button
3. User clicks button
4. Uses default test context ID: `'test-context-123'`

**Console Output:**
```
No context ID in URL. Waiting for manual activation.
[User clicks Activate button]
Manual trigger button clicked (TESTING MODE)
[Test Mode] Starting with context ID: test-context-123
```

---

### Scenario 4: Testing Mode with Real API

**Configuration:**
```typescript
export const TESTING_MODE = true;
export const USE_MOCK_AUDIO = false;
export const USE_MOCK_EVENTS = false;
```

**URL:**
```
http://localhost:5173/?context_id=staging-789
```

**Behavior:**
1. App loads with context ID from URL
2. Shows "Activate" button (not "Mock")
3. User clicks button to connect to real API
4. Uses real event stream and TTS with context ID from URL

**Use Case:** Testing with real backend without auto-start

---

## Flow Diagrams

### Production Flow (TESTING_MODE = false)

```
┌─────────────────────────────────────────────────────────┐
│                    App Loads                            │
└────────────────────┬────────────────────────────────────┘
                     │
                     ▼
           ┌─────────────────────┐
           │ Parse URL for       │
           │ context_id param    │
           └──────────┬──────────┘
                      │
         ┌────────────┴─────────────┐
         │                          │
         ▼                          ▼
   ┌──────────┐              ┌──────────┐
   │ Found?   │              │ Not      │
   │ context  │              │ Found    │
   │ ID       │              │          │
   └────┬─────┘              └────┬─────┘
        │                         │
        ▼                         ▼
   ┌──────────┐              ┌──────────┐
   │ Auto-    │              │ Wait for │
   │ start    │              │ events   │
   │ stream   │              │          │
   └────┬─────┘              └──────────┘
        │
        ▼
   ┌──────────────────────┐
   │ Connect to real API  │
   │ Start listening      │
   │ Show events          │
   └──────────────────────┘
```

---

### Testing Flow (TESTING_MODE = true)

```
┌─────────────────────────────────────────────────────────┐
│                    App Loads                            │
└────────────────────┬────────────────────────────────────┘
                     │
                     ▼
           ┌─────────────────────┐
           │ Parse URL for       │
           │ context_id param    │
           └──────────┬──────────┘
                      │
         ┌────────────┴─────────────┐
         │                          │
         ▼                          ▼
   ┌──────────┐              ┌──────────┐
   │ Found    │              │ Not      │
   │ context  │              │ Found    │
   │ ID       │              │          │
   └────┬─────┘              └────┬─────┘
        │                         │
        └────────────┬────────────┘
                     │
                     ▼
           ┌─────────────────────┐
           │ Show Activate       │
           │ Button (below       │
           │ sphere)             │
           └──────────┬──────────┘
                      │
                      ▼
           ┌─────────────────────┐
           │ User Clicks         │
           │ Activate            │
           └──────────┬──────────┘
                      │
         ┌────────────┴──────────────┐
         │                           │
         ▼                           ▼
   ┌──────────┐              ┌───────────────┐
   │ Use URL  │              │ Use Default   │
   │ context  │              │ 'test-context'│
   │ ID       │              │ '-123'        │
   └────┬─────┘              └────┬──────────┘
        │                         │
        └────────────┬────────────┘
                     │
                     ▼
        ┌────────────────────────┐
        │ USE_MOCK_EVENTS?       │
        └────┬────────────────┬───┘
             │                │
             ▼                ▼
      ┌──────────┐      ┌──────────┐
      │ Yes:     │      │ No:      │
      │ Mock     │      │ Real API │
      │ Events   │      │ Call     │
      └────┬─────┘      └────┬─────┘
           │                 │
           └────────┬────────┘
                    │
                    ▼
           ┌─────────────────┐
           │ Show events     │
           │ in stream       │
           └─────────────────┘
```

---

## URL Parameter Parsing

### Supported Parameters

```typescript
// Both parameter names supported
'context_id'  // Recommended (snake_case)
'contextId'   // Also supported (camelCase)
```

### Parsing Logic

```typescript
const urlParams = new URLSearchParams(window.location.search);
const urlContextId = urlParams.get('context_id') || urlParams.get('contextId') || '';
```

**Examples:**

| URL | Extracted Context ID |
|-----|---------------------|
| `?context_id=abc-123` | `abc-123` |
| `?contextId=xyz-789` | `xyz-789` |
| `?context_id=abc-123&contextId=xyz-789` | `abc-123` (first match) |
| `?other_param=value` | `''` (empty string) |
| No query string | `''` (empty string) |

---

## State Management

### Previous State Structure

```typescript
// ❌ Removed
const [isListening, setIsListening] = useState(false);
const [contextInputExpanded, setContextInputExpanded] = useState(false);
const [currentContextId, setCurrentContextId] = useState<string>("");
```

### New State Structure

```typescript
// ✅ Simplified
const [contextId, setContextId] = useState<string>("");
```

**Benefits:**
- Simpler state management
- Single source of truth for context ID
- No UI state for input expansion
- No listening state tracking

---

## Console Logging

### Production Mode Logs

```javascript
// App starts
🔧 Savant Control Center - Configuration
Environment: PRODUCTION
Testing Mode: ❌ DISABLED
Mock Audio: ❌ DISABLED
Mock Events: ❌ DISABLED
Event Stream API: https://api.yourdomain.com
💡 Enter Context ID in the Intelligence Stream to start listening

// URL has context ID
Context ID found in URL: real-context-456
Auto-starting event stream with URL context ID
Starting event stream with context ID: real-context-456

// OR URL has no context ID
No context ID in URL. Waiting for manual activation.
```

---

### Testing Mode Logs

```javascript
// App starts
🔧 Savant Control Center - Configuration
Environment: DEVELOPMENT
Testing Mode: ✅ ENABLED
Mock Audio: ✅ ENABLED
Mock Events: ✅ ENABLED
Event Source: Mock Data (Hardcoded)
Audio Source: https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3

// URL has context ID
Context ID found in URL: test-123
No context ID in URL. Waiting for manual activation.

// User clicks Activate
Manual trigger button clicked (TESTING MODE)
Audio initialized via button click
[Test Mode] Starting with context ID: test-123
```

---

## Error Handling

### Invalid Context ID in URL

**Scenario:** URL has malformed or invalid context ID

```
?context_id=<script>alert('xss')</script>
```

**Handling:**
- Context ID is extracted as-is (string value)
- Backend API should validate context ID format
- Frontend treats any string as valid
- Backend returns 404 or error if invalid

**Recommendation:** Add URL parameter validation

```typescript
// Optional: Add validation
const urlContextId = urlParams.get('context_id') || '';
if (urlContextId && !isValidContextId(urlContextId)) {
  console.error('Invalid context ID format:', urlContextId);
  // Don't auto-start, show error message
  return;
}
```

---

### Missing Context ID in Production

**Scenario:** Production mode, no context ID in URL

**Behavior:**
```typescript
if (!TESTING_MODE) {
  if (urlContextId) {
    handleStartListening(urlContextId);
  } else {
    // Do nothing - app waits for events
    console.log('No context ID in URL. Waiting for manual activation.');
  }
}
```

**Result:**
- App loads but doesn't start stream
- Intelligence Stream shows: "Listening for events..."
- Sphere remains in listening state
- No events appear until triggered externally

**Solution:** Ensure production URLs always include context ID

---

## Component Interface Changes

### ContentDisplay Component

**Before:**
```typescript
interface ContentDisplayProps {
  events: QueuedEvent[];
  workflowCompleted: boolean;
  onTypingStart?: (eventIndex: number) => void;
  onTypingEnd?: (eventIndex: number) => void;
  onStartListening?: (contextId: string) => void;  // ❌ Removed
  onDisconnect?: () => void;                        // ❌ Removed
  isListening?: boolean;                            // ❌ Removed
  contextInputExpanded?: boolean;                   // ❌ Removed
  onToggleContextInput?: () => void;                // ❌ Removed
  currentContextId?: string;                        // ❌ Removed
}
```

**After:**
```typescript
interface ContentDisplayProps {
  events: QueuedEvent[];
  workflowCompleted: boolean;
  onTypingStart?: (eventIndex: number) => void;
  onTypingEnd?: (eventIndex: number) => void;
}
```

**Impact:**
- Simpler component interface
- No context input UI logic
- Purely focused on event display

---

### App Component

**Before:**
```tsx
<ContentDisplay 
  events={allEvents} 
  workflowCompleted={workflowCompleted}
  onTypingStart={handleTypingStart} 
  onTypingEnd={handleTypingEnd}
  onStartListening={handleStartListening}        // ❌ Removed
  onDisconnect={handleDisconnect}                // ❌ Removed
  isListening={isListening}                      // ❌ Removed
  contextInputExpanded={contextInputExpanded}    // ❌ Removed
  onToggleContextInput={() => setContextInputExpanded(!contextInputExpanded)}  // ❌ Removed
  currentContextId={currentContextId}            // ❌ Removed
/>
```

**After:**
```tsx
<ContentDisplay 
  events={allEvents} 
  workflowCompleted={workflowCompleted}
  onTypingStart={handleTypingStart} 
  onTypingEnd={handleTypingEnd}
/>
```

---

## Testing Instructions

### Test 1: Production Mode with URL Context ID

**Setup:**
```typescript
// config/environment.ts
export const TESTING_MODE = false;
export const USE_MOCK_EVENTS = false;
```

**Steps:**
1. Start app with URL: `http://localhost:5173/?context_id=test-123`
2. Check console for: `Context ID found in URL: test-123`
3. Check console for: `Auto-starting event stream with URL context ID`
4. Verify no Activate button visible
5. Verify app attempts to connect to API

**Expected:**
- ✅ Context ID extracted from URL
- ✅ Auto-start triggered
- ✅ No test buttons visible
- ✅ Connection to real API attempted

---

### Test 2: Production Mode without URL Context ID

**Setup:**
```typescript
export const TESTING_MODE = false;
```

**Steps:**
1. Start app with URL: `http://localhost:5173/`
2. Check console for: `No context ID in URL`
3. Verify no Activate button visible
4. Verify Intelligence Stream shows "Listening for events..."

**Expected:**
- ✅ No context ID found
- ✅ App waits in idle state
- ✅ No test buttons visible

---

### Test 3: Testing Mode with Mock Events

**Setup:**
```typescript
export const TESTING_MODE = true;
export const USE_MOCK_EVENTS = true;
```

**Steps:**
1. Start app (any URL)
2. Verify "Activate (Mock)" button visible below sphere
3. Click "Activate (Mock)" button
4. Verify mock events appear in Intelligence Stream
5. Verify sphere activates

**Expected:**
- ✅ Activate button visible
- ✅ Button shows "(Mock)" suffix
- ✅ Mock events stream on click
- ✅ Sphere activates

---

### Test 4: Testing Mode with URL Context ID

**Setup:**
```typescript
export const TESTING_MODE = true;
export const USE_MOCK_EVENTS = true;
```

**Steps:**
1. Start app with URL: `http://localhost:5173/?context_id=my-test-context`
2. Verify "Activate (Mock)" button visible
3. Click button
4. Check console for: `[Test Mode] Starting with context ID: my-test-context`

**Expected:**
- ✅ Context ID extracted from URL
- ✅ Button uses URL context ID (not default)
- ✅ Console shows correct context ID

---

### Test 5: Testing Mode without URL Context ID

**Setup:**
```typescript
export const TESTING_MODE = true;
```

**Steps:**
1. Start app without context ID: `http://localhost:5173/`
2. Click "Activate" button
3. Check console for: `[Test Mode] Starting with context ID: test-context-123`

**Expected:**
- ✅ No context ID in URL
- ✅ Button uses default test context ID
- ✅ Console shows default ID

---

## Migration Checklist

### Removed Components
- [x] Remove ContextIdInput import from App.tsx
- [x] Remove ContextIdInput import from ContentDisplay.tsx
- [x] Remove ContextIdInput component usage
- [x] Remove context input state variables
- [x] Remove context input props from ContentDisplay

### Added Features
- [x] URL parameter parsing for context_id
- [x] Auto-start in production mode
- [x] Test mode activate button
- [x] Context ID fallback to test ID
- [x] Console logging for context ID source

### Updated Logic
- [x] handleManualTrigger uses URL or default context ID
- [x] handleReset simplified (removed context state)
- [x] ContentDisplay props simplified
- [x] App component state simplified

---

## Benefits

### Simplified User Experience

**Before:**
- User opens app
- User expands context input
- User types context ID
- User clicks "Start Listening"
- Events start streaming

**After (Production):**
- User opens app with context ID in URL
- Events automatically start streaming

**After (Testing):**
- User opens app
- User clicks "Activate" button
- Mock events start streaming

---

### Better URL Sharing

**Before:**
```
Share URL: https://savant.example.com
User has to manually enter context ID
```

**After:**
```
Share URL: https://savant.example.com/?context_id=abc-123
Context ID automatically loaded
```

---

### Cleaner Codebase

**Before:**
- 3 state variables for context input
- 5 props passed to ContentDisplay
- Complex expand/collapse logic
- Context input component

**After:**
- 1 state variable for context ID
- 2 props passed to ContentDisplay
- No UI state management
- No context input component

---

## Future Enhancements

### 1. Multiple Context ID Support

```typescript
// Support multiple contexts
?context_id=ctx1,ctx2,ctx3

// Parse and handle
const contextIds = urlContextId.split(',');
contextIds.forEach(id => {
  eventOrchestrator.start(id, false);
});
```

---

### 2. Context ID Validation

```typescript
function isValidContextId(id: string): boolean {
  // UUID format
  const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
  return uuidRegex.test(id);
}

// Use in URL parsing
if (urlContextId && !isValidContextId(urlContextId)) {
  console.error('Invalid context ID format');
  showErrorToast('Invalid context ID in URL');
  return;
}
```

---

### 3. URL Hash Support

```typescript
// Support hash-based routing
// https://savant.example.com/#/context/abc-123

const hash = window.location.hash;
const match = hash.match(/#\/context\/([^/]+)/);
const contextId = match ? match[1] : '';
```

---

### 4. URL State Sync

```typescript
// Update URL when context changes
function updateUrlWithContext(contextId: string) {
  const url = new URL(window.location.href);
  url.searchParams.set('context_id', contextId);
  window.history.pushState({}, '', url);
}
```

---

## Summary

### What Changed
- ✅ Removed context ID input component
- ✅ Added URL parameter parsing
- ✅ Auto-start in production mode
- ✅ Test mode activate button only
- ✅ Simplified state management
- ✅ Cleaner component interfaces

### URL Format
```
?context_id=your-context-id-here
OR
?contextId=your-context-id-here
```

### Modes
- **Production Mode:** Auto-start with URL context ID
- **Testing Mode:** Manual activate button (uses URL or default ID)

### Button Behavior
- **Production:** No button (auto-starts)
- **Testing + Mock Events:** "Activate (Mock)" button
- **Testing + Real Events:** "Activate" button

**Perfect context ID management via URL! 🔗✨**
