/**
 * Custom hook to handle comprehensive state reset when workflow activates
 * This ensures clean state for each new workflow, preventing bubble sync issues
 */

import { useEffect, useRef } from 'react';
import { eventQueue, type WorkflowState } from '../services/eventQueue';

interface UseWorkflowStateResetProps {
  onActivate: () => void;
  onComplete: () => void;
  onIdle: () => void;
}

export function useWorkflowStateReset({ onActivate, onComplete, onIdle }: UseWorkflowStateResetProps) {
  useEffect(() => {
    const unsubscribe = eventQueue.subscribeToWorkflow((state: WorkflowState) => {
      console.log("[useWorkflowStateReset] Workflow state changed:", state.status);
      
      if (state.status === "active") {
        console.log("[useWorkflowStateReset] Workflow activated - triggering reset");
        onActivate();
      } else if (state.status === "completed") {
        console.log("[useWorkflowStateReset] Workflow completed");
        onComplete();
      } else if (state.status === "idle") {
        console.log("[useWorkflowStateReset] Workflow idle");
        onIdle();
      }
    });

    return unsubscribe;
  }, [onActivate, onComplete, onIdle]);
}
