# Testing Mode Setup - Quick Verification

## ✅ Configuration Set

The app is now configured for **Testing Mode** with the following settings:

```typescript
// /config/environment.ts
export const TESTING_MODE = true;    // ✅ Shows Activate button
export const USE_MOCK_AUDIO = true;  // ✅ Uses mock audio
export const USE_MOCK_EVENTS = true; // ✅ Uses mock events
```

---

## 🎯 What You Should See

### When the App Loads

1. **Savant Control Center** title at top center
2. **Playbook Memory** card on the far left (vertically centered)
3. **Mind Sphere** in the center (pulsating, inactive)
4. **Lake Cloud** (word cloud) below the playbook
5. **Intelligence Stream** panel on the right side
6. **Two buttons below the sphere:**
   - 🔴 **"Activate (Mock)"** button (red)
   - ⚪ **"Reset"** button (outlined)
7. **Status text below buttons:**
   - "Ready to activate..."
   - "• Audio & Events Mock" (in orange)

---

## 🔍 Visual Layout

```
┌─────────────────────────────────────────────────────────────────────┐
│                     Savant Control Center                           │
├─────────────────────────────────────────────────────────────────────┤
│                                                   │                 │
│  ┌──────────┐                                    │  Intelligence   │
│  │ Playbook │           ●                        │  Stream         │
│  │ Memory   │        ⚫ ⚫ ⚫   (Sphere)          │                 │
│  │          │           ●                        │  Listening...   │
│  └──────────┘                                    │                 │
│                                                   │                 │
│  ~~~~ Lake Cloud ~~~~                            │                 │
│  words flowing →→→                               │                 │
│                                                   │                 │
│         [Activate (Mock)]  [Reset]               │                 │
│         Ready to activate...                     │                 │
│         • Audio & Events Mock                    │                 │
│                                                   │                 │
└─────────────────────────────────────────────────────────────────────┘
```

---

## 🚀 How to Test

### Step 1: Verify Buttons Visible

1. **Check the bottom of the left zone** (below the sphere)
2. You should see two buttons centered:
   - Red "Activate (Mock)" button
   - Gray "Reset" button

**If you don't see the buttons:**
- Make sure the page has refreshed after config change
- Open browser console and check for any errors
- Verify TESTING_MODE is imported correctly

---

### Step 2: Click "Activate (Mock)"

1. Click the red **"Activate (Mock)"** button
2. **Expected behavior:**
   - Sphere activates (glowing animation)
   - Thought bubbles appear and move diagonally
   - Events appear in Intelligence Stream on the right
   - Typewriter effect shows event text
   - Mock audio plays (if speakers on)
   - Status changes to "Processing... (X events)"

---

### Step 3: Watch the Flow

**Visual Flow:**
```
Playbook → Sphere → Thought Bubbles → Intelligence Stream
(left)     (center) (diagonal motion)  (right panel)
```

**Expected Events:**
1. **Thought** (blue brain icon) - "Starting workflow analysis..."
2. **Tool** (orange wrench icon) - "search_database"
3. **Thought** (blue brain icon) - "Processing search results..."
4. **Tool** (orange wrench icon) - "generate_report"
5. **Response** (green message icon) - "Workflow completed successfully..."

---

### Step 4: Verify Console Output

Open browser console (F12) and look for:

```javascript
🔧 Savant Control Center - Configuration
Environment: DEVELOPMENT
Testing Mode: ✅ ENABLED
Mock Audio: ✅ ENABLED
Mock Events: ✅ ENABLED
Event Source: Mock Data (Hardcoded)
Audio Source: https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3
Audio Volume: 0.3

// When you click Activate:
Manual trigger button clicked (TESTING MODE)
Audio initialized via button click
[Test Mode] Starting with context ID: test-context-123
```

---

## 🐛 Troubleshooting

### Button Not Visible?

**Check 1: Config File**
```bash
# Verify the config file shows:
TESTING_MODE = true
USE_MOCK_AUDIO = true
USE_MOCK_EVENTS = true
```

**Check 2: Browser Refresh**
- Hard refresh: `Ctrl + Shift + R` (Windows/Linux) or `Cmd + Shift + R` (Mac)
- Or clear browser cache

**Check 3: Console Errors**
- Open browser console (F12)
- Look for red error messages
- Check if imports failed

**Check 4: Button Placement**
The button should be:
- Below the sphere
- Inside the left zone (Zone 1)
- Centered horizontally
- Visible without scrolling

---

### Button Disabled/Grayed Out?

**If button is gray and can't click:**
- Sphere is already active
- Click "Reset" button first
- Then click "Activate (Mock)" again

---

### No Events Appearing?

**If you click Activate but nothing happens:**

1. **Check Console:**
   ```javascript
   // Should see:
   [Test Mode] Starting with context ID: test-context-123
   [EventOrchestrator] Starting...
   [Mock Events] Workflow started
   ```

2. **Check Mock Events Config:**
   - Verify `USE_MOCK_EVENTS = true`
   - Check `/services/eventOrchestrator.ts` has mock data

3. **Check Intelligence Stream:**
   - Should show "Listening for events..."
   - Then events start appearing

---

### Audio Not Playing?

**If visual works but no sound:**

1. **Check Browser Audio:**
   - Volume not muted
   - Tab not muted (right-click tab)

2. **Check Mock Audio:**
   - Verify `USE_MOCK_AUDIO = true`
   - Mock audio URL is valid: https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3

3. **Check Console:**
   ```javascript
   // Should see:
   Audio initialized via button click
   [StreamingTTS] Playing mock audio
   ```

4. **Browser Autoplay Policy:**
   - Audio requires user interaction
   - Clicking "Activate" provides this interaction
   - If audio still blocked, check browser settings

---

## 📋 Complete Testing Checklist

### Visual Elements
- [ ] Title "Savant Control Center" visible at top
- [ ] Playbook Memory card on left side
- [ ] Mind Sphere in center (pulsating)
- [ ] Lake Cloud below playbook (words flowing)
- [ ] Intelligence Stream panel on right
- [ ] "Activate (Mock)" button below sphere
- [ ] "Reset" button next to Activate
- [ ] Status text showing "Ready to activate..."
- [ ] Status showing "• Audio & Events Mock" in orange

### Button Functionality
- [ ] "Activate (Mock)" button is clickable
- [ ] Clicking Activate starts the workflow
- [ ] Sphere activates (glowing)
- [ ] Thought bubbles appear and move
- [ ] Events stream in right panel
- [ ] Reset button stops everything

### Events & Audio
- [ ] Multiple events appear in sequence
- [ ] Typewriter effect for text
- [ ] Icons show (brain, wrench, message)
- [ ] Mock audio plays (if enabled)
- [ ] Console shows correct logs

### Configuration
- [ ] Console shows "TESTING MODE: ✅ ENABLED"
- [ ] Console shows "Mock Audio: ✅ ENABLED"
- [ ] Console shows "Mock Events: ✅ ENABLED"
- [ ] Environment detected as "DEVELOPMENT"

---

## 🎨 Button Styling

The "Activate (Mock)" button should have:

- **Background:** Solid red `#CC0000` (J&J red)
- **Text:** White
- **Shadow:** Subtle shadow
- **Hover:** Darker red `#B30000`
- **Disabled:** 50% opacity (when sphere active)
- **Size:** Standard button height
- **Text:** "Activate (Mock)" when `USE_MOCK_EVENTS = true`
- **Text:** "Activate" when `USE_MOCK_EVENTS = false`

---

## 💡 Quick Test URLs

### Standard Test (Mock Data)
```
http://localhost:5173/
```

**Expected:**
- Shows Activate button
- Uses default test context ID
- Streams mock events

---

### Test with Custom Context ID
```
http://localhost:5173/?context_id=my-custom-test
```

**Expected:**
- Shows Activate button
- Uses "my-custom-test" as context ID
- Streams mock events with custom ID

---

### Test with Real API (Testing Mode)
```typescript
// Set in config:
export const TESTING_MODE = true;
export const USE_MOCK_EVENTS = false; // Use real API

// URL:
http://localhost:5173/?context_id=real-context-id
```

**Expected:**
- Shows "Activate" button (no "Mock")
- Uses real event stream API
- Connects to backend

---

## 🔧 Configuration Modes Quick Reference

### Mode 1: Full Mock (Default - Current Setup)
```typescript
TESTING_MODE = true     // ✅ Button visible
USE_MOCK_AUDIO = true   // ✅ Mock audio
USE_MOCK_EVENTS = true  // ✅ Mock events
```
**Result:** Perfect for local development, no backend needed

---

### Mode 2: Testing with Real API
```typescript
TESTING_MODE = true     // ✅ Button visible
USE_MOCK_AUDIO = false  // Real TTS API
USE_MOCK_EVENTS = false // Real event API
```
**Result:** Test with real backend, manual activation

---

### Mode 3: Production
```typescript
TESTING_MODE = false    // ❌ Button hidden
USE_MOCK_AUDIO = false  // Real TTS API
USE_MOCK_EVENTS = false // Real event API
```
**Result:** Auto-start with URL context ID, no test buttons

---

## 🎯 Expected Console Output (Full Test)

```javascript
// Page Load
🔧 Savant Control Center - Configuration
Environment: DEVELOPMENT
Testing Mode: ✅ ENABLED
Mock Audio: ✅ ENABLED
Mock Events: ✅ ENABLED
Event Source: Mock Data (Hardcoded)
Audio Source: https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3
Audio Volume: 0.3
No context ID in URL. Waiting for manual activation.

// Click Activate
Manual trigger button clicked (TESTING MODE)
Audio initialized via button click
[Test Mode] Starting with context ID: test-context-123
[EventOrchestrator] Starting with context: test-context-123
[Mock Mode] Using hardcoded mock events
[Mock Events] Simulating workflow started event

// Events Stream
[ContentItem 1] Activated, starting sequence
[ContentItem 1] Starting TTS and typewriter SIMULTANEOUSLY for thought event
[ContentItem 1] Audio playback completed
[ContentItem 1] Typing completed
[ContentItem 1] Both audio and typing complete, moving to next event

[ContentItem 2] Activated, starting sequence
[ContentItem 2] Starting typewriter (no TTS for tool events)
...

// Workflow Complete
[Mock Events] Simulating workflow completed event
[App] Workflow completed signal received
```

---

## ✅ Success Indicators

You'll know everything is working when you see:

1. ✅ **Two buttons below the sphere** ("Activate (Mock)" and "Reset")
2. ✅ **Orange status text** showing "• Audio & Events Mock"
3. ✅ **Console shows** "Testing Mode: ✅ ENABLED"
4. ✅ **Clicking Activate** makes sphere glow and events appear
5. ✅ **Events stream** with typewriter effect in Intelligence Stream
6. ✅ **Audio plays** (if speakers on)
7. ✅ **Reset button** stops everything and resets state

---

## 🚀 Next Steps After Verification

Once you confirm the buttons are visible and working:

1. **Test the full workflow** - Click Activate and watch events stream
2. **Test Reset** - Click Reset and verify sphere deactivates
3. **Test Audio toggle** - Use the audio switch in Intelligence Stream
4. **Test with URL context ID** - Add `?context_id=test` to URL
5. **Test production mode** - Set `TESTING_MODE = false` and verify auto-start

---

## 📞 Still Having Issues?

If buttons are still not visible after:
- ✅ Setting `TESTING_MODE = true`
- ✅ Hard refreshing the browser
- ✅ Checking console for errors

**Check these:**

1. **File saved correctly?**
   - Verify `/config/environment.ts` file saved
   - Check for syntax errors in config file

2. **Build/Dev server restarted?**
   - Some changes require dev server restart
   - Stop and restart: `npm run dev` or `pnpm dev`

3. **Browser cache cleared?**
   - Try incognito/private window
   - Or completely clear browser cache

4. **Verify imports:**
   - Check App.tsx imports TESTING_MODE correctly
   - Verify no TypeScript errors

**Perfect setup for testing! The "Activate (Mock)" button should now be visible below the sphere! 🚀✨**
