# Production Mode Debugging Guide

## 🎯 Quick Start

1. **Open your browser** to: `http://localhost:3000/?contextId=aabde`
2. **Open DevTools** (F12 or right-click → Inspect)
3. **Go to Console tab**
4. **Hard refresh** the page (Ctrl+Shift+R or Cmd+Shift+R)

## ⚠️ Important: Audio Autoplay Policy

When the app auto-starts from a URL context ID, **audio will be disabled** due to browser autoplay policies. This is expected behavior:

- ✅ **Event stream connects automatically** and starts processing
- ✅ **Typewriter effects work** normally
- ❌ **Audio is silent** until user interaction

**To enable audio:** Click the audio toggle switch in the Intelligence Stream panel after the page loads.

---

## ✅ Expected Console Output (Production Mode)

When working correctly, you should see this sequence:

```
🔧 Savant Control Center - Configuration
  Environment: PRODUCTION
  Testing Mode: ❌ DISABLED
  Mock Audio: ❌ DISABLED
  Mock Events: ❌ DISABLED
  Event Stream API: http://localhost:8000
  💡 Enter Context ID in the Intelligence Stream to start listening

🔍 URL Parsing Debug: {
  fullUrl: "http://localhost:3000/?contextId=aabde",
  searchParams: "?contextId=aabde",
  parsedContextId: "aabde",
  testingMode: false,
  useMockEvents: false
}

✅ Context ID found in URL: aabde
🚀 Production mode detected - Auto-starting event stream with context ID: aabde

📡 Starting event stream with context ID: aabde
🔧 Configuration: {
  testingMode: false,
  useMockEvents: false,
  useMockAudio: false
}

[StreamingTTS] ⚠️ Audio initialization blocked by browser autoplay policy
[StreamingTTS] Audio will be initialized on first user interaction
⚠️ Audio initialization deferred (requires user interaction)

🎬 Calling eventOrchestrator.start() with context ID: aabde

[Orchestrator] Starting... {
  contextId: "aabde",
  testingMode: false,
  useMockEvents: false
}

[EventStream] Using REAL API streaming
🌐 Connecting to stream API: http://localhost:8000/api/v1/contexts/aabde/log/stream
📋 Request headers: {Accept: 'text/event-stream', Cache-Control: 'no-cache'}
📤 Sending GET request to: http://localhost:8000/api/v1/contexts/aabde/log/stream
📥 Response status: 200 OK
✅ Stream connected successfully, starting to read...

📨 Received event: workflow Starting
📨 Received event: reasoning Analyzing...
📨 Received event: tool Using tool...
[...more events...]
```

---

## ❌ Common Issues & Solutions

### **Issue 1: Configuration Still Shows Testing Mode**

**Symptoms:**
```
Testing Mode: ✅ ENABLED
Mock Events: ✅ ENABLED
```

**Solution:**
- You need to **hard refresh** the page (Ctrl+Shift+R)
- Browser is using cached JavaScript
- The configuration changes haven't loaded yet

---

### **Issue 2: Context ID Not Found**

**Symptoms:**
```
⚠️ No context ID in URL. Waiting for manual activation.
parsedContextId: ""
```

**Solution:**
- Check your URL format: `?contextId=aabde` (camelCase)
- Alternative format also works: `?context_id=aabde` (snake_case)
- Make sure there's a `?` before the parameter

---

### **Issue 3: CORS Error**

**Symptoms:**
```
❌ Stream error: TypeError: Failed to fetch
Access to fetch at 'http://localhost:8000/...' from origin 'http://localhost:3000' 
has been blocked by CORS policy
```

**Solution:**
Your backend needs CORS headers. Add this to your backend:

```python
# Python/Flask example
@app.after_request
def add_cors_headers(response):
    response.headers['Access-Control-Allow-Origin'] = 'http://localhost:3000'
    response.headers['Access-Control-Allow-Headers'] = 'Accept, Cache-Control'
    response.headers['Access-Control-Allow-Methods'] = 'GET, OPTIONS'
    return response
```

```javascript
// Node.js/Express example
app.use(cors({
  origin: 'http://localhost:3000',
  methods: ['GET', 'OPTIONS'],
  allowedHeaders: ['Accept', 'Cache-Control']
}));
```

---

### **Issue 4: No Events Received**

**Symptoms:**
```
✅ Stream connected successfully, starting to read...
[...nothing happens...]
```

**Solution:**
- Backend connected but not sending events
- Check backend logs to see if it's streaming data
- Test with curl: `curl http://localhost:8000/api/v1/contexts/aabde/log/stream`
- Make sure backend sends NDJSON format (one JSON object per line)

---

### **Issue 5: Events Not Transformed**

**Symptoms:**
```
⚠️ Event transformation returned null for: update
```

**Solution:**
- Backend is sending events but format is wrong
- Each event must have: `{"event":"update","data":{...}}`
- Each event must have `data.kvps.event_type` field
- Valid event types: `workflow`, `reasoning`, `tool`, `response`

---

## 🔍 Network Tab Debugging

1. **Open DevTools** → **Network** tab
2. **Hard refresh** the page
3. **Look for** request to `localhost:8000`

### **What to Check:**

| Column | Expected Value |
|--------|---------------|
| **Name** | `stream` (or context ID) |
| **Status** | `200 OK` or `pending` |
| **Type** | `fetch` or `eventsource` |
| **Method** | `GET` |

### **Click on the request** to see details:

**Headers tab:**
- Request URL: `http://localhost:8000/api/v1/contexts/aabde/log/stream`
- Request Method: `GET`
- Status: `200`

**Response tab:**
- Should show streaming NDJSON data
- Each line is a JSON object

---

## 🧪 Test Backend with curl

```bash
# Test if backend is responding
curl -N http://localhost:8000/api/v1/contexts/aabde/log/stream

# Expected output (NDJSON stream):
{"event":"update","data":{"no":1,"id":null,"kvps":{"event_type":"workflow","workflow_status":"started"}}}
{"event":"update","data":{"no":2,"id":null,"kvps":{"event_type":"reasoning","headline":"Thinking...","thoughts":["Step 1"]}}}
```

If curl works but browser doesn't → **CORS issue**

---

## 📝 Checklist

Before asking for help, verify:

- [ ] Hard refreshed browser (Ctrl+Shift+R)
- [ ] Console shows `Testing Mode: ❌ DISABLED`
- [ ] Console shows `Mock Events: ❌ DISABLED`
- [ ] URL includes `?contextId=YOUR_ID`
- [ ] Backend is running on `http://localhost:8000`
- [ ] curl command works
- [ ] Checked Network tab for API call
- [ ] Checked Console tab for errors

---

## 🆘 Still Not Working?

Copy and paste ALL console output and share:

1. **Console output** from page load
2. **Network tab** screenshot showing the API request
3. **curl output** from your backend
4. **Backend logs** (if available)

This will help identify exactly where the connection is failing.
