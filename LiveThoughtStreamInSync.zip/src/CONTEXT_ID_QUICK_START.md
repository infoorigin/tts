# Context ID Quick Start Guide

## Overview
The Savant Control Center now features an intuitive context ID input system that allows you to connect to live agent workflows without URL parameters.

## How to Use (Production Mode)

### Step 1: Open the Application
Load the application in your browser. You'll see the Intelligence Stream panel on the right with a collapsed input section.

### Step 2: Expand Context Input
Click on **"Enter Context ID to Start Listening"** to expand the input section.

### Step 3: Enter Context ID
Type your agent workflow context ID into the input field.

Example: `abc123xyz`

### Step 4: Start Listening
Click the **"Start Listening"** button.

This will:
- ✅ Initialize audio (solving browser autoplay restrictions)
- ✅ Connect to your event stream API
- ✅ Activate the MindSphere
- ✅ Begin streaming events

## Benefits of This Approach

### 1. **Intuitive UX**
- No need to manually edit URLs
- Clear call-to-action
- Progressive disclosure (input only shown when needed)

### 2. **Solves Autoplay Issue**
- Button click = user interaction
- Audio initializes automatically
- No browser blocking errors

### 3. **Clean URLs**
- No query parameters needed
- Shareable base URL
- Works in any environment

### 4. **Smart State Management**
- Input disappears once listening starts
- Shows connection status
- Can reset and enter new context ID

## Configuration Modes

### Production Mode (Default)
```typescript
// /config/environment.ts
export const TESTING_MODE = false;
export const USE_MOCK_EVENTS = false;
export const USE_MOCK_AUDIO = false;
```

**Behavior:**
- Shows Context ID input
- No manual "Activate Agent" button
- Connects to real API when context ID is submitted

### Testing Mode (Development)
```typescript
// /config/environment.ts
export const TESTING_MODE = true;
export const USE_MOCK_EVENTS = true;
export const USE_MOCK_AUDIO = true;
```

**Behavior:**
- Shows "Activate Agent" button
- No Context ID input
- Uses hardcoded mock data

## User Flow Diagram

```
┌─────────────────────────────────────┐
│   User Opens Application            │
└──────────────┬──────────────────────┘
               │
               ▼
┌─────────────────────────────────────┐
│   Intelligence Stream Panel         │
│   Shows: "Enter Context ID..."      │
└──────────────┬──────────────────────┘
               │
               │ User Clicks
               ▼
┌─────────────────────────────────────┐
│   Input Section Expands             │
│   - Context ID field                │
│   - Start Listening button          │
└──────────────┬──────────────────────┘
               │
               │ User Enters ID
               ▼
┌─────────────────────────────────────┐
│   User Clicks "Start Listening"     │
└──────────────┬──────────────────────┘
               │
               ├─► Audio Initialized ✓
               ├─► API Connection ✓
               └─► MindSphere Activates ✓
               
┌─────────────────────────────────────┐
│   Events Stream In Real-Time        │
│   - Input section hidden            │
│   - Events display with audio       │
│   - Sphere emits bubbles            │
└─────────────────────────────────────┘
```

## API Configuration

The context ID will be used to construct the API URL:

```typescript
// Default configuration
baseUrl: "http://localhost:8000"
streamPath: "/api/v1/contexts/{contextId}/log/stream"

// Example with context ID "abc123"
// Final URL: http://localhost:8000/api/v1/contexts/abc123/log/stream
```

Configure your API endpoint in `/config/environment.ts`:

```typescript
export const EVENT_STREAM_API = {
  baseUrl: "https://your-api.com",
  streamPath: "/api/v1/contexts/{contextId}/log/stream",
  headers: {
    Accept: "text/event-stream",
    "Cache-Control": "no-cache",
  },
};
```

## Reset and Reconnect

To reset and enter a new context ID:

1. Click the **Reset** button (circular arrow icon)
2. The input section will reappear
3. Enter a new context ID
4. Click "Start Listening" again

## Troubleshooting

### Input Not Showing
**Cause:** `TESTING_MODE = true`
**Solution:** Set `TESTING_MODE = false` in `/config/environment.ts`

### Events Not Streaming
**Cause:** Incorrect API configuration or context ID
**Solution:** 
- Check console for API connection errors
- Verify `EVENT_STREAM_API.baseUrl` in config
- Confirm context ID is valid

### No Audio Playing
**Cause:** Audio toggle is disabled
**Solution:** Enable audio using the toggle switch in the header

### "Cannot play audio - no user interaction"
**Cause:** Audio toggle was disabled when "Start Listening" was clicked
**Solution:** This is expected - enable audio toggle to hear future events

## Visual States

### State 1: Ready for Input
```
┌─────────────────────────────────┐
│ Intelligence Stream        🔊 ⚪ │
├─────────────────────────────────┤
│ ○ Enter Context ID to Start... ▼│
└─────────────────────────────────┘
```

### State 2: Input Expanded
```
┌─────────────────────────────────┐
│ Intelligence Stream        🔊 ⚪ │
├─────────────────────────────────┤
│ ● Hide                        ▲ │
│                                  │
│ Context ID                       │
│ [abc123xyz____________]          │
│                                  │
│ Enter the context ID from your   │
│ agent workflow to begin...       │
│                                  │
│ [▶ Start Listening]             │
└─────────────────────────────────┘
```

### State 3: Listening (Input Hidden)
```
┌─────────────────────────────────┐
│ Intelligence Stream        🔊 ⚪ │
├─────────────────────────────────┤
│ 🧠 THOUGHT                       │
│ Starting First Purchase...       │
│ ● Typing...                      │
│                                  │
│ 🔧 TOOL CALL                     │
│ Using territory alignment...     │
└─────────────────────────────────┘
```

## Best Practices

### ✅ DO:
- Use descriptive context IDs
- Test with your API endpoint before deploying
- Keep the default config for production
- Use Reset button between different workflows

### ❌ DON'T:
- Hardcode context IDs in the application
- Share sensitive context IDs publicly
- Use context IDs from test environments in production
- Forget to configure the correct API base URL

## Related Files
- `/components/ContextIdInput.tsx` - Input component
- `/App.tsx` - Main application with context ID handling
- `/config/environment.ts` - Configuration settings
- `/services/eventOrchestrator.ts` - Event streaming logic

## Migration from URL Parameters

If you were previously using URL parameters (`?context_id=xxx`):

### Old Method (Deprecated)
```
https://your-app.com/?context_id=abc123
```

### New Method (Current)
1. Open: `https://your-app.com/`
2. Click: "Enter Context ID to Start Listening"
3. Enter: `abc123`
4. Click: "Start Listening"

**Note:** URL parameter support has been removed in favor of the more intuitive input method.

## Security Considerations

- Context IDs are only stored in component state (not persisted)
- No context IDs are sent to browser storage
- Each session requires manual input
- Reset clears all state including context ID

## Next Steps

1. Configure your API endpoint in `/config/environment.ts`
2. Deploy the application
3. Share the base URL with users
4. Users enter their context IDs when ready
5. Monitor events in real-time

For more details, see:
- `/AUDIO_AUTOPLAY_POLICY.md` - Audio handling
- `/config/README.md` - Full configuration guide
- `/ARCHITECTURE.md` - System architecture
