# Savant Meta Agent Workflow Setup and Execution Guide

## 1. Create a Virtual Environment

Create a new Python virtual environment:

```bash
python -m venv venv
```

## 2. Activate the Virtual Environment

Activate your virtual environment:

```bash
venv\Scripts\activate
```

## 3. Install Dependencies

Install all required Python packages:

```bash
pip install -r requirements.txt
```

## 4: Start the Uvicorn  Server

  Once the MCP server is running, start the Uvicorn debug server.

```bash
  uvicorn app.main:app --reload --host $HOST --port $PORT 
```

  After **“Application startup complete”**, the API will be ready.
