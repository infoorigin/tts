
from pydantic_settings import BaseSettings
from typing import List

class Settings(BaseSettings):
    aws_region: str = "us-east-1"
    default_voice: str = "Ruth"
    default_engine: str = "neural"
    output_format: str = "mp3"
    aws_profile: str = "default"
    local_dev: bool = False

    async_bucket: str | None = None
    async_prefix: str = "demos/output"

    max_sync_chars: int = 5500

    cors_allow_origins: str = "*"

    log_level: str = "INFO"

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"
        extra = "ignore"

    @property
    def cors_origins(self) -> List[str]:
        if self.cors_allow_origins.strip() == "*":
            return ["*"]
        return [o.strip() for o in self.cors_allow_origins.split(",") if o.strip()]

settings = Settings()
