
import os
import yaml
from functools import lru_cache

BASE_PATH = os.path.join(os.path.dirname(__file__), "preprocessor")

def _load_yaml(file_name: str) -> dict:
    path = os.path.join(BASE_PATH, file_name)
    if not os.path.exists(path):
        return {}
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f) or {}

@lru_cache(maxsize=1)
def load_preprocessor_config() -> dict:
    return _load_yaml("preprocessor.yml")

@lru_cache(maxsize=1)
def load_abbreviations() -> dict:
    return _load_yaml("abbreviations.yml")

@lru_cache(maxsize=1)
def load_acronyms() -> list[str]:
    data = _load_yaml("acronyms_pharma.yml")
    all_acronyms = []
    for section in data.values():
        all_acronyms.extend(section or [])
    return list(set(all_acronyms))
