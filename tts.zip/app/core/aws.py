import boto3
from botocore.exceptions import ClientError
from app.core.config import settings


# ---- AWS Session Bootstrap ----
if getattr(settings, "local_dev", None) and getattr(settings, "aws_profile", None):
    session = boto3.Session(
        region_name=settings.aws_region,
        profile_name=settings.aws_profile,
    )
else:
    # Use ambient credentials (IRSA, ECS Task Role, etc.)
    session = boto3.Session(region_name=settings.aws_region)

polly = session.client("polly")
s3 = session.client("s3")

__all__ = ["polly", "s3", "ClientError"]
