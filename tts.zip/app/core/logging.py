
import logging, sys
from app.core.config import settings

def setup_logging():
    fmt = "[%(asctime)s] [%(levelname)s] %(name)s: %(message)s"
    level = getattr(logging, settings.log_level.upper(), logging.INFO)
    logging.basicConfig(level=level, format=fmt, handlers=[logging.StreamHandler(sys.stdout)])
    logging.getLogger("boto3").setLevel(logging.WARNING)
    logging.getLogger("botocore").setLevel(logging.WARNING)
