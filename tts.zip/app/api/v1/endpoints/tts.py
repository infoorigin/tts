
from typing import List, Optional
from urllib.parse import urlparse
from fastapi import APIRouter, HTTPException, Query
from starlette.responses import StreamingResponse, JSONResponse
from app.models.tts_models import SpeakIn
from app.services.tts_service import stream_one, sentence_chunks, content_type
from app.core.aws import polly, s3, ClientError
from app.core.config import settings
import logging

router = APIRouter()
log = logging.getLogger(__name__)

@router.get("/healthz")
def healthz():
    return {"status": "ok"}

@router.post("/stream")
def stream_audio_post(payload: SpeakIn):
    voice = payload.voice or settings.default_voice
    engine = payload.engine or settings.default_engine
    fmt = payload.format or settings.output_format

    chunks = sentence_chunks(payload.text, settings.max_sync_chars)
    def gen():
        for ch in chunks:
            yield from stream_one(ch, voice, engine, fmt, payload.sample_rate, payload.lexicons)

    headers = {
        "Content-Type": content_type(fmt),
        "Cache-Control": "no-store",
        "Content-Disposition": f'inline; filename="speech.{fmt}"'
    }
    return StreamingResponse(gen(), headers=headers)

@router.get("/stream")
def stream_audio_get(
    text: str = Query(..., min_length=1, max_length=4000),
    voice: Optional[str] = None,
    engine: Optional[str] = None,
    format: Optional[str] = None,
    sample_rate: Optional[str] = None,
    lexicons: Optional[List[str]] = Query(default=None),
):
    voice = voice or settings.default_voice
    engine = engine or settings.default_engine
    fmt = format or settings.output_format

    chunks = sentence_chunks(text, settings.max_sync_chars)
    def gen():
        for ch in chunks:
            yield from stream_one(ch, voice, engine, fmt, sample_rate, lexicons)

    headers = {"Content-Type": content_type(fmt), "Cache-Control": "no-store"}
    return StreamingResponse(gen(), headers=headers)

@router.post("/async")
def async_to_s3(payload: SpeakIn):
    if not settings.async_bucket:
        raise HTTPException(400, "Server not configured for async (missing ASYNC_BUCKET).")
    try:
        resp = polly.start_speech_synthesis_task(
            Text=payload.text,
            OutputFormat=payload.format or settings.output_format,
            VoiceId=payload.voice or settings.default_voice,
            Engine=payload.engine or "long-form",
            OutputS3BucketName=settings.async_bucket,
            OutputS3KeyPrefix=settings.async_prefix,
            LexiconNames=payload.lexicons or [],
        )
    except ClientError as e:
        msg = e.response["Error"].get("Message", str(e))
        raise HTTPException(502, f"Polly error: {msg}")

    task = resp["SynthesisTask"]
    return JSONResponse(status_code=202, content={
        "taskId": task["TaskId"],
        "taskStatus": task["TaskStatus"],
        "outputUri": task.get("OutputUri"),
    })

@router.get("/task/{task_id}")
def get_task_status(task_id: str):
    try:
        st = polly.get_speech_synthesis_task(TaskId=task_id)["SynthesisTask"]
    except ClientError as e:
        msg = e.response["Error"].get("Message", str(e))
        raise HTTPException(502, f"Polly error: {msg}")
    return {"taskId": task_id, "taskStatus": st["TaskStatus"], "outputUri": st.get("OutputUri")}

@router.get("/presign")
def presign(uri: str):
    u = urlparse(uri)
    parts = u.path.split("/")
    if len(parts) < 3:
        raise HTTPException(400, "Invalid S3 URI")
    bucket = parts[1]
    key_s3 = "/".join(parts[2:])
    url = s3.generate_presigned_url("get_object", Params={"Bucket": bucket, "Key": key_s3}, ExpiresIn=3600)
    return {"url": url}
