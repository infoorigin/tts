
from fastapi import FastAPI
from app.api.middleware.cors import add_cors_middleware
from app.api.v1.endpoints import tts
from app.core.logging import setup_logging

def lifespan(app: FastAPI):
    yield

app = FastAPI(
    title="AWS Polly TTS Proxy (Enterprise)",
    version="2.0.0",
    lifespan=lifespan,
)

setup_logging()
add_cors_middleware(app)
app.include_router(tts.router, prefix="/api/v1/tts", tags=["tts"])

@app.get("/")
def root():
    return {"message": "Polly TTS Proxy up"}
