"""
app/services/tts_preprocessor.py
--------------------------------
Engine-aware text preprocessor for AWS Polly TTS Proxy.

Rules enforced:
  neural     → <speak>, <sub>, <break>, <say-as> only
  standard   → Full SSML (<prosody>, <emphasis>, etc.)
  long-form  → Plain text only (no SSML)
"""

from markdown import markdown
from bs4 import BeautifulSoup
import re
import emoji
import logging
from dateutil import parser as dateparser
from app.core.configs.config_loader import (
    load_abbreviations,
    load_acronyms,
    load_preprocessor_config,
)

log = logging.getLogger(__name__)

MONTH_NAMES = [
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December",
]


# --------------------------------------------------------------------------- #
#  Utility expansions
# --------------------------------------------------------------------------- #
def _process_emojis(text: str) -> str:
    cfg = load_preprocessor_config()
    mode = cfg.get("emoji_mode", "strip")
    return emoji.demojize(text) if mode == "describe" else emoji.replace_emoji(text, replace="")

def _markdown_to_text(md):
    html = markdown(md)
    return ''.join(BeautifulSoup(html, 'html.parser').stripped_strings)

def _expand_abbreviations(text: str, engine: str = "neural") -> str:
    """
    Expands common abbreviations like 'Dr.' -> 'Doctor'.
    Uses SSML <sub> for standard/neural engines, plain text for generative.
    """
    abbr = load_abbreviations()

    for pattern, replacement in abbr.items():
        # SSML substitution (only for engines that support it)
        if engine in ("standard", "neural"):
            sub = f"<sub alias='{replacement}'>{pattern}</sub>"
        else:
            # For generative or long-form — replace directly with word
            sub = replacement

        # Use word-boundary safe substitution
        text = re.sub(rf"\b{re.escape(pattern)}\b", sub, text)

    return text



def _expand_dates_and_numbers(text: str) -> str:
    """Normalize common date/time/number formats into Polly-friendly SSML."""
    def verbalize_date(date_str: str) -> str:
        try:
            dt = dateparser.parse(date_str)
            day = dt.day
            suffix = "th" if 11 <= day <= 13 else {1: "st", 2: "nd", 3: "rd"}.get(day % 10, "th")
            return f"{MONTH_NAMES[dt.month - 1]} {day}{suffix} {dt.year}"
        except Exception:
            return date_str

    patterns = [
        r"\b\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z\b",
        r"\b\d{4}-\d{2}-\d{2}\b",
        r"\b\d{1,2}/\d{1,2}/\d{2,4}\b",
        r"\b\d{4}/\d{1,2}/\d{1,2}\b",
    ]
    for p in patterns:
        text = re.sub(p, lambda m: verbalize_date(m.group()), text)

    text = re.sub(r"\b(\d{1,2}):(\d{2})(?::\d{2})?\b",
                  lambda m: f"<say-as interpret-as='time'>{m.group()}</say-as>", text)
    text = re.sub(r"\b\d{3,6}\b",
                  lambda m: f"<say-as interpret-as='digits'>{' '.join(m.group())}</say-as>", text)
    return text


def _expand_currency(text: str) -> str:
    def fmt(m):
        val = m.group(1)
        return f"<say-as interpret-as='cardinal'>{val}</say-as> dollars"
    return re.sub(r"\$(\d+(?:,\d{3})*(?:\.\d+)?)", fmt, text)


def _expand_units(text: str) -> str:
    units = {
        "mg": "milligrams", "ml": "milliliters", "kg": "kilograms",
        "cm": "centimeters", "mm": "millimeters", "hr": "hours",
        "sec": "seconds", "°C": "degrees Celsius", "°F": "degrees Fahrenheit",
    }
    for k, v in units.items():
        text = re.sub(rf"(\d+)\s*{re.escape(k)}\b", rf"\1 {v}", text)
    return text


def _expand_phone_numbers(text: str) -> str:
    return re.sub(
        r"\+?\d[\d\s\-]{7,}\d",
        lambda m: f"<say-as interpret-as='telephone'>{m.group()}</say-as>",
        text,
    )


def _expand_percentages(text: str) -> str:
    return re.sub(r"(\d+(?:\.\d+)?)%", r"\1 percent", text)


def _prepare_acronyms(
    text: str,
    custom_acronyms: list[str] | None = None,
    engine: str = "neural"
) -> str:
    """
    Expands acronyms per engine type:
    - neural/standard: uses SSML <say-as interpret-as='characters'>
    - generative: injects non-breaking spaces between characters (O S) for natural flow
    """
    cfg = load_preprocessor_config()
    acronyms = custom_acronyms or load_acronyms()
    max_len = cfg.get("max_acronym_length", 6)

    pattern_cap = rf"\b[A-Z&]{{2,{max_len}}}\b"
    potential = re.findall(pattern_cap, text)
    all_acronyms = sorted(set(acronyms + potential), key=len, reverse=True)

    for acronym in all_acronyms:
        safe = acronym.replace("&", "and")

        if engine == "generative":
            # ✅ Use narrow non-breaking spaces (U+202F) or regular ones for smooth separation
            # Example: "O\u202fS" reads as “O S” (short pause, no punctuation spoken)
            spoken = "\u202f".join(list(safe))  # "O S E"
            text = re.sub(rf"\b{re.escape(acronym)}\b", spoken, text)
        else:
            # ✅ Standard/Neural engines: SSML form
            text = re.sub(
                rf"\b{re.escape(acronym)}\b",
                f"<say-as interpret-as='characters'>{safe}</say-as>",
                text
            )

    return text






# --------------------------------------------------------------------------- #
#  Engine-aware SSML builder
# --------------------------------------------------------------------------- #
def _add_prosody_and_breaks(text: str, engine: str = "neural") -> str:
    """
    Adds SSML prosody/breaks only when supported.
    - neural: skip prosody/emphasis
    - standard: add prosody and optional short breaks
    - long-form: plain text only
    """
    cfg = load_preprocessor_config()

    if engine == "long-form":
        return text  # no SSML

    # optional commas/semicolon breaks
    if cfg.get("enable_auto_breaks", False):
        text = re.sub(r"(;|,)\s+", r"\1 <break time='150ms'/> ", text)

    # Prosody supported only for 'standard'
    if cfg.get("enable_prosody", True) and engine == "standard":
        rate = cfg.get("speech_rate", "100%")
        pitch = cfg.get("pitch", "+0%")
        volume = cfg.get("volume", "+3 dB")
        text = f'<prosody rate="{rate}" pitch="{pitch}" volume="{volume}">{text}</prosody>'

    return f"<p>{text}</p>"


def prepare_text_for_tts(
    text: str,
    custom_acronyms: list[str] | None = None,
    engine: str = "neural",
) -> str:
    """
    Generate Polly-ready text or SSML depending on engine type.
    """
    cfg = load_preprocessor_config()
    text = _process_emojis(text)
    text = _markdown_to_text(text)
    

    if cfg.get("enable_abbreviation_expansion", True):
        text = _expand_abbreviations(text, engine=engine)
    if cfg.get("enable_date_expansion", True):
        text = _expand_dates_and_numbers(text)
    if cfg.get("enable_currency_expansion", True):
        text = _expand_currency(text)
    if cfg.get("enable_units_expansion", True):
        text = _expand_units(text)
    if cfg.get("enable_phone_expansion", True):
        text = _expand_phone_numbers(text)
    if cfg.get("enable_percentage_expansion", True):
        text = _expand_percentages(text)
    if cfg.get("enable_acronym_expansion", True):
        text = _prepare_acronyms(text, custom_acronyms, engine=engine)

    # Engine-aware wrapping
    if engine in ("long-form", "generative"):
        # long-form: no SSML tags allowed
        clean_text = re.sub(r"<[^>]+>", "", text)
        log.debug("Generated plain text for long-form engine.")
        return clean_text

    elif engine == "neural":
        # limited SSML support (no prosody)
        text = _add_prosody_and_breaks(text, engine="neural")
        log.debug("Generated limited SSML for neural engine.")
        return f"<speak>{text.strip()}</speak>"

    else:
        # standard engine: full SSML
        text = _add_prosody_and_breaks(text, engine="standard")
        log.debug("Generated full SSML for standard engine.")
        return f"<speak>{text.strip()}</speak>"
