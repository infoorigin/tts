import json
from textwrap import shorten
import re
from typing import Iterator, List, Optional
from app.core.aws import polly, ClientError
from app.core.config import settings
from app.services.tts_preprocessor import prepare_text_for_tts
import logging

log = logging.getLogger(__name__)

def sentence_chunks(text: str, limit: int) -> List[str]:
    sentences = re.split(r"(?<=[.!?])\s+", text.strip())
    parts, buf = [], ""
    for s in sentences:
        s = s.strip()
        if not s:
            continue
        if len(buf) + len(s) + 1 > limit:
            if buf:
                parts.append(buf)
                buf = s
            else:
                parts.append(s[:limit])
                buf = s[limit:]
        else:
            buf = (buf + " " + s).strip()
    if buf:
        parts.append(buf)
    return parts

def _strip_ssml(text: str) -> str:
    """Remove SSML tags to produce plain text fallback."""
    return re.sub(r"<[^>]+>", "", text)

def stream_one(
    text: str,
    voice: str,
    engine: str,
    fmt: str,
    sample_rate: Optional[str],
    lexicons: Optional[List[str]],
) -> Iterator[bytes]:
    """
    Streams audio from Polly, supporting 'standard', 'neural', 'long-form', and 'generative' engines.
    Handles text preprocessing, SSML logic, and graceful fallbacks.
    """
    # Prepare text based on engine
    processed_text = prepare_text_for_tts(text, engine=engine)
    text_type = "ssml" if engine in ("standard", "neural") else "text"

    # Generative engine requires plain text (no SSML)
    if engine == "generative":
        log.info("Using Polly Generative engine (SSML not supported). Stripping markup if present.")
        processed_text = _strip_ssml(processed_text)
        text_type = "text"

    kwargs = dict(
        Text=processed_text,
        VoiceId=voice,
        Engine=engine,
        OutputFormat=fmt,
        TextType=text_type,
    )
    if sample_rate:
        kwargs["SampleRate"] = sample_rate
    if lexicons:
        kwargs["LexiconNames"] = lexicons

    try:
        safe_kwargs = {k: v for k, v in kwargs.items() if k != "Text"}
        log.debug("Calling Polly with params: %s", json.dumps(safe_kwargs, indent=2))
        log.debug("Polly Text Preview:\n%s", shorten(kwargs["Text"].replace("\n", " "), width=300))
        resp = polly.synthesize_speech(**kwargs)

    except ClientError as e:
        code = e.response["Error"].get("Code")
        msg = e.response["Error"].get("Message", "")
        log.warning("Polly error on initial call: %s (%s)", code, msg)

        # Fallback for unsupported SSML in neural/standard
        if code in ("InvalidSsmlException", "InvalidSsml"):
            log.warning("SSML rejected, retrying with plain text fallback.")
            kwargs["TextType"] = "text"
            kwargs["Text"] = _strip_ssml(processed_text)
            resp = polly.synthesize_speech(**kwargs)
        elif code in ("EngineNotSupportedException", "LanguageNotSupportedException"):
            log.warning("Engine not supported; retrying with 'standard' engine.")
            kwargs["Engine"] = "standard"
            kwargs["TextType"] = "ssml"
            kwargs["Text"] = prepare_text_for_tts(text, engine="standard")
            resp = polly.synthesize_speech(**kwargs)
        else:
            raise

    stream = resp["AudioStream"]
    with stream as s:
        while True:
            data = s.read(16384)
            if not data:
                break
            yield data

def content_type(fmt: str) -> str:
    return {"mp3": "audio/mpeg", "ogg_vorbis": "audio/ogg"}.get(fmt, "audio/basic")
