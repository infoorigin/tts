
from typing import List, Optional, Literal
from pydantic import BaseModel, Field, field_validator

class SpeakIn(BaseModel):
    text: str = Field(..., min_length=1, max_length=200000)
    voice: Optional[str] = Field(None, description="AWS Polly voice ID (e.g., Ruth, Joanna)")
    engine: Optional[Literal["standard", "neural", "long-form"]] = Field(None)
    format: Optional[Literal["mp3", "ogg_vorbis", "pcm"]] = Field(None)
    sample_rate: Optional[str] = Field(None, pattern=r"^\d+$")
    lexicons: Optional[List[str]] = None

    @field_validator("text")
    def strip_whitespace(cls, v: str) -> str:
        return v.strip()
