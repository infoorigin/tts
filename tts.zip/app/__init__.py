# app/core/config/__init__.py
"""Configuration package for AWS Polly TTS Proxy."""
