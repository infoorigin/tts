# Public Folder

Place your static assets here (videos, images, etc.).

## Usage

Files placed in this folder can be referenced directly in your code:

- Video: `/your-video.mp4`
- Images: `/your-image.jpg`
- Other assets: `/your-file.ext`

## Note

In the Figma Make environment, you'll need to host videos externally or export this project to run locally with your video files.
