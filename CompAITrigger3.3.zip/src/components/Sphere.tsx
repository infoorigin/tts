import { useState, useEffect } from 'react';
import { RedSphere } from './RedSphere';
import { config } from '../config';

interface SphereProps {
  savantCount?: number;
  onThoughtStreamOpened?: () => void;
}

export function Sphere({ savantCount = 0, onThoughtStreamOpened }: SphereProps) {
  const [visibleSavants, setVisibleSavants] = useState<number[]>([]);

  useEffect(() => {
    if (savantCount > visibleSavants.length) {
      // Add new savant after a delay
      const timer = setTimeout(() => {
        setVisibleSavants([...visibleSavants, savantCount - 1]);
      }, 500);
      return () => clearTimeout(timer);
    }
  }, [savantCount, visibleSavants]);

  const getSavantName = (savantIndex: number): string => {
    return savantIndex === 0 ? 'Tecvali Savant' : 'Inlexzo Savant';
  };

  const getSavantKey = (savantIndex: number): 'tecvali_savant' | 'inlexzo_savant' => {
    return savantIndex === 0 ? 'tecvali_savant' : 'inlexzo_savant';
  };

  return (
    <div className="relative w-full h-full flex items-center justify-center overflow-hidden">
      <video
        className="object-cover"
        style={{
          width: '70vw',
          height: '70vh',
          maxWidth: '70%',
          maxHeight: '70%',
        }}
        autoPlay
        loop
        muted
        playsInline
      >
        <source src={config.videoUrl} type="video/mp4" />
        Your browser does not support the video tag.
      </video>

      {/* Red sphere birth animations */}
      {visibleSavants.map((savantIndex) => (
        <RedSphere 
          key={savantIndex} 
          isVisible={true} 
          position={savantIndex === 0 ? 'top-right' : 'bottom-right'}
          savantName={getSavantName(savantIndex)}
          savantKey={getSavantKey(savantIndex)}
          onThoughtStreamOpened={onThoughtStreamOpened}
        />
      ))}
    </div>
  );
}