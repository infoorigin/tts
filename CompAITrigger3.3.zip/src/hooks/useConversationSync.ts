import { useState, useEffect, useRef } from "react";
import { conversationStream, ConversationMessage } from "../utils/conversationStream";
import { playTTS } from "../utils/tts";
import { playThoughtTTS } from "../utils/thoughtTTS";

interface UseConversationSyncProps {
  savantKey: string;
  isVisible: boolean;
  isAudioEnabled: boolean;
  onMessage?: (message: string) => void;
  typingSpeed?: number;
}

export function useConversationSync({
  savantKey,
  isVisible,
  isAudioEnabled,
  onMessage,
  typingSpeed = 30,
}: UseConversationSyncProps) {
  const [currentText, setCurrentText] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const [completedMessages, setCompletedMessages] = useState<string[]>([]);
  
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const typingTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    // Only subscribe if visible
    if (!isVisible) return;

    /**
     * Process a single message with synchronized audio + typing
     * Both run in parallel, and we wait for BOTH to complete
     */
    const processMessage = async (message: string): Promise<void> => {
      return new Promise<void>(async (resolve) => {
        // Callback for external handlers
        if (onMessage) {
          onMessage(message);
        }

        // Create audio promise
        const audioPromise = isAudioEnabled
          ? (savantKey === 'mother_savant' 
              ? playTTS(message, audioRef) 
              : playThoughtTTS(
                  message.replace(/[⚡🔍🎯🧠📊⚙️🔗✓🚀💡]/g, '').trim(), 
                  savantKey as 'tecvali_savant' | 'inlexzo_savant', 
                  audioRef
                ))
          : Promise.resolve();

        // Create typing promise
        const typingPromise = new Promise<void>((typingResolve) => {
          let charIndex = 0;
          setIsTyping(true);
          setCurrentText('');

          const typeChar = () => {
            if (charIndex < message.length) {
              setCurrentText(message.substring(0, charIndex + 1));
              charIndex++;
              typingTimeoutRef.current = setTimeout(typeChar, typingSpeed);
            } else {
              // Typing complete
              setCompletedMessages((prev) => [...prev, message]);
              setCurrentText('');
              setIsTyping(false);
              typingResolve();
            }
          };

          typeChar();
        });

        // Wait for BOTH audio and typing to complete
        console.log(`[ConversationSync ${savantKey}] Starting audio and typing in parallel...`);
        await Promise.all([audioPromise, typingPromise]);
        console.log(`[ConversationSync ${savantKey}] Both complete, ready for next event`);
        
        resolve();
      });
    };

    // Subscribe to the conversation stream for this savant
    const unsubscribe = conversationStream.subscribe(
      savantKey,
      async (msg: ConversationMessage) => {
        await processMessage(msg.message);
      }
    );

    return () => {
      unsubscribe();
      if (typingTimeoutRef.current) {
        clearTimeout(typingTimeoutRef.current);
      }
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current.currentTime = 0;
      }
    };
  }, [isVisible, isAudioEnabled, savantKey, onMessage, typingSpeed]);

  return {
    currentText,
    isTyping,
    completedMessages,
  };
}