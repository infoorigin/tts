import { useState } from "react";
import { Sphere } from "./components/Sphere";
import { ChatInterface } from "./components/ChatInterface";
import { MessageCircleMore } from 'lucide-react';
import jnjLogo from 'figma:asset/423611bc1574c7e40b5e99f6e50aedc7b6382e6b.png';
import savantLogo from 'figma:asset/01267cdb23607527a7cf4507f45e5bd11f228c9e.png';
import { motion } from "motion/react";
import { Button } from "./components/ui/button";

export default function App() {
  const [isStreamComplete, setIsStreamComplete] = useState(false);
  const [isChatOpen, setIsChatOpen] = useState(true);
  const [isChatVisible, setIsChatVisible] = useState(false);

  const handleChatToggle = () => {
    setIsChatVisible(!isChatVisible);
  };

  const handleFirstResponse = () => {
    setIsStreamComplete(true);
  };

  return (
    <div className="h-screen w-screen bg-white overflow-hidden relative">
      {/* Full Screen Sphere Video */}
      <Sphere 
        onStreamComplete={isStreamComplete}
      />

      {/* J&J Logo with Savant COMP AI text - Extreme Top Left */}
      <div className="absolute top-4 left-4 z-30">
        <div className="flex items-center gap-3">
          <img 
            src={jnjLogo} 
            alt="Johnson & Johnson" 
            className="h-10 w-auto object-contain"
          />
          <div className="w-px h-8 bg-gray-300" />
          <span className="text-gray-700">Savant COMP AI</span>
        </div>
      </div>

      {/* Floating Chat Toggle Button - visible when chat is collapsed */}
      {isChatOpen && !isChatVisible && (
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          className="absolute top-20 left-4 z-40"
        >
          <Button
            onClick={handleChatToggle}
            size="icon"
            className="w-12 h-12 rounded-full shadow-lg hover:opacity-90"
            style={{ backgroundColor: '#D71600' }}
          >
            <MessageCircleMore className="w-6 h-6" />
          </Button>
        </motion.div>
      )}

      {/* Chat Interface - Slide in/out from left */}
      <motion.div
        initial={{ x: 0 }}
        animate={{ x: isChatVisible ? 0 : -500 }}
        transition={{ type: 'spring', stiffness: 300, damping: 30 }}
        className="absolute top-20 left-4 z-50"
      >
        <ChatInterface 
          onClose={handleChatToggle}
          onFirstResponse={handleFirstResponse}
          isVisible={isChatVisible}
        />
      </motion.div>
    </div>
  );
}