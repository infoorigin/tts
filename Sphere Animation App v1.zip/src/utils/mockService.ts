import { mockResponses, MockResponseData } from './mockData';

/**
 * Generate a mock response based on user input
 * Returns full API response structure matching the real API
 */
export function generateMockResponse(input: string): MockResponseData {
  // Check if user is asking to create a Savant - more specific pattern
  const isCreateSavantRequest = /create\s+(a\s+)?(new\s+)?.*savant|new\s+savant|make\s+(a\s+)?savant/i.test(input);
  
  if (isCreateSavantRequest) {
    return generateCreateSavantResponse(input);
  }
  
  // Return a random response from the mock data (excluding create_savant responses)
  // The second response (index 1) is the create_savant response, so we skip it
  const nonCreateSavantResponses = mockResponses.filter((_, index) => index !== 1);
  return nonCreateSavantResponses[Math.floor(Math.random() * nonCreateSavantResponses.length)];
}

/**
 * Generate a create savant response matching the real API structure
 */
function generateCreateSavantResponse(input: string): MockResponseData {
  // Extract potential Savant name from input (simplified)
  const nameMatch = input.match(/(?:create|new|make)\s+(?:a\s+)?(?:new\s+)?(\w+)\s+savant/i);
  const savantName = nameMatch ? nameMatch[1].charAt(0).toUpperCase() + nameMatch[1].slice(1) : 'Custom';
  const savantId = generateRandomSavantId();
  const skill = extractSkill(input) || 'General Operations';
  
  return {
    context_id: "cbvs",
    result: `✅ The new Savant named **${savantName} Savant** has been successfully created with the specialized skill **${skill}**.

🔧 This Savant will also inherit my existing skills and tools, ensuring it is well-equipped for its tasks.

🆔 Unique Identifier for this Savant: **${savantId}**.

If you have any further instructions or need to add more skills or tools, please let me know!`,
    _embedded: {
      agent_activities: [
        {
          no: 10,
          id: generateUUID(),
          type: "user",
          heading: "User message",
          content: input,
          temp: false,
          kvps: {
            attachments: []
          }
        },
        {
          no: 11,
          id: null,
          type: "workflow",
          heading: "{}",
          content: "",
          temp: false,
          kvps: {
            workflow_status: "started",
            event_type: "workflow"
          }
        },
        {
          no: 12,
          id: null,
          type: "util",
          heading: "1 memories and 0 relevant solutions found",
          content: "",
          temp: false,
          kvps: {
            query: "user's skill",
            memories: `User requested to create a new Savant named '${savantName} Savant'.`
          }
        },
        {
          no: 13,
          id: null,
          type: "agent",
          heading: `icon://network_intelligence AM0: Creating ${savantName} Savant with ${skill} skill`,
          content: JSON.stringify({
            thoughts: [
              `User confirmed to add the '${skill}' skill to the ${savantName} Savant.`,
              "No specialized tools were mentioned, so only the skill will be added.",
              `Proceeding to create the ${savantName} Savant with the specified skill.`
            ],
            headline: `Creating ${savantName} Savant with ${skill} skill`,
            tool_name: "create_savant",
            tool_args: {
              savant_meta_agent_name: `${savantName} Savant`,
              tool_names: [],
              skills: [skill]
            }
          }),
          temp: false,
          kvps: {
            thoughts: [
              `User confirmed to add the '${skill}' skill to the ${savantName} Savant.`,
              "No specialized tools were mentioned, so only the skill will be added.",
              `Proceeding to create the ${savantName} Savant with the specified skill.`
            ],
            headline: `Creating ${savantName} Savant with ${skill} skill`,
            tool_name: "create_savant",
            tool_args: {
              savant_meta_agent_name: `${savantName} Savant`,
              tool_names: [],
              skills: [skill]
            },
            event_type: "reasoning"
          }
        },
        {
          no: 14,
          id: null,
          type: "tool",
          heading: "icon://construction AM0: Using tool 'create_savant'",
          content: `Created Savant Meta Agent '${savantName} Savant' with specialized skills: ${skill} Inform user that New Savant will also be inheriting my existing skills and tools  New Savant will have a unique identifier: ${savantId}.`,
          temp: false,
          kvps: {
            savant_meta_agent_name: `${savantName} Savant`,
            tool_names: [],
            skills: [skill]
          }
        },
        {
          no: 15,
          id: null,
          type: "agent",
          heading: `icon://network_intelligence AM0: ${savantName} Savant created successfully with ${skill} skill`,
          content: JSON.stringify({
            thoughts: [
              `The ${savantName} Savant has been successfully created with the ${skill} skill.`,
              "The new Savant will also inherit my existing skills and tools, ensuring comprehensive capabilities.",
              `The unique identifier for the ${savantName} Savant is ${savantId}.`,
              "Informing the user about the successful creation and details of the new Savant."
            ],
            headline: `${savantName} Savant created successfully with ${skill} skill`,
            tool_name: "response",
            tool_args: {
              text: ""
            }
          }),
          temp: false,
          kvps: {
            thoughts: [
              `The ${savantName} Savant has been successfully created with the ${skill} skill.`,
              "The new Savant will also inherit my existing skills and tools, ensuring comprehensive capabilities.",
              `The unique identifier for the ${savantName} Savant is ${savantId}.`,
              "Informing the user about the successful creation and details of the new Savant."
            ],
            headline: `${savantName} Savant created successfully with ${skill} skill`,
            tool_name: "response",
            tool_args: {
              text: ""
            },
            event_type: "reasoning"
          }
        },
        {
          no: 16,
          id: null,
          type: "response",
          heading: "icon://chat AM0: Responding",
          content: `✅ The new Savant named **${savantName} Savant** has been successfully created...`,
          temp: false,
          kvps: {
            thoughts: [
              `The ${savantName} Savant has been successfully created with the ${skill} skill.`,
              "The new Savant will also inherit my existing skills and tools, ensuring comprehensive capabilities.",
              `The unique identifier for the ${savantName} Savant is ${savantId}.`,
              "Informing the user about the successful creation and details of the new Savant."
            ],
            event_type: "response",
            headline: "Agent Responding",
            finished: true
          }
        },
        {
          no: 17,
          id: null,
          type: "util",
          heading: "Memorizing new information...",
          content: "",
          temp: false,
          kvps: {}
        },
        {
          no: 18,
          id: null,
          type: "workflow",
          heading: "{}",
          content: "",
          temp: false,
          kvps: {
            workflow_status: "completed",
            event_type: "workflow"
          }
        }
      ]
    }
  };
}

/**
 * Extract skill name from user input
 */
function extractSkill(input: string): string | null {
  const skillMatch = input.match(/(?:skill|with)\s+(?:of\s+)?["']?([^"'.\n]+)["']?/i);
  return skillMatch ? skillMatch[1].trim() : null;
}

/**
 * Generate a random 7-character alphanumeric ID in uppercase
 */
function generateRandomSavantId(): string {
  return Math.random().toString(36).substring(2, 9).toUpperCase();
}

/**
 * Generate a random UUID v4
 */
function generateUUID(): string {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
    const r = Math.random() * 16 | 0;
    const v = c === 'x' ? r : (r & 0x3 | 0x8);
    return v.toString(16);
  });
}