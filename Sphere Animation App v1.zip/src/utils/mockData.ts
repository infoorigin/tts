export interface MockResponseData {
  context_id: string;
  result: string;
  _embedded: {
    agent_activities: Array<{
      no: number;
      id: string | null;
      type: string;
      heading: string;
      content: string;
      temp: boolean;
      kvps: any;
    }>;
  };
}

// Mock responses that simulate the real API structure
export const mockResponses: MockResponseData[] = [
  {
    context_id: "cbvs",
    result: `# Welcome to Savant COMP AI! 👋

I can help you with various tasks. Here are some features:

## Key Capabilities
- **Data Analysis**: Process and analyze complex datasets
- **Decision Support**: Provide actionable insights
- **Real-time Assistance**: Available 24/7

### Quick Example
\`\`\`javascript
const result = analyze(data);
console.log(result);
\`\`\`

> 💡 **Tip**: Feel free to ask me anything!`,
    _embedded: {
      agent_activities: [
        {
          no: 1,
          id: "mock-user-1",
          type: "user",
          heading: "User message",
          content: "Hello",
          temp: false,
          kvps: { attachments: [] }
        },
        {
          no: 2,
          id: null,
          type: "response",
          heading: "icon://chat AM0: Responding",
          content: "Welcome message",
          temp: false,
          kvps: { event_type: "response", finished: true }
        }
      ]
    }
  },
  {
    context_id: "cbvs",
    result: `✅ The new Savant named **Analytics Savant** has been successfully created with the specialized skill **Data Analysis**.

🔧 This Savant will also inherit my existing skills and tools, ensuring it is well-equipped for its tasks.

🆔 Unique Identifier for this Savant: **ANL7X9K**.

If you have any further instructions or need to add more skills or tools, please let me know!`,
    _embedded: {
      agent_activities: [
        {
          no: 10,
          id: "304e34fa-2393-489c-a4fe-f8db87d35af4",
          type: "user",
          heading: "User message",
          content: "Create an analytics savant",
          temp: false,
          kvps: {
            attachments: []
          }
        },
        {
          no: 11,
          id: null,
          type: "workflow",
          heading: "{}",
          content: "",
          temp: false,
          kvps: {
            workflow_status: "started",
            event_type: "workflow"
          }
        },
        {
          no: 12,
          id: null,
          type: "util",
          heading: "1 memories and 0 relevant solutions found",
          content: "",
          temp: false,
          kvps: {
            query: "user's skill",
            memories: "User requested to create a new Savant named 'Analytics Savant'."
          }
        },
        {
          no: 13,
          id: null,
          type: "agent",
          heading: "icon://network_intelligence AM0: Creating Analytics Savant with Data Analysis skill",
          content: JSON.stringify({
            thoughts: [
              "User confirmed to add the 'Data Analysis' skill to the Analytics Savant.",
              "No specialized tools were mentioned, so only the skill will be added.",
              "Proceeding to create the Analytics Savant with the specified skill."
            ],
            headline: "Creating Analytics Savant with Data Analysis skill",
            tool_name: "create_savant",
            tool_args: {
              savant_meta_agent_name: "Analytics Savant",
              tool_names: [],
              skills: ["Data Analysis"]
            }
          }),
          temp: false,
          kvps: {
            thoughts: [
              "User confirmed to add the 'Data Analysis' skill to the Analytics Savant.",
              "No specialized tools were mentioned, so only the skill will be added.",
              "Proceeding to create the Analytics Savant with the specified skill."
            ],
            headline: "Creating Analytics Savant with Data Analysis skill",
            tool_name: "create_savant",
            tool_args: {
              savant_meta_agent_name: "Analytics Savant",
              tool_names: [],
              skills: ["Data Analysis"]
            },
            event_type: "reasoning"
          }
        },
        {
          no: 14,
          id: null,
          type: "tool",
          heading: "icon://construction AM0: Using tool 'create_savant'",
          content: "Created Savant Meta Agent 'Analytics Savant' with specialized skills: Data Analysis Inform user that New Savant will also be inheriting my existing skills and tools  New Savant will have a unique identifier: ANL7X9K.",
          temp: false,
          kvps: {
            savant_meta_agent_name: "Analytics Savant",
            tool_names: [],
            skills: ["Data Analysis"]
          }
        },
        {
          no: 15,
          id: null,
          type: "agent",
          heading: "icon://network_intelligence AM0: Analytics Savant created successfully with Data Analysis skill",
          content: JSON.stringify({
            thoughts: [
              "The Analytics Savant has been successfully created with the Data Analysis skill.",
              "The new Savant will also inherit my existing skills and tools, ensuring comprehensive capabilities.",
              "The unique identifier for the Analytics Savant is ANL7X9K.",
              "Informing the user about the successful creation and details of the new Savant."
            ],
            headline: "Analytics Savant created successfully with Data Analysis skill",
            tool_name: "response",
            tool_args: {
              text: ""
            }
          }),
          temp: false,
          kvps: {
            thoughts: [
              "The Analytics Savant has been successfully created with the Data Analysis skill.",
              "The new Savant will also inherit my existing skills and tools, ensuring comprehensive capabilities.",
              "The unique identifier for the Analytics Savant is ANL7X9K.",
              "Informing the user about the successful creation and details of the new Savant."
            ],
            headline: "Analytics Savant created successfully with Data Analysis skill",
            tool_name: "response",
            tool_args: {
              text: ""
            },
            event_type: "reasoning"
          }
        },
        {
          no: 16,
          id: null,
          type: "response",
          heading: "icon://chat AM0: Responding",
          content: "✅ The new Savant named **Analytics Savant** has been successfully created...",
          temp: false,
          kvps: {
            thoughts: [
              "The Analytics Savant has been successfully created with the Data Analysis skill.",
              "The new Savant will also inherit my existing skills and tools, ensuring comprehensive capabilities.",
              "The unique identifier for the Analytics Savant is ANL7X9K.",
              "Informing the user about the successful creation and details of the new Savant."
            ],
            event_type: "response",
            headline: "Agent Responding",
            finished: true
          }
        },
        {
          no: 17,
          id: null,
          type: "util",
          heading: "Memorizing new information...",
          content: "",
          temp: false,
          kvps: {}
        },
        {
          no: 18,
          id: null,
          type: "workflow",
          heading: "{}",
          content: "",
          temp: false,
          kvps: {
            workflow_status: "completed",
            event_type: "workflow"
          }
        }
      ]
    }
  },
  {
    context_id: "cbvs",
    result: `## Analysis Complete ✓

Based on your query, here are my findings:

1. **Primary Insight**: The data shows significant trends
2. **Secondary Factors**: Multiple variables at play
3. **Recommendations**: 
   - Review the baseline metrics
   - Consider seasonal adjustments
   - Monitor ongoing changes

### Code Snippet
\`\`\`python
def process_data(input):
    return analyze(input)
\`\`\`

*Let me know if you need more details!*`,
    _embedded: {
      agent_activities: [
        {
          no: 1,
          id: "mock-user-2",
          type: "user",
          heading: "User message",
          content: "Analyze this",
          temp: false,
          kvps: { attachments: [] }
        },
        {
          no: 2,
          id: null,
          type: "agent",
          heading: "icon://network_intelligence AM0: Analyzing data",
          content: "Analysis in progress",
          temp: false,
          kvps: {
            tool_name: "analyze_data",
            event_type: "reasoning"
          }
        },
        {
          no: 3,
          id: null,
          type: "response",
          heading: "icon://chat AM0: Responding",
          content: "Analysis complete",
          temp: false,
          kvps: { event_type: "response", finished: true }
        }
      ]
    }
  },
  {
    context_id: "cbvs",
    result: `### Great question! 🎯

Here's what I found:

- ✅ **Option A**: Best for short-term goals
- ⚠️ **Option B**: Requires more resources
- 🚀 **Option C**: Highest potential ROI

#### Quick Stats
| Metric | Value | Status |
|--------|-------|--------|
| Accuracy | 98% | ✓ |
| Speed | Fast | ✓ |
| Cost | Low | ✓ |

> Remember: Results may vary based on your specific use case.`,
    _embedded: {
      agent_activities: [
        {
          no: 1,
          id: "mock-user-3",
          type: "user",
          heading: "User message",
          content: "What are my options?",
          temp: false,
          kvps: { attachments: [] }
        },
        {
          no: 2,
          id: null,
          type: "response",
          heading: "icon://chat AM0: Responding",
          content: "Options analysis",
          temp: false,
          kvps: { event_type: "response", finished: true }
        }
      ]
    }
  },
  {
    context_id: "cbvs",
    result: `## Response Summary

**Your request has been processed!** Here's what you need to know:

### Main Points
1. First consideration
2. Second factor to review
3. Third actionable step

**Bold insight**: This is a critical finding that requires attention.

*Italic note*: Additional context for reference.

\`inline code example\` can be used like this.

---

Need more help? Just ask! 💬`,
    _embedded: {
      agent_activities: [
        {
          no: 1,
          id: "mock-user-4",
          type: "user",
          heading: "User message",
          content: "Process my request",
          temp: false,
          kvps: { attachments: [] }
        },
        {
          no: 2,
          id: null,
          type: "response",
          heading: "icon://chat AM0: Responding",
          content: "Request processed",
          temp: false,
          kvps: { event_type: "response", finished: true }
        }
      ]
    }
  },
  {
    context_id: "cbvs",
    result: `# Deep Dive Analysis 📊

## Overview
The analysis reveals interesting patterns in the data.

### Breakdown
- **Category 1**: Shows 23% improvement
- **Category 2**: Stable performance
- **Category 3**: Needs attention ⚠️

#### Technical Details
\`\`\`json
{
  "status": "success",
  "confidence": 0.95,
  "recommendation": "proceed"
}
\`\`\`

### Next Steps
1. Review findings
2. Implement changes
3. Monitor results

> 🔍 **Note**: This is based on current data trends`,
    _embedded: {
      agent_activities: [
        {
          no: 1,
          id: "mock-user-5",
          type: "user",
          heading: "User message",
          content: "Deep dive analysis",
          temp: false,
          kvps: { attachments: [] }
        },
        {
          no: 2,
          id: null,
          type: "agent",
          heading: "icon://network_intelligence AM0: Deep analysis",
          content: "Running deep analysis",
          temp: false,
          kvps: {
            tool_name: "deep_analysis",
            event_type: "reasoning"
          }
        },
        {
          no: 3,
          id: null,
          type: "response",
          heading: "icon://chat AM0: Responding",
          content: "Analysis complete",
          temp: false,
          kvps: { event_type: "response", finished: true }
        }
      ]
    }
  }
];