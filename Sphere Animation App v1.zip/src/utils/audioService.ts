import { config } from '../config';

/**
 * Play mock TTS audio using AudioContext
 * Generates a simple tone that plays for 1-2 seconds
 */
export async function playMockTTS(text: string): Promise<void> {
  try {
    // Mock mode - use AudioContext to generate a simple tone
    const mockDuration = 1000 + Math.random() * 1000; // Random duration between 1000-2000ms
    
    console.log(`[Mock TTS] Playing audio for ${mockDuration.toFixed(0)}ms`);
    console.log(`[Mock TTS] Text: "${text.substring(0, 50)}${text.length > 50 ? '...' : ''}"`);
    
    // Create audio context and generate tone
    const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
    const oscillator = audioContext.createOscillator();
    const gainNode = audioContext.createGain();
    
    oscillator.connect(gainNode);
    gainNode.connect(audioContext.destination);
    
    // Configure tone
    oscillator.type = 'sine';
    oscillator.frequency.setValueAtTime(440, audioContext.currentTime); // A4 note
    gainNode.gain.setValueAtTime(0.1, audioContext.currentTime); // Low volume
    
    // Fade in
    gainNode.gain.linearRampToValueAtTime(0.3, audioContext.currentTime + 0.1);
    
    // Start playing
    oscillator.start();
    
    // Fade out and stop after mock duration
    setTimeout(() => {
      gainNode.gain.linearRampToValueAtTime(0, audioContext.currentTime + 0.1);
      setTimeout(() => {
        oscillator.stop();
        audioContext.close();
        console.log('[Mock TTS] Playback complete');
      }, 100);
    }, mockDuration);
    
    console.log('[Mock TTS] Audio started');
  } catch (error) {
    console.error('Error playing mock TTS audio:', error);
    throw error;
  }
}

/**
 * Play real TTS audio by calling the TTS API
 * Returns an Audio element that can be controlled
 */
export async function playRealTTS(text: string): Promise<HTMLAudioElement> {
  try {
    console.log('[TTS] Calling real TTS API with text:', text.substring(0, 100) + (text.length > 100 ? '...' : ''));
    
    // Build the full URL with query parameters
    const ttsUrl = config.tts.getFullUrl(text);
    console.log('[TTS] API URL:', config.tts.url);
    console.log('[TTS] Parameters:', {
      voice: config.tts.params.voice,
      engine: config.tts.params.engine,
      format: config.tts.params.format,
      textLength: text.length
    });
    
    const response = await fetch(ttsUrl, {
      method: 'GET',
      headers: { 
        'accept': 'audio/mpeg',
      },
    });

    if (!response.ok) {
      throw new Error(`TTS API error: ${response.status} ${response.statusText}`);
    }

    // The API returns audio stream directly
    const audioBlob = await response.blob();
    const audioUrl = URL.createObjectURL(audioBlob);
    
    const audio = new Audio(audioUrl);
    audio.volume = 0.7;
    
    audio.onended = () => {
      console.log('[TTS] Playback complete');
      URL.revokeObjectURL(audioUrl);
    };
    
    audio.onerror = (e) => {
      console.error('[TTS] Audio playback error:', e);
      URL.revokeObjectURL(audioUrl);
    };
    
    await audio.play();
    console.log('[TTS] Playing audio from API');
    
    return audio;
  } catch (error) {
    console.error('Error playing real TTS audio:', error);
    throw error;
  }
}

/**
 * Play TTS audio - either mock or real based on config
 */
export async function playTTS(text: string, audioRef?: React.MutableRefObject<HTMLAudioElement | null>): Promise<void> {
  try {
    if (config.mockAudio) {
      await playMockTTS(text);
    } else {
      // Stop any currently playing audio
      if (audioRef?.current) {
        audioRef.current.pause();
        audioRef.current.currentTime = 0;
      }
      
      const audio = await playRealTTS(text);
      
      // Store reference if provided
      if (audioRef) {
        audioRef.current = audio;
      }
    }
  } catch (error) {
    console.error('Error playing TTS audio:', error);
  }
}