import { useState, useEffect } from 'react';
import { RedSphere } from './RedSphere';
import { config } from '../config';

interface SphereProps {
  onStreamComplete?: boolean;
}

export function Sphere({ onStreamComplete = false }: SphereProps) {
  const [showRedSphere, setShowRedSphere] = useState(false);

  useEffect(() => {
    if (onStreamComplete) {
      // Delay before showing the red sphere
      const timer = setTimeout(() => {
        setShowRedSphere(true);
      }, 500);
      return () => clearTimeout(timer);
    }
  }, [onStreamComplete]);

  return (
    <div className="relative w-full h-full flex items-center justify-center overflow-hidden">
      <video
        className="w-full h-full object-contain"
        autoPlay
        loop
        muted
        playsInline
      >
        <source src={config.videoUrl} type="video/mp4" />
        Your browser does not support the video tag.
      </video>

      {/* Red sphere birth animation */}
      <RedSphere isVisible={showRedSphere} />
    </div>
  );
}