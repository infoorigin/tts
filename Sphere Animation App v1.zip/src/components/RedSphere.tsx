import { motion } from "motion/react";
import { useEffect, useState } from "react";
import { config } from "../config";

interface RedSphereProps {
  isVisible: boolean;
}

export function RedSphere({ isVisible }: RedSphereProps) {
  const [pulseIntensity, setPulseIntensity] = useState(1);
  const [hasMovedToEdge, setHasMovedToEdge] = useState(false);

  useEffect(() => {
    const interval = setInterval(() => {
      setPulseIntensity(prev => (prev === 1 ? 1.08 : 1));
    }, 2000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    if (isVisible) {
      // After sphere is born, wait a moment then move to edge
      const timer = setTimeout(() => {
        setHasMovedToEdge(true);
      }, 2500); // Wait for birth animation to complete
      return () => clearTimeout(timer);
    }
  }, [isVisible]);

  if (!isVisible) return null;

  // Calculate horizontal movement to the right side just outside the purple sphere
  // Move to the right edge of the viewport
  const moveDistance = window.innerWidth * 0.35; // Move to right side (35% of viewport width)
  const moveX = moveDistance; // Horizontal movement to the right
  const moveY = 0; // No vertical movement

  const handleClick = () => {
    window.open(config.redSphereLink, '_blank', 'noopener,noreferrer');
  };

  return (
    <motion.div
      className="absolute inset-0 flex items-center justify-center pointer-events-none"
      initial={{ opacity: 0 }}
      animate={{ 
        opacity: 1,
        x: hasMovedToEdge ? moveX : 0,
        y: hasMovedToEdge ? moveY : 0,
      }}
      transition={{ 
        opacity: { duration: 1, ease: "easeOut" },
        x: { duration: 2, ease: "easeInOut", delay: 0 },
        y: { duration: 2, ease: "easeInOut", delay: 0 },
      }}
    >
      <motion.div
        className="relative flex items-center justify-center pointer-events-auto cursor-pointer"
        onClick={handleClick}
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ 
          duration: 2.5,
          ease: [0.34, 1.56, 0.64, 1],
        }}
      >
        {/* Outer glow ring - gentle pulse */}
        <motion.div
          className="absolute w-[240px] h-[240px] rounded-full"
          style={{
            background: "radial-gradient(circle, rgba(215, 22, 0, 0.15) 0%, transparent 70%)",
          }}
          animate={{
            scale: pulseIntensity,
            opacity: [0.4, 0.6, 0.4],
          }}
          transition={{
            duration: 3,
            repeat: Infinity,
            ease: "easeInOut",
          }}
        />

        {/* Middle glow ring */}
        <motion.div
          className="absolute w-[200px] h-[200px] rounded-full"
          style={{
            background: "radial-gradient(circle, rgba(215, 22, 0, 0.2) 0%, transparent 70%)",
          }}
          animate={{
            scale: pulseIntensity,
            opacity: [0.5, 0.7, 0.5],
          }}
          transition={{
            duration: 3,
            repeat: Infinity,
            ease: "easeInOut",
            delay: 0.5,
          }}
        />

        {/* Main red sphere - 30% of 600px = 180px */}
        <motion.div
          className="relative w-[180px] h-[180px] rounded-full overflow-hidden"
          style={{
            background: "radial-gradient(circle at 35% 35%, #fca5a5, #f87171, #dc2626, #b91c1c, #991b1b, #7f1d1d)",
            boxShadow: `
              0 0 60px rgba(215, 22, 0, 0.4),
              0 0 90px rgba(215, 22, 0, 0.2),
              inset -25px -25px 70px rgba(0, 0, 0, 0.5),
              inset 25px 25px 70px rgba(255, 200, 200, 0.4),
              inset 0 0 80px rgba(220, 38, 38, 0.2)
            `,
          }}
          animate={{
            scale: pulseIntensity,
            rotate: 360,
          }}
          transition={{
            scale: {
              duration: 3,
              repeat: Infinity,
              ease: "easeInOut",
            },
            rotate: {
              duration: 40,
              repeat: Infinity,
              ease: "linear",
            },
          }}
        >
          {/* Primary highlight - top left - creates glossy effect */}
          <motion.div
            className="absolute top-[22px] left-[36px] w-[72px] h-[72px] rounded-full pointer-events-none"
            style={{
              background: "radial-gradient(circle, rgba(255, 255, 255, 0.9) 0%, rgba(255, 255, 255, 0.5) 30%, transparent 70%)",
            }}
            initial={{ opacity: 0, scale: 0 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.3, duration: 0.8 }}
          />

          {/* Secondary highlight - subtle shimmer */}
          <motion.div
            className="absolute top-[45px] left-[18px] w-[36px] h-[36px] rounded-full pointer-events-none"
            style={{
              background: "radial-gradient(circle, rgba(255, 255, 255, 0.6) 0%, transparent 60%)",
            }}
            initial={{ opacity: 0 }}
            animate={{ opacity: [0, 0.8, 0] }}
            transition={{ 
              delay: 0.5, 
              duration: 2.5,
              repeat: Infinity,
              ease: "easeInOut"
            }}
          />

          {/* Globe meridian lines - vertical stripes */}
          {[...Array(8)].map((_, i) => (
            <div
              key={`meridian-${i}`}
              className="absolute top-0 left-1/2 w-px h-full -translate-x-1/2 pointer-events-none"
              style={{
                background: "linear-gradient(to bottom, transparent, rgba(255, 255, 255, 0.12) 20%, rgba(255, 255, 255, 0.12) 80%, transparent)",
                transform: `translateX(-50%) rotateY(${i * 22.5}deg)`,
                transformOrigin: "center",
              }}
            />
          ))}

          {/* Globe latitude circles - horizontal bands */}
          {[...Array(5)].map((_, i) => {
            const size = 168 - Math.abs(i - 2) * 36;
            const top = 6 + i * 42;
            return (
              <div
                key={`latitude-${i}`}
                className="absolute left-1/2 -translate-x-1/2 rounded-full border border-white/10 pointer-events-none"
                style={{
                  width: `${size}px`,
                  height: `${size * 0.25}px`,
                  top: `${top}px`,
                }}
              />
            );
          })}

          {/* 3D Mesh Network Core */}
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[108px] h-[108px] pointer-events-none">
            {/* Central glow */}
            <motion.div
              className="absolute inset-0 rounded-full"
              style={{
                background: "radial-gradient(circle, rgba(255, 255, 255, 0.25) 0%, transparent 70%)",
              }}
              animate={{
                scale: [1, 1.05, 1],
                opacity: [0.4, 0.6, 0.4],
              }}
              transition={{
                duration: 3,
                repeat: Infinity,
                ease: "easeInOut",
              }}
            />

            {/* Rotating mesh lines - horizontal rotation only */}
            {[...Array(6)].map((_, lineIndex) => (
              <motion.div
                key={`v-line-${lineIndex}`}
                className="absolute top-1/2 left-1/2 w-px h-[96px] -translate-x-1/2 -translate-y-1/2 pointer-events-none"
                style={{
                  background: "linear-gradient(to bottom, transparent, rgba(255, 255, 255, 0.35) 50%, transparent)",
                  transformOrigin: "center",
                }}
                animate={{
                  rotate: [lineIndex * 30, lineIndex * 30 + 360],
                }}
                transition={{
                  duration: 10,
                  repeat: Infinity,
                  ease: "linear",
                }}
              />
            ))}
          </div>

          {/* Bottom shadow/depth */}
          <div
            className="absolute bottom-0 left-1/2 -translate-x-1/2 w-[140px] h-[70px] rounded-full pointer-events-none"
            style={{
              background: "radial-gradient(ellipse at center, rgba(0, 0, 0, 0.4) 0%, transparent 70%)",
            }}
          />
        </motion.div>
      </motion.div>
    </motion.div>
  );
}