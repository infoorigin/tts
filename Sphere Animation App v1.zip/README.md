
  # Sphere Animation App v1

  This is a code bundle for Sphere Animation App v1. The original project is available at https://www.figma.com/design/GEACXLDTZkRVsbcVWSN9I2/Sphere-Animation-App-v1.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  