import { useState, useRef, useEffect } from "react";
import {
  Send,
  ChevronLeft,
  MessageCircleMore,
  Volume2,
  VolumeX,
} from "lucide-react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { config } from "../config";
import savantLogo from "figma:asset/01267cdb23607527a7cf4507f45e5bd11f228c9e.png";
import jnjLogo from "figma:asset/423611bc1574c7e40b5e99f6e50aedc7b6382e6b.png";
import ReactMarkdown from "react-markdown";
import { generateMockResponse } from "../utils/mockService";
import { playTTS } from "../utils/audioService";
import { useConversationSync } from "../hooks/useConversationSync";
import { conversationStream } from "../utils/conversationStream";

interface Message {
  id: string;
  role: "user" | "assistant";
  content: string;
  timestamp: Date;
  isStreaming?: boolean;
}

interface ChatInterfaceProps {
  onClose?: () => void;
  onFirstResponse?: () => void;
  isVisible?: boolean;
  onThoughtStreamOpened?: () => void;
}

export function ChatInterface({
  onClose,
  onFirstResponse,
  isVisible,
  onThoughtStreamOpened,
}: ChatInterfaceProps) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputValue, setInputValue] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const [
    hasReceivedFirstResponse,
    setHasReceivedFirstResponse,
  ] = useState(false);
  const [isAudioEnabled, setIsAudioEnabled] = useState(true); // Default to true
  const [hasShownWelcome, setHasShownWelcome] = useState(false);
  const [hasStartedConversation, setHasStartedConversation] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false); // Prevent concurrent messages
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const typingTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const messageQueueRef = useRef<Array<() => Promise<void>>>([]);
  const isProcessingQueueRef = useRef(false);

  // Use centralized conversation sync hook for handling conversation stream messages
  const conversationSync = useConversationSync({
    savantKey: "mother_savant",
    isVisible: !!isVisible, // Always subscribe when visible, works for both mock and real modes
    isAudioEnabled,
    onMessage: (message) => {
      // Don't add message here - let the hook handle typing animation
      // The message will be added to completedMessages after typing finishes
      console.log(
        "[ChatInterface] Received message from conversation stream:",
        message.substring(0, 50) + "...",
      );
    },
  });

  // Add completed messages from conversation stream to chat messages
  useEffect(() => {
    // When a new completed message arrives from conversation stream, add it to chat
    const lastCompletedMessage =
      conversationSync.completedMessages[
        conversationSync.completedMessages.length - 1
      ];

    if (lastCompletedMessage) {
      console.log(
        "[ChatInterface] New completed message from conversation stream:",
        lastCompletedMessage.substring(0, 50) + "...",
      );
      
      // Use functional update to access current state
      setMessages((prevMessages) => {
        // Check if this message is already in the messages array
        const messageExists = prevMessages.some(
          (m) => m.content === lastCompletedMessage,
        );

        if (!messageExists) {
          console.log(
            "[ChatInterface] Adding completed conversation stream message to chat",
          );
          const streamingMessage: Message = {
            id: `conv-${Date.now()}`,
            role: "assistant",
            content: lastCompletedMessage,
            timestamp: new Date(),
            isStreaming: false,
          };
          return [...prevMessages, streamingMessage];
        }
        
        return prevMessages;
      });
    }
  }, [conversationSync.completedMessages]);

  // Update typing state from hook
  useEffect(() => {
    setIsTyping(conversationSync.isTyping);
  }, [conversationSync.isTyping]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({
      behavior: "smooth",
    });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, conversationSync.currentText]); // Also scroll when currentText changes

  // Show welcome message only when chat becomes visible for the first time
  useEffect(() => {
    if (isVisible && !hasShownWelcome) {
      setHasShownWelcome(true);
      setIsProcessing(true);

      const showWelcome = async () => {
        const welcomeText =
          "I am the **Principal Savant Meta Controller** of COMP AI system. I create and manage specialized subordinate Savants.\\n";

        // Use streamMessage which handles audio and typing in parallel
        await streamMessage(
          welcomeText,
          "assistant",
          "welcome-" + Date.now(),
          true,
        ); // Pass true to indicate this is welcome message

        setIsProcessing(false);
      };

      showWelcome();
    }
  }, [isVisible, hasShownWelcome]);

  const streamMessage = async (
    fullText: string,
    role: "user" | "assistant",
    id: string,
    isWelcome = false,
  ) => {
    const streamingMessage: Message = {
      id,
      role,
      content: "",
      timestamp: new Date(),
      isStreaming: true,
    };

    setMessages((prev) => [...prev, streamingMessage]);

    // Start audio and typing in PARALLEL for assistant messages
    const audioPromise = (role === "assistant" && isAudioEnabled)
      ? playTTS(fullText, audioRef)
      : Promise.resolve();

    // Create typing promise
    const typingPromise = (async () => {
      const words = fullText.split(" ");
      let currentText = "";

      for (let i = 0; i < words.length; i++) {
        currentText += (i === 0 ? "" : " ") + words[i];

        setMessages((prev) =>
          prev.map((msg) =>
            msg.id === id
              ? { ...msg, content: currentText }
              : msg,
          ),
        );

        await new Promise((resolve) => setTimeout(resolve, 80));
      }

      // Mark streaming as complete
      setMessages((prev) =>
        prev.map((msg) =>
          msg.id === id ? { ...msg, isStreaming: false } : msg,
        ),
      );
    })();

    // Wait for BOTH audio and typing to complete
    console.log(
      "[ChatInterface] Starting audio and typing in parallel for real TTS...",
    );
    await Promise.all([audioPromise, typingPromise]);
    console.log("[ChatInterface] Both audio and typing complete for real TTS");
  };

  const toggleAudio = () => {
    setIsAudioEnabled(!isAudioEnabled);
    if (isAudioEnabled) {
      // Stop any playing audio
      if (audioRef.current) {
        audioRef.current.pause();
      }
    }
  };

  const handleSendMessage = async () => {
    if (!inputValue.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: "user",
      content: inputValue,
      timestamp: new Date(),
    };

    const userMessageContent = inputValue;
    setMessages((prev) => [...prev, userMessage]);
    setInputValue("");
    setIsTyping(true);
    setIsProcessing(true);

    try {
      // Check if we're in real API mode (based on thoughtStream.mock config)
      const isRealApiMode = !config.thoughtStream.mock;

      if (isRealApiMode) {
        // REAL API MODE: Route through global queue
        console.log(
          "[ChatInterface] Using global queue for user message in real API mode",
        );

        // Send message through global queue - response will come back via subscription
        await conversationStream.sendUserMessage(userMessageContent);

        // Note: Response handling is done via the useConversationSync subscription
        // The onMessage callback will add the assistant's response to the messages array

        setIsTyping(false);
        setIsProcessing(false);

      } else {
        // MOCK MODE: Handle locally with mock response
        console.log("[ChatInterface] Using local mock response handler");

        let responseText = "";
        let shouldShowRedSphere = false;

        if (config.mockChat) {
          // Mock mode - simulate API response
          await new Promise((resolve) =>
            setTimeout(resolve, 1000 + Math.random() * 1000),
          );
          const mockResponse = generateMockResponse(
            userMessageContent,
          );
          responseText = mockResponse.result;

          // Debug logging
          console.log(
            "Mock response for input:",
            userMessageContent,
          );
          console.log(
            "Mock response activities:",
            mockResponse._embedded?.agent_activities,
          );

          // Check if any activity has tool_name === "create_savant"
          if (mockResponse._embedded?.agent_activities) {
            shouldShowRedSphere =
              mockResponse._embedded.agent_activities.some(
                (activity: any) => {
                  const hasCreateSavant =
                    activity.kvps?.tool_name === "create_savant";
                  if (hasCreateSavant) {
                    console.log(
                      "Found create_savant in activity:",
                      activity,
                    );
                  }
                  return hasCreateSavant;
                },
              );
          }
          console.log(
            "shouldShowRedSphere:",
            shouldShowRedSphere,
          );
        } else {
          // Real API call (but not using global queue because thought stream is in mock mode)
          const response = await fetch(config.chatApiUrl, {
            method: "POST",
            headers: {
              accept: "application/json",
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              message: userMessageContent,
              context_id: config.contextId,
              embed: ["agent_activities"],
            }),
          });

          if (!response.ok) {
            throw new Error(`API error: ${response.status}`);
          }

          const data = await response.json();
          responseText = data.result || "No response received";

          // Check if any activity has tool_name === "create_savant"
          if (data._embedded?.agent_activities) {
            shouldShowRedSphere =
              data._embedded.agent_activities.some(
                (activity: any) =>
                  activity.kvps?.tool_name === "create_savant",
              );
          }
        }

        setIsTyping(false);

        // streamMessage now handles audio internally, so we don't call playTTS here
        await streamMessage(
          responseText,
          "assistant",
          (Date.now() + 1).toString(),
        );

        // Only clear processing after audio + text complete
        setIsProcessing(false);

        // Trigger callback every time create_savant is detected
        if (shouldShowRedSphere && onFirstResponse) {
          onFirstResponse();
        }
      }
    } catch (error) {
      console.error("Error sending message:", error);
      setIsTyping(false);
      setIsProcessing(false);

      // Show error message
      const errorMessage =
        "Sorry, I encountered an error processing your request. Please try again.";

      // streamMessage now handles audio internally, so we don't call playTTS here
      await streamMessage(
        errorMessage,
        "assistant",
        (Date.now() + 1).toString(),
      );
    }
  };

  const handleKeyPress = (
    e: React.KeyboardEvent<HTMLInputElement>,
  ) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  return (
    <div className="w-full max-w-sm h-[calc(100vh-96px)] bg-white/95 backdrop-blur-xl rounded-3xl shadow-2xl flex flex-col border border-gray-200/50">
      {/* Header */}
      <div className="p-3 border-b border-gray-200/50 flex items-center justify-between flex-shrink-0">
        <div className="flex items-center gap-2">
          <MessageCircleMore
            className="w-5 h-5"
            style={{ color: "#D71600" }}
          />
        </div>
        <div className="flex items-center gap-2">
          <Button
            onClick={toggleAudio}
            size="icon"
            variant="ghost"
            className="w-7 h-7 rounded-full hover:bg-gray-100"
          >
            {isAudioEnabled ? (
              <Volume2
                className="w-4 h-4"
                style={{ color: "#D71600" }}
              />
            ) : (
              <VolumeX className="w-4 h-4 text-gray-400" />
            )}
          </Button>
          <Button
            onClick={onClose}
            size="icon"
            className="w-7 h-7 rounded-full hover:opacity-90"
            style={{ backgroundColor: "#D71600" }}
          >
            <ChevronLeft className="w-3.5 h-3.5" />
          </Button>
        </div>
      </div>

      {/* Messages Container */}
      <div className="flex-1 overflow-y-auto p-3 space-y-2 scrollbar-hide min-h-0">
        {messages.map((message) => (
          <div
            key={message.id}
            className={`flex ${
              message.role === "user"
                ? "justify-end"
                : "justify-start"
            }`}
          >
            <div
              className={`max-w-[85%] rounded-2xl px-3 py-2 ${
                message.role === "user"
                  ? "text-white"
                  : "bg-gray-100 text-gray-900"
              }`}
              style={
                message.role === "user"
                  ? { backgroundColor: "#D71600" }
                  : undefined
              }
            >
              <div
                className={
                  message.role === "user"
                    ? "markdown-content markdown-content-user"
                    : "markdown-content"
                }
              >
                <ReactMarkdown>{message.content}</ReactMarkdown>
              </div>
            </div>
          </div>
        ))}

        {/* Show currently typing text from conversation stream */}
        {conversationSync.isTyping && conversationSync.currentText && (
          <div className="flex justify-start">
            <div className="bg-gray-100 rounded-2xl px-3 py-2 text-gray-900">
              <div className="markdown-content">
                <ReactMarkdown>{conversationSync.currentText}</ReactMarkdown>
              </div>
            </div>
          </div>
        )}

        {/* Show typing indicator only when typing but no text yet */}
        {isTyping && !conversationSync.currentText && (
          <div className="flex justify-start">
            <div className="bg-gray-100 rounded-2xl px-3 py-2">
              <div className="flex gap-1">
                <span
                  className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"
                  style={{ animationDelay: "0ms" }}
                ></span>
                <span
                  className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"
                  style={{ animationDelay: "150ms" }}
                ></span>
                <span
                  className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"
                  style={{ animationDelay: "300ms" }}
                ></span>
              </div>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Input Area */}
      <div className="p-3 border-t border-gray-200/50 flex-shrink-0">
        <div className="flex gap-2 items-center bg-gray-100 rounded-full px-3 py-1.5">
          <Input
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder="Message..."
            className="flex-1 border-0 bg-transparent focus-visible:ring-0 focus-visible:ring-offset-0 px-0 text-sm"
          />
          <Button
            onClick={handleSendMessage}
            disabled={!inputValue.trim() || isTyping || isProcessing}
            size="icon"
            className="w-7 h-7 rounded-full hover:opacity-90"
            style={{ backgroundColor: "#D71600" }}
          >
            <Send className="w-3.5 h-3.5" />
          </Button>
        </div>
      </div>
    </div>
  );
}