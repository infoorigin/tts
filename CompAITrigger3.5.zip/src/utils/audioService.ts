import { config } from '../config';

/**
 * Play mock TTS audio using AudioContext
 * Generates a simple tone that plays for configured duration
 */
export async function playMockTTS(text: string): Promise<void> {
  return new Promise((resolve, reject) => {
    try {
      // Use configurable duration range from config
      const { min, max } = config.mockAudioDuration;
      const mockDuration = min + Math.random() * (max - min);
      
      console.log(`[Mock TTS] Playing generated tone for ${mockDuration.toFixed(0)}ms`);
      console.log(`[Mock TTS] Text: "${text.substring(0, 50)}${text.length > 50 ? '...' : ''}"`);
      
      // Create audio context and generate tone
      const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
      const oscillator = audioContext.createOscillator();
      const gainNode = audioContext.createGain();
      
      oscillator.connect(gainNode);
      gainNode.connect(audioContext.destination);
      
      // Configure tone
      oscillator.type = 'sine';
      oscillator.frequency.setValueAtTime(440, audioContext.currentTime); // A4 note
      gainNode.gain.setValueAtTime(0.1, audioContext.currentTime); // Low volume
      
      // Fade in
      gainNode.gain.linearRampToValueAtTime(0.3, audioContext.currentTime + 0.1);
      
      // Start playing
      oscillator.start();
      
      // Fade out and stop after mock duration
      setTimeout(() => {
        gainNode.gain.linearRampToValueAtTime(0, audioContext.currentTime + 0.1);
        setTimeout(() => {
          oscillator.stop();
          audioContext.close();
          console.log('[Mock TTS] Playback complete');
          resolve();
        }, 100);
      }, mockDuration);
      
      console.log('[Mock TTS] Audio started');
    } catch (error) {
      console.error('Error playing mock TTS audio:', error);
      reject(error);
    }
  });
}

/**
 * Play mock TTS audio from a sample URL
 * @param audioUrl - The URL of the sample audio file
 * @param audioType - Type of audio for logging (e.g., 'chat', 'tecvali', 'inlexzo')
 */
export async function playMockTTSFromUrl(audioUrl: string, audioType: string = 'chat'): Promise<void> {
  return new Promise((resolve, reject) => {
    try {
      console.log(`[Mock TTS] Attempting to play sample audio from URL for ${audioType}`);
      console.log(`[Mock TTS] Audio URL: ${audioUrl}`);
      
      const audio = new Audio(audioUrl);
      audio.volume = 0.5; // Lower volume for mock audio
      
      // Use configurable duration range from config
      const { min, max } = config.mockAudioDuration;
      const mockDuration = min + Math.random() * (max - min);
      
      let hasResolved = false;
      
      audio.onloadeddata = () => {
        console.log(`[Mock TTS] Audio loaded, playing for ${mockDuration.toFixed(0)}ms`);
        audio.play().catch(error => {
          console.error('[Mock TTS] Error playing audio:', error);
          if (!hasResolved) {
            hasResolved = true;
            // Fallback to generated tone
            console.log('[Mock TTS] Falling back to generated tone');
            playMockTTS('Fallback audio').then(resolve).catch(reject);
          }
        });
        
        // Stop audio after mock duration
        setTimeout(() => {
          audio.pause();
          audio.currentTime = 0;
          console.log('[Mock TTS] Playback complete');
          if (!hasResolved) {
            hasResolved = true;
            resolve();
          }
        }, mockDuration);
      };
      
      audio.onerror = (e) => {
        console.warn('[Mock TTS] Error loading audio from URL, falling back to generated tone:', e);
        if (!hasResolved) {
          hasResolved = true;
          // Fallback to generated tone instead of rejecting
          playMockTTS('Fallback audio').then(resolve).catch(reject);
        }
      };
      
      // Set a timeout in case the audio never loads
      setTimeout(() => {
        if (!hasResolved) {
          console.warn('[Mock TTS] Audio loading timeout, falling back to generated tone');
          hasResolved = true;
          audio.pause();
          playMockTTS('Fallback audio').then(resolve).catch(reject);
        }
      }, 2000); // 2 second timeout
      
    } catch (error) {
      console.error('Error playing mock TTS audio from URL:', error);
      // Fallback to generated tone
      console.log('[Mock TTS] Falling back to generated tone');
      playMockTTS('Fallback audio').then(resolve).catch(reject);
    }
  });
}

/**
 * Play real TTS audio by calling the TTS API
 * Returns a promise that resolves when audio finishes playing
 */
export async function playRealTTS(text: string): Promise<void> {
  return new Promise(async (resolve, reject) => {
    try {
      console.log('[TTS] Calling real TTS API with text:', text.substring(0, 100) + (text.length > 100 ? '...' : ''));
      
      // Build the full URL with query parameters
      const ttsUrl = config.tts.getFullUrl(text);
      console.log('[TTS] API URL:', config.tts.url);
      console.log('[TTS] Parameters:', {
        voice: config.tts.params.voice,
        engine: config.tts.params.engine,
        format: config.tts.params.format,
        textLength: text.length
      });
      
      const response = await fetch(ttsUrl, {
        method: 'GET',
        headers: { 
          'accept': 'audio/mpeg',
        },
      });

      if (!response.ok) {
        throw new Error(`TTS API error: ${response.status} ${response.statusText}`);
      }

      // The API returns audio stream directly
      const audioBlob = await response.blob();
      const audioUrl = URL.createObjectURL(audioBlob);
      
      const audio = new Audio(audioUrl);
      audio.volume = 0.7;
      
      // Set up event handlers BEFORE starting playback
      audio.onended = () => {
        console.log('[TTS] Playback complete');
        URL.revokeObjectURL(audioUrl);
        resolve();
      };
      
      audio.onerror = (e) => {
        console.error('[TTS] Audio playback error:', e);
        URL.revokeObjectURL(audioUrl);
        reject(e);
      };
      
      // Start playback - only wait for play() to start, NOT complete
      // The promise will resolve when onended fires
      await audio.play();
      console.log('[TTS] Audio playback started, waiting for completion...');
      
      // DO NOT resolve here - wait for onended event
    } catch (error) {
      console.error('Error playing real TTS audio:', error);
      reject(error);
    }
  });
}

/**
 * Play real TTS audio for thought streams by calling the savant-specific TTS API
 * Returns a promise that resolves when audio finishes playing
 */
export async function playThoughtStreamTTS(text: string, savantKey: 'tecvali_savant' | 'inlexzo_savant'): Promise<void> {
  return new Promise(async (resolve, reject) => {
    try {
      const savantConfigKey = savantKey === 'tecvali_savant' ? 'tecvali' : 'inlexzo';
      const audioConfig = config.thoughtStream.audioUrls[savantConfigKey];
      
      console.log(`[Thought Stream TTS] Calling ${savantConfigKey} TTS API with text:`, text.substring(0, 100) + (text.length > 100 ? '...' : ''));
      
      // Build the full URL with query parameters
      const ttsUrl = audioConfig.getFullUrl(text);
      console.log(`[Thought Stream TTS] API URL: ${audioConfig.baseUrl}${audioConfig.streamPath}`);
      console.log('[Thought Stream TTS] Parameters:', {
        voice: audioConfig.params.voice,
        engine: audioConfig.params.engine,
        format: audioConfig.params.format,
        textLength: text.length,
        savant: savantConfigKey
      });
      
      const response = await fetch(ttsUrl, {
        method: 'GET',
        headers: { 
          'accept': 'audio/mpeg',
        },
      });

      if (!response.ok) {
        throw new Error(`Thought Stream TTS API error: ${response.status} ${response.statusText}`);
      }

      // The API returns audio stream directly
      const audioBlob = await response.blob();
      const audioUrl = URL.createObjectURL(audioBlob);
      
      const audio = new Audio(audioUrl);
      audio.volume = 0.6; // Slightly lower volume for thought streams
      
      // Set up event handlers BEFORE starting playback
      audio.onended = () => {
        console.log(`[Thought Stream TTS] Playback complete for ${savantConfigKey}`);
        URL.revokeObjectURL(audioUrl);
        resolve();
      };
      
      audio.onerror = (e) => {
        console.error(`[Thought Stream TTS] Audio playback error for ${savantConfigKey}:`, e);
        URL.revokeObjectURL(audioUrl);
        reject(e);
      };
      
      // Start playback - only wait for play() to start, NOT complete
      // The promise will resolve when onended fires
      await audio.play();
      console.log(`[Thought Stream TTS] Audio playback started for ${savantConfigKey}, waiting for completion...`);
      
      // DO NOT resolve here - wait for onended event
    } catch (error) {
      console.error('Error playing thought stream TTS audio:', error);
      reject(error);
    }
  });
}

/**
 * Play TTS audio - either mock or real based on config
 */
export async function playTTS(text: string, audioRef?: React.MutableRefObject<HTMLAudioElement | null>): Promise<void> {
  try {
    if (config.mockAudio) {
      // Use sample audio URL if available, otherwise use generated tone
      if (config.mockAudioUrls?.chat) {
        await playMockTTSFromUrl(config.mockAudioUrls.chat, 'chat');
      } else {
        await playMockTTS(text);
      }
    } else {
      // Stop any currently playing audio
      if (audioRef?.current) {
        audioRef.current.pause();
        audioRef.current.currentTime = 0;
      }
      
      // Wait for real TTS to complete
      await playRealTTS(text);
    }
  } catch (error) {
    console.error('Error playing TTS audio:', error);
  }
}

/**
 * Play thought stream TTS audio - either mock or real based on thoughtStream.mockAudio config
 */
export async function playThoughtTTS(
  text: string, 
  savantKey: 'tecvali_savant' | 'inlexzo_savant',
  audioRef?: React.MutableRefObject<HTMLAudioElement | null>
): Promise<void> {
  try {
    if (config.thoughtStream.mockAudio) {
      // Determine which sample audio to use based on savant
      const savantConfigKey = savantKey === 'tecvali_savant' ? 'tecvali' : 'inlexzo';
      const mockAudioUrl = config.mockAudioUrls?.[savantConfigKey];
      
      // Use sample audio URL if available, otherwise use generated tone
      if (mockAudioUrl) {
        await playMockTTSFromUrl(mockAudioUrl, savantConfigKey);
      } else {
        await playMockTTS(text);
      }
    } else {
      // Stop any currently playing audio
      if (audioRef?.current) {
        audioRef.current.pause();
        audioRef.current.currentTime = 0;
      }
      
      // Wait for real TTS to complete
      await playThoughtStreamTTS(text, savantKey);
    }
  } catch (error) {
    console.error('Error playing thought stream TTS audio:', error);
  }
}