import { motion } from "motion/react";
import { useState, useEffect, useRef } from "react";
import { Brain, Zap, Sparkles, Volume2, VolumeX } from "lucide-react";
import { Button } from "./ui/button";
import { config } from "../config";
import { trymfyaThoughtEvents, inlexzoThoughtEvents } from "../utils/mockData";
import { useConversationSync } from "../hooks/useConversationSync";

interface ThoughtStreamProps {
  isVisible: boolean;
  thoughts?: string[];
  position?: 'top-right' | 'bottom-right';
  savantName: string;
  savantKey: 'tecvali_savant' | 'inlexzo_savant';
  onTypingChange?: (isTyping: boolean) => void;
}

export function ThoughtStream({ isVisible, thoughts = [], position = 'top-right', savantName, savantKey, onTypingChange }: ThoughtStreamProps) {
  const [isAudioEnabled, setIsAudioEnabled] = useState(true); // Default to true
  const scrollContainerRef = useRef<HTMLDivElement>(null);

  // Use centralized conversation sync hook for handling conversation stream messages
  const { currentText, isTyping, completedMessages } = useConversationSync({
    savantKey,
    isVisible: isVisible && config.thoughtStream.mock,
    isAudioEnabled,
  });

  // Update parent component with typing state
  useEffect(() => {
    if (onTypingChange) {
      onTypingChange(isTyping);
    }
  }, [isTyping, onTypingChange]);

  const toggleAudio = () => {
    setIsAudioEnabled(!isAudioEnabled);
  };

  // Auto-scroll effect when new thoughts are added
  useEffect(() => {
    if (scrollContainerRef.current) {
      scrollContainerRef.current.scrollTop = scrollContainerRef.current.scrollHeight;
    }
  }, [completedMessages, currentText]);

  if (!isVisible) return null;

  // Position styling based on sphere position
  // Account for the parent's transform to ensure thought stream doesn't overlap sphere
  // Top sphere: moves up by 35vh, sphere radius ~120px, so thought stream should be positioned
  // to appear visually below the sphere's topmost point
  // Bottom sphere: moves down by 35vh, similar calculation for bottom
  const positionStyle = position === 'top-right' 
    ? {
        // Sphere center is at 50vh - 35vh = 15vh from top
        // Sphere top (with glow) is at 15vh - 120px
        // To position thought stream below sphere, account for parent's -35vh transform
        // Visual position: (50vh - 80px) + (-35vh) = 15vh - 80px (40px below sphere top)
        top: 'calc(50vh - 80px)',
        right: 'calc(50% + 140px)',
      }
    : {
        // Sphere center is at 50vh + 35vh = 85vh from top
        // Sphere bottom (with glow) is at 85vh + 120px
        // To position thought stream above sphere bottom, account for parent's +35vh transform
        // Visual position: bottom at (50vh - 80px) with parent moved down 35vh
        // Results in visual bottom at: 100vh - (50vh - 80px) + 35vh = 85vh + 80px (40px above sphere bottom)
        bottom: 'calc(50vh - 80px)',
        right: 'calc(50% + 140px)',
      };

  return (
    <motion.div
      initial={{ opacity: 0, x: 20, scale: 0.95 }}
      animate={{ opacity: 1, x: 0, scale: 1 }}
      transition={{ duration: 0.6, ease: "easeOut" }}
      className="absolute pointer-events-auto"
      style={positionStyle}
    >
      <div
        className="w-[320px] rounded-2xl shadow-2xl overflow-hidden"
        style={{
          background: "#FFFFFF",
          border: "2px solid rgba(215, 22, 0, 0.3)",
          boxShadow: "0 8px 32px rgba(0, 0, 0, 0.2)",
        }}
      >
        {/* Header */}
        <div
          className="px-4 py-3 border-b"
          style={{
            background: "rgba(215, 22, 0, 0.15)",
            borderBottom: "1px solid rgba(215, 22, 0, 0.2)",
          }}
        >
          <div className="flex items-center gap-2">
            <motion.div
              animate={{
                rotate: [0, 360],
              }}
              transition={{
                duration: 3,
                repeat: Infinity,
                ease: "linear",
              }}
            >
              <Brain className="w-5 h-5" style={{ color: "#D71600" }} />
            </motion.div>
            <span className="text-sm" style={{ color: "#D71600" }}>
              Savant Thought Stream
            </span>
            <motion.div
              animate={{
                scale: [1, 1.2, 1],
                opacity: [0.5, 1, 0.5],
              }}
              transition={{
                duration: 2,
                repeat: Infinity,
                ease: "easeInOut",
              }}
            >
              <Sparkles className="w-4 h-4" style={{ color: "#D71600" }} />
            </motion.div>
            <Button
              onClick={toggleAudio}
              size="icon"
              variant="ghost"
              className="ml-auto w-7 h-7 rounded-full hover:bg-red-50"
            >
              {isAudioEnabled ? (
                <Volume2
                  className="w-4 h-4"
                  style={{ color: "#D71600" }}
                />
              ) : (
                <VolumeX className="w-4 h-4" style={{ color: "rgba(215, 22, 0, 0.4)" }} />
              )}
            </Button>
          </div>
        </div>

        {/* Thought Stream Content */}
        <div 
          ref={scrollContainerRef}
          className="p-4 max-h-[240px] overflow-y-auto"
          style={{
            scrollbarWidth: 'thin',
            scrollbarColor: '#D71600 rgba(215, 22, 0, 0.1)'
          }}
        >
          <div className="space-y-3">
            {completedMessages.map((thought, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3 }}
                className="flex items-start gap-2"
              >
                <Zap className="w-4 h-4 mt-0.5 flex-shrink-0" style={{ color: "#D71600" }} />
                <p className="text-sm" style={{ color: "#D71600" }}>{thought}</p>
              </motion.div>
            ))}

            {/* Current typing thought */}
            {currentText && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="flex items-start gap-2"
              >
                <Zap className="w-4 h-4 mt-0.5 flex-shrink-0" style={{ color: "#D71600" }} />
                <p className="text-sm" style={{ color: "#D71600" }}>
                  {currentText}
                  <motion.span
                    animate={{ opacity: [1, 0] }}
                    transition={{ duration: 0.8, repeat: Infinity }}
                    className="inline-block w-1 h-4 ml-1"
                    style={{ backgroundColor: "#D71600" }}
                  />
                </p>
              </motion.div>
            )}
          </div>
        </div>

        {/* Activity Indicator */}
        {(isTyping) && (
          <div
            className="px-4 py-2 border-t flex items-center gap-2"
            style={{
              borderTop: "1px solid rgba(255, 255, 255, 0.1)",
              background: "rgba(215, 22, 0, 0.08)",
            }}
          >
            <motion.div
              animate={{
                scale: [1, 1.3, 1],
              }}
              transition={{
                duration: 1.5,
                repeat: Infinity,
                ease: "easeInOut",
              }}
              className="w-2 h-2 rounded-full"
              style={{ backgroundColor: "#D71600" }}
            />
            <span className="text-xs" style={{ color: "#D71600" }}>
              Processing thoughts...
            </span>
          </div>
        )}
      </div>
    </motion.div>
  );
}