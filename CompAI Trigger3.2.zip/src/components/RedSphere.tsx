import { motion } from "motion/react";
import { useEffect, useState } from "react";
import { config } from "../config";
import { ThoughtStream } from "./ThoughtStream";
import { MessageSquareText } from "lucide-react";

interface RedSphereProps {
  isVisible: boolean;
  position?: 'top-right' | 'bottom-right';
  savantName: string;
  savantKey: 'tecvali_savant' | 'inlexzo_savant';
  onThoughtStreamOpened?: () => void;
}

export function RedSphere({ isVisible, position = 'top-right', savantName, savantKey, onThoughtStreamOpened }: RedSphereProps) {
  const [pulseIntensity, setPulseIntensity] = useState(1);
  const [hasMovedToEdge, setHasMovedToEdge] = useState(false);
  const [showThoughtStream, setShowThoughtStream] = useState(position === 'bottom-right'); // First sphere hidden, second sphere open by default
  const [isTyping, setIsTyping] = useState(false);

  useEffect(() => {
    const interval = setInterval(() => {
      setPulseIntensity(prev => (prev === 1 ? 1.08 : 1));
    }, 2000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    if (isVisible) {
      // After sphere is born, wait a moment then move to edge
      const timer = setTimeout(() => {
        setHasMovedToEdge(true);
        
        // For bottom-right sphere (second sphere), auto-open thought stream after movement completes
        // Movement animation takes 2 seconds, so wait an additional 2 seconds
        if (position === 'bottom-right') {
          const thoughtStreamTimer = setTimeout(() => {
            setShowThoughtStream(true);
            if (onThoughtStreamOpened) {
              onThoughtStreamOpened();
            }
          }, 2000); // Wait for movement to complete
          
          return () => clearTimeout(thoughtStreamTimer);
        }
      }, 2500); // Wait for birth animation to complete
      return () => clearTimeout(timer);
    }
  }, [isVisible, position, onThoughtStreamOpened]);

  const toggleThoughtStream = (e: React.MouseEvent) => {
    e.stopPropagation(); // Prevent sphere click from triggering
    setShowThoughtStream(!showThoughtStream);
    if (onThoughtStreamOpened && !showThoughtStream) {
      onThoughtStreamOpened();
    }
  };

  const handleTypingChange = (typing: boolean) => {
    setIsTyping(typing);
  };

  if (!isVisible) return null;

  // Calculate movement based on position
  let moveX: number;
  let moveY: number;

  if (position === 'top-right') {
    // Move to top right corner of the viewport
    moveX = window.innerWidth * 0.38; // Move right (38% of viewport width from center)
    moveY = -window.innerHeight * 0.35; // Move up (35% of viewport height from center)
  } else {
    // bottom-right position
    moveX = window.innerWidth * 0.38; // Move right (38% of viewport width from center)
    moveY = window.innerHeight * 0.35; // Move down (35% of viewport height from center)
  }

  const handleClick = () => {
    window.open(config.redSphereLink, '_blank', 'noopener,noreferrer');
  };

  return (
    <motion.div
      className="absolute inset-0 flex items-center justify-center pointer-events-none"
      initial={{ opacity: 0 }}
      animate={{ 
        opacity: 1,
        x: hasMovedToEdge ? moveX : 0,
        y: hasMovedToEdge ? moveY : 0,
      }}
      transition={{ 
        opacity: { duration: 1, ease: "easeOut" },
        x: { duration: 2, ease: "easeInOut", delay: 0 },
        y: { duration: 2, ease: "easeInOut", delay: 0 },
      }}
    >
      <motion.div
        className="relative flex items-center justify-center pointer-events-auto cursor-pointer"
        onClick={handleClick}
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ 
          duration: 2.5,
          ease: [0.34, 1.56, 0.64, 1],
        }}
      >
        {/* Outer glow ring - gentle pulse */}
        <motion.div
          className="absolute w-[240px] h-[240px] rounded-full"
          style={{
            background: "radial-gradient(circle, rgba(215, 22, 0, 0.15) 0%, transparent 70%)",
          }}
          animate={isTyping ? {
            scale: [1, 1.08, 1, 1.08, 1],
            opacity: [0.5, 0.75, 0.5, 0.75, 0.5],
          } : {
            scale: pulseIntensity,
            opacity: [0.4, 0.6, 0.4],
          }}
          transition={isTyping ? {
            duration: 1.2,
            repeat: Infinity,
            ease: "easeInOut",
          } : {
            duration: 3,
            repeat: Infinity,
            ease: "easeInOut",
          }}
        />

        {/* Middle glow ring */}
        <motion.div
          className="absolute w-[200px] h-[200px] rounded-full"
          style={{
            background: "radial-gradient(circle, rgba(215, 22, 0, 0.2) 0%, transparent 70%)",
          }}
          animate={isTyping ? {
            scale: [1, 1.08, 1, 1.08, 1],
            opacity: [0.6, 0.85, 0.6, 0.85, 0.6],
          } : {
            scale: pulseIntensity,
            opacity: [0.5, 0.7, 0.5],
          }}
          transition={isTyping ? {
            duration: 1.2,
            repeat: Infinity,
            ease: "easeInOut",
            delay: 0.15,
          } : {
            duration: 3,
            repeat: Infinity,
            ease: "easeInOut",
            delay: 0.5,
          }}
        />

        {/* Main red sphere - 30% of 600px = 180px */}
        <motion.div
          className="relative w-[180px] h-[180px] rounded-full overflow-visible"
          style={{
            background: isTyping 
              ? "radial-gradient(circle at 35% 35%, #fca5a5, #f87171, #dc2626, #b91c1c, #991b1b, #7f1d1d)"
              : "radial-gradient(circle at 35% 35%, #fecaca, #fca5a5, #f87171, #ef4444, #dc2626, #b91c1c)",
            boxShadow: isTyping
              ? `
                0 0 80px rgba(215, 22, 0, 0.7),
                0 0 120px rgba(215, 22, 0, 0.4),
                inset -25px -25px 70px rgba(0, 0, 0, 0.5),
                inset 25px 25px 70px rgba(255, 200, 200, 0.5),
                inset 0 0 100px rgba(220, 38, 38, 0.4)
              `
              : `
                0 0 60px rgba(215, 22, 0, 0.25),
                0 0 90px rgba(215, 22, 0, 0.15),
                inset -25px -25px 70px rgba(0, 0, 0, 0.3),
                inset 25px 25px 70px rgba(255, 220, 220, 0.6),
                inset 0 0 80px rgba(220, 38, 38, 0.15)
              `,
          }}
          animate={isTyping ? {
            scale: [1, 1.05, 1, 1.05, 1],
            rotate: 360,
          } : {
            scale: pulseIntensity,
            rotate: 360,
          }}
          transition={isTyping ? {
            scale: {
              duration: 1.2,
              repeat: Infinity,
              ease: "easeInOut",
            },
            rotate: {
              duration: 40,
              repeat: Infinity,
              ease: "linear",
            },
          } : {
            scale: {
              duration: 3,
              repeat: Infinity,
              ease: "easeInOut",
            },
            rotate: {
              duration: 40,
              repeat: Infinity,
              ease: "linear",
            },
          }}
        >
          {/* Primary highlight - top left - creates glossy effect */}
          <motion.div
            className="absolute top-[22px] left-[36px] w-[72px] h-[72px] rounded-full pointer-events-none"
            style={{
              background: "radial-gradient(circle, rgba(255, 255, 255, 0.9) 0%, rgba(255, 255, 255, 0.5) 30%, transparent 70%)",
            }}
            initial={{ opacity: 0, scale: 0 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.3, duration: 0.8 }}
          />

          {/* Secondary highlight - subtle shimmer */}
          <motion.div
            className="absolute top-[45px] left-[18px] w-[36px] h-[36px] rounded-full pointer-events-none"
            style={{
              background: "radial-gradient(circle, rgba(255, 255, 255, 0.6) 0%, transparent 60%)",
            }}
            initial={{ opacity: 0 }}
            animate={{ opacity: [0, 0.8, 0] }}
            transition={{ 
              delay: 0.5, 
              duration: 2.5,
              repeat: Infinity,
              ease: "easeInOut"
            }}
          />

          {/* Globe meridian lines - vertical stripes */}
          {[...Array(8)].map((_, i) => (
            <div
              key={`meridian-${i}`}
              className="absolute top-0 left-1/2 w-px h-full -translate-x-1/2 pointer-events-none"
              style={{
                background: "linear-gradient(to bottom, transparent, rgba(255, 255, 255, 0.12) 20%, rgba(255, 255, 255, 0.12) 80%, transparent)",
                transform: `translateX(-50%) rotateY(${i * 22.5}deg)`,
                transformOrigin: "center",
              }}
            />
          ))}

          {/* Globe latitude circles - horizontal bands */}
          {[...Array(5)].map((_, i) => {
            const size = 168 - Math.abs(i - 2) * 36;
            const top = 6 + i * 42;
            return (
              <div
                key={`latitude-${i}`}
                className="absolute left-1/2 -translate-x-1/2 rounded-full border border-white/10 pointer-events-none"
                style={{
                  width: `${size}px`,
                  height: `${size * 0.25}px`,
                  top: `${top}px`,
                }}
              />
            );
          })}

          {/* 3D Mesh Network Core */}
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[108px] h-[108px] pointer-events-none">
            {/* Central glow */}
            <motion.div
              className="absolute inset-0 rounded-full"
              style={{
                background: "radial-gradient(circle, rgba(255, 255, 255, 0.25) 0%, transparent 70%)",
              }}
              animate={{
                scale: [1, 1.05, 1],
                opacity: [0.4, 0.6, 0.4],
              }}
              transition={{
                duration: 3,
                repeat: Infinity,
                ease: "easeInOut",
              }}
            />

            {/* Rotating mesh lines - horizontal rotation only */}
            {[...Array(6)].map((_, lineIndex) => (
              <motion.div
                key={`v-line-${lineIndex}`}
                className="absolute top-1/2 left-1/2 w-px h-[96px] -translate-x-1/2 -translate-y-1/2 pointer-events-none"
                style={{
                  background: "linear-gradient(to bottom, transparent, rgba(255, 255, 255, 0.35) 50%, transparent)",
                  transformOrigin: "center",
                }}
                animate={{
                  rotate: [lineIndex * 30, lineIndex * 30 + 360],
                }}
                transition={{
                  duration: 10,
                  repeat: Infinity,
                  ease: "linear",
                }}
              />
            ))}
          </div>

          {/* Bottom shadow/depth */}
          <div
            className="absolute bottom-0 left-1/2 -translate-x-1/2 w-[140px] h-[70px] rounded-full pointer-events-none"
            style={{
              background: "radial-gradient(ellipse at center, rgba(0, 0, 0, 0.4) 0%, transparent 70%)",
            }}
          />
        </motion.div>

        {/* Flowing Glowing Bubbles - Active Mode */}
        {isTyping && hasMovedToEdge && (
          <>
            {[...Array(6)].map((_, i) => {
              // Random positioning around sphere perimeter
              const angle = (i * 60) + (Math.random() * 30 - 15); // Spread around sphere
              const distance = 90; // Start from sphere edge
              const startX = Math.cos((angle * Math.PI) / 180) * distance;
              const startY = Math.sin((angle * Math.PI) / 180) * distance;
              
              // Random end position (floating away)
              const endDistance = 180 + Math.random() * 60;
              const endX = Math.cos((angle * Math.PI) / 180) * endDistance;
              const endY = Math.sin((angle * Math.PI) / 180) * endDistance;
              
              const size = 8 + Math.random() * 8; // Random size 8-16px
              const duration = 2.5 + Math.random() * 1.5; // Random duration 2.5-4s
              const delay = i * 0.3; // Stagger the bubbles

              return (
                <motion.div
                  key={`bubble-${i}`}
                  className="absolute rounded-full pointer-events-none"
                  style={{
                    width: `${size}px`,
                    height: `${size}px`,
                    background: "radial-gradient(circle, rgba(255, 200, 200, 0.9) 0%, rgba(215, 22, 0, 0.6) 50%, rgba(215, 22, 0, 0.2) 100%)",
                    boxShadow: `
                      0 0 ${size * 2}px rgba(215, 22, 0, 0.6),
                      0 0 ${size * 4}px rgba(215, 22, 0, 0.3),
                      inset 0 0 ${size}px rgba(255, 255, 255, 0.3)
                    `,
                  }}
                  initial={{
                    x: startX,
                    y: startY,
                    opacity: 0,
                    scale: 0,
                  }}
                  animate={{
                    x: [startX, endX],
                    y: [startY, endY],
                    opacity: [0, 0.8, 0.6, 0],
                    scale: [0, 1, 1, 0.5],
                  }}
                  transition={{
                    duration: duration,
                    delay: delay,
                    repeat: Infinity,
                    ease: "easeOut",
                  }}
                />
              );
            })}
          </>
        )}

        {/* Toggle Button - Top Right of Sphere */}
        {hasMovedToEdge && (
          <motion.button
            initial={{ opacity: 0, scale: 0 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.5, duration: 0.3 }}
            onClick={toggleThoughtStream}
            className="absolute top-2 right-2 w-10 h-10 rounded-full flex items-center justify-center shadow-lg hover:scale-110 transition-transform pointer-events-auto"
            style={{
              background: "rgba(255, 255, 255, 0.95)",
              border: "2px solid rgba(215, 22, 0, 0.3)",
            }}
          >
            <MessageSquareText 
              className="w-5 h-5" 
              style={{ color: showThoughtStream ? "#D71600" : "rgba(215, 22, 0, 0.4)" }} 
            />
          </motion.button>
        )}

        {/* Savant Name Label */}
        {hasMovedToEdge && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.7, duration: 0.4 }}
            className="absolute -bottom-8 left-1/2 -translate-x-1/2 pointer-events-none whitespace-nowrap"
          >
            <span 
              className="text-sm tracking-wide underline decoration-2"
              style={{ color: "#D71600", textUnderlineOffset: "4px" }}
            >
              {savantName}
            </span>
          </motion.div>
        )}
      </motion.div>

      {/* Thought Stream - appears next to the sphere */}
      <ThoughtStream isVisible={showThoughtStream} position={position} savantName={savantName} savantKey={savantKey} onTypingChange={handleTypingChange} />
    </motion.div>
  );
}