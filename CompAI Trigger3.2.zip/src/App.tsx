import { useState, useEffect } from "react";
import { Sphere } from "./components/Sphere";
import { ChatInterface } from "./components/ChatInterface";
import { MessageCircleMore } from 'lucide-react';
import jnjLogo from 'figma:asset/423611bc1574c7e40b5e99f6e50aedc7b6382e6b.png';
import compAiLogo from 'figma:asset/c56162774a5e25d367f82a9cf1bf3b167b45703c.png';
import savantLogo from 'figma:asset/01267cdb23607527a7cf4507f45e5bd11f228c9e.png';
import { motion } from "motion/react";
import { Button } from "./components/ui/button";
import { conversationStream } from "./utils/conversationStream";
import { config } from "./config";

export default function App() {
  const [savantCount, setSavantCount] = useState(0);
  const [isChatOpen, setIsChatOpen] = useState(true);
  const [isChatVisible, setIsChatVisible] = useState(false);
  const [hasStartedConversation, setHasStartedConversation] = useState(false);

  useEffect(() => {
    // Subscribe to savant creation events from conversation stream
    const unsubscribe = conversationStream.subscribeToSavantCreation((savantName) => {
      console.log(`App: Received savant creation event for: ${savantName}`);
      handleSavantCreated();
    });

    return () => {
      unsubscribe();
    };
  }, []);

  const handleChatToggle = () => {
    setIsChatVisible(!isChatVisible);
  };

  const handleSavantCreated = () => {
    setSavantCount(prev => prev + 1);
  };

  const handleThoughtStreamOpened = () => {
    // Start conversation stream when any thought stream is opened for the first time
    if (config.thoughtStream.mock && !hasStartedConversation && !conversationStream.isCurrentlyPlaying()) {
      setHasStartedConversation(true);
      conversationStream.start();
    }
  };

  return (
    <div className="h-screen w-screen bg-white overflow-hidden relative">
      {/* Full Screen Sphere Video */}
      <Sphere 
        savantCount={savantCount}
        onThoughtStreamOpened={handleThoughtStreamOpened}
      />

      {/* J&J Logo with COMP AI Logo - Extreme Top Left */}
      <div className="absolute top-4 left-4 z-30">
        <div className="flex items-center gap-3">
          <img 
            src={jnjLogo} 
            alt="Johnson & Johnson" 
            className="h-10 w-auto object-contain"
          />
          <div className="w-px h-8 bg-gray-300" />
          <img 
            src={compAiLogo} 
            alt="COMP AI" 
            className="h-4 w-auto object-contain"
          />
        </div>
      </div>

      {/* Floating Chat Toggle Button - visible when chat is collapsed */}
      {isChatOpen && !isChatVisible && (
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          className="absolute top-20 left-4 z-40"
        >
          <Button
            onClick={handleChatToggle}
            size="icon"
            className="w-12 h-12 rounded-full shadow-lg hover:opacity-90"
            style={{ backgroundColor: '#D71600' }}
          >
            <MessageCircleMore className="w-6 h-6" />
          </Button>
        </motion.div>
      )}

      {/* Chat Interface - Slide in/out from left */}
      <motion.div
        initial={{ x: 0 }}
        animate={{ x: isChatVisible ? 0 : -500 }}
        transition={{ type: 'spring', stiffness: 300, damping: 30 }}
        className="absolute top-20 left-4 z-50"
      >
        <ChatInterface 
          onClose={handleChatToggle}
          onFirstResponse={handleSavantCreated}
          isVisible={isChatVisible}
          onThoughtStreamOpened={handleThoughtStreamOpened}
        />
      </motion.div>
    </div>
  );
}