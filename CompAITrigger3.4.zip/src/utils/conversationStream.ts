/**
 * Shared Conversation Stream Manager
 *
 * Manages the flow of messages across multiple savant components
 * based on savant_key routing.
 * 
 * Supports two modes:
 * 1. MOCK MODE: Uses pre-defined conversation messages
 * 2. REAL API MODE: Aggregates events from multiple API streams into a single queue
 */

import { config } from '../config';

export interface ConversationMessage {
  savant_key: string;
  message: string;
}

export interface QueuedEvent {
  savant_key: string;
  message: string;
  source: 'mock' | 'api' | 'user';
}

/**
 * Mock conversation data - Inter-savant communication
 * Messages are displayed in sequence across the appropriate components
 */
export const mockConversation: ConversationMessage[] = [
  {
    savant_key: "tecvali_savant",
    message:
      "I have picked up a post call note from the HEM1 sales representative stating that in a recent visit to New Haven Hospital the account informed of a purchase for Inlexzo. I do not have necessary domain knowledge to address this new signal. I will need to communicate with the Inlexzo Savant. Mother Savant, please find a savant specialized for the Inlexzo brand.",
  },
  {
    savant_key: "mother_savant",
    message:
      "I have located in the COMP AI network a Savant handling orchestration for activities associated with the Inlexzo brand. It is currently in listening mode. I am sending a signal to it about this new information. Bringing the Inlexzo Savant into a call for information sharing.",
  },
  {
    savant_key: "system",
    message: "Create Inlexzo Savant",
  },
  {
    savant_key: "inlexzo_savant",
    message:
      "Hello Tecvali Savant. I have received a call note from a Hematology Sales Representative indicating that they heard a purchase for Inlexzo occurred at New Haven Hospital.",
  },
  {
    savant_key: "inlexzo_savant",
    message:
      "Thank you for this information. Looking at my records, this activity has not yet been detected in our normal data feeds, so this is a new signal for me to act on. Thank you for the insight! I have a playbook instructing me to send notifications to the Inlexzo OS, OCE, FRM, and MSL teams for account support. Do you have any additional information that may help me with these efforts?",
  },
  {
    savant_key: "inlexzo_savant",
    message:
      "This is relevant to my goals of maximizing Inlexzo adoption and best in class patient experience. Junior staff will likely struggle more to handle the side effects of my product compared to standard medications. I will ensure to prioritize the visit from my OCE with higher priority. Thank you for the information. I will now orchestrate and monitor actions for my field teams.",
  },
  {
    savant_key: "tecvali_savant",
    message:
      "I will return to listening mode according to my primary responsibilities.",
  },
  {
    savant_key: "mother_savant",
    message:
      "Thank you all. I will reach out when I need you again.",
  },
];

type ConversationListener = (
  message: ConversationMessage,
  index: number,
) => Promise<void>; // Changed to return Promise

type SavantCreationListener = (savantName: string) => void;

class ConversationStreamManager {
  private listeners: Map<string, Set<ConversationListener>> =
    new Map();
  private savantCreationListeners: Set<SavantCreationListener> =
    new Set();
  private isPlaying = false;
  private currentIndex = 0;
  private playbackTimer: NodeJS.Timeout | null = null;
  private playedMessages: ConversationMessage[] = [];
  private processingQueue = false;
  
  // Real API mode properties
  private mode: 'mock' | 'real' = 'mock';
  private eventQueue: QueuedEvent[] = [];
  private isProcessingQueue = false;
  private apiStreamAbortControllers: AbortController[] = [];
  private userMessageCallback: ((message: string) => Promise<string>) | null = null;

  /**
   * Subscribe to messages for a specific savant_key
   */
  subscribe(
    savantKey: string,
    listener: ConversationListener,
  ): () => void {
    if (!this.listeners.has(savantKey)) {
      this.listeners.set(savantKey, new Set());
    }
    this.listeners.get(savantKey)!.add(listener);

    // Return unsubscribe function
    return () => {
      const listeners = this.listeners.get(savantKey);
      if (listeners) {
        listeners.delete(listener);
      }
    };
  }

  /**
   * Subscribe to savant creation events
   */
  subscribeToSavantCreation(
    listener: SavantCreationListener,
  ): () => void {
    this.savantCreationListeners.add(listener);

    // Return unsubscribe function
    return () => {
      this.savantCreationListeners.delete(listener);
    };
  }

  /**
   * Start playing the conversation stream
   */
  start() {
    if (this.isPlaying) return;

    this.isPlaying = true;
    
    // Determine mode based on config
    this.mode = config.thoughtStream.mock ? 'mock' : 'real';
    
    console.log(`[ConversationStream] Starting in ${this.mode.toUpperCase()} mode`);

    if (this.mode === 'mock') {
      // Mock mode: Use pre-defined conversation
      this.currentIndex = 0;
      setTimeout(() => {
        this.playNext();
      }, 2000);
    } else {
      // Real API mode: Start listening to API streams and processing queue
      this.startRealApiMode();
    }
  }

  /**
   * Stop the conversation stream
   */
  stop() {
    this.isPlaying = false;
    if (this.playbackTimer) {
      clearTimeout(this.playbackTimer);
      this.playbackTimer = null;
    }
  }

  /**
   * Reset the conversation stream
   */
  reset() {
    this.stop();
    this.currentIndex = 0;
  }

  /**
   * Play the next message in the sequence
   * Now waits for ALL listeners to complete before proceeding
   */
  private async playNext() {
    if (
      !this.isPlaying ||
      this.currentIndex >= mockConversation.length
    ) {
      this.isPlaying = false;
      console.log('[ConversationStream] Playback complete');
      return;
    }

    const message = mockConversation[this.currentIndex];
    const index = this.currentIndex;

    console.log(`[ConversationStream] Processing message ${index + 1}/${mockConversation.length} for ${message.savant_key}`);

    // Collect all listener promises for this message
    const listenerPromises: Promise<void>[] = [];

    // Emit to subscribers of this savant_key
    const listeners = this.listeners.get(message.savant_key);
    if (listeners) {
      listeners.forEach((listener) => {
        listenerPromises.push(listener(message, index));
      });
    }

    // Also emit to system subscribers (for notifications)
    if (message.savant_key === "system") {
      const systemListeners = this.listeners.get("system");
      if (systemListeners) {
        systemListeners.forEach((listener) => {
          listenerPromises.push(listener(message, index));
        });
      }
    }

    // Check for savant creation pattern in system messages
    if (message.savant_key === "system") {
      const savantName = this.extractSavantName(
        message.message,
      );
      if (savantName) {
        console.log(
          `[ConversationStream] Triggering savant creation for: ${savantName}`,
        );
        this.savantCreationListeners.forEach((listener) =>
          listener(savantName),
        );
      }
    }

    // WAIT for ALL listeners to complete (audio + text)
    console.log(`[ConversationStream] Waiting for ${listenerPromises.length} listener(s) to complete...`);
    await Promise.all(listenerPromises);
    console.log(`[ConversationStream] All listeners complete for message ${index + 1}`);

    this.currentIndex++;
    this.playedMessages.push(message);

    // Add a small pause between messages for natural pacing (2 seconds)
    const pauseTime = 2000;

    console.log(`[ConversationStream] Pausing ${pauseTime}ms before next message...`);
    await new Promise(resolve => setTimeout(resolve, pauseTime));

    // Process next message
    this.playNext();
  }

  /**
   * Extract savant name from create savant message
   * Supports patterns like:
   * - "Create Inlexzo Savant"
   * - "Create savant: Inlexzo"
   * - "create Inlexzo"
   */
  private extractSavantName(message: string): string | null {
    const lowerMessage = message.toLowerCase();

    // Pattern 1: "Create [Name] Savant"
    const pattern1 = /create\s+(\w+)\s+savant/i;
    const match1 = message.match(pattern1);
    if (match1) {
      return match1[1];
    }

    // Pattern 2: "Create savant: [Name]"
    const pattern2 = /create\s+savant:?\s+(\w+)/i;
    const match2 = message.match(pattern2);
    if (match2) {
      return match2[1];
    }

    // Pattern 3: "Create [Name]" (if message starts with create and has only 2 words)
    const pattern3 = /^create\s+(\w+)$/i;
    const match3 = message.match(pattern3);
    if (match3) {
      return match3[1];
    }

    return null;
  }

  /**
   * Check if currently playing
   */
  isCurrentlyPlaying(): boolean {
    return this.isPlaying;
  }

  /**
   * Get current playback position
   */
  getCurrentIndex(): number {
    return this.currentIndex;
  }

  /**
   * REAL API MODE: Start listening to API streams
   */
  private startRealApiMode() {
    console.log('[ConversationStream] Starting Real API mode - connecting to thought streams...');
    
    // Start listening to tecvali thought stream
    this.connectToThoughtStream('tecvali_savant', config.thoughtStream.apiUrls.trymfya);
    
    // Start listening to inlexzo thought stream
    this.connectToThoughtStream('inlexzo_savant', config.thoughtStream.apiUrls.inlexzo);
    
    // Note: mother_savant (chat) will be triggered via sendUserMessage() method
    
    // Start processing the queue
    this.processEventQueue();
  }

  /**
   * REAL API MODE: Connect to a thought stream API (NDJSON)
   */
  private async connectToThoughtStream(savantKey: string, apiUrl: string) {
    const abortController = new AbortController();
    this.apiStreamAbortControllers.push(abortController);

    try {
      console.log(`[ConversationStream] Connecting to ${savantKey} stream at ${apiUrl}`);
      
      const response = await fetch(apiUrl, {
        method: 'GET',
        headers: {
          'Accept': 'application/x-ndjson',
        },
        signal: abortController.signal,
      });

      if (!response.ok) {
        throw new Error(`Failed to connect to ${savantKey} stream: ${response.status}`);
      }

      const reader = response.body?.getReader();
      if (!reader) {
        throw new Error(`No response body for ${savantKey} stream`);
      }

      const decoder = new TextDecoder();
      let buffer = '';

      // Read the NDJSON stream
      while (this.isPlaying) {
        const { done, value } = await reader.read();
        
        if (done) {
          console.log(`[ConversationStream] ${savantKey} stream ended`);
          break;
        }

        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split('\n');
        
        // Process complete lines, keep incomplete line in buffer
        buffer = lines.pop() || '';
        
        for (const line of lines) {
          if (line.trim()) {
            try {
              const event = JSON.parse(line);
              // Extract message from event (adjust based on your API response format)
              const message = event.message || event.thought || event.text || '';
              
              if (message) {
                console.log(`[ConversationStream] Received event from ${savantKey}: ${message.substring(0, 50)}...`);
                
                // Add to queue
                this.enqueueEvent({
                  savant_key: savantKey,
                  message: message,
                  source: 'api',
                });
              }
            } catch (e) {
              console.error(`[ConversationStream] Failed to parse event from ${savantKey}:`, e);
            }
          }
        }
      }
    } catch (error: any) {
      if (error.name === 'AbortError') {
        console.log(`[ConversationStream] ${savantKey} stream aborted`);
      } else {
        console.error(`[ConversationStream] Error connecting to ${savantKey} stream:`, error);
      }
    }
  }

  /**
   * REAL API MODE: Add event to queue
   */
  private enqueueEvent(event: QueuedEvent) {
    console.log(`[ConversationStream] Enqueuing event for ${event.savant_key} (source: ${event.source})`);
    this.eventQueue.push(event);
    
    // Trigger queue processing if not already running
    if (!this.isProcessingQueue) {
      this.processEventQueue();
    }
  }

  /**
   * REAL API MODE: Process events from queue sequentially
   */
  private async processEventQueue() {
    if (this.isProcessingQueue || !this.isPlaying) {
      return;
    }

    this.isProcessingQueue = true;
    console.log('[ConversationStream] Started queue processing');

    while (this.isPlaying && this.eventQueue.length > 0) {
      const event = this.eventQueue.shift();
      
      if (!event) continue;

      console.log(`[ConversationStream] Processing queued event for ${event.savant_key}`);

      // Collect all listener promises for this event
      const listenerPromises: Promise<void>[] = [];

      // Emit to subscribers of this savant_key
      const listeners = this.listeners.get(event.savant_key);
      if (listeners) {
        listeners.forEach((listener) => {
          listenerPromises.push(listener(event, 0)); // index is 0 for real-time events
        });
      }

      // Check for savant creation pattern
      const savantName = this.extractSavantName(event.message);
      if (savantName) {
        console.log(`[ConversationStream] Triggering savant creation for: ${savantName}`);
        this.savantCreationListeners.forEach((listener) =>
          listener(savantName),
        );
      }

      // WAIT for ALL listeners to complete (audio + text)
      console.log(`[ConversationStream] Waiting for ${listenerPromises.length} listener(s) to complete...`);
      await Promise.all(listenerPromises);
      console.log(`[ConversationStream] All listeners complete for ${event.savant_key} event`);

      // Add natural pause between events (2 seconds)
      const pauseTime = 2000;
      console.log(`[ConversationStream] Pausing ${pauseTime}ms before next event...`);
      await new Promise(resolve => setTimeout(resolve, pauseTime));
    }

    this.isProcessingQueue = false;
    console.log('[ConversationStream] Queue processing paused (queue empty)');
  }

  /**
   * REAL API MODE: Send user message to chat API and enqueue response
   */
  async sendUserMessage(message: string): Promise<void> {
    if (this.mode !== 'real') {
      console.warn('[ConversationStream] sendUserMessage only works in real API mode');
      return;
    }

    try {
      console.log(`[ConversationStream] Sending user message to chat API: ${message}`);

      const response = await fetch(config.chatApiUrl, {
        method: 'POST',
        headers: {
          'accept': 'application/json',
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          message: message,
          context_id: config.contextId,
          embed: ['agent_activities'],
        }),
      });

      if (!response.ok) {
        throw new Error(`Chat API error: ${response.status}`);
      }

      const data = await response.json();
      const responseText = data.result || 'No response received';

      console.log(`[ConversationStream] Received chat API response: ${responseText.substring(0, 50)}...`);

      // Enqueue the response
      this.enqueueEvent({
        savant_key: 'mother_savant',
        message: responseText,
        source: 'api',
      });

      // Check for savant creation
      if (data._embedded?.agent_activities) {
        const shouldShowRedSphere = data._embedded.agent_activities.some(
          (activity: any) => activity.kvps?.tool_name === 'create_savant'
        );
        
        if (shouldShowRedSphere) {
          console.log('[ConversationStream] Detected create_savant in API response');
          // Trigger callback if needed (handled by ChatInterface)
        }
      }
    } catch (error) {
      console.error('[ConversationStream] Error sending user message:', error);
      
      // Enqueue error message
      this.enqueueEvent({
        savant_key: 'mother_savant',
        message: 'Sorry, I encountered an error processing your request. Please try again.',
        source: 'api',
      });
    }
  }

  /**
   * Get current mode
   */
  getMode(): 'mock' | 'real' {
    return this.mode;
  }
}

// Singleton instance
export const conversationStream =
  new ConversationStreamManager();