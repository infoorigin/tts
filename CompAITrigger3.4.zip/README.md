
  # CompAI Trigger 3

  This is a code bundle for CompAI Trigger 3. The original project is available at https://www.figma.com/design/qVpcN8ceLIA0GwWX0R8ivc/CompAI-Trigger-3.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  