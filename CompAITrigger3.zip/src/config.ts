/**
 * Application Configuration
 *
 * This file contains configurable settings for the application.
 * Update these values before deploying to production.
 */

/**
 * Generate a random 8-digit alphanumeric context ID in uppercase
 * @returns Random 8-character string (A-Z, 0-9)
 */
function generateContextId(): string {
  const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
  let result = "";
  for (let i = 0; i < 8; i++) {
    result += chars.charAt(
      Math.floor(Math.random() * chars.length),
    );
  }
  return result;
}

export const config = {
  /**
   * Purple Sphere Video URL
   * The AWS S3 URL for the purple sphere background video
   */
  videoUrl:
    "https://io-sphere-bucket.s3.us-east-1.amazonaws.com/purple_spehere.mp4",

  /**
   * Chat API URL
   * The endpoint for the meta agent chat API
   */
  chatApiUrl: "http://localhost:8000/api/v1/meta_agent/chat",

  /**
   * Mock Chat Mode
   * When true, uses simulated responses instead of calling the real API
   */
  mockChat: true,

  /**
   * Context ID for chat sessions
   * Used to maintain conversation context, should be random 8 digit alphanumeric value in all caps everytime application is initialized
   */
  contextId: generateContextId(),

  /**
   * TTS API Configuration
   */
  tts: {
    /**
     * Base URL for TTS streaming API
     * Example: "https://tts.yourdomain.com" or "http://127.0.0.1:8000"
     */
    baseUrl: "http://127.0.0.1:8080",

    /**
     * API path for TTS streaming
     * Text will be appended as query parameter automatically
     */
    streamPath: "/api/v1/tts/stream",

    /**
     * TTS Voice Parameters
     * Customize voice settings for your TTS engine
     * Example API call: /api/v1/tts/stream?voice=Danielle&engine=long-form&format=mp3&text=hello
     */
    params: {
      /**
       * Voice to use for speech synthesis
       * Common options: "Danielle", "Matthew", "Joanna", etc.
       */
      voice: "Danielle",

      /**
       * TTS engine mode
       * Options: "long-form", "standard", "neural", "generative", etc.
       */
      engine: "generative",

      /**
       * Audio format
       * Options: "mp3", "wav", "ogg", etc.
       */
      format: "mp3",
    },

    /**
     * Get full TTS URL with parameters (don't modify this unless you change API format)
     */
    get url() {
      return `${this.baseUrl}${this.streamPath}`;
    },

    /**
     * Build query string from params
     */
    getQueryString(text: string): string {
      const params = new URLSearchParams({
        voice: this.params.voice,
        engine: this.params.engine,
        format: this.params.format,
        text: text,
      });
      return params.toString();
    },

    /**
     * Get full URL with all parameters
     */
    getFullUrl(text: string): string {
      return `${this.url}?${this.getQueryString(text)}`;
    },
  },

  /**
   * Mock Audio Mode
   * When true, simulates TTS playback for random duration (1-2 seconds)
   * When false, calls the real TTS API with the response text
   */
  mockAudio: true,

  /**
   * Mock Audio Duration Configuration
   * Control the duration range for mock audio playback (in milliseconds)
   * This helps test audio completion behavior with longer durations
   */
  mockAudioDuration: {
    min: 8000, // Minimum duration: 3 seconds
    max: 18000, // Maximum duration: 8 seconds
  },

  /**
   * Mock Audio Sample URLs
   * Sample audio files to use in mock mode instead of generated tones
   * These are placeholder URLs - replace with your own sample audio files
   */
  mockAudioUrls: {
    /**
     * Sample audio for chat TTS (Mother Savant)
     * Female voice sample
     */
    chat: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3",

    /**
     * Sample audio for Tecvali Savant thoughts
     * Female voice sample (Danielle)
     */
    tecvali:
      "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3",

    /**
     * Sample audio for Inlexzo Savant thoughts
     * Male voice sample (Matthew)
     */
    inlexzo:
      "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3",
  },

  /**
   * Thought Stream Configuration
   */
  thoughtStream: {
    /**
     * Mock Thought Stream Mode
     * When true, uses fixed mock events (10 events per savant)
     * When false, connects to real NDJSON stream APIs
     */
    mock: true,

    /**
     * Mock Thought Stream Audio Mode
     * When true, simulates TTS playback for thought streams (1-2 seconds)
     * When false, calls the real TTS API for thought stream events
     */
    mockAudio: true,

    /**
     * Thought Stream API URLs for each savant
     * These endpoints should return NDJSON (newline-delimited JSON) streams
     */
    apiUrls: {
      /**
       * Tecvali Savant thought stream endpoint
       */
      trymfya:
        "http://localhost:8000/api/v1/savant/trymfya/thoughts",

      /**
       * Inlexzo Savant thought stream endpoint
       */
      inlexzo:
        "http://localhost:8000/api/v1/savant/inlexzo/thoughts",

      /**
       * Mother Savant (chat) thought stream endpoint
       */
      mother:
        "http://localhost:8000/api/v1/savant/mother/thoughts",
    },

    /**
     * Thought Stream TTS Audio URLs for each savant
     * These endpoints should accept thought text and return audio streams
     */
    audioUrls: {
      /**
       * Tecvali Savant TTS endpoint
       * Query format: /api/v1/savant/tecvali/tts?voice=Danielle&engine=generative&format=mp3&text=<thought_text>
       */
      tecvali: {
        baseUrl: "http://127.0.0.1:8080",
        streamPath: "/api/v1/savant/tecvali/tts",
        params: {
          voice: "Danielle",
          engine: "generative",
          format: "mp3",
        },
        getQueryString(text: string): string {
          const params = new URLSearchParams({
            voice: this.params.voice,
            engine: this.params.engine,
            format: this.params.format,
            text: text,
          });
          return params.toString();
        },
        getFullUrl(text: string): string {
          return `${this.baseUrl}${this.streamPath}?${this.getQueryString(text)}`;
        },
      },

      /**
       * Inlexzo Savant TTS endpoint
       * Query format: /api/v1/savant/inlexzo/tts?voice=Matthew&engine=generative&format=mp3&text=<thought_text>
       */
      inlexzo: {
        baseUrl: "http://127.0.0.1:8080",
        streamPath: "/api/v1/savant/inlexzo/tts",
        params: {
          voice: "Matthew",
          engine: "generative",
          format: "mp3",
        },
        getQueryString(text: string): string {
          const params = new URLSearchParams({
            voice: this.params.voice,
            engine: this.params.engine,
            format: this.params.format,
            text: text,
          });
          return params.toString();
        },
        getFullUrl(text: string): string {
          return `${this.baseUrl}${this.streamPath}?${this.getQueryString(text)}`;
        },
      },
    },
  },

  /**
   * Red Sphere Click Target
   * The URL that opens in a new tab when the red sphere is clicked
   */
  redSphereLink:
    "https://www.figma.com/make/4vXRPOt3aOIYkfiaSMxSbq/ThoughtStreamCenterGlobe?node-id=0-1&p=f&t=ExdLaO0JzRLwX28C-0&fullscreen=1",
} as const;