import { config } from '../config';

/**
 * Play mock TTS audio from a sample URL
 * @param audioUrl - The URL of the sample audio file
 * @param audioType - Type of audio for logging (e.g., 'chat', 'tecvali', 'inlexzo')
 */
export async function playMockTTSFromUrl(audioUrl: string, audioType: string = 'chat'): Promise<void> {
  return new Promise((resolve, reject) => {
    try {
      console.log(`[Mock TTS] Playing sample audio from URL for ${audioType}`);
      console.log(`[Mock TTS] Audio URL: ${audioUrl}`);
      
      const audio = new Audio(audioUrl);
      audio.volume = 0.5; // Lower volume for mock audio
      
      // Use configurable duration range from config
      const { min, max } = config.mockAudioDuration;
      const mockDuration = min + Math.random() * (max - min);
      
      audio.onloadeddata = () => {
        console.log(`[Mock TTS] Audio loaded, playing for ${mockDuration.toFixed(0)}ms`);
        audio.play().catch(error => {
          console.error('[Mock TTS] Error playing audio:', error);
          reject(error);
        });
        
        // Stop audio after mock duration
        setTimeout(() => {
          audio.pause();
          audio.currentTime = 0;
          console.log('[Mock TTS] Playback complete');
          resolve();
        }, mockDuration);
      };
      
      audio.onerror = (e) => {
        console.error('[Mock TTS] Error loading audio:', e);
        reject(new Error('Failed to load mock audio'));
      };
    } catch (error) {
      console.error('Error playing mock TTS audio from URL:', error);
      reject(error);
    }
  });
}

/**
 * Play real TTS audio by calling the TTS API
 * Returns a promise that resolves when audio finishes playing
 */
export async function playRealTTS(text: string): Promise<void> {
  return new Promise(async (resolve, reject) => {
    try {
      console.log('[TTS] Calling real TTS API with text:', text.substring(0, 100) + (text.length > 100 ? '...' : ''));
      
      // Build the full URL with query parameters
      const ttsUrl = config.tts.getFullUrl(text);
      console.log('[TTS] API URL:', config.tts.url);
      console.log('[TTS] Parameters:', {
        voice: config.tts.params.voice,
        engine: config.tts.params.engine,
        format: config.tts.params.format,
        textLength: text.length
      });
      
      const response = await fetch(ttsUrl, {
        method: 'GET',
        headers: { 
          'accept': 'audio/mpeg',
        },
      });

      if (!response.ok) {
        throw new Error(`TTS API error: ${response.status} ${response.statusText}`);
      }

      // The API returns audio stream directly
      const audioBlob = await response.blob();
      const audioUrl = URL.createObjectURL(audioBlob);
      
      const audio = new Audio(audioUrl);
      audio.volume = 0.7;
      
      audio.onended = () => {
        console.log('[TTS] Playback complete');
        URL.revokeObjectURL(audioUrl);
        resolve();
      };
      
      audio.onerror = (e) => {
        console.error('[TTS] Audio playback error:', e);
        URL.revokeObjectURL(audioUrl);
        reject(e);
      };
      
      await audio.play();
      console.log('[TTS] Playing audio from API');
    } catch (error) {
      console.error('Error playing real TTS audio:', error);
      reject(error);
    }
  });
}

/**
 * Play real TTS audio for thought streams by calling the savant-specific TTS API
 * Returns a promise that resolves when audio finishes playing
 */
export async function playThoughtStreamTTS(text: string, savantKey: 'tecvali_savant' | 'inlexzo_savant'): Promise<void> {
  return new Promise(async (resolve, reject) => {
    try {
      const savantConfigKey = savantKey === 'tecvali_savant' ? 'tecvali' : 'inlexzo';
      const audioConfig = config.thoughtStream.audioUrls[savantConfigKey];
      
      console.log(`[Thought Stream TTS] Calling ${savantConfigKey} TTS API with text:`, text.substring(0, 100) + (text.length > 100 ? '...' : ''));
      
      // Build the full URL with query parameters
      const ttsUrl = audioConfig.getFullUrl(text);
      console.log(`[Thought Stream TTS] API URL: ${audioConfig.baseUrl}${audioConfig.streamPath}`);
      console.log('[Thought Stream TTS] Parameters:', {
        voice: audioConfig.params.voice,
        engine: audioConfig.params.engine,
        format: audioConfig.params.format,
        textLength: text.length,
        savant: savantConfigKey
      });
      
      const response = await fetch(ttsUrl, {
        method: 'GET',
        headers: { 
          'accept': 'audio/mpeg',
        },
      });

      if (!response.ok) {
        throw new Error(`Thought Stream TTS API error: ${response.status} ${response.statusText}`);
      }

      // The API returns audio stream directly
      const audioBlob = await response.blob();
      const audioUrl = URL.createObjectURL(audioBlob);
      
      const audio = new Audio(audioUrl);
      audio.volume = 0.6; // Slightly lower volume for thought streams
      
      audio.onended = () => {
        console.log(`[Thought Stream TTS] Playback complete for ${savantConfigKey}`);
        URL.revokeObjectURL(audioUrl);
        resolve();
      };
      
      audio.onerror = (e) => {
        console.error(`[Thought Stream TTS] Audio playback error for ${savantConfigKey}:`, e);
        URL.revokeObjectURL(audioUrl);
        reject(e);
      };
      
      await audio.play();
      console.log(`[Thought Stream TTS] Playing audio from API for ${savantConfigKey}`);
    } catch (error) {
      console.error('Error playing thought stream TTS audio:', error);
      reject(error);
    }
  });
}

/**
 * Play TTS audio - either mock or real based on config
 */
export async function playTTS(text: string, audioRef?: React.MutableRefObject<HTMLAudioElement | null>): Promise<void> {
  try {
    if (config.mockAudio) {
      // Use sample audio URL if available, otherwise use generated tone
      if (config.mockAudioUrls?.chat) {
        await playMockTTSFromUrl(config.mockAudioUrls.chat, 'chat');
      } else {
        await playMockTTS(text);
      }
    } else {
      // Stop any currently playing audio
      if (audioRef?.current) {
        audioRef.current.pause();
        audioRef.current.currentTime = 0;
      }
      
      const audio = await playRealTTS(text);
      
      // Store reference if provided
      if (audioRef) {
        audioRef.current = audio;
      }
    }
  } catch (error) {
    console.error('Error playing TTS audio:', error);
  }
}

/**
 * Play thought stream TTS audio - either mock or real based on thoughtStream.mockAudio config
 */
export async function playThoughtTTS(
  text: string, 
  savantKey: 'tecvali_savant' | 'inlexzo_savant',
  audioRef?: React.MutableRefObject<HTMLAudioElement | null>
): Promise<void> {
  try {
    if (config.thoughtStream.mockAudio) {
      // Determine which sample audio to use based on savant
      const savantConfigKey = savantKey === 'tecvali_savant' ? 'tecvali' : 'inlexzo';
      const mockAudioUrl = config.mockAudioUrls?.[savantConfigKey];
      
      // Use sample audio URL if available, otherwise use generated tone
      if (mockAudioUrl) {
        await playMockTTSFromUrl(mockAudioUrl, savantConfigKey);
      } else {
        await playMockTTS(text);
      }
    } else {
      // Stop any currently playing audio
      if (audioRef?.current) {
        audioRef.current.pause();
        audioRef.current.currentTime = 0;
      }
      
      const audio = await playThoughtStreamTTS(text, savantKey);
      
      // Store reference if provided
      if (audioRef) {
        audioRef.current = audio;
      }
    }
  } catch (error) {
    console.error('Error playing thought stream TTS audio:', error);
  }
}