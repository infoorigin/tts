/**
 * Shared Conversation Stream Manager
 *
 * Manages the flow of messages across multiple savant components
 * based on savant_key routing
 */

export interface ConversationMessage {
  savant_key: string;
  message: string;
}

/**
 * Mock conversation data - Inter-savant communication
 * Messages are displayed in sequence across the appropriate components
 */
export const mockConversation: ConversationMessage[] = [
  {
    savant_key: "tecvali_savant",
    message:
      "I have picked up a post call note from the HEM1 sales representative stating that in a recent visit to New Haven Hospital the account informed of a purchase for Inlexzo. I do not have necessary domain knowledge to address this new signal. I will need to communicate with the Inlexzo Savant. Mother Savant, please find a savant specialized for the Inlexzo brand.",
  },
  {
    savant_key: "mother_savant",
    message:
      "I have located in the COMP AI network a Savant handling orchestration for activities associated with the Inlexzo brand. It is currently in listening mode. I am sending a signal to it about this new information. Bringing the Inlexzo Savant into a call for information sharing.",
  },
  {
    savant_key: "system",
    message: "Create Inlexzo Savant",
  },
  {
    savant_key: "inlexzo_savant",
    message:
      "Hello Tecvali Savant. I have received a call note from a Hematology Sales Representative indicating that they heard a purchase for Inlexzo occurred at New Haven Hospital.",
  },
  {
    savant_key: "inlexzo_savant",
    message:
      "Thank you for this information. Looking at my records, this activity has not yet been detected in our normal data feeds, so this is a new signal for me to act on. Thank you for the insight! I have a playbook instructing me to send notifications to the Inlexzo OS, OCE, FRM, and MSL teams for account support. Do you have any additional information that may help me with these efforts?",
  },
  {
    savant_key: "inlexzo_savant",
    message:
      "This is relevant to my goals of maximizing Inlexzo adoption and best in class patient experience. Junior staff will likely struggle more to handle the side effects of my product compared to standard medications. I will ensure to prioritize the visit from my OCE with higher priority. Thank you for the information. I will now orchestrate and monitor actions for my field teams.",
  },
  {
    savant_key: "tecvali_savant",
    message:
      "I will return to listening mode according to my primary responsibilities.",
  },
  {
    savant_key: "mother_savant",
    message:
      "Thank you all. I will reach out when I need you again.",
  },
];

/**
 * Event emitter for conversation stream
 */
type ConversationListener = (
  message: ConversationMessage,
  index: number,
) => void;

type SavantCreationListener = (savantName: string) => void;

class ConversationStreamManager {
  private listeners: Map<string, Set<ConversationListener>> =
    new Map();
  private savantCreationListeners: Set<SavantCreationListener> =
    new Set();
  private isPlaying = false;
  private currentIndex = 0;
  private playbackTimer: NodeJS.Timeout | null = null;
  private playedMessages: ConversationMessage[] = [];

  /**
   * Subscribe to messages for a specific savant_key
   */
  subscribe(
    savantKey: string,
    listener: ConversationListener,
  ): () => void {
    if (!this.listeners.has(savantKey)) {
      this.listeners.set(savantKey, new Set());
    }
    this.listeners.get(savantKey)!.add(listener);

    // Return unsubscribe function
    return () => {
      const listeners = this.listeners.get(savantKey);
      if (listeners) {
        listeners.delete(listener);
      }
    };
  }

  /**
   * Subscribe to savant creation events
   */
  subscribeToSavantCreation(
    listener: SavantCreationListener,
  ): () => void {
    this.savantCreationListeners.add(listener);

    // Return unsubscribe function
    return () => {
      this.savantCreationListeners.delete(listener);
    };
  }

  /**
   * Start playing the conversation stream
   */
  start() {
    if (this.isPlaying) return;

    this.isPlaying = true;
    this.currentIndex = 0;

    // Add 2-second delay before starting to ensure all components are subscribed
    setTimeout(() => {
      this.playNext();
    }, 2000);
  }

  /**
   * Stop the conversation stream
   */
  stop() {
    this.isPlaying = false;
    if (this.playbackTimer) {
      clearTimeout(this.playbackTimer);
      this.playbackTimer = null;
    }
  }

  /**
   * Reset the conversation stream
   */
  reset() {
    this.stop();
    this.currentIndex = 0;
  }

  /**
   * Play the next message in the sequence
   */
  private playNext() {
    if (
      !this.isPlaying ||
      this.currentIndex >= mockConversation.length
    ) {
      this.isPlaying = false;
      return;
    }

    const message = mockConversation[this.currentIndex];
    const index = this.currentIndex;

    // Emit to subscribers of this savant_key
    const listeners = this.listeners.get(message.savant_key);
    if (listeners) {
      listeners.forEach((listener) => listener(message, index));
    }

    // Also emit to system subscribers (for notifications)
    if (message.savant_key === "system") {
      const systemListeners = this.listeners.get("system");
      if (systemListeners) {
        systemListeners.forEach((listener) =>
          listener(message, index),
        );
      }
    }

    // Check for savant creation pattern in system messages
    // Pattern: "Create [Name] Savant" or similar variations
    if (message.savant_key === "system") {
      const savantName = this.extractSavantName(
        message.message,
      );
      if (savantName) {
        console.log(
          `Triggering savant creation for: ${savantName}`,
        );
        this.savantCreationListeners.forEach((listener) =>
          listener(savantName),
        );
      }
    }

    this.currentIndex++;
    this.playedMessages.push(message);

    // Calculate delay based on message length for natural pacing
    // Typewriter speed: 30ms per char + 5 seconds pause between messages
    const typingTime = message.message.length * 30;
    const pauseTime = 5000; // 5 seconds in milliseconds
    const totalDelay = typingTime + pauseTime;

    this.playbackTimer = setTimeout(() => {
      this.playNext();
    }, totalDelay);
  }

  /**
   * Extract savant name from create savant message
   * Supports patterns like:
   * - "Create Inlexzo Savant"
   * - "Create savant: Inlexzo"
   * - "create Inlexzo"
   */
  private extractSavantName(message: string): string | null {
    const lowerMessage = message.toLowerCase();

    // Pattern 1: "Create [Name] Savant"
    const pattern1 = /create\s+(\w+)\s+savant/i;
    const match1 = message.match(pattern1);
    if (match1) {
      return match1[1];
    }

    // Pattern 2: "Create savant: [Name]"
    const pattern2 = /create\s+savant:?\s+(\w+)/i;
    const match2 = message.match(pattern2);
    if (match2) {
      return match2[1];
    }

    // Pattern 3: "Create [Name]" (if message starts with create and has only 2 words)
    const pattern3 = /^create\s+(\w+)$/i;
    const match3 = message.match(pattern3);
    if (match3) {
      return match3[1];
    }

    return null;
  }

  /**
   * Check if currently playing
   */
  isCurrentlyPlaying(): boolean {
    return this.isPlaying;
  }

  /**
   * Get current playback position
   */
  getCurrentIndex(): number {
    return this.currentIndex;
  }
}

// Singleton instance
export const conversationStream =
  new ConversationStreamManager();